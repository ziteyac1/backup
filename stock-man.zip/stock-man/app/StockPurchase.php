<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StockPurchase extends Model
{
    protected $guarded = [];

    public function category()
    {
        return $this->belongsTo(Category::class, 'item_category','id');
    }
    public function inventory()
    {
        return $this->belongsTo(Inventory::class,'inventory_id','id');
    }
}
