<?php
/** @noinspection ClassNameCollisionInspection */

namespace App;

use App\core\model\ModelAttributeCommons;
use App\filters\core\HasModelFilter;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use OwenIt\Auditing\Contracts\Auditable;
use Spatie\Permission\Traits\HasRoles;

/**
 * @property string $name
 * @property string $role
 * @property string $email
 * @property string $avatar_name
 * @property Carbon $created_at
 * @property mixed $last_name
 * @property mixed $full_name
 * @property mixed $id
 * @property Carbon $updated_at
 * @property mixed roles
 * @property \Illuminate\Database\Eloquent\Collection permissions
 */
class User extends Authenticatable implements Auditable
{
    use Notifiable , HasModelFilter , HasRoles , \OwenIt\Auditing\Auditable , Notifiable ,
        ModelAttributeCommons;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    protected $fillable = [
        'name', 'email', 'password','last_name','status'
    ];

    protected $appends = [
      'role','avatar_name','last_update' ,'full_name'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    protected $auditExclude = [
        'password'
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];


    /**
     * @return string
     */
    public function getLastUpdateAttribute() : string
    {
        return $this->updated_at->diffForHumans();
    }

    /**
     * @return string
     */
    public function getAvatarNameAttribute() : string
    {
        return strtoupper(substr($this->name , 0 ,  1 ))
            . strtoupper(substr($this->last_name , 0 ,  1 ));
    }

    public function request(){
        return $this->hasMany(StockRequest::class,'user_id','id');
    }


    /**
     * @return string
     */
    public function getFullNameAttribute() : string
    {
        return ucwords($this->name) . ' '. ucwords($this->last_name);
    }


    /**
     * @return string
     */
    public function getRoleAttribute() : string
    {
        $roles = $this->getRoleNames();
        if (count($roles))
        {
            return ucwords($roles[0]);
        }
        return 'default';
    }

}
