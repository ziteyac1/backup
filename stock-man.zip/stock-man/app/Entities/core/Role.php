<?php /** @noinspection ClassNameCollisionInspection */


namespace App\Entities\core;


use App\Application;
use App\filters\core\HasModelFilter;
use Carbon\Carbon;
use OwenIt\Auditing\Contracts\Auditable;

/**
 * @property mixed id
 * @property mixed name
 * @property Carbon created_at
 * @property mixed guard_name
 */
class Role extends \Spatie\Permission\Models\Role implements Auditable
{
      use HasModelFilter , \OwenIt\Auditing\Auditable;

      protected $appends = [
          'avatar_name' , 'select_name'
      ];

        /**
         * @return string
         */
        public  function getAvatarNameAttribute()
        {
          return strtoupper(substr($this->name , 0, 1 ));
        }

        /**
         * @return string
         */
        public function getSelectNameAttribute() : string
        {
            return $this->name;
        }
}
