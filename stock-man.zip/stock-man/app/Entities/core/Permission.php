<?php /** @noinspection ClassNameCollisionInspection */


namespace App\Entities\core;


use App\Application;
use App\filters\core\HasModelFilter;

/**
 * @property mixed name
 * @property mixed guard_name
 */
class Permission extends \Spatie\Permission\Models\Permission
{
    use HasModelFilter;

    protected $appends = [
      'avatar_name' , 'select_name'
    ];

    /**
     * @return string
     */
    public function getAvatarNameAttribute()
    {
        return strtoupper(substr($this->name , 0 , 1));
    }

    /**
     * @return string
     */
    public function getSelectNameAttribute() : string
    {
        return $this->name;
    }
}
