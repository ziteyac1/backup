<?php

namespace App\Exports;

use App\Inventory;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Events\AfterSheet;

class InventoryExport implements FromCollection, WithHeadings, ShouldAutoSize
{
    use Exportable;
    protected $inventory;

    public function __construct($inventory)
    {
        $this->inventory = $inventory;
    }

    /**
     * @return \Illuminate\Support\Collection
     */
    public function collection()
    {
        return $this->inventory;
    }
    public function headings(): array
    {
        return ['Item Code','Item Category','Description','Available Quantity','Unit Cost','Total Cost'];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class=>function(AfterSheet $event)
            {
                $cellRange = 'A1:H1';
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->getSize(12);
            },
        ];
    }
}
