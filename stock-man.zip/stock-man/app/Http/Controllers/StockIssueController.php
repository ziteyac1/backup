<?php

namespace App\Http\Controllers;

use App\Category;
use App\CostCenter;
use App\Inventory;
use App\StockDistribution;
use App\StockIssue;
use App\StockRequest;
use App\Timeline;
use Illuminate\Http\Request;

class StockIssueController extends Controller
{
    public function index()
    {
        $stock_requests = StockDistribution::query()->select()->paginate(25);

        if (\request()->has('go'))
        {
            $stock_requests = StockDistribution::query()->select()
                ->where('location_id','=',\request('location'))
                ->orWhere('item_code','=',\request('search'))
                ->paginate(25);
        }

        if (\request()->has('run') && \request()->has('location'))
        {
            $name =    "storage/inventory/distributions/".auth()->user()->email . '-' . now()->format('Y-m-d-H-i-s') . '-' . random_int( 10 , 99 )  . '.csv';
            $output = fopen(public_path($name) , 'w+');

            fwrite($output , "Item Code, Description, Quantity Issue, Unit Cost, Total Cost, Date Issued".PHP_EOL);

            foreach ($stock_requests as $dist)
            {
                $total = $dist->quantity * $dist->inventory->cost_unit;
                fwrite($output , "{$dist->inventory->item_code},{$dist->inventory->description},{$dist->quantity},{$dist->inventory->cost_unit},{$total},{$dist->created_at}".PHP_EOL);
            }

            fclose($output);

            return response()->download(public_path($name));
        }

        $centres = CostCenter::all();

        return view('stock_issues.issue',['stock_requests'=>$stock_requests,'centres'=>$centres]);
    }

    public function create()
    {
        $locations = CostCenter::all();
        $items = Inventory::all();
        return view('stock_issues.request',['locations'=>$locations,'items'=>$items]);
    }

    public function store(Request $request)
    {
        $this->validate($request,[
           'item_code' => ['required','exists:inventories,item_code'],
           'quantity' => ['required','numeric'],
           'location_id' => 'required',
        ]);

        $item = Inventory::query()->select()->where('item_code',$request->item_code)->first();

        if ($item->quantity < $request->quantity)
        {
            return back()->with('error','Not enough '.$item->description.' in stock. Available is '.$item->quantity);
        }

        $issue = StockDistribution::query()->create([
            'item_code' => $request->item_code,
            'quantity' => $request->quantity,
            'location_id' => $request->location_id,
            'issuer_id' => auth()->user()->id,
        ]);

        $new_total = $item->quantity - $issue->quantity;

        $new_cost = $item->cost_unit * $new_total;

        Inventory::query()
            ->where('item_code',$issue->item_code)
            ->update([
                'quantity' => $new_total,
                'total_cost' => $new_cost,
            ]);

        $message = auth()->user()->fullname." distributed, ".$request->quantity." ".$item->description." to ".$issue->location->location_name;

        $this->create_timeline($message);

        return back()->with('message','Stock Issue Successful');

    }
    public function create_timeline($message){
        return Timeline::query()->create([
            'user_id' => auth()->user()->id,
            'email' => auth()->user()->email,
            'activity_description' => $message,
            'location_id' => auth()->user()->location_id,
        ]);
    }
}
