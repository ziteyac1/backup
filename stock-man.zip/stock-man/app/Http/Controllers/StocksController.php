<?php

namespace App\Http\Controllers;

use App\Category;
use App\Charts\InventoryChart;
use App\Inventory;
use App\StockPurchase;
use App\StockRequest;
use App\Timeline;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StocksController extends Controller
{
    public function index(){
        $stock_items = Inventory::query()->select()->paginate(25);

        if (\request()->get('search') || \request()->get('start_date') || \request()->get('end_date'))
        {
            $search = \request('search');
            $stock_items = Inventory::query()->select()
                ->where('item_category' , 'LIKE','%'.$search.'%')
                ->orWhere('description','LIKE','%'.$search .'%')
                ->paginate(25);
        }

        $categories = Category::all();
        $timelines = Timeline::query()->select()->paginate(25);
        return view('stocks.index',[
            'stock_items'=>$stock_items,
            'categories'=>$categories,
            'timelines'=>$timelines
        ]);
    }
    public function create(){
        $categories = Category::all();
        return view('stocks.add_new',['categories'=>$categories]);
    }

    public function chart()
    {
        $stocks = Inventory::all();

        return response()->json($stocks);
    }

    public function stock_category_view($id)
    {
        $cat_name = Category::find($id);

        $stock_category = Inventory::query()->where('item_category','=',$id)->select()->paginate(25);

        if (\request('search'))
        {
            $request = \request('search');

            $stock_category = Inventory::query()->select()
                ->where('item_category','=',$id)
                ->where(function (Builder $builder) use ($request) {
                    $builder->orWhere('item_code','LIKE','%'.$request.'%');
                    $builder->orWhere('description','LIKE','%'.$request.'%');
                })->paginate(25);
        }

        $item_code = [];
        $item_quantity = [];
        $item_minimum = [];

        $inventory_chart = new InventoryChart();

        foreach ($stock_category as $inv)
        {
            $item_code[] = $inv->item_code;
            $item_minimum[] = $inv->minimum_quantity;
            $item_quantity[] = $inv->quantity;
        }

        $inventory_chart->labels($item_code);

        $inventory_chart->title('Inventory Items');


        $inventory_chart->dataset('Quantity','bar',$item_quantity)->options([
            'fill' => 'true',
            'backgroundColor' => '#367D97',
            'barThickness' => 'flex',
        ]);

        $inventory_chart->dataset('Minimum Quantity','line',$item_minimum)->options([
            'fill' => 'true',
            'borderColor' => '#AD6C79',
            'backgroundColor' => 'red',
            'gridLines' => false,
        ]);


        return view('stocks.view',['stock_category'=>$stock_category,'cat_name'=>$cat_name,'inventory_chart'=>$inventory_chart]);
    }

    public function view($id)
    {
        $item = Inventory::find($id);

        return view('stocks.view_item',['item'=>$item]);
    }

    public function add_request(Request $request){
        $this->validate($request,[
            'item_category' => 'required',
            'item_code' => 'required',
            'quantity' => 'required|numeric'
        ]);

        $user = auth()->user();

        $stock_request = StockRequest::query()->create([
            'user_id' => $user->id,
            'email' => $user->email,
            'location' => $user->location_id,
            'item_category' => $request->item_category,
            'item_code' => $request->item_code,
            'quantity' => $request->quantity,
        ]);

        $message = "Added ".$request->description." stock items";

        $this->create_timeline($message);

        return back()->with('message',"Request Submitted");


    }
    public function update($id,Request $request)
    {
        $this->validate($request,[
            'quantity' => 'numeric',
            'cost_unit' => 'numeric',
            'total_cost' => 'numeric',
        ]);

        Inventory::query()
            ->where('id','=',$id)
            ->update([
                'description' => $request->description,
                'quantity' => $request->quantity,
                'cost_unit' => $request->cost_unit,
                'total_cost' => $request->total_cost,
            ]);

        return back()->with('message',"Stock Updated");
    }

    public function create_timeline($message){
        return Timeline::query()->create([
            'user_id' => auth()->user()->id,
            'email' => auth()->user()->email,
            'activity_description' => $message,
            'location_id' => auth()->user()->location_id,
        ]);
    }

    public function downloadCategoryItems($id)
    {
        $inventories = Inventory::query()->where('item_category','=',$id)->select()->get();

        $name =   "storage/inventory/category/".auth()->user()->email . '-' . now()->format('Y-m-d-H-i-s') . '-' . random_int( 10 , 99 )  . '.csv';
        $output = fopen(public_path($name) , 'w+');

        fwrite($output , "Item Category, Item Code, Description, Quantity, Unit Price, Total Cost".PHP_EOL);

        foreach ($inventories as $inventory)
        {
            fwrite($output , "{$inventory->category->name},{$inventory->item_code},{$inventory->description},{$inventory->quantity},{$inventory->cost_unit},{$inventory->total_cost}".PHP_EOL);
        }

        fclose($output);

        return response()->download(public_path($name));
    }


    public function store(Request $request){

        $this->validate($request,[
            'item_category'  => 'required',
            'item_code'  => 'required|unique:inventories',
            'description'  => 'required',
            'quantity'  => 'required|numeric',
            'total_cost'  => 'required|numeric',
            'cost_unit'  => 'required|numeric',
            'minimum_quantity' => 'required|numeric'
        ]);

        $stock_item = new Inventory();

        $stock_item->item_category = $request->item_category;
        $stock_item->item_code = $request->item_code;
        $stock_item->description = $request->description;
        $stock_item->quantity = $request->quantity;
        $stock_item->total_cost = $request->total_cost;
        $stock_item->cost_unit = $request->cost_unit;
        $stock_item->minimum_quantity = $request->minimum_quantity;
        $stock_item->save();

        $message = "Added ".$request->description." stock items";

        $this->create_timeline($message);

        return back()->with('message',"Data Saved");

    }

}
