<?php

namespace App\Http\Controllers;

use App\Category;
use App\Inventory;
use App\StockPurchase;
use App\Timeline;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public function index()
    {
        $stock_categories = Inventory::query()->select('item_category',DB::raw('count(item_code) as total_items'))->groupBy('item_category')->get();

        $stock_depleted = Inventory::query()->select()->whereColumn('quantity','<=','minimum_quantity')->paginate(10);

        $stock_updates = Inventory::query()->select()->latest('updated_at')->limit(10)->orderBy('updated_at','desc')->get();

        $purchases = StockPurchase::all();

        if (\request()->get('category') || \request()->get('start_date') || \request()->get('end_date') || \request()->has('run'))
        {
            $purchases = StockPurchase::query()->select()
                ->whereBetween('purchase_date',array(\request()->get('start_date'),\request()->get('end_date')))
                ->paginate(25);
        }

        $timelines = Timeline::all();

        $categories = Category::all();

        return \view('reports.index',
            [
                'stock_categories'=>$stock_categories,
                'stock_depleted'=>$stock_depleted,
                'timelines'=>$timelines,
                'stock_updates' => $stock_updates,
                'purchases' => $purchases,
                'categories' => $categories
            ]);
    }
}
