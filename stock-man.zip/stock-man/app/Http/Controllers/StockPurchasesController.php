<?php

namespace App\Http\Controllers;

use App\Category;
use App\Charts\PurchasesTrendChart;
use App\Inventory;
use App\StockPurchase;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StockPurchasesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\View\View|\Symfony\Component\HttpFoundation\BinaryFileResponse
     */
    public function index()
    {
        $purchases = StockPurchase::query()->select()->paginate(25);

        if (\request()->get('search') || \request()->get('start_date') || \request()->get('end_date'))
        {
            $purchases = StockPurchase::query()->select()
                ->where('supplier_name','LIKE', '%'.\request()->get('search').'%')
                ->orWhere('grn_number','LIKE', '%'.\request()->get('search').'%')
                ->orWhereBetween('purchase_date',array(\request()->get('start_date'),\request()->get('end_date')))
                ->paginate(25);

        }

        if (\request()->has('run'))
        {
            $name =    "storage/inventory/purchases/".auth()->user()->email . '-' . now()->format('Y-m-d-H-i-s') . '-' . random_int( 10 , 99 )  . '.csv';
            $output = fopen(public_path($name) , 'w+');

            fwrite($output , "Item Code, Description, GRN Number, Purchase Date, Supplier, Quantity, Unit Price, Total Cost".PHP_EOL);

            foreach ($purchases as $purchase)
            {
                fwrite($output , "{$purchase->inventory->item_code},{$purchase->inventory->description},{$purchase->grn_number},{$purchase->purchase_date},{$purchase->supplier_name},{$purchase->purchase_quantity},{$purchase->amount},{$purchase->purchase_total_cost}".PHP_EOL);
            }

            fclose($output);

            return response()->download(public_path($name));
        }

        $trend_chart = new PurchasesTrendChart();

        $purch_date = [];
        $purch_total = [];
        $purch_item = [];
        $purch_quantity = [];

        foreach ($purchases as $purchase)
        {
            $purch_item[] = $purchase->item_code;
            $purch_date[] = $purchase->purchase_date;
            $purch_total[] = $purchase->purchase_total_cost;
            $purch_quantity[] = $purchase->purchase_quantity;
        }

        $trend_chart->labels($purch_date,$purch_item);

        $trend_chart->dataset('Quantity','line',$purch_quantity);

        $trend_chart->dataset('Purchases','line',$purch_total);

        return view('stocks.purchases',['purchases'=>$purchases,'trend_chart'=>$trend_chart]);
    }

    public function view_grn($id)
    {
        $purchase = StockPurchase::query()->select()->where('grn_number','=',$id)->paginate(10);

        return view('stocks.view_grn',['purchase'=>$purchase,'id'=>$id]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function create()
    {
        $categories = Category::all();
        return view('stocks.add_stock_purchase',['categories'=>$categories]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'item_category' => 'required',
            'item_code' => 'required|unique:inventories',
            'quantity' => 'required|numeric',
            'description' => 'required',
            'grn_number' => 'required|numeric',
            'supplier_name' => 'required',
            'cost_unit' => 'required|numeric',
            'purchase_date' => 'required',

        ]);

        $inventory = Inventory::query()->create([
            'item_category' => $request->item_category,
            'item_code' => $request->item_code,
            'description' => $request->description,
            'quantity' => $request->quantity,
            'cost_unit' => $request->cost_unit,
            'total_cost' => $request->total_cost,
        ]);

        StockPurchase::query()->create([
            'inventory_id' => $inventory->id,
            'grn_number' => $request->grn_number,
            'supplier_name' => $request->supplier_name,
            'purchase_quantity' => $request->quantity,
            'amount' => $request->cost_unit,
            'purchase_total_cost' => $request->total_cost,
            'purchase_date' => $request->purchase_date,
        ]);

        return back()->with('message',"Stock Updated");
    }

    public function stock_update(Inventory $stock_item){
        $stock_item = Inventory::find($stock_item->id);
        return view('stocks.update_stock_purchase',['stock_item'=>$stock_item]);
    }

    public function update_stock(Request $request,$id){

        $this->validate($request,[
            'quantity' => 'required|numeric',
            'grn_number' => 'required|numeric',
            'supplier_name' => 'required',
            'cost_unit' => 'required|numeric',
            'purchase_date' => 'required',

        ]);

        $current_bal = Inventory::find($id);

        Inventory::query()
            ->where('id','=',$id)
            ->update([
                'quantity'=>$request->quantity + $current_bal->quantity,
                'total_cost' =>$request->total_cost + $current_bal->total_cost,
            ]);

        StockPurchase::query()->create([
            'inventory_id' => $id,
            'grn_number' => $request->grn_number,
            'supplier_name' => $request->supplier_name,
            'purchase_quantity' => $request->quantity,
            'amount' => $request->cost_unit,
            'purchase_total_cost' => $request->total_cost,
            'purchase_date' => $request->purchase_date,
        ]);

        return back()->with('message',"Stock Updated");
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function show($id)
    {
        $purchase =  Inventory::query()->select()->where('inventory_id','=',$id)->join('stock_purchases','inventories.id','=','stock_purchases.inventory_id')->first();

        return view('stocks.view_purchase',['purchase'=>$purchase,'id'=>$id]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
