<?php

namespace App\Http\Controllers;

use App\Application;
use App\Charts\CategoriesChart;
use App\Charts\InventoryChart;
use App\Inventory;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;
use Illuminate\Support\Str;

class HomeController extends Controller
{
    /**
     * @return RedirectResponse|Redirector
     */
    public function landing()  : RedirectResponse
    {
        return redirect('/login');
    }

    /**
     * @return Factory|RedirectResponse|Redirector|View
     */
    public function home()
    {
        //return redirect('/stocks/index');
        $stock_categories = Inventory::query()->select('item_category',DB::raw('count(item_code) as total_items'))->groupBy('item_category')->get();

        $data = [];

        $inventory_category = Inventory::query()
            ->select('item_category',DB::raw('count(item_code) as total_items'))
            ->join('categories','categories.id','=','inventories.item_category')
            ->groupBy('item_category')
            ->get();


        $labels = [];

        $count = [];

        $chart = new CategoriesChart();

        foreach ($inventory_category as $item => $value)
        {

            $labels[] = Str::limit($value->category->name,20,'...');

            $count[] = $value->total_items;

        }


        $chart->labels($labels);

        $chart->title('Stock Categories');

        $chart->dataset('Category','horizontalBar',$count)
            ->options([
            'fill' => 'true',
            'borderColor' => '#51C1C0',
            'backgroundColor' => '#00B1ED',
            'barThickness' => 3,
        ]);


        return \view('dashboard.home',
            [
                'stock_categories'=>$stock_categories,
                'chart' => $chart,
            ]);
    }
}
