<?php

namespace App\Http\Controllers;

use Illuminate\Contracts\View\Factory;
use Illuminate\Http\Request;
use Illuminate\View\View;

class AppController extends Controller
{
    /**
     * @return Factory|View
     */
    public function users() : View
    {
        return view('apps.users');
    }

    /**
     * @return Factory|View
     */
    public function profile() : View
    {
        return view('apps.profile');
    }

    /**
     * @return Factory|View
     */
    public function properties() : View
    {
        return view('apps.home');
    }
}
