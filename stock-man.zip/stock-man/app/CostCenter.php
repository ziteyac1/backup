<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CostCenter extends Model
{
    public function stock_request(){
       return $this->hasMany(StockRequest::class,'location','id');
    }
}
