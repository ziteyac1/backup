<?php

namespace App;

use Illuminate\Database\Eloquent\Concerns\HasRelationships;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class StockDistribution extends Model
{
    use SoftDeletes;
    use HasRelationships;
    protected $guarded = [];

    public function location()
    {
        return $this->belongsTo(CostCenter::class,'location_id','id');
    }

    public function issuer(){
        return$this->belongsTo(User::class,'issuer_id','id');
    }

    public function inventory(){
        return $this->belongsTo(Inventory::class, 'item_code','item_code');
    }
}
