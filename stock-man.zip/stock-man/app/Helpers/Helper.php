<?php
use App\core\api\response\Response;

if (!function_exists('api'))
{
    function api(){
        return new Response();
    }
}
