<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property  email
 * @property  user_id
 * @property int location
 */
class StockRequest extends Model
{
    protected $guarded = [];
    public function cost_center(){
        return $this->belongsTo(CostCenter::class,'location','id');
    }

    public function user_request(){
        return$this->belongsTo(User::class,'user_id','id');
    }

    public function inventory(){
        return $this->belongsTo(Category::class, 'item_category','id');
    }
}
