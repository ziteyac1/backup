<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Inventory extends Model
{
    protected $guarded=[];

    public function category(){
        return $this->belongsTo(Category::class, 'item_category','id');
    }
    public function purchase()
    {
        return $this->hasMany(StockPurchase::class, 'item_code','item_code');
    }
}
