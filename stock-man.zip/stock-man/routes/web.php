<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Http\Controllers\CostCenterController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\StockIssueController;
use App\Http\Controllers\StockPurchasesController;
use App\Http\Controllers\StocksController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

// Authentication Routes

Auth::routes([
    'register' => false,
    'verify' => false,
    "reset" => false,
]);

// Landing Page

Route::get('/', [HomeController::class , 'landing']);

// Auth Guard

Route::middleware('auth')->group(function (){
    Route::get('/home', [HomeController::class , 'home']);
    Route::get('/stocks/index',[StocksController::class,'index'])->name('stocks.index');
    Route::get('/stocks/{id}/view',[StocksController::class,'view'])->name('stocks.view');
    Route::get('/stocks/add_new',[StocksController::class, 'create'])->name('stocks.add_new');
    Route::get('/stocks/issue',[StocksController::class, 'stock_issue'])->name('stocks.issue');
    Route::get('/stocks/request',[StocksController::class, 'stock_request'])->name('stocks.request');
    Route::post('/stocks/add_request',[StocksController::class, 'add_request']);
    Route::post('/stocks/add_items',[StocksController::class, 'store']);
    Route::post('/stocks/{id}/update',[StocksController::class, 'update']);
    Route::get('/stocks/category/{id}/view',[StocksController::class,'stock_category_view'])->name('stocks.view');
    Route::get('/stocks/category/{id}/download',[StocksController::class,'downloadCategoryItems']);
    Route::get('/stocks/download',[StocksController::class,'download_stocks']);
    Route::get('/stocks/upload/batch',[StocksController::class,'upload_stocks']);
    Route::get('/stocks/chart',[StocksController::class,'chart']);


    Route::get('/stocks/purchases',[StockPurchasesController::class, 'index'])->name('stocks.purchases');
    Route::get('/stocks/purchase/add',[StockPurchasesController::class, 'create'])->name('stocks.add_stock_purchase');
    Route::post('/stocks/add_purchase/add',[StockPurchasesController::class, 'store']);
    Route::get('/stocks/purchases/{id}/view_purchase',[StockPurchasesController::class,'show'])->name('stocks.view_purchase');
    Route::get('/stocks/purchases/{id}/view_grn',[StockPurchasesController::class,'view_grn'])->name('stocks.view_grn');
    Route::get('/stocks/{id}/add_purchase',[StockPurchasesController::class, 'stock_update'])->name('stocks.update_stock_purchase');
    Route::post('/stocks/{id}/update_purchase',[StockPurchasesController::class, 'update_stock']);

    Route::get('/stocks/issues',[StockIssueController::class,'index'])->name('stock_issues.index');
    Route::get('/stocks/issue/new',[StockIssueController::class,'create'])->name('stock_issues.request');
    Route::post('/stocks/issue/new',[StockIssueController::class,'store']);

    Route::get('/stocks/reports',[ReportController::class,'index'])->name('reports.index');
    Route::get('/cost_center/index',[CostCenterController::class, 'index'])->name('cost_center.index');
});

