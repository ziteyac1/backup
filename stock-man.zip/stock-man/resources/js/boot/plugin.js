import { Plugin } from 'vue-fragment';
import Vue from "vue";
Vue.use(Plugin);
