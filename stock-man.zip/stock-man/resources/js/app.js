/**
 * Import Vue for application
 */
import Vue from "vue";

/**
 * Import routes for the vue routing engine
 */
import router from "./routes/routes";

/**
 * Load necessary components
 * For the application
 * Axios => making ajax requests in the background
 * Alerts => Sweet alerts attached to the window variables
 * Filters => Vue filters
 * Helpers => Helper functions for the application
 * Socket => Setting up socket io and laravel echo
 */
require('./boot/axios');
require('./boot/alerts');
require('./boot/filters');
require('./boot/helpers');
require('./boot/plugin');
require('./boot/socket');

/**
 * Icon
 */

import {
    PlusCircleIcon , UsersIcon , UserPlusIcon ,
    UserCheckIcon, UserIcon , EditIcon , LockIcon ,
    ClockIcon , BellIcon , ColumnsIcon , CommandIcon , TagIcon ,
    FolderIcon ,
} from "vue-feather-icons";

/**
 * Auth components
 */

const Login  = () => import(/* webpackChunkName: "js/auth" */"./components/auth/Login");

// Vue instance

window.vue = new Vue({
    router : router,
    components : {
        Login , PlusCircleIcon ,
        UsersIcon , UserPlusIcon , UserCheckIcon ,
        EditIcon , UserIcon , LockIcon , ClockIcon , FolderIcon ,
        BellIcon   , ColumnsIcon , CommandIcon ,
        TagIcon

    },
    el: '#app',
    methods : {
        logout : function () {
            document.getElementById('logout-form').submit();
        }
    }
});

