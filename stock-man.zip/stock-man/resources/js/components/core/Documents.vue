<!--suppress ALL -->

<template>
    <div  class="filemgr-content-body">
        <div style="" :class="['dimmer' , data.loading ? '' : '' ]">
            <div class="loader"></div>
            <div class="dimmer-content">
                <div style="position: relative">
                    <div :class="['timeline-filters' , filterPanel ? 'timeline-filters-open' : '']">
                        <div style="font-size: 18px;height: 55px;padding: 0 20px" class="d-flex justify-content-between align-items-center border-bottom">
                            <span>Filters</span>
                            <x-icon @click="closeFilterPanel"/>
                        </div>
                        <div class="filemgr-content-filters-content">
                            <div class="card-body">
                                <div  class="form-row">
                                    <div  class="form-group col-md-8">
                                        <label for="order-by-filter-field" class="col-form-label">Order By</label>
                                        <select v-model="data.sort.field" id="order-by-filter-field" class="form-control">
                                            <option :value="item" :key="`sort-value-key-${item.field}`" v-for="item in data.sortFields">{{ item.read }}</option>
                                        </select>
                                    </div>
                                    <div  class="form-group col-md-4">
                                        <label for="order-by-filter-direction" class="col-form-label">Direction</label>
                                        <select v-model="data.sort.value" id="order-by-filter-direction" class="form-control">
                                            <option  value="Asc">ASC</option>
                                            <option  value="Desc">DESC</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group" :key="`key-filter-fields-${item.field}`" v-for="item in data.filterFields">
                                    <label for="inputState" class="col-form-label">{{ item.read }}</label>
                                    <select v-model="data.filterForm.filters[item.field]" id="inputState" class="form-control">
                                        <option :key="`key-filter-fields-value-${i.value}-${item.field}`" :value="i" v-for="i in item.filter">{{ i.read }}</option>
                                    </select>
                                </div>
                                <div class="form-group" :key="`key-range-fields-${item.field}`" v-for="item in data.rangeFields">
                                    <label>{{ item.read }} </label>
                                    <div class="d-flex">
                                        <!--suppress HtmlFormInputWithoutLabel -->
                                        <input v-model="data.filterForm.ranges.min[item.field]" :type="[item.date ? 'date' : 'text']" placeholder="Min" class="form-control d-inline-block ">
                                        <span class="d-inline-block text-center text-muted mx-2"><i class="mdi mdi-window-minimize"/></span>
                                        <!--suppress HtmlFormInputWithoutLabel -->
                                        <input v-model="data.filterForm.ranges.max[item.field]" :type="[item.date ? 'date' : 'text']" placeholder="Max" class="form-control d-inline-block ">
                                    </div>
                                </div>
                            </div>
                            <div class="border-top text-center card-body">
                                <button @click="runFilters" class="btn btn-sm pd-x-15 btn-white btn-uppercase mr-3"><i class="fa fa-filter wd-10 mg-r-5"/> Filter </button>
                            </div>
                        </div>
                    </div>
                    <div style="height: 55px;padding: 0 20px;" class="border-bottom d-flex align-items-center">
                        <h6 class="mb-0 tx-uppercase mr-3">{{ name }}</h6>
                        <div class="search-form mr-auto d-flex align-items-center border-left border-right mr-3 px-3">
                            <search-icon class="" size="16"/>
                            <!--suppress HtmlFormInputWithoutLabel -->
                            <input v-model="data.search" type="text" class="form-control border-0" placeholder="Search..">
                        </div>
                        <div  class="d-flex align-items-center mr-2 tx-12">
                            <span class="mr-3"> Showing {{ data.content.data.length }} of {{ data.content.total }} Records </span>
                            <span class="border border-secondary py-1 px-2 rounded mr-auto">Sorted By  : <strong> {{ data.sort.field.read }} </strong> , {{ data.sort.value }} </span>
                        </div>
                        <button @click="data.fetch()"  :class="['tx-uppercase btn btn-white btn-sm mr-2' , data.loading ? 'btn-loading' :'']">
                            <refresh-ccw-icon class="mr-1"/> Refresh
                        </button>
                        <button @click="openFilterPanel"  :class="['tx-uppercase btn btn-white btn-sm' , data.loading ? 'btn-loading' :'']">
                            <filter-icon class="mr-1"/> Filter
                        </button>
                    </div>
                    <div style="padding: 15px" class="border-bottom">
                        <div class="large-12 medium-12 small-12 filezone">
                            <input type="file" id="files" ref="files" multiple @change="handleFiles()" accept=".xls,.xlsx,.csv,.docx,.doc,.pdf"/>
                            <p>
                                Drop your documents here <br> or click to select
                            </p>
                        </div>
                        <div v-for="(file, key) in files"  :class="['dimmer' , file.id === 3 ? 'active' : '']">
                            <div class="loader"></div>
                            <div class="dimmer-content">
                                <div class="file-listing border-bottom">
                                    <img class="preview" :ref="'preview'+parseInt(key)"/>
                                    <span class="text-muted">{{ file.name }}</span>
                                    <div class="success-container" v-if="file.id === 1">
                                        Success
                                    </div>
                                    <div class="error-container" v-else-if="file.id === 2">
                                        Error
                                    </div>
                                    <div class="remove-container" v-else>
                                        <button class="btn btn-icon btn-danger btn-sm" @click="removeFile(key)">
                                            <trash-icon/>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div v-if="close" class="d-flex align-items-center justify-content-center p-4">
                            <button class="btn btn-white px-5" @click="reset">
                                <x-icon class="mr-2"/> Close
                            </button>
                        </div>
                        <div v-if="upload" class="d-flex align-items-center justify-content-center p-4">
                            <button :class="['btn btn-white px-5' , loading ? 'btn-loading' : '']" @click="submitFiles">
                               <upload-icon class="mr-2"/> Upload
                            </button>
                        </div>
                    </div>
                    <div v-if="data.filters.length > 0 || data.ranges.length > 0 " class="px-2 py-2 filters-container tx-12 border-bottom">
                        <span class="ml-2" :key="`filters-${index}`" v-for="(item, index) in data.filters" >
                            <span class="border border-secondary py-2 px-2 rounded-left">{{ item.field.read }} : <strong > {{ item.value.read }} </strong></span>
                            <span @click="data.removeFilter(index)" class="border-top border-bottom border-right border-secondary text-muted  py-2 px-2 rounded-right" style="cursor: pointer;"><x-icon size="15"/></span>
                        </span>
                        <span :key="`ranges-${index}`" class="ml-2" v-for="(item, index) in data.ranges">
                            <span class="border border-secondary py-2 px-2 rounded-left"> {{ item.field.read }} : <strong> {{ item.min }} - {{ item.max }} </strong></span>
                            <span @click="data.removeRange(item)" class="border-top border-bottom border-right border-secondary text-muted  py-2 px-2 rounded-right" style="cursor: pointer;"><x-icon size="15"/></span>
                        </span>
                    </div>
                    <div class="container">
                        <div class="row mt-4">
                            <div :key="item.id" v-for="item in data.content.data" class="col-lg-4">
                                <div class="card mt-4 rounded-0">
                                    <div style="height: 160px" class="border-bottom d-flex align-items-center justify-content-center">
                                        <img :src="item.thumbnail" style="height: 90px;width: 90px" alt="">
                                    </div>
                                    <div class="card-body">
                                        <div class="tx-11">
                                            <div><strong>{{ item.name }}</strong></div>
                                            <div class="text-muted">{{ item.user.email }}  | <strong>  {{ item.user.full_name }} </strong></div>
                                            <div class="text-muted">{{ item.created_at }}  | <strong>  {{ Math.round(item.size / 1024) }} kb </strong></div>
                                        </div>
                                        <div class="d-flex justify-content-between mt-3 tx-11">
                                            <a :href="`/documents/${item.id}/download`" target="_blank" :class="['btn btn-sm btn-white bnt-icon' , data.loading ? 'btn-loading' : '']">
                                                <download-icon/>
                                            </a>
                                            <button @click="remove(item)" :class="['btn btn-sm btn-white bnt-icon' , data.loading ? 'btn-loading' : '']">
                                                <trash-icon/>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center py-5">
                        <button @click="data.append()" v-if="data.content.total !== data.content.to && data.content.data.length > 0" :class="['btn btn-white btn-sm' , data.loading ? 'btn-loading' :'']">
                            <arrow-down-icon class="mr-1"/> Load More
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { FilterIcon , XIcon , ArrowDownIcon , RefreshCcwIcon ,
        SearchIcon , UploadIcon , TrashIcon , DownloadIcon  } from 'vue-feather-icons'
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    import DataHandler from "../../core/data/DataHandler";
    export default {
        props : ['url' , 'name'],
        mounted : function (){
            new PerfectScrollbar('.filemgr-content-filters-content', {
                suppressScrollX: true,
            });
            this.data.fetch();
        },
        name: "documents",
        components : {
            FilterIcon , XIcon , ArrowDownIcon , RefreshCcwIcon ,
            SearchIcon  , UploadIcon , TrashIcon , DownloadIcon
        },
        computed : {
            upload : function () {
                return this.files.length > 0 && !this.close;
            },

            close : function () {
                return this.files.length > 0 && this.files.filter(e => e.id === 1 || e.id === 2  ).length === this.files.length;
            },
            loading :  function () {
                return this.files.filter( e =>  e.id === 3 ).length > 0
            }
        },
        data :  function () {
            return {
                files : [] ,
                data : new DataHandler({
                    url : `/documents/${this.$route.params.id}/building/list`,
                    prefix : 'files',
                }),
                // Filter Panel with filter form
                filterPanel : false,
            }
        },
        methods : {
            remove : function(item){
                this.data.loading = true;
                window.axios.get(`${window.location.origin}/documents/${item.id}/delete`).then((response) => {
                    this.data.content.data = this.data.content.data.filter(e => e.id !== item.id );
                    this.data.content.total--;
                    this.data.content.to--;
                }).catch((error) => {

                }).finally(() => {
                    this.data.loading = false;
                });
            },
            reset : function(){
                this.files = [];
            },
            handleFiles : function(){

                let uploadedFiles = this.$refs.files.files;

                for(let i = 0; i < uploadedFiles.length; i++)
                {
                    this.files.push(uploadedFiles[i]);
                }

                this.getImagePreviews();
            },
            getImagePreviews : function()
            {
                for( let i = 0; i < this.files.length; i++ )
                {
                    if ( /\.(jpe?g|png|gif)$/i.test( this.files[i].name ) ) {

                        let reader = new FileReader();
                        reader.addEventListener("load", function(){
                            this.$refs['preview'+parseInt(i)][0].src = reader.result;
                        }.bind(this), false);
                        reader.readAsDataURL( this.files[i] );

                    } else {
                        this.$nextTick(function(){
                            this.$refs['preview'+parseInt(i)][0].src = '/img/generic.png';
                        });
                    }
                }
            },
            removeFile : function(key){
                this.files.splice( key, 1 );
                this.getImagePreviews()
            },
            submitFiles : function()
            {
                for( let i = 0; i < this.files.length; i++ ){
                    if(this.files[i].id) {
                        continue;
                    }
                    let formData = new FormData();
                    formData.append('file', this.files[i]);
                    let type = "building";
                    let id = this.$route.params.id;

                    this.files[i].id = 3;

                    window.axios.post(`/documents/${id}/${type}/upload`,
                        formData,
                        {
                            headers: {
                                'Content-Type': 'multipart/form-data'
                            }
                        }
                    ).then((data) => {
                        this.files[i].id = 1;
                        this.files.splice(i, 1, this.files[i]);
                        this.data.fetch();
                    }).catch((data) => {
                        this.files[i].id = 2;
                    }).finally(() => {

                    });
                }
            },
            openFilterPanel : function () {
                this.filterPanel = true
            },
            closeFilterPanel : function () {
                this.filterPanel = false
            },
            runFilters : function (){
                // Add to filters
                this.data.runFilters();
                this.closeFilterPanel();

            },
        }
    }
</script>

<style scoped>
    input[type="file"]{
        opacity: 0;
        width: 100%;
        height: 100px;
        position: absolute;
        cursor: pointer;
    }
    .filezone {
        outline: 3px dashed grey;
        outline-offset: -10px;
        background: #fff;
        color: dimgray;
        padding: 10px 10px;
        min-height: 100px;
        position: relative;
        cursor: pointer;
        display: flex;
        align-content: center;
        justify-content: center;
    }
    .filezone:hover {
        background: #fff;
    }

    .filezone p {
        font-size: 1.2em;
        text-align: center;
        padding: 20px;
        margin: 0;
    }
    div.file-listing img {
        width: 40px;
        height: 20px;
    }

    div.file-listing {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 20px 40px;
    }

    div.success-container{
        text-align: center;
        color: green;
    }

    div.error-container{
        text-align: center;
        color: red;
    }

    div.remove-container{
        text-align: center;
    }

    div.remove-container a{
        color: red;
        cursor: pointer;
    }
</style>
