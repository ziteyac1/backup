class DataHandler {

    constructor(data   , global = '' )
    {
         this.global  = global;
         this.sortFields = [];
         this.rangeFields = [];
         this.filterFields = [];

          // Url and the prefix
          // For fetching data
          this.url = data.url;
          this.prefix = data.prefix;
          this.sroll = data.scroll ? data.scroll : 'filemgr-content-body';


          // Default sort

          this.sort = {
              field : {
                  date:true,
                  field:"id",
                  filter :[],
                  range: true,
                  read:"ID",
                  sort:true
              },
              value: 'Desc',
          };

          // Size
          this.size = 20;

          // Search

         this.search = "";

         // Loading state

         this.loading = false;

         // Filter Form default values

         this.filterForm = {
             filters: {},
             ranges : {
                 min : {},
                 max : {}
             },
         };

         // Information for building filter form
        this.documentation = [];

        // Filters

        this.filters = [];

        // Ranges

        this.ranges = [];

        // Start Default Pages number

        this.page  = 1;

        // Default Content

        this.content = {
            current_page: 1,
            data: [],
            total: 0,
            to : 0
        };


    }

    setGlobal(global)
    {
      this.global = global;
    }

    // Building the url for sending on the ajax requests

    build()
    {
        // Start url
        let url = `${window.location.origin}${this.url}?size=${this.size}`;

        // Adding filters to the url
        // Filters
        this.filters.forEach((value) => {
            url = url + `&${value.field.field}[]=${value.value.value}`;
        });

        // Adding Ranges to the url
        // Ranges
        this.ranges.forEach((value) => {
            let min = value.min ? value.min : '';
            let max = value.max ? value.max : '';
            if (value.field.date) {
                min = value.min ? value.min.replace(/-/g, '') : '';
                max = value.max ? value.max.replace(/-/g, '') : '';
            }
            url = url + `&range=${value.field.field},${min}-${max}`;
        });

        // Adding Sort , Search , Page number  to the url
        return url + `&page=${this.page}&search=${this.search}&sort=${this.sort.field.field},${this.sort.value}&${this.global}`;
    }

    fetch(){
        this.load(false);
    }

    append(){
        this.load(true);
    }

    getDocumentationValue(key){
        // Get field value by key
        let t  = this.documentation.filter((e) => e.field === key );
        if (t.length > 0 ){
            return t[0];
        }
        return  null;
    }

    runFilters(){

        // Add to filters
        Object.getOwnPropertyNames(this.filterForm.filters).forEach((value) => {
            let field = this.getDocumentationValue(value);
            if (field !== null) {
                this.filters.push({
                    field : field,
                    value : this.filterForm.filters[value]
                });
            }
        });

        // Add to ranges
        let max = Object.getOwnPropertyNames(this.filterForm.ranges.max);
        let min = Object.getOwnPropertyNames(this.filterForm.ranges.min);
        let union = [ ...new Set([...max , ...min])];
        union.forEach((value) => {
            let field = this.getDocumentationValue(value);
            if (field !== null) {
                this.ranges.push({
                    min :  this.filterForm.ranges.min[value],
                    max :  this.filterForm.ranges.max[value],
                    field : this.getDocumentationValue(value)
                });
            }
        });

        this.resetFilters();

    }

    removeFilter(item){
        this.filters.splice(item, 1);
    }

    removeRange(item){
        this.ranges.splice(item, 1);
    }

    resetFilters(){
        // Clear filter form to default
        this.filterForm = {
            filters: {},
            ranges : {
                min : {},
                max : {}
            },
        };
    }

    // Send Ajax Requests to the server and the assign values
    load(append){
        // Open the loader
        this.openLoader();

        // Assign the page number based on request
        this.page = append ? this.page + 1 : 1;

        window.axios.get(this.build()).then((response) => {

            // Load Documentation values

            if (response.data.body.filters)
            {
                this.documentation = response.data.body.filters;
                this.sortFields = this.documentation.filter((e) => e.sort);
                this.rangeFields = this.documentation.filter((e) => e.range);
                this.filterFields = this.documentation.filter((e) => e.filter.length >  0 );
            }

            // Append Content

            if (append){

                // Push items to content

                response.data.body[this.prefix].data.forEach((value) => {
                    this.content.data.push(value);
                });

                // Update all content data remaining

                this.content.to = response.data.body[this.prefix].to;
                this.content.total = response.data.body[this.prefix].total;

                return;
            }

            // Replace all content data
            this.content = response.data.body[this.prefix];

            // Scroll to top

            document.getElementById(this.sroll).scroll(0 , 0);


        }).catch((error) => {

        }).finally(() =>{
            this.closeLoader();
        });


    }
    // Sets the loader to loading state
    openLoader(){
        this.loading = true;
    }

    // Sets the loader to closed state
    closeLoader(){
        this.loading =  false;
    }
}

export default DataHandler;
