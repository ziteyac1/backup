@extends('layouts.main')

@section('content')
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">Stock Issue</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
        </div>
    </div>
@endsection
