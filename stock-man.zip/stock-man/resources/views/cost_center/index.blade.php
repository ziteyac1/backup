@extends('layouts.main')

@section('content')
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3"+>
                <h4 class="mr-auto mb-0">Cost Centers</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row col-lg-12">
                <div class="col-lg-3">
                    <div class="card" style="overflow-y: scroll;height: 600px">
                        <div class="card-header pd-b-0 pd-x-20 bd-b-0">
                            <div class="d-sm-flex align-items-center justify-content-between">
                                <h6 class="mg-b-0">Recent Activities</h6>
                            </div>
                        </div><!-- card-header -->
                        <div class="card-body pd-20">
                            <ul class="activity tx-13">
                                <li class="activity-item">
                                    <div class="activity-icon bg-primary-light tx-primary">
                                        <i data-feather="clock"></i>
                                    </div>
                                    <div class="activity-body">
                                        <p class="mg-b-2"><strong>Louise</strong> added a time entry to the ticket <a href="" class="link-02"><strong>Sales Revenue</strong></a></p>
                                        <small class="tx-color-03">2 hours ago</small>
                                    </div><!-- activity-body -->
                                </li><!-- activity-item -->
                            </ul><!-- activity -->
                        </div><!-- card-body -->
                    </div><!-- card -->
                </div>
                <div class="col-lg-9">
                    <div class="card" style="height: 600px; overflow-y: scroll">
                        <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                            <thead>
                            <tr>
                                <th>Center Details</th>
                                <th>Requester Details</th>
                                <th>Item Details</th>
                                <th>Quantity</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($stock_requests as $stock_request)
                                <tr>
                                    <td>
                                        <div>Location ID : <span>{{$stock_request->cost_center->id}}</span></div>
                                        <div>Location Name : <span>{{$stock_request->cost_center->location_name}}</span></div>
                                        <div>Location Description : <span>{{$stock_request->cost_center->description}}</span></div>
                                    </td>
                                    <td>
                                        <div>Requester Name : <span>{{$stock_request->user_request->full_name}}</span></div>
                                        <div>Requester Email : <span>{{$stock_request->user_request->email}}</span></div>
                                    </td>
                                    <td>
                                        <div>Item Code : <span>{{$stock_request->item_code}}</span></div>
                                        <div>Item Category : <span>{{$stock_request->item_category}}</span></div>
                                        <div>Item Category : <span>{{$stock_request->item_category}}</span></div>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer">
                        <div class="justify-content-center align-items-center">
                            {{ $stock_items->render() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
