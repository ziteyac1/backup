@extends('layouts.main')

@section('css')
    <style>
        .blinking{
            animation:blinkingText 5.0s infinite;
        }
        @keyframes blinkingText{
            0%{		color: #ff1c0c;	}
            49%{	color: transparent;	}
            50%{	color: transparent;	}
            99%{	color:transparent;	}
            100%{	color: #ff1c0c;	}
        }
    </style>
@endsection

@section('content')
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center">
                <h4 class="mr-auto mb-0">Dashboard</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row col-lg-12 mb-2 justify-content-center">
                @foreach($stock_categories as $stock_category)
                    <div class="col-lg-3 mb-3">
                         <div class="card rounded-0">
                            <div class="card-header text-center">
                                {{$stock_category->category->name}}
                            </div>
                            <div class="card-body p-3 text-center">
                                <h3>Sub Items {{$stock_category->total_items}} <a href="/stocks/category/{{$stock_category->category->id}}/view"><i class="fa fa-arrow-circle-right"></i></a></h3>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            <div class="row col-lg-12">
                <div class="col-lg-12 mb-3">
                    <div class="card rounded-0">
                        <div class="card-body">
                            {!! $chart->container() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script src="{{ asset('/lib/chart.js/Chart.bundle.min.js') }}"></script>
    {!! $chart->script() !!}
@endsection
