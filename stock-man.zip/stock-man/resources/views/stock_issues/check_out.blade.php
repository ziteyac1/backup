@extends('layouts.main')

@section('content')
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <h1>CHECK OUT</h1>
        </div>
    </div>
@endsection
