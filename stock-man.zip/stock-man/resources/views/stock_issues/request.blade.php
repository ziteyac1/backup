@extends('layouts.main')

@section('content')
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">Internal Stock Requisition</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-5">
                    <div class="card rounded-0">
                        <div class="card-header">
                            @if(session()->has('message'))
                                <div class="alert alert-success rounded-0 text-center">
                                    {{ session()->get('message') }}
                                </div>
                            @elseif(session()->has('error'))
                                <div class="alert alert-danger rounded-0 text-center">
                                    {{ session()->get('error') }}
                                </div>
                            @endif
                        </div>
                        <div class="card-body">
                            <form method="post" action="/stocks/issue/new" enctype="multipart/form-data" class="row col-lg-12 justify-content-center">
                                @csrf
                                <div class="col-12 mb-3">
                                    <label for="">Item Code</label>
                                    <select name="item_code" id="item_code" class="form-control rounded-0 @error('item_code') is-invalid @enderror">
                                        <option value="">Select Stock Item</option>
                                        @foreach($items as $item)
                                            <option {{ old('item_code') == $item->item_code ? 'selected' : '' }} value="{{$item->item_code}}">{{$item->description}}</option>
                                        @endforeach
                                    </select>
                                    @error('item_code')
                                    <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                                {{--<div class="col-12 mb-3">
                                    <label for="">Item Code</label>
                                    <input type="text" name="item_code" id="item_code" class="form-control rounded-0 @error('item_code') is-invalid @enderror" value="{{old('item_code')}}">
                                    @error('item_code')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>--}}
                                <div class="col-12 mb-3">
                                    <label for="">Quantity</label>
                                    <input type="text" name="quantity" id="quantity" class="form-control rounded-0 @error('quantity') is-invalid @enderror" value="{{old('quantity')}}">
                                    @error('quantity')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                                <div class="col-12 mb-3">
                                    <label for="">Department</label>
                                    <select name="location_id" id="location_id" class="form-control rounded-0 @error('location_id') is-invalid @enderror">
                                        <option value="">Select Destination</option>
                                        @foreach($locations as $location)
                                            <option {{old('location_id') == $location->id ? 'selected' : '' }} value="{{$location->id}}">{{$location->location_name}}</option>
                                        @endforeach
                                    </select>
                                    @error('location_id')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                                <div class="col-4 mb-3">
                                    <button type="submit" class="form-control rounded-0 btn-outline-primary mt-3"><i class="fa fa-plus"></i> Add New Record</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
