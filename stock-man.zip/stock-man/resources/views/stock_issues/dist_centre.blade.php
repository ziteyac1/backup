@extends('layouts.main')

@section('content')
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">Distribution Center</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row col-lg-12">
                <div class="row col-lg-12">
                    <div class="col-lg-12">
                        <div class="card rounded-0">
                            <div class="card-body">
                                <div class="row col-lg-12">
                                    <div class="col-lg-8">
                                        <form action="" method="get" class="row col-lg-12">
                                            <div class="search-form col-lg-5">
                                                <input type="search" name="search" placeholder="Search..." class="form-control rounded-0 mr0">
                                                <button class="btn rounded-0" type="button"><i data-feather="search"></i></button>
                                            </div>
                                            <div class="col-lg-5">
                                                <select name="location" id="location" class="form-control rounded-0">
                                                    <option value="">Select Branch</option>
                                                    @foreach($centres as $centre)
                                                        <option value="{{$centre->id}}">{{$centre->location_name}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-lg-2">
                                                <button type="submit" name="go" id="go" class="form-control btn btn-outline-primary rounded-0">GO</button>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="col-lg-1">
                                        <a href="">
                                            <button class="form-control rounded-0 btn btn-outline-primary"><i data-feather="refresh-cw"></i></button>
                                        </a>
                                    </div>
                                    <div class="col-lg-3">
                                        <a href="/stocks/issue/new">
                                            <button class="form-control rounded-0 btn btn-outline-primary"><i data-feather="refresh-cw"></i> Add Request</button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 mt-3">
                    <div class="card rounded-0">
                        <div class="card-body">
                            <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                                <thead>
                                <tr>
                                    <th>Location Details</th>
                                    <th>Issuer Details</th>
                                    <th>Item Details</th>
                                    <th>Quantity</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                @if($stock_requests->isEmpty())
                                    <tr class="text-center">
                                        <td colspan="5"><span>Please Select a branch</span></td>
                                    </tr>
                                @endif
                                @foreach($stock_requests as $stock_request)
                                    <tr>
                                        <td>
                                            <div class="text-muted">ID : <span>{{$stock_request->location->id}}</span></div>
                                            <div class="text-muted">Name : <span>{{$stock_request->location->location_name}}</span></div>
                                            <div class="text-muted">Description : <span>{{$stock_request->location->description}}</span></div>
                                        </td>
                                        <td>
                                            <div class="text-muted">Name : <span>{{$stock_request->issuer->full_name}}</span></div>
                                            <div class="text-muted">Email : <span>{{$stock_request->issuer->email}}</span></div>
                                        </td>
                                        <td>
                                            <div class="text-muted">Item Code : <span>{{$stock_request->inventory->item_code}}</span></div>
                                            <div class="text-muted">Item Description : <span>{{$stock_request->inventory->description}}</span></div>
                                            <div class="text-muted">Category : <span>{{$stock_request->inventory->name}}</span></div>
                                        </td>
                                        <td>
                                            <div class="text-muted">{{$stock_request->quantity}}</div>
                                        </td>
                                        <td>
                                            <div>
                                                <a href="">
                                                    <button type="button" class="form-control btn-outline-primary" ><i data-feather="navigation"></i> Issue Request</button>
                                                </a>
                                            </div>
                                        </td>
                                @endforeach
                                </tbody>
                                <tfoot>
                                <div class="justify-content-center align-items-center">
                                    @if(!$stock_requests->isEmpty())
                                        {{ $stock_requests->render() }}
                                    @endif
                                </div>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
