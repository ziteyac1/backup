@extends('layouts.app')
@section('css')
    <link rel="stylesheet" href="{{ asset('assets/css/dashforge.filemgr.css') }}">
@endsection
@section('main')
    <div class="filemgr-wrapper">
        <div class="filemgr-sidebar">
            <div class="filemgr-sidebar-body">
                <div class="pd-t-20 pd-b-10 pd-x-10">
                    <label class="tx-sans tx-uppercase tx-medium tx-10 tx-spacing-1 tx-color-03 pd-l-10">Transactions</label>
                    <nav class="nav nav-sidebar tx-13">
                        <router-link class="nav-link" active-class="active" to="/transactions/dashboard" exact> <bar-chart-2-icon size="24"></bar-chart-2-icon>SAF Monitor  </router-link>
                        <router-link class="nav-link" active-class="active" to="/transactions/saf" exact> <activity-icon size="24"></activity-icon>SAF Aborting </router-link>
                        <router-link class="nav-link" active-class="active" to="/transactions/requests" exact> <zap-icon size="24"></zap-icon> Requests </router-link>
                        <router-link class="nav-link" active-class="active" to="/transactions/reports" exact> <folder-icon size="24"></folder-icon> Reports </router-link>
                        <router-link class="nav-link" active-class="active" to="/transactions/reports/create" exact> <plus-circle-icon size="24"></plus-circle-icon> Create Report  </router-link>
                        <<<<<<< HEAD
                        <router-link class="nav-link" active-class="active" to="/balance_update/manual" exact> <settings-icon size="24"></settings-icon> Account Balance Update  </router-link>
                        =======

                        <span class="nav-link" active-class="active" exact> <settings-icon size="24"></settings-icon>
                            <a style="color: #1b2e4b" href="/balance_update/manual">Actual Bal </a>
                        </span>


                        >>>>>>> fb2223ad06d138a28241af454dd31d2d90676097
                    </nav>
                </div>
            </div>
        </div>
        <transition name="slide-in-left">
            <router-view></router-view>
        </transition>
    </div>
@endsection

@section('js')
    <script>
        const scroll1 = new PerfectScrollbar('.filemgr-sidebar-body', {
            suppressScrollX: true
        });
    </script>
@endsection

