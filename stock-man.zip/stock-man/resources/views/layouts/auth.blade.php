@extends('layouts.app')
@section('main')
    <div class="content content-fixed content-auth">
        <div class="container">
            <div class="media align-items-stretch justify-content-center ht-100p pos-relative">
                @yield('content')
            </div><!-- media -->
        </div><!-- container -->
    </div>
@endsection
