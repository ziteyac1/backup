@extends('layouts.main')

@section('js')
    <script src="{{asset('js/jquery.min.js')}}"></script>
    <script src="{{asset('js/repeater.js')}}"></script>
@endsection

@section('content')
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center">
                <h4 class="mr-auto mb-0">Add New Stock Items</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row justify-content-center">
                <div class="card rounded-0" style="width: 1080px;">
                    <div class="card-header">
                        @if(session()->has('message'))
                            <div class="alert alert-success rounded-0 text-center">
                                {{ session()->get('message') }}
                            </div>
                        @endif
                    </div>
                    <div class="card-body">
                        <form method="post" action="/stocks/add_items" enctype="multipart/form-data">
                            @csrf
                            {{--This table to be used later--}}
                            {{--<div class="table-responsive">
                                <table class="table table-borderless" id="dynamic_field">
                                    <thead>
                                        <th>
                                            <label for="">Item Category</label>
                                        </th>
                                        <th>
                                            <label for="">Item Code</label>
                                        </th>
                                        <th>
                                            <label for="">Item Description</label>
                                        </th>
                                        <th>
                                            <label for="">Quantity</label>
                                        </th>
                                        <th>
                                            <label for="">Cost Per Unit</label>
                                        </th>
                                        <th>
                                            <label for="">Total Cost</label>
                                        </th>
                                        --}}{{--<th>
                                            <label for="">Action</label>
                                        </th>--}}{{--
                                    </thead>
                                    <tr>
                                        <td>
                                            <select name="item_category[]" id="item_category" class="form-control col-12">
                                                <option value="" disabled>Choose Category</option>
                                                @foreach($categories as $category)
                                                    <option {{ old('item_category') == $category->id ? 'selected' : '' }} value="{{$category->id}}">{{$category->name}}</option>
                                                @endforeach
                                            </select>
                                            <div class="alert alert-danger print-error-msg" style="display:none">
                                                <ul></ul>
                                            </div>
                                        </td>
                                        <td>
                                            <select name="item_code[]" id="item_code" class="form-control @error('item_code') is-invalid @enderror">
                                                <option value="">Choose Item Code</option>
                                                <option value="2">Option One</option>
                                                <option value="3">Option Two</option>
                                            </select>
                                        </td>
                                        <td>
                                            <input type="text" name="description[]" id="description" class="form-control @error('description') is-invalid @enderror">
                                        </td>
                                        <td>
                                            <input type="text" name="quantity[]" id="quantity" class="form-control @error('quantity') is-invalid @enderror" >
                                        </td>
                                        <td>
                                            <input type="text" name="cost_unit[]" id="cost_unit" class="form-control @error('cost_unit') is-invalid @enderror" >
                                        </td>
                                        <td>
                                            <input type="text" name="total_cost[]" id="total_cost" class="form-control @error('cost_unit') is-invalid @enderror" >
                                        </td>
                                        --}}{{--<td>
                                            <button type="button" class="form-control btn btn-outline-primary"  name="add_more" id="add_more"><i class="fa fa-plus"></i> Add More Items</button>
                                        </td>--}}{{--
                                    </tr>
                                </table>
                                <div class="">
                                    <input type="button" name="submit" id="submit" class="form-control btn btn-outline-success" value="Submit" />
                                </div>
                            </div>--}}
                            <div class="row mb-3">
                                <div class="col-lg-4">
                                    <label for=""> Item Category</label>
                                    <select name="item_category" id="item_category" class="form-control @error('item_category') is-invalid @enderror rounded-0">
                                        <option value="">Choose Category</option>
                                        @foreach($categories as $category)
                                            <option {{ old('item_category') == $category->id ? 'selected' : '' }} value="{{$category->id}}">{{$category->name}}</option>
                                        @endforeach
                                    </select>
                                    @error('item_category')
                                    <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                                <div class="col-lg-4">
                                    <label for="">Item Code</label>
                                    <input type="text" name="item_code" id="item_code" class="form-control @error('item_code') is-invalid @enderror rounded-0">
                                    @error('item_code')
                                    <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label for="">Item Description</label>
                                    <input type="text" name="description" id="description" class="form-control @error('description') is-invalid @enderror rounded-0" value="{{old('description')}}">
                                    @error('description')
                                    <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="row justify-content-center">
                                <div class="col-lg-4">
                                    <label for="">Minimum Quantity</label>
                                    <input type="text" name="minimum_quantity" id="minimum_quantity" class="form-control @error('minimum_quantity') is-invalid @enderror rounded-0" value="{{old('minimum_quantity')}}">
                                    @error('minimum_quantity')
                                    <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                                <div class="col-lg-4">
                                    <label for="">Quantity</label>
                                    <input type="number" name="quantity" id="quantity" class="form-control @error('quantity') is-invalid @enderror rounded-0" onchange="cal()" value="{{old('quantity')}}">
                                    @error('quantity')
                                    <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label for="">Cost Per Unit</label>
                                    <input type="text" name="cost_unit" id="cost_unit" class="form-control @error('cost_unit') is-invalid @enderror" onchange="cal()" value="{{old('cost_unit')}}">
                                    @error('cost_unit')
                                    <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                                <div class="col-lg-4">
                                    <label for="">Total Cost</label>
                                    <input type="number" name="total_cost" id="total_cost" class="form-control @error('total_cost') is-invalid @enderror rounded-0" value="{{old('total_cost')}}">
                                    @error('total_cost')
                                    <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <button type="submit" class="form-control btn btn-outline-primary mt-3 rounded-0"><i class="fa fa-plus"></i> Add New Record</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

