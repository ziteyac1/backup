@extends('layouts.main')

@section('content')
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">View Item Details</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row col-lg-12">
                <div class="col-lg 12">
                    @if(session()->has('message'))
                        <div class="alert alert-success rounded-0 text-center">
                            {{ session()->get('message') }}
                        </div>
                    @endif
                </div>
                <div class="col-lg-12">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab"
                               aria-controls="home" aria-selected="true">View <i class="fa fa-eye"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab"
                               aria-controls="contact" aria-selected="false">Edit <i class="fa fa-edit"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="purchase-tab" data-toggle="tab" href="#purchase" role="tab"
                               aria-controls="purchase" aria-selected="false"><span>Update via Purchase <i class="fa fa-hand-holding-usd"></i></span> </a>
                        </li>
                    </ul>
                    <div class="tab-content bd bd-gray-300 bd-t-0 pd-20" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <div class="row col-lg-12">
                                <div class="col-lg-6">
                                    <div class="card rounded-0">
                                        @if($item->quantity < $item->minimum_quantity)
                                            <div class="card-header text-center" style="background: #9a050f">
                                                <div><p><span><b>Stocks are running low</b></span></p></div>
                                            </div>
                                        @endif
                                        <div class="card-header text-center">
                                            <h6>Item Details</h6>
                                        </div>
                                        <div class="card-body">
                                            <div><p><span><b>Category: </b>{{$item->category->name}}</span></p></div>
                                            <div><p><span><b>Item Code: </b>{{$item->item_code}}</span></p></div>
                                            <div><p><span><b>Description: </b>{{$item->description}}</span></p></div>
                                            <div><p><span><b>Quantity in Stock: </b>{{$item->quantity}}</span></p></div>
                                            <div><p><span><b>Minimum Quantity: </b>{{$item->minimum_quantity}}</span>
                                                </p></div>
                                            <div><p><span><b>Cost per Unit: </b>${{$item->cost_unit}}</span></p></div>
                                            <div><p><span><b>Total Stock Value: </b>${{$item->total_cost}}</span></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                            <div class="row col-lg-12">
                                <div class="col-lg-6">
                                    <div class="card" style="width: 1080px;">
                                        <div class="card-body">
                                            <form method="post" action="/stocks/{{$item->id}}/update"
                                                  enctype="multipart/form-data">
                                                @csrf
                                                <div class="row mb-3">
                                                    <div class="col-lg-6 ">
                                                        <label for=""> Item Category</label>
                                                        <input name="item_category" id="item_category" class="form-control" value="{{$item->category->name}}" disabled>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="">Item Code</label>
                                                        <input name="item_code" id="item_code" class="form-control" value="{{$item->item_code}}" disabled>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <div class="col-lg-12">
                                                        <label for="">Item Description</label>
                                                        <textarea type="text" name="description" id="description" class="form-control" value="{{old('description')}}">{{$item->description}}</textarea>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-4">
                                                        <label for="">Quantity</label>
                                                        <input type="number" name="quantity" id="quantity"
                                                               class="form-control @error('quantity') is-invalid @enderror"
                                                               onchange="cal()" value="{{$item->quantity}}">
                                                        @error('quantity')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                        @enderror
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <label for="">Cost Per Unit</label>
                                                        <input type="text" name="cost_unit" id="cost_unit"
                                                               class="form-control @error('cost_unit') is-invalid @enderror"
                                                               onchange="cal()" value="{{$item->cost_unit}}">
                                                        @error('cost_unit')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                        @enderror
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <label for="">Total Cost</label>
                                                        <input type="number" name="total_cost" id="total_cost"
                                                               class="form-control @error('total_cost') is-invalid @enderror"
                                                               value="{{$item->total_cost}}">
                                                        @error('total_cost')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                        @enderror
                                                    </div>
                                                </div>
                                                <button type="submit" class="form-control btn btn-outline-primary mt-3">
                                                    <i class="fa fa-save"></i>
                                                    <h7> SAVE</h7>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="purchase" role="tabpanel" aria-labelledby="purchase-tab">
                            <div class="row col-lg-12">
                                <div class="col-lg-6">
                                    <div class="card" style="width: 1080px;">
                                        <div class="card-body">
                                            <form method="post" action="/stocks/{{$item->id}}/update_purchase" enctype="multipart/form-data">
                                                @csrf
                                                <div class="row mb-3">
                                                    <div class="col-lg-6">
                                                        <label for="">Item Description</label>
                                                        <input type="text" name="description" id="description" class="form-control" value="{{$item->description}}" disabled>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="">Purchase Date</label>
                                                        <input type="date" name="purchase_date" id="purchase_date" class="form-control @error('purchase_date') is-invalid @enderror" value="{{old('purchase_date')}}">
                                                        @error('purchase_date')
                                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                                        @enderror
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <div class="col-lg-6">
                                                        <label for="">Supplier Name</label>
                                                        <input type="text" name="supplier_name" id="supplier_name" class="form-control @error('supplier_name') is-invalid @enderror" value="{{old('supplier_name')}}">
                                                        @error('supplier_name')
                                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                    </span>
                                                        @enderror
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="">GRN Number</label>
                                                        <input type="text" name="grn_number" id="grn_number" class="form-control @error('grn_number') is-invalid @enderror" value="{{old('grn_number')}}">
                                                        @error('grn_number')
                                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                                        @enderror
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-4">
                                                        <label for="">Quantity</label>
                                                        <input type="number" name="quantity" id="quantity" class="form-control @error('quantity') is-invalid @enderror" onchange="cal()" value="{{old('quantity')}}">
                                                        @error('quantity')
                                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                                        @enderror
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <label for="">Cost Per Unit</label>
                                                        <input type="text" name="cost_unit" id="cost_unit" class="form-control @error('cost_unit') is-invalid @enderror" onchange="cal()" value="{{old('cost_unit')}}">
                                                        @error('cost_unit')
                                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                                        @enderror
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <label for="">Total Cost</label>
                                                        <input type="number" name="total_cost" id="total_cost" class="form-control @error('total_cost') is-invalid @enderror" value="{{old('total_cost')}}">
                                                        @error('total_cost')
                                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                                        @enderror
                                                    </div>
                                                </div>
                                                <button type="submit" class="form-control btn btn-outline-primary mt-3"><i class="fa fa-save"></i><h7> SAVE</h7></button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('js')
    <script>
        function Calculate(){
            var bal1 = parseFloat(document.getElementById("cost_unit").value);
            var bal2 = parseInt(document.getElementById("quantity").value);

            return parseFloat(bal1 * bal2);
        }
        function cal(){
            if(document.getElementById("cost_unit")||document.getElementById("quantity")){
                document.getElementById("total_cost").value=Calculate();
            }
        }
    </script>
@endsection
