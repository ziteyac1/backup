@extends('layouts.main')

@section('content')
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-4 align-items-center mt-3">
                <h4 class="mr-auto mb-0">Stock Purchases</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row col-lg-12">
                <div class="col-lg-12 mb-3">
                    {{$trend_chart->container()}}
                </div>
                <div class="col-lg-12 mb-3">
                    <div class="card rounded-0">
                        <div class="card-body">
                            <form action="" method="get" class="row col-12">
                                <div class="col-10">
                                    <label style="visibility: hidden;display: block"> Filter</label>
                                    <div class="search-form ">
                                        <input type="search" name="search" placeholder="Search..." class="form-control rounded-0 mr0">
                                        <button class="btn rounded-0" type="button"><i data-feather="search"></i></button>
                                    </div>
                                </div>
                                <div class="col-2">
                                    <label style="visibility: hidden;display: block"> Extract</label>
                                    <a href="/stocks/purchase/add" class="form-control btn btn-white rounded-0">Add New Stock Item</a>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="card rounded-0">
                        <div class="card-body">
                            <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                                <thead>
                                <th>Item Code</th>
                                <th>Item Description</th>
                                <th>Date Purchased</th>
                                <th>Supplier</th>
                                <th>GRN Number</th>
                                <th>Quantity</th>
                                <th>Cost Per Unit</th>
                                <th>Total Cost</th>
                                </thead>
                                <tbody>
                                @if($purchases->isEmpty())
                                    <tr>
                                        <td colspan="7" class="text-center"> No Records Found.</td>
                                    </tr>
                                @endif
                                @foreach($purchases as $purchase)
                                    <tr>
                                        <td><div class="mb-2 text-muted">{{$purchase->inventory->item_code}}</div></td>
                                        <td><div class="mb-2 text-muted">{{$purchase->inventory->description}}</div></td>
                                        <td><div class="mb-2 text-muted">{{$purchase->purchase_date}}</div></td>
                                        <td><div class="mb-2 text-muted">{{$purchase->supplier_name}}</div></td>
                                        <td><div class="mb-2 text-muted">{{$purchase->grn_number}}</div></td>
                                        <td><div class="mb-2 text-muted">{{$purchase->purchase_quantity}}</div></td>
                                        <td><div class="mb-2 text-muted">{{$purchase->amount}}</div></td>
                                        <td><div class="mb-2 text-muted">{{$purchase->purchase_total_cost}}</div></td>
                                    </tr>
                                @endforeach
                                </tbody>
                                <tfoot>
                                <div class="justify-content-center align-items-center">
                                    <div class="row col-lg-12">
                                        <div class="col-lg-4">
                                            <span>Showing {{$purchases->firstItem()}} to {{$purchases->lastItem()}} of {{$purchases->total()}} Records </span>
                                        </div>
                                        <div class="col-lg-4">{{ $purchases->render() }}</div>
                                    </div>
                                </div>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script src="{{ asset('/lib/chart.js/Chart.bundle.min.js') }}"></script>
    {!! $trend_chart->script() !!}
@endsection
