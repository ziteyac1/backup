@extends('layouts.main')

@section('content')
    <div class="filemgr-content-header">
        <a href="/stocks/grn/{{$id}}/download" class="btn btn-white  ml-auto btn-sm px-5">Download GRN</a>
    </div>
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">View GRN # {{$id}}</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row col-lg-12 justify-content-center">
                <div class="col-lg-8">
                    <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                        <thead>
                        <th>ID</th>
                        <th>Item Code</th>
                        <th>Item Description</th>
                        <th>Quantity</th>
                        </thead>
                        <tbody>
                        @if($purchase->isEmpty())
                            <tr>
                                <td colspan="4" class="text-center"><h5>Nothing to show.</h5></td>
                            </tr>
                        @endif
                        @foreach($purchase as $item)
                            <tr>
                                <td><div class="mb-2"><span class="text-muted">{{$item->id}}</span></div></td>
                                <td><div class="mb-2"><span class="text-muted">{{$item->inventory->item_code}}</span></div></td>
                                <td><div class="mb-2"><span class="text-muted">{{$item->inventory->description}}</span></div></td>
                                <td><div class="mb-2"><span class="text-muted">{{$item->purchase_quantity}}</span></div></td>
                            </tr>
                        @endforeach
                        </tbody>
                        <tfoot>
                        <div class="justify-content-center align-items-center">
                            <div class="row col-lg-12">
                                <div class="col-lg-4">{{ $purchase->render() }}</div>
                                {{--<div class="col-lg-4">
                                    <span>Showing {{$stock_depleted->firstItem()}} to {{$stock_depleted->lastItem()}} of {{$stock_depleted->total()}} Records </span>
                                </div>--}}
                            </div>
                        </div>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
