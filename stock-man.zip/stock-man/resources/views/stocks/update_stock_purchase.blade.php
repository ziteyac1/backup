@extends('layouts.main')

@section('content')
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">Add Stock Purchases</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row justify-content-center">
                <div class="card" style="width: 1080px;">
                    <div class="card-header">
                        @if(session()->has('message'))
                            <div class="alert alert-success rounded-0 text-center">
                                {{ session()->get('message') }}
                            </div>
                        @endif
                    </div>
                    <div class="card-body">
                        <form method="post" action="/stocks/{{$stock_item->id}}/update" enctype="multipart/form-data">
                            @csrf
                            <div class="row mb-3">
                                <div class="col-lg-6 ">
                                    <label for=""> Item Category</label>
                                    <input name="item_category" id="item_category"  class="form-control" value="{{$stock_item->category->name}}" disabled>
                                </div>
                                <div class="col-lg-6">
                                    <label for="">Item Code</label>
                                    <input name="item_code" id="item_code" class="form-control" value="{{$stock_item->item_code}}" disabled>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-6">
                                    <label for="">Item Description</label>
                                    <input type="text" name="description" id="description" class="form-control" value="{{$stock_item->description}}" disabled>
                                </div>
                                <div class="col-lg-6">
                                    <label for="">Purchase Date</label>
                                    <input type="date" name="purchase_date" id="purchase_date" class="form-control @error('purchase_date') is-invalid @enderror" value="{{old('purchase_date')}}">
                                    @error('purchase_date')
                                    <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-6">
                                    <label for="">Supplier Name</label>
                                    <input type="text" name="supplier_name" id="supplier_name" class="form-control @error('supplier_name') is-invalid @enderror" value="{{old('supplier_name')}}">
                                    @error('supplier_name')
                                    <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                                <div class="col-lg-6">
                                    <label for="">GRN Number</label>
                                    <input type="text" name="grn_number" id="grn_number" class="form-control @error('grn_number') is-invalid @enderror" value="{{old('grn_number')}}">
                                    @error('grn_number')
                                    <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-4">
                                    <label for="">Quantity</label>
                                    <input type="number" name="quantity" id="quantity" class="form-control @error('quantity') is-invalid @enderror" onchange="cal()" value="{{old('quantity')}}">
                                    @error('quantity')
                                    <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                                <div class="col-lg-4">
                                    <label for="">Cost Per Unit</label>
                                    <input type="text" name="cost_unit" id="cost_unit" class="form-control @error('cost_unit') is-invalid @enderror" onchange="cal()" value="{{old('cost_unit')}}">
                                    @error('cost_unit')
                                    <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                                <div class="col-lg-4">
                                    <label for="">Total Cost</label>
                                    <input type="number" name="total_cost" id="total_cost" class="form-control @error('total_cost') is-invalid @enderror" value="{{old('total_cost')}}">
                                    @error('total_cost')
                                    <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <button type="submit" class="form-control btn btn-outline-primary mt-3"><i class="fa fa-save"></i><h7> SAVE</h7></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection
@section('js')
    <script>
        function Calculate(){
            var bal1 = parseFloat(document.getElementById("cost_unit").value);
            var bal2 = parseInt(document.getElementById("quantity").value);

            return parseFloat(bal1 * bal2);
        }
        function cal(){
            if(document.getElementById("cost_unit")||document.getElementById("quantity")){
                document.getElementById("total_cost").value=Calculate();
            }
        }
    </script>
@endsection
