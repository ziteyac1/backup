@extends('layouts.main')

@section('content')
    <div class="filemgr-content-header px-5">
        <form method="get" action="">
            <div class="search-form ">
                <input type="search" name="search" placeholder="Search..." class="form-control  mr0">
            </div>
        </form>
        <a href="/stocks/category/{{$cat_name->id}}/download" class="btn btn-white  ml-auto btn-sm px-5">Download to Excel</a>
        <a href="/stocks/add_new" class="btn btn-white ml-2 btn-sm px-5">Add New Stock Item</a>
    </div>
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">Stock Items in {{$cat_name->name}}</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row col-lg-12 mb-3">
                <div class="col-lg-12">
                    <div class="card rounded-0">
                        <div class="card-body">
                            {!! $inventory_chart->container() !!}
                        </div>
                    </div>
                </div>
            </div>
            <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                    <thead>
                    <tr>
                        <th>Item Code</th>
                        <th>Item Description</th>
                        <th>Minimum Quantity</th>
                        <th>Quantity</th>
                        <th>Cost Per Unit</th>
                        <th>Total Cost</th>
                        <th>View</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($stock_category as $stock)
                        <tr>
                            <td>
                                <div>{{$stock->item_code}}</div>
                            </td>
                            <td>
                                <div>{{$stock->description}}</div>
                            </td>
                            <td>
                                <div>{{$stock->minimum_quantity}}</div>
                            </td>
                            <td>
                                <div>{{$stock->quantity}}</div>
                            </td>
                            <td>
                                <div>{{$stock->cost_unit}}</div>
                            </td>
                            <td>
                                <div>{{$stock->total_cost}}</div>
                            </td>
                            <td>
                                <div>
                                    <a href="/stocks/{{$stock->id}}/view">
                                        <i class="fa fa-eye"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                    <tfoot>
                        <div class="justify-content-center align-items-center">
                            <div class="row col-lg-12">
                                <div class="col-lg-4">{{ $stock_category->render() }}</div>
                                <div class="col-lg-4">
                                    <span>Showing {{$stock_category->firstItem()}} to {{$stock_category->lastItem()}} of {{$stock_category->total()}} Records </span>
                                </div>
                            </div>
                        </div>
                    </tfoot>
                </table>
        </div>
    </div>
@endsection

@section('js')
    <script src="{{ asset('/lib/chart.js/Chart.bundle.min.js') }}"></script>
    {!! $inventory_chart->script() !!}
@endsection
