@extends('layouts.main')

@section('content')
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex mt-3 mb-3 align-items-center">
                <h4 class="mr-auto mb-0">Stock Items</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="col-lg-12 mb-3">
                <div class="card rounded-0">
                    <div class="card-body">
                        <form action="" method="get" class="row col-12">
                            <div class="col-8">
                                <label style="visibility: hidden;display: block"> Filter</label>
                                <div class="search-form ">
                                    <input type="search" name="search" placeholder="Search..." class="form-control rounded-0 mr0">
                                    <button class="btn rounded-0" type="button"><i data-feather="search"></i></button>
                                </div>
                            </div>
                            <div class="col-2">
                                <label style="visibility: hidden;display: block"> Extract</label>
                                <button type="submit" name="run" id="run" class="form-control btn btn-outline-primary rounded-0"><i data-feather="download"></i> EXTRACT</button>
                            </div>
                            {{--<div class="col-2">
                                <label style="visibility: hidden;display: block"> Upload Stocks</label>
                                <a href="/stocks/upload/batch">
                                    <button type="submit" class="form-control btn btn-outline-primary rounded-0"><i data-feather="upload"></i> Upload Stocks</button>
                                </a>
                            </div>--}}
                            <div class="col-2">
                                <label style="visibility: hidden;display: block"> Extract</label>
                                <a href="/stocks/add_new" class="form-control btn btn-white rounded-0">Add New Stock Item</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="card rounded-0">
                    <div class="card-body">
                        <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                            <thead>
                            <tr>
                                <th>Item Code</th>
                                <th>Item Category</th>
                                <th>Item Description</th>
                                <th>Quantity</th>
                                <th>Cost Per Unit</th>
                                <th>Total Cost</th>
                                <th>View Move</th>
                            </tr>
                            </thead>
                            <tbody>
                            @if($stock_items->isEmpty())
                                <tr>
                                    <td colspan="7" class="text-center"><h7>Nothing to show...</h7></td>
                                </tr>
                            @endif
                            @foreach($stock_items as $stock_item)
                                <tr>
                                    <td>
                                        <div>{{$stock_item->item_code}}</div>
                                    </td>
                                    <td>
                                        <div>{{$stock_item->category->name}}</div>
                                    </td>
                                    <td>
                                        <div>{{$stock_item->description}}</div>
                                    </td>
                                    <td>
                                        <div>{{$stock_item->quantity}}</div>
                                    </td>
                                    <td>
                                        <div>{{$stock_item->cost_unit}}</div>
                                    </td>
                                    <td>
                                        <div>{{$stock_item->total_cost}}</div>
                                    </td>
                                    <td>
                                        <div class="justify-content-center">
                                            <a href="/stocks/{{$stock_item->id}}/view">
                                                <i class="fa fa-eye"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                            <tfoot>
                            <div class="justify-content-center align-items-center">
                                <div class="row col-lg-12">
                                    <div class="col-lg-4">
                                        <span>Showing {{$stock_items->firstItem()}} to {{$stock_items->lastItem()}} of {{$stock_items->total()}} Records </span>
                                    </div>
                                    <div class="col-lg-4">{{ $stock_items->render() }}</div>
                                </div>
                            </div>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
