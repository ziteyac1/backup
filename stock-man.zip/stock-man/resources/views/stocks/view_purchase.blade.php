@extends('layouts.main')

@section('content')
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">View Purchase # {{$id}}</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row col-lg-12 justify-content-center">
                <div class="col-lg-10">
                    <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                        <thead>
                        <th>Item Code</th>
                        <th>Item Category</th>
                        <th>Item Description</th>
                        <th>Date Purchased</th>
                        <th>Supplier</th>
                        <th>GRN Number</th>
                        <th>Quantity</th>
                        <th>Cost Per Unit</th>
                        <th>Total Cost</th>
                        </thead>
                        <tbody>
                        <tr>
                            <td><div class="mb-2 text-muted">{{$purchase->item_code}}</div></td>
                            <td><div class="mb-2 text-muted">{{$purchase->category->name}}</div></td>
                            <td><div class="mb-2 text-muted">{{$purchase->description}}</div></td>
                            <td><div class="mb-2 text-muted">{{$purchase->purchase_date}}</div></td>
                            <td><div class="mb-2 text-muted">{{$purchase->supplier_name}}</div></td>
                            <td><div class="mb-2 text-muted">{{$purchase->grn_number}}</div></td>
                            <td><div class="mb-2 text-muted">{{$purchase->purchase_quantity}}</div></td>
                            <td><div class="mb-2 text-muted">{{$purchase->amount}}</div></td>
                            <td><div class="mb-2 text-muted">{{$purchase->purchase_total_cost}}</div></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
