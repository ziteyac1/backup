<?php

use App\Building;
use App\Owner;
use App\Room;
use App\RoomTypes;
use App\Tenant;
use App\Unit;
use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Seeder;
use SSO\Module\models\Permission;
use SSO\Module\models\Role;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
         // Create Base User
        // Remove Guards

        echo "Starting Database Seeding".PHP_EOL;

        Model::unguard();

        /*Permission::query()->where('application_id' , env('APP_ID'))->delete();
        Role::query()->where('application_id' , env('APP_ID'))->delete();

        Permission::query()->create([
            'name' => 'monitor system',
            'application_id' => env('APP_ID')
        ]);*/

        $this->call(UserSeeder::class);
        $this->call(CostCenterSeeder::class);
        $this->call(CategorySeeder::class);
        //$this->call(InventorySeeder::class);

    }
}
