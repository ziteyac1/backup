<?php

use Illuminate\Database\Seeder;

class UnitSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $values = [
            [
                'name' => 'Kilograms',
                'value' => 'kg',
            ],
            [
                'name' => 'Ream',
                'value' => 'rm',
            ],
            [
                'name' => 'Litre',
                'value' => 'l',
            ],
            [
                'name' => 'Sheets',
                'value' => 'sheet',
            ],
            [
                'name' => 'Kilograms',
                'value' => 'kg',
            ],
            [
                'name' => 'Kilograms',
                'value' => 'kg',
                'minimum_quantity' => 10
            ],
            [
                'name' => 'Kilograms',
                'value' => 'kg',
                'minimum_quantity' => 10
            ],
        ];
    }
}
