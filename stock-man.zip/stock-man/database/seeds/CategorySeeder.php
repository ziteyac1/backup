<?php

use App\Category;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $values = [
            [
                'name'=>'Printed Stationery',
                'short_name' => 'PS'
            ],
            [
                'name'=>'General Stationery',
                'short_name' => 'GS'
            ],
            [
                'name'=>'Computer Consumables',
                'short_name' => 'CC'
            ],
            [
                'name'=>'Public Relations Materials',
                'short_name' => 'PRM'
            ],
            [
                'name'=>'Postage Materials',
                'short_name' => 'PM'
            ],
            [
                'name'=>'Office Cleaning and Maintenance',
                'short_name' => 'OCM'
            ],
            [
                'name'=>'Building Repairs and Maintenance',
                'short_name' => 'BRM'
            ]
        ];

        Model::unguard();

        foreach($values as $value)
        {
            Category::query()->create([
                'name' => ucwords($value['name']),
                'short_name' => $value['short_name']
            ]);
        }
    }
}
