<?php

use App\Category;
use Illuminate\Database\Seeder;

use Faker\Factory as Faker;
use Illuminate\Support\Facades\DB;

class InventorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $categories = Category::select('id')->get();
        $cat = array();
        for($i=0;$i<count($categories);$i++){
            array_push( $cat,$categories[$i]['id']);
        }

        $items = [];

        $faker = Faker::create();
        foreach (range(1,100) as $index) {
            DB::table('inventories')->insert([
                'item_category' => $faker->randomElement($cat),
                'item_code' => $faker->randomElement($cat),
                'description' => $faker->city,
                'quantity' => random_int(100,100000),
                'minimum_quantity' => random_int(10,10000),
                'cost_unit' => random_int(100,50000),
                'total_cost' => random_int(1000,100000),
            ]);
        }
    }
}
