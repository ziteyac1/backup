<?php $__env->startSection('content'); ?>
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">View Item Details</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row col-lg-12">
                <div class="col-lg 12">
                    <?php if(session()->has('message')): ?>
                        <div class="alert alert-success rounded-0 text-center">
                            <?php echo e(session()->get('message')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-lg-12">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab"
                               aria-controls="home" aria-selected="true">View <i class="fa fa-eye"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab"
                               aria-controls="contact" aria-selected="false">Edit <i class="fa fa-edit"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="purchase-tab" data-toggle="tab" href="#purchase" role="tab"
                               aria-controls="purchase" aria-selected="false"><span>Update via Purchase <i class="fa fa-hand-holding-usd"></i></span> </a>
                        </li>
                    </ul>
                    <div class="tab-content bd bd-gray-300 bd-t-0 pd-20" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <div class="row col-lg-12">
                                <div class="col-lg-6">
                                    <div class="card rounded-0">
                                        <?php if($item->quantity < $item->minimum_quantity): ?>
                                            <div class="card-header text-center" style="background: #9a050f">
                                                <div><p><span><b>Stocks are running low</b></span></p></div>
                                            </div>
                                        <?php endif; ?>
                                        <div class="card-header text-center">
                                            <h6>Item Details</h6>
                                        </div>
                                        <div class="card-body">
                                            <div><p><span><b>Category: </b><?php echo e($item->category->name); ?></span></p></div>
                                            <div><p><span><b>Item Code: </b><?php echo e($item->item_code); ?></span></p></div>
                                            <div><p><span><b>Description: </b><?php echo e($item->description); ?></span></p></div>
                                            <div><p><span><b>Quantity in Stock: </b><?php echo e($item->quantity); ?></span></p></div>
                                            <div><p><span><b>Minimum Quantity: </b><?php echo e($item->minimum_quantity); ?></span>
                                                </p></div>
                                            <div><p><span><b>Cost per Unit: </b>$<?php echo e($item->cost_unit); ?></span></p></div>
                                            <div><p><span><b>Total Stock Value: </b>$<?php echo e($item->total_cost); ?></span></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                            <div class="row col-lg-12">
                                <div class="col-lg-6">
                                    <div class="card" style="width: 1080px;">
                                        <div class="card-body">
                                            <form method="post" action="/stocks/<?php echo e($item->id); ?>/update"
                                                  enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="row mb-3">
                                                    <div class="col-lg-6 ">
                                                        <label for=""> Item Category</label>
                                                        <input name="item_category" id="item_category" class="form-control" value="<?php echo e($item->category->name); ?>" disabled>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="">Item Code</label>
                                                        <input name="item_code" id="item_code" class="form-control" value="<?php echo e($item->item_code); ?>" disabled>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <div class="col-lg-12">
                                                        <label for="">Item Description</label>
                                                        <textarea type="text" name="description" id="description" class="form-control" value="<?php echo e(old('description')); ?>"><?php echo e($item->description); ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-4">
                                                        <label for="">Quantity</label>
                                                        <input type="number" name="quantity" id="quantity"
                                                               class="form-control <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               onchange="cal()" value="<?php echo e($item->quantity); ?>">
                                                        <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <label for="">Cost Per Unit</label>
                                                        <input type="text" name="cost_unit" id="cost_unit"
                                                               class="form-control <?php $__errorArgs = ['cost_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               onchange="cal()" value="<?php echo e($item->cost_unit); ?>">
                                                        <?php $__errorArgs = ['cost_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <label for="">Total Cost</label>
                                                        <input type="number" name="total_cost" id="total_cost"
                                                               class="form-control <?php $__errorArgs = ['total_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               value="<?php echo e($item->total_cost); ?>">
                                                        <?php $__errorArgs = ['total_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <button type="submit" class="form-control btn btn-outline-primary mt-3">
                                                    <i class="fa fa-save"></i>
                                                    <h7> SAVE</h7>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="purchase" role="tabpanel" aria-labelledby="purchase-tab">
                            <div class="row col-lg-12">
                                <div class="col-lg-6">
                                    <div class="card" style="width: 1080px;">
                                        <div class="card-body">
                                            <form method="post" action="/stocks/<?php echo e($item->id); ?>/update_purchase" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="row mb-3">
                                                    <div class="col-lg-6">
                                                        <label for="">Item Description</label>
                                                        <input type="text" name="description" id="description" class="form-control" value="<?php echo e($item->description); ?>" disabled>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="">Purchase Date</label>
                                                        <input type="date" name="purchase_date" id="purchase_date" class="form-control <?php $__errorArgs = ['purchase_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('purchase_date')); ?>">
                                                        <?php $__errorArgs = ['purchase_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <div class="col-lg-6">
                                                        <label for="">Supplier Name</label>
                                                        <input type="text" name="supplier_name" id="supplier_name" class="form-control <?php $__errorArgs = ['supplier_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('supplier_name')); ?>">
                                                        <?php $__errorArgs = ['supplier_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                    </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="">GRN Number</label>
                                                        <input type="text" name="grn_number" id="grn_number" class="form-control <?php $__errorArgs = ['grn_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('grn_number')); ?>">
                                                        <?php $__errorArgs = ['grn_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-4">
                                                        <label for="">Quantity</label>
                                                        <input type="number" name="quantity" id="quantity" class="form-control <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" onchange="cal()" value="<?php echo e(old('quantity')); ?>">
                                                        <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <label for="">Cost Per Unit</label>
                                                        <input type="text" name="cost_unit" id="cost_unit" class="form-control <?php $__errorArgs = ['cost_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" onchange="cal()" value="<?php echo e(old('cost_unit')); ?>">
                                                        <?php $__errorArgs = ['cost_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <label for="">Total Cost</label>
                                                        <input type="number" name="total_cost" id="total_cost" class="form-control <?php $__errorArgs = ['total_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('total_cost')); ?>">
                                                        <?php $__errorArgs = ['total_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <button type="submit" class="form-control btn btn-outline-primary mt-3"><i class="fa fa-save"></i><h7> SAVE</h7></button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        function Calculate(){
            var bal1 = parseFloat(document.getElementById("cost_unit").value);
            var bal2 = parseInt(document.getElementById("quantity").value);

            return parseFloat(bal1 * bal2);
        }
        function cal(){
            if(document.getElementById("cost_unit")||document.getElementById("quantity")){
                document.getElementById("total_cost").value=Calculate();
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zuvarashe\PhpstormProjects\stock-man\resources\views/stocks/view_item.blade.php ENDPATH**/ ?>