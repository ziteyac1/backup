<!DOCTYPE html>
<html lang="en">
<head>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title> <?php echo e(config('app.name')); ?></title>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script>
        window.laravel_echo_port='<?php echo e(env("LARAVEL_ECHO_PORT")); ?>';
        <?php if(auth()->guard()->check()): ?>
            window.user = <?php echo auth()->user()->toJson(); ?> ;
            window.permissions = <?php echo auth()->user()->getAllPermissions()->toJson(); ?>;
        <?php endif; ?>
    </script>

    <!-- vendor css -->
    <link href="<?php echo e(asset('/lib/@fortawesome/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/lib/ionicons/css/ionicons.min.css')); ?>" rel="stylesheet">

    <!-- DashForge CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dashforge.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dashforge.auth.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dashforge.profile.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dashforge.filemgr.css')); ?>">

    <?php echo $__env->yieldContent('css'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

</head>
<body>
<div id="app">
    <header class="navbar navbar-header navbar-header-fixed">
        <a href="#" id="mainMenuOpen" class="burger-menu"><i data-feather="menu"></i></a>
        <div class="navbar-brand">
            <a href="<?php echo e(url('/home')); ?>" class="df-logo"> <?php echo e(config('app.name')); ?></a>
        </div><!-- navbar-brand -->
        <div id="navbarMenu" class="navbar-menu-wrapper">
            <div class="navbar-menu-header">
                <a href="<?php echo e(url('/home')); ?>" class="df-logo"> <?php echo e(config('app.name')); ?></a>
                <a id="mainMenuClose" href=""><i data-feather="x"></i></a>
            </div>
            <?php if(auth()->guard()->check()): ?>
                <div class="navbar-right">
                    <div class="dropdown dropdown-notification">
                        <a href="" class="dropdown-link" data-toggle="dropdown">
                            <i data-feather="bell"></i>
                        </a>
                         <!--notifications-->
                        <div class="dropdown-menu dropdown-menu-right">
                            <div class="dropdown-header">Notifications</div>
                            <notifications-small></notifications-small>
                            <div class="dropdown-footer"><a href="#">View all Notifications</a></div>
                        </div>

                    </div><!-- dropdown -->
                    <div class="dropdown dropdown-profile">
                        <a href="" class="dropdown-link" data-toggle="dropdown">
                            <div class="avatar avatar-sm">
                                <span class="avatar-initial rounded-circle"><?php echo e(auth()->user()->avatar_name); ?></span>
                            </div>
                        </a><!-- dropdown-link -->
                        <div class="dropdown-menu dropdown-menu-right tx-13">
                            <div class="avatar avatar-lg mg-b-15">
                                <span class="avatar-initial rounded-circle"><?php echo e(auth()->user()->avatar_name); ?></span>
                            </div>
                            <h6 class="tx-semibold mg-b-5"><?php echo e(auth()->user()->full_name); ?></h6>
                            <a href="<?php echo e(env('APP_SSO_LINk')); ?>apps/profile" class="dropdown-item"><i data-feather="user"></i> View Profile</a>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                <i class="dropdown-icon fe fe-log-out"></i> Sign out
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div><!-- dropdown-menu -->
                    </div><!-- dropdown -->
                </div><!-- navbar-right -->
            <?php endif; ?>
        </div>


    </header><!-- navbar -->
    <div class="filemgr-wrapper">
        <?php echo $__env->make('includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="filemgr-content" style="overflow-y: scroll" >
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    <div class="file"></div>
    <footer class="footer">
        <div>
            <span> <?php echo e(now()->format('Y')); ?> &copy; <?php echo e(config('app.name')); ?></span>
            <span>Developed by  by <strong> E-Channels Development Team </strong> - Agribank  -  Information Technology </span>
        </div>
    </footer>
</div>

<script src="<?php echo e(asset('/lib/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('/lib/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/lib/feather-icons/feather.min.js')); ?>"></script>
<script src="<?php echo e(asset('/lib/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/js/dashforge.js')); ?>"></script>
<?php echo $__env->yieldContent('js'); ?>
<?php if(!isset($ignoreJS)): ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php endif; ?>
</body>
</html>
<?php /**PATH C:\Users\zuvarashe\PhpstormProjects\stock-man\resources\views/layouts/main.blade.php ENDPATH**/ ?>