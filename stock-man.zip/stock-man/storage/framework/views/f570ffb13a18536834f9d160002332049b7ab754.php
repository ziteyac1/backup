<?php $__env->startSection('content'); ?>
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center">
                <h4 class="mr-auto mb-0">Overview</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row col-lg-12 mb-3">
                <div class="col-lg-4">
                    <div class="card rounded-0">
                        <div class="card-header">
                            <h4 class="mr-auto mb-0">Recent Stock Updates</h4>
                        </div>
                        <div class="card-body">
                            <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                                <thead>
                                <th>Item Category</th>
                                <th>Item Code</th>
                                <th>Item Description</th>
                                <th>Quantity</th>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $stock_updates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $updated): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><div class="mb-2"><small class="text-muted"><?php echo e($updated->category->name); ?></small></div></td>
                                        <td><div class="mb-2"><small class="text-muted"><?php echo e($updated->item_code); ?></small></div></td>
                                        <td><div class="mb-2"><span><small class="text-muted"><?php echo e($updated->description); ?></small></span></div></td>
                                        <td><div class="mb-2"><span><small class="text-muted"><?php echo e($updated->quantity); ?></small></span></div></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card rounded-0">
                        <div class="card-header">
                            <h4 class="mr-auto mb-0" style="color: #ff1c0c">Depleting Stock Levels</h4>
                        </div>
                        <div class="card-body">
                            <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                                <thead>
                                <th>Item Code</th>
                                <th>Item Category</th>
                                <th>Item Description</th>
                                <th>Quantity</th>
                                </thead>
                                <tbody>
                                <?php if($stock_depleted->isEmpty()): ?>
                                    <tr>
                                        <td colspan="4" class="text-center"><h5>All Stock items have steady levels</h5></td>
                                    </tr>
                                <?php endif; ?>
                                <?php $__currentLoopData = $stock_depleted; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depleted): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><div class="mb-2"><small class="text-muted"><?php echo e($depleted->item_code); ?></small></div></td>
                                        <td><div class="mb-2"><small class="text-muted"><?php echo e($depleted->category->name); ?></small></div></td>
                                        <td><div class="mb-2"><span><small class="text-muted"><?php echo e($depleted->description); ?></small></span></div></td>
                                        <td><div class="mb-2"><span><small class="text-muted"><?php echo e($depleted->quantity); ?></small></span></div></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                <div class="justify-content-center align-items-center">
                                    <div class="row col-lg-12">
                                        <div class="col-lg-4"><?php echo e($stock_depleted->render()); ?></div>
                                        
                                    </div>
                                </div>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card rounded-0">
                        <div class="card-header text-center">
                            <h6 class="mg-b-3">Recent Activities</h6>
                        </div>
                        <div class="card-body">
                            <ul class="activity tx-13">
                                <?php if($timelines->isEmpty()): ?>
                                    <li class="activity-item">
                                        <div class="activity-icon bg-primary-light tx-primary">
                                            <i data-feather="clock"></i>
                                        </div>
                                        <div class="activity-body">
                                            <p class="mg-b-2"><strong>No Activity</strong></p>
                                        </div>
                                    </li>
                                <?php endif; ?>
                                <?php $__currentLoopData = $timelines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timeline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="activity-item">
                                        <div class="activity-icon bg-primary-light tx-primary">
                                            <i data-feather="clock"></i>
                                        </div>
                                        <div class="activity-body">
                                            <p class="mg-b-2"><strong><?php echo e($timeline->user->fullname); ?></strong> <?php echo e($timeline->activity_description); ?> </p>
                                            <small class="tx-color-03"><?php echo e($timeline->created_at->diffForHumans()); ?></small>
                                        </div><!-- activity-body -->
                                    </li><!-- activity-item -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-flex  mb-3 align-items-center">
                <h4 class="mr-auto mb-0">Extract Reports</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row col-lg-12">
                <div class="col-lg-12">
                    <div class="card rounded-0">
                        <div class="card-header">
                            <h6>Download Purchases Report</h6>
                        </div>
                        <div class="card-body">
                            <form action="" method="get" class="row col-12">
                                <div class="col-4">
                                    <label>Category</label>
                                    <select name="category" id="category" class="form-control rounded-0">
                                        <option value="">Select Category</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-2">
                                    <label>Period Start</label>
                                    <input type="date" name="start_date" class="form-control rounded-0">
                                </div>
                                <div class="col-2">
                                    <label>Period End</label>
                                    <input type="date" name="start_date" class="form-control rounded-0">
                                </div>
                                <div class="col-2">
                                    <label style="visibility: hidden;display: block"> Extract</label>
                                    <button type="submit" name="run" id="run" class="form-control btn btn-outline-primary rounded-0"><i data-feather="filter"></i> Filter</button>
                                </div>
                                <div class="col-2">
                                    <label style="visibility: hidden;display: block"> Extract</label>
                                    <button type="submit" name="run" id="run" class="form-control btn btn-outline-primary rounded-0"><i data-feather="download"></i> EXTRACT</button>
                                </div>
                            </form>
                            <div class="col-12 mt-3 text-center">
                                <span><h3>Number of Items Found</h3></span>
                                <h1><?php echo e($purchases->count()); ?></h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zuvarashe\PhpstormProjects\stock-man\resources\views/reports/index.blade.php ENDPATH**/ ?>