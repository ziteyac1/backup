<div class="filemgr-sidebar">
    <div class="filemgr-sidebar-body">
        <div class="pd-t-20 pd-b-10 pd-x-10">
            <label class="tx-sans tx-uppercase tx-medium tx-10 tx-spacing-1 tx-color-03 pd-l-10">Transactions</label>
            <nav class="nav nav-sidebar tx-13">
                <ul class="nav nav-aside">
                    <li class="nav-item">
                        <a href="/home" class="nav-link"><i data-feather="layers"></i> Dashboard</a>
                    </li>
                    <br>
                    <li class="nav-item">
                        <a href="/stocks/index" class="nav-link"><i data-feather="folder"></i> Inventory</a>
                    </li>
                    <br>
                    <li class="nav-item">
                        <a href="/stocks/add_new" class="nav-link"><i data-feather="plus-circle"></i> Add New Stock Item</a>
                    </li>
                    <br>
                    <li class="nav-item">
                        <a href="/stocks/add_purchase" class="nav-link"><i data-feather="plus-circle"></i> Add Stock Purchase</a>
                    </li>
                    <br>
                    <li class="nav-item">
                        <a href="/stocks/purchases" class="nav-link"><i data-feather="send"></i> Stock Purchases</a>
                    </li>
                    <br>
                    <li class="nav-item">
                        <a href="" class="nav-link"><i data-feather="book-open"></i> Reports</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</div>

<?php /**PATH C:\Users\cziteya\PhpstormProjects\stock-man\resources\views/includes/nav.blade.php ENDPATH**/ ?>