<?php $__env->startSection('content'); ?>
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">Distribution Center</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row col-lg-12">
                <div class="row col-lg-12">
                    <div class="col-lg-12">
                        <div class="card rounded-0">
                            <div class="card-body">
                                <div class="row col-lg-12">
                                    <div class="col-lg-8">
                                        <form action="" method="get" class="row col-lg-12">
                                            <div class="search-form col-lg-5">
                                                <input type="search" name="search" placeholder="Search..." class="form-control rounded-0 mr0">
                                                <button class="btn rounded-0" type="button"><i data-feather="search"></i></button>
                                            </div>
                                            <div class="col-lg-5">
                                                <select name="location" id="location" class="form-control rounded-0">
                                                    <option value="">Select Branch</option>
                                                    <?php $__currentLoopData = $centres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($centre->id); ?>"><?php echo e($centre->location_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-lg-2">
                                                <button type="submit" name="go" id="go" class="form-control btn btn-outline-primary rounded-0">GO</button>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="col-lg-1">
                                        <a href="">
                                            <button class="form-control rounded-0 btn btn-outline-primary"><i data-feather="refresh-cw"></i></button>
                                        </a>
                                    </div>
                                    <div class="col-lg-3">
                                        <a href="/stocks/issue/new">
                                            <button class="form-control rounded-0 btn btn-outline-primary"><i data-feather="refresh-cw"></i> Add Request</button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 mt-3">
                    <div class="card rounded-0">
                        <div class="card-body">
                            <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                                <thead>
                                <tr>
                                    <th>Location Details</th>
                                    <th>Issuer Details</th>
                                    <th>Item Details</th>
                                    <th>Quantity</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if($stock_requests->isEmpty()): ?>
                                    <tr class="text-center">
                                        <td colspan="5"><span>Please Select a branch</span></td>
                                    </tr>
                                <?php endif; ?>
                                <?php $__currentLoopData = $stock_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock_request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <div class="text-muted">ID : <span><?php echo e($stock_request->location->id); ?></span></div>
                                            <div class="text-muted">Name : <span><?php echo e($stock_request->location->location_name); ?></span></div>
                                            <div class="text-muted">Description : <span><?php echo e($stock_request->location->description); ?></span></div>
                                        </td>
                                        <td>
                                            <div class="text-muted">Name : <span><?php echo e($stock_request->issuer->full_name); ?></span></div>
                                            <div class="text-muted">Email : <span><?php echo e($stock_request->issuer->email); ?></span></div>
                                        </td>
                                        <td>
                                            <div class="text-muted">Item Code : <span><?php echo e($stock_request->inventory->item_code); ?></span></div>
                                            <div class="text-muted">Item Description : <span><?php echo e($stock_request->inventory->description); ?></span></div>
                                            <div class="text-muted">Category : <span><?php echo e($stock_request->inventory->name); ?></span></div>
                                        </td>
                                        <td>
                                            <div class="text-muted"><?php echo e($stock_request->quantity); ?></div>
                                        </td>
                                        <td>
                                            <div>
                                                <a href="">
                                                    <button type="button" class="form-control btn-outline-primary" ><i data-feather="navigation"></i> Issue Request</button>
                                                </a>
                                            </div>
                                        </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                <div class="justify-content-center align-items-center">
                                    <?php if(!$stock_requests->isEmpty()): ?>
                                        <?php echo e($stock_requests->render()); ?>

                                    <?php endif; ?>
                                </div>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zuvarashe\PhpstormProjects\stock-man\resources\views/stock_issues/dist_centre.blade.php ENDPATH**/ ?>