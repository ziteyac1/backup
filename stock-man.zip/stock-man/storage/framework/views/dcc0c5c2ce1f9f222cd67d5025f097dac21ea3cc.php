<?php $__env->startSection('content'); ?>
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">Stock Issue</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row col-lg-12">
                <div class="col-lg-3">
                    <div class="card" style="overflow-y: scroll;height: 600px">
                        <div class="card-header pd-b-0 pd-x-20 bd-b-0">
                            <div class="d-sm-flex align-items-center justify-content-between">
                                <h6 class="mg-b-0">Recent Activities</h6>
                            </div>
                        </div><!-- card-header -->
                        <div class="card-body pd-20">
                            <ul class="activity tx-13">
                                <li class="activity-item">
                                    <div class="activity-icon bg-primary-light tx-primary">
                                        <i data-feather="clock"></i>
                                    </div>
                                    <div class="activity-body">
                                        <p class="mg-b-2"><strong>Louise</strong> added a time entry to the ticket <a href="" class="link-02"><strong>Sales Revenue</strong></a></p>
                                        <small class="tx-color-03">2 hours ago</small>
                                    </div><!-- activity-body -->
                                </li><!-- activity-item -->
                            </ul><!-- activity -->
                        </div><!-- card-body -->
                    </div><!-- card -->
                </div>
                <div class="col-lg-9">
                    <div class="card" style="height: 600px; overflow-y: scroll">
                        <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                            <thead>
                            <tr>
                                <th>Location Details</th>
                                <th>Requester Details</th>
                                <th>Item Details</th>
                                <th>Quantity</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $stock_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock_request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="text-muted">ID : <span><?php echo e($stock_request->cost_center->id); ?></span></div>
                                        <div class="text-muted">Name : <span><?php echo e($stock_request->cost_center->location_name); ?></span></div>
                                        <div class="text-muted">Description : <span><?php echo e($stock_request->cost_center->description); ?></span></div>
                                    </td>
                                    <td>
                                        <div class="text-muted">Name : <span><?php echo e($stock_request->user_request->full_name); ?></span></div>
                                        <div class="text-muted">Email : <span><?php echo e($stock_request->user_request->email); ?></span></div>
                                        <div class="text-muted">Approval : <span><?php echo e($stock_request->authorisation_status); ?></span></div>
                                    </td>
                                    <td>
                                        <div class="text-muted">Code : <span><?php echo e($stock_request->item_code); ?></span></div>
                                        <div class="text-muted">Category : <span><?php echo e($stock_request->inventory->name); ?></span></div>
                                    </td>
                                    <td>
                                        <div class="text-muted"><?php echo e($stock_request->quantity); ?></div>
                                    </td>
                                    <td>
                                        <div>
                                            <a href="">
                                                <button type="button" class="form-control btn-outline-primary" ><i data-feather="navigation"></i> Issue Request</button>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer">
                        <div class="justify-content-center align-items-center">
                            <?php echo e($stock_requests->render()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cziteya\PhpstormProjects\stock-man\resources\views/stocks/issue.blade.php ENDPATH**/ ?>