<?php $__env->startSection('content'); ?>
    <div class="filemgr-content-header px-5">
        <form method="get" action="">
            <div class="search-form ">
                <input type="search" name="search" placeholder="Search..." class="form-control  mr0">
            </div>
        </form>
        <a href="/stocks/add_new" class="btn btn-white  ml-auto btn-sm px-5">Add New Stock Item</a>
    </div>
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex mt-3  mb-5 align-items-center">
                <h4 class="mr-auto mb-0">Stock Items</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                <thead>
                <tr>
                    <th>Item Code</th>
                    <th>Item Category</th>
                    <th>Item Description</th>
                    <th>Quantity</th>
                    <th>Cost Per Unit</th>
                    <th>Total Cost</th>
                    <th>Update</th>
                </tr>
                </thead>
                <tbody>
                <?php if($stock_items->isEmpty()): ?>
                    <tr>
                        <td colspan="7" class="text-center"><h7>Nothing to show...</h7></td>
                    </tr>
                <?php endif; ?>
                <?php $__currentLoopData = $stock_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div><?php echo e($stock_item->item_code); ?></div>
                        </td>
                        <td>
                            <div><?php echo e($stock_item->category->name); ?></div>
                        </td>
                        <td>
                            <div><?php echo e($stock_item->description); ?></div>
                        </td>
                        <td>
                            <div><?php echo e($stock_item->quantity); ?></div>
                        </td>
                        <td>
                            <div><?php echo e($stock_item->cost_unit); ?></div>
                        </td>
                        <td>
                            <div><?php echo e($stock_item->total_cost); ?></div>
                        </td>
                        <td>
                            <div>
                                <a href="/stocks/<?php echo e($stock_item->id); ?>/add_purchase">
                                    <button type="button" class="form-control btn btn-outline-primary"><i class="fa fa-plus-circle"></i> Update</button>
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                <div class="justify-content-center align-items-center">
                    <div class="row col-lg-12">
                        <div class="col-lg-4"><?php echo e($stock_items->render()); ?></div>
                        <div class="col-lg-4">
                            <span>Showing <?php echo e($stock_items->firstItem()); ?> to <?php echo e($stock_items->lastItem()); ?> of <?php echo e($stock_items->total()); ?> Records </span>
                        </div>
                    </div>
                </div>
                </tfoot>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cziteya\PhpstormProjects\stock-man\resources\views/stocks/index.blade.php ENDPATH**/ ?>