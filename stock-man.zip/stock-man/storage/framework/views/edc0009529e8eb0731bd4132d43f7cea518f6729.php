<?php $__env->startSection('css'); ?>
    <style>
        .blinking{
            animation:blinkingText 5.0s infinite;
        }
        @keyframes  blinkingText{
            0%{		color: #ff1c0c;	}
            49%{	color: transparent;	}
            50%{	color: transparent;	}
            99%{	color:transparent;	}
            100%{	color: #ff1c0c;	}
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center">
                <h4 class="mr-auto mb-0">Dashboard</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row col-lg-12 mb-2">
                <?php $__currentLoopData = $stock_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 mb-3">
                         <div class="card">
                            <div class="card-header text-center">
                                <?php echo e($stock_category->category->name); ?>

                            </div>
                            <div class="card-body p-3 text-center">
                                <h3>Sub Items <?php echo e($stock_category->total_items); ?> <a href="/stocks/category/<?php echo e($stock_category->category->id); ?>/view"><i class="fa fa-arrow-circle-right"></i></a></h3>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="d-flex  mb-5 align-items-center">
                <h4 class="mr-auto mb-0">Overview</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row col-lg-12">
                <div class="col-lg-5">
                    <div class="d-flex  mb-5 align-items-center">
                        <h4 class="mr-auto mb-0">Recent Stock Updates</h4>
                        <div class="border-bottom ml-3 flex-fill"></div>
                    </div>
                    <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                        <thead>
                        <th>Item Category</th>
                        <th>Item Code</th>
                        <th>Item Description</th>
                        <th>Quantity</th>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $stock_updates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $updated): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><div class="mb-2"><small class="text-muted"><?php echo e($updated->category->name); ?></small></div></td>
                                <td><div class="mb-2"><small class="text-muted"><?php echo e($updated->item_code); ?></small></div></td>
                                <td><div class="mb-2"><span><small class="text-muted"><?php echo e($updated->description); ?></small></span></div></td>
                                <td><div class="mb-2"><span><small class="text-muted"><?php echo e($updated->quantity); ?></small></span></div></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="col-lg-4">
                    <div class="d-flex  mb-5 align-items-center">
                        <h4 class="mr-auto mb-0" style="color: #ff1c0c">Depleting Stock Levels</h4>
                        <div class="border-bottom ml-3 flex-fill"></div>
                    </div>
                    <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                        <thead>
                        <th>Item Code</th>
                        <th>Item Category</th>
                        <th>Item Description</th>
                        <th>Quantity</th>
                        </thead>
                        <tbody>
                        <?php if($stock_depleted->isEmpty()): ?>
                            <tr>
                                <td colspan="4" class="text-center"><h5>All Stock items have steady levels</h5></td>
                            </tr>
                        <?php endif; ?>
                        <?php $__currentLoopData = $stock_depleted; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depleted): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><div class="mb-2"><small class="text-muted"><?php echo e($depleted->item_code); ?></small></div></td>
                                <td><div class="mb-2"><small class="text-muted"><?php echo e($depleted->category->name); ?></small></div></td>
                                <td><div class="mb-2"><span><small class="text-muted"><?php echo e($depleted->description); ?></small></span></div></td>
                                <td><div class="mb-2"><span><small class="text-muted"><?php echo e($depleted->quantity); ?></small></span></div></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                        <div class="justify-content-center align-items-center">
                            <div class="row col-lg-12">
                                <div class="col-lg-4"><?php echo e($stock_depleted->render()); ?></div>
                                
                            </div>
                        </div>
                        </tfoot>
                    </table>
                </div>
                <div class="col-lg-3">
                    <div class="d-sm-flex align-items-center justify-content-between">
                        <h6 class="mg-b-3">Recent Activities</h6>
                        <div class="border-bottom ml-3 flex-fill"></div>
                    </div>
                    <ul class="activity tx-13">
                        <?php if($timelines->isEmpty()): ?>
                            <li class="activity-item">
                                <div class="activity-icon bg-primary-light tx-primary">
                                    <i data-feather="clock"></i>
                                </div>
                                <div class="activity-body">
                                    <p class="mg-b-2"><strong>No Activity</strong></p>
                                </div>
                            </li>
                        <?php endif; ?>
                        <?php $__currentLoopData = $timelines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timeline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="activity-item">
                                <div class="activity-icon bg-primary-light tx-primary">
                                    <i data-feather="clock"></i>
                                </div>
                                <div class="activity-body">
                                    <p class="mg-b-2"><strong><?php echo e($timeline->user->fullname); ?></strong> <?php echo e($timeline->activity_description); ?> </p>
                                    <small class="tx-color-03"><?php echo e($timeline->created_at->diffForHumans()); ?></small>
                                </div><!-- activity-body -->
                            </li><!-- activity-item -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul><!-- activity -->
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cziteya\PhpstormProjects\stock-man\resources\views/dashboard/home.blade.php ENDPATH**/ ?>