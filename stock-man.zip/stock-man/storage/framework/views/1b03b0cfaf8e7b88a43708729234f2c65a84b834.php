<?php $__env->startSection('content'); ?>
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">View Purchase # <?php echo e($id); ?></h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row col-lg-12 justify-content-center">
                <div class="col-lg-10">
                    <div class="d-flex  mb-5 align-items-center">
                        <h4 class="mr-auto mb-0" style="color: #ff1c0c">Depleting Stock Levels</h4>
                        <div class="border-bottom ml-3 flex-fill"></div>
                    </div>
                    <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                        <thead>
                        <th>Item Code</th>
                        <th>Item Category</th>
                        <th>Item Description</th>
                        <th>Date Purchased</th>
                        <th>Supplier</th>
                        <th>GRN Number</th>
                        <th>Quantity</th>
                        <th>Cost Per Unit</th>
                        <th>Total Cost</th>
                        </thead>
                        <tbody>
                        <?php if($purchase->isEmpty()): ?>
                            <tr>
                                <td colspan="4" class="text-center"><h5>No Purchases Recorded</h5></td>
                            </tr>
                        <?php endif; ?>
                        <?php $__currentLoopData = $purchase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><div class="mb-2 text-muted"><?php echo e($item->item_code); ?></div></td>
                                <td><div class="mb-2 text-muted"><?php echo e($item->category->name); ?></div></td>
                                <td><div class="mb-2 text-muted"><?php echo e($item->description); ?></div></td>
                                <td><div class="mb-2 text-muted"><?php echo e($item->purchase_date); ?></div></td>
                                <td><div class="mb-2 text-muted"><?php echo e($item->supplier_name); ?></div></td>
                                <td><div class="mb-2 text-muted"><?php echo e($item->grn_number); ?></div></td>
                                <td><div class="mb-2 text-muted"><?php echo e($item->purchase_quantity); ?></div></td>
                                <td><div class="mb-2 text-muted"><?php echo e($item->amount); ?></div></td>
                                <td><div class="mb-2 text-muted"><?php echo e($item->purchase_total_cost); ?></div></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                        <div class="justify-content-center align-items-center">
                            <div class="row col-lg-12">
                                <div class="col-lg-4"><?php echo e($purchase->render()); ?></div>
                                
                            </div>
                        </div>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cziteya\PhpstormProjects\stock-man\resources\views/stocks/view_purchase.blade.php ENDPATH**/ ?>