<?php $__env->startSection('content'); ?>
    <div class="filemgr-content-header">
        <a href="/stocks/grn/<?php echo e($id); ?>/download" class="btn btn-white  ml-auto btn-sm px-5">Download GRN</a>
    </div>
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">View GRN # <?php echo e($id); ?></h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row col-lg-12 justify-content-center">
                <div class="col-lg-8">
                    <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                        <thead>
                        <th>ID</th>
                        <th>Item Code</th>
                        <th>Item Description</th>
                        <th>Quantity</th>
                        </thead>
                        <tbody>
                        <?php if($purchase->isEmpty()): ?>
                            <tr>
                                <td colspan="4" class="text-center"><h5>Nothing to show.</h5></td>
                            </tr>
                        <?php endif; ?>
                        <?php $__currentLoopData = $purchase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><div class="mb-2"><span class="text-muted"><?php echo e($item->id); ?></span></div></td>
                                <td><div class="mb-2"><span class="text-muted"><?php echo e($item->inventory->item_code); ?></span></div></td>
                                <td><div class="mb-2"><span class="text-muted"><?php echo e($item->inventory->description); ?></span></div></td>
                                <td><div class="mb-2"><span class="text-muted"><?php echo e($item->purchase_quantity); ?></span></div></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                        <div class="justify-content-center align-items-center">
                            <div class="row col-lg-12">
                                <div class="col-lg-4"><?php echo e($purchase->render()); ?></div>
                                
                            </div>
                        </div>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zuvarashe\PhpstormProjects\stock-man\resources\views/stocks/view_grn.blade.php ENDPATH**/ ?>