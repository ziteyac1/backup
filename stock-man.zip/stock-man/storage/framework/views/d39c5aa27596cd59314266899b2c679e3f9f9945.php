<?php $__env->startSection('content'); ?>
    <div class="filemgr-content-header">
        <form method="get" action="">
            <div class="search-form ">
                <input type="search" name="search" placeholder="Search..." class="form-control  mr0">
            </div>
        </form>
    </div>
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">Stock Purchases</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row col-lg-12">
                <div class="col-lg-2">
                    <div class="card row rounded-0">
                        <div class="card-header">
                            <h6 class="text-center">Filter Panel</h6>
                        </div>
                        <div class="card-body">
                            <form action="" method="get">
                                <div class="row mb-3">
                                    <label for="">Period Start</label>
                                    <input type="date" name="start_date" id="start_date" placeholder="Start Date..." class="form-control rounded-0">
                                </div>
                                <div class="row mb-3">
                                    <label for="">Period End</label>
                                    <input type="date" name="end_date" id="end_date" class="form-control rounded-0">
                                </div>
                                <div class="row mb-3">
                                    <button type="submit" name="filter" id="filter" class="form-control btn btn-outline-primary rounded-0"><i data-feather="filter"></i> FILTER</button>
                                </div>
                                <div class="row mb-3">
                                    <button type="submit" name="run" id="run" class="form-control btn btn-outline-primary rounded-0"><i data-feather="settings"></i> EXTRACT</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-10">
                    <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Date Purchased</th>
                            <th>Supplier</th>
                            <th>GRN Number</th>
                            <th>Quantity</th>
                            <th>Cost Per Unit</th>
                            <th>Total Cost</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if($purchases->isEmpty()): ?>
                            <tr>
                                <td colspan="8" class="text-center"> No Records Found.</td>
                            </tr>
                        <?php endif; ?>
                        <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><div><a href="/stocks/purchases/<?php echo e($purchase->inventory_id); ?>/view_purchase"><i class="fa fa-arrow-circle-right"></i></a> <?php echo e($purchase->id); ?></div></td>
                                <td><div><?php echo e($purchase->purchase_date); ?></div></td>
                                <td><div><?php echo e($purchase->supplier_name); ?></div></td>
                                <td><div><a href="/stocks/purchases/<?php echo e($purchase->grn_number); ?>/view_grn"><i class="fa fa-arrow-circle-right"></i></a> <?php echo e($purchase->grn_number); ?></div></td>
                                <td>
                                    <div><?php echo e($purchase->quantity); ?></div>
                                </td>
                                <td>
                                    <div><?php echo e($purchase->amount); ?></div>
                                </td>
                                <td>
                                    <div><?php echo e($purchase->purchase_total_cost); ?></div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                        <div class="justify-content-center align-items-center">
                            <div class="row col-lg-12">
                                <div class="col-lg-4"><?php echo e($purchases->render()); ?></div>
                                <div class="col-lg-4">
                                    <span>Showing <?php echo e($purchases->firstItem()); ?> to <?php echo e($purchases->lastItem()); ?> of <?php echo e($purchases->total()); ?> Records </span>
                                </div>
                            </div>
                        </div>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cziteya\PhpstormProjects\stock-man\resources\views/stocks/purchases.blade.php ENDPATH**/ ?>