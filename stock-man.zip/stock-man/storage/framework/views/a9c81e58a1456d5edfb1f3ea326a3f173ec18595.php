<?php $__env->startSection('content'); ?>
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">Stock Issue</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row col-lg-12">
                <div class="row col-lg-12">
                    <div class="col-lg-12">
                        <div class="card rounded-0">
                            <div class="card-body">
                                <div class="row col-lg-12">
                                    <div class="col-lg-10">
                                        <form action="" method="get" class="row col-lg-12">
                                            <div class="search-form col-lg-4">
                                                <input type="search" name="search" placeholder="Search Using Item Code..." class="form-control rounded-0 mr0">
                                                <button class="btn rounded-0" type="button"><i data-feather="search"></i></button>
                                            </div>
                                            <div class="col-lg-4">
                                                <select name="location" id="location" class="form-control rounded-0">
                                                    <option value="">Select Branch</option>
                                                    <?php $__currentLoopData = $centres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($centre->id); ?>"><?php echo e($centre->location_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-lg-2">
                                                <button type="submit" name="go" id="go" class="form-control btn btn-outline-primary rounded-0">GO</button>
                                            </div>
                                            <div class="col-lg-2">
                                                <button type="submit" name="run" id="run" class="form-control btn btn-outline-primary rounded-0"><i class="fa fa-download"></i> Download</button>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="col-lg-2">
                                        <a href="/stocks/issue/new">
                                            <button class="form-control rounded-0 btn btn-outline-primary"><i data-feather="refresh-cw"></i> Add Request</button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 mt-3">
                    <div class="card rounded-0">
                        <div class="card-body">
                            <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                                <thead>
                                <tr>
                                    <th>Location Details</th>
                                    <th>Issuer Details</th>
                                    <th>Item Details</th>
                                    <th>Quantity</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if($stock_requests->isEmpty()): ?>
                                    <tr class="text-center">
                                        <td colspan="5"><span>No Data Here!</span></td>
                                    </tr>
                                <?php endif; ?>
                                <?php $__currentLoopData = $stock_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock_request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <div class="text-muted">ID : <span><?php echo e($stock_request->location->id); ?></span></div>
                                            <div class="text-muted">Name : <span><?php echo e($stock_request->location->location_name); ?></span></div>
                                            <div class="text-muted">Description : <span><?php echo e($stock_request->location->description); ?></span></div>
                                        </td>
                                        <td>
                                            <div class="text-muted">Name : <span><?php echo e($stock_request->issuer->full_name); ?></span></div>
                                            <div class="text-muted">Email : <span><?php echo e($stock_request->issuer->email); ?></span></div>
                                        </td>
                                        <td>
                                            <div class="text-muted">Item Code : <span><?php echo e($stock_request->inventory->item_code); ?></span></div>
                                            <div class="text-muted">Item Description : <span><?php echo e($stock_request->inventory->description); ?></span></div>
                                        </td>
                                        <td>
                                            <div class="text-muted"><?php echo e($stock_request->quantity); ?></div>
                                        </td>
                                        <td>
                                            <div>
                                                <a href="">
                                                    <button type="button" class="form-control btn-outline-primary" ><i data-feather="navigation"></i> Issue Request</button>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                <div class="justify-content-center align-items-center">
                                    <?php echo e($stock_requests->render()); ?>

                                </div>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zuvarashe\PhpstormProjects\stock-man\resources\views/stock_issues/issue.blade.php ENDPATH**/ ?>