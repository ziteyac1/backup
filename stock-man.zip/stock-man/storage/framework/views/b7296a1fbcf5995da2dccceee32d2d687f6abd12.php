<?php $__env->startSection('content'); ?>
    <div class="filemgr-content-header px-5">
        <form method="get" action="">
            <div class="search-form ">
                <input type="search" name="search" placeholder="Search..." class="form-control  mr0">
            </div>
        </form>
        <a href="/stocks/category/<?php echo e($cat_name->id); ?>/download" class="btn btn-white  ml-auto btn-sm px-5">Download to Excel</a>
        <a href="/stocks/add_new" class="btn btn-white ml-2 btn-sm px-5">Add New Stock Item</a>
    </div>
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">Stock Items in <?php echo e($cat_name->name); ?></h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row col-lg-12 mb-3">
                <div class="col-lg-12">
                    <div class="card rounded-0">
                        <div class="card-body">
                            <?php echo $inventory_chart->container(); ?>

                        </div>
                    </div>
                </div>
            </div>
            <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                    <thead>
                    <tr>
                        <th>Item Code</th>
                        <th>Item Description</th>
                        <th>Minimum Quantity</th>
                        <th>Quantity</th>
                        <th>Cost Per Unit</th>
                        <th>Total Cost</th>
                        <th>View</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $stock_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div><?php echo e($stock->item_code); ?></div>
                            </td>
                            <td>
                                <div><?php echo e($stock->description); ?></div>
                            </td>
                            <td>
                                <div><?php echo e($stock->minimum_quantity); ?></div>
                            </td>
                            <td>
                                <div><?php echo e($stock->quantity); ?></div>
                            </td>
                            <td>
                                <div><?php echo e($stock->cost_unit); ?></div>
                            </td>
                            <td>
                                <div><?php echo e($stock->total_cost); ?></div>
                            </td>
                            <td>
                                <div>
                                    <a href="/stocks/<?php echo e($stock->id); ?>/view">
                                        <i class="fa fa-eye"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <div class="justify-content-center align-items-center">
                            <div class="row col-lg-12">
                                <div class="col-lg-4"><?php echo e($stock_category->render()); ?></div>
                                <div class="col-lg-4">
                                    <span>Showing <?php echo e($stock_category->firstItem()); ?> to <?php echo e($stock_category->lastItem()); ?> of <?php echo e($stock_category->total()); ?> Records </span>
                                </div>
                            </div>
                        </div>
                    </tfoot>
                </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('/lib/chart.js/Chart.bundle.min.js')); ?>"></script>
    <?php echo $inventory_chart->script(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zuvarashe\PhpstormProjects\stock-man\resources\views/stocks/view.blade.php ENDPATH**/ ?>