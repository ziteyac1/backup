$(document).ready(function(){
    var i=0;
    $('#add_more').click(function(){
        i++;
        $('#dynamic_field').append('<tr id="row'+i+'">\n' +
            '                                    <td>\n' +
            '                                        <select name="item_category[]" id="" class="form-control col-12">\n' +
            '                                            <option value="">Choose Category</option>\n' +
            '                                            @foreach($categories as $category)\n' +
            '                                            <option value="{{$category->id}}">{{$category->name}}</option>\n' +
            '                                            @endforeach\n' +
            '                                        </select>\n' +
            '                                    </td>\n' +
            '                                    <td>\n' +
            '                                        <select name="item_code[]" id="" class="form-control">\n' +
            '                                            <option value="">Choose Item Code</option>\n' +
            '                                            <option value="2">Option One</option>\n' +
            '                                            <option value="3">Option Two</option>\n' +
            '                                        </select>\n' +
            '                                    </td>\n' +
            '                                    <td>\n' +
            '                                        <input type="text" name="description[]" class="form-control col-12">\n' +
            '                                    </td>\n' +
            '                                    <td>\n' +
            '                                        <input type="text" class="form-control" name="quantity[]">\n' +
            '                                    </td>\n' +
            '                                    <td>\n' +
            '                                        <input type="text" class="form-control" name="cost_unit[]">\n' +
            '                                    </td>\n' +
            '                                    <td>\n' +
            '                                        <input type="text" class="form-control" name="total_cost[]">\n' +
            '                                    </td>\n' +
            '                                    <td>\n' +
            '                                        <button type="button" name="remove" id="'+i+'" class="form-control btn btn-outline-danger btn_remove"><i class="fa fa-trash"></i> Delete Row</button>\n' +
            '                                    </td>\n' +
            '                                </tr>');
    });

    $(document).on('click', '.btn_remove', function(){
        var button_id = $(this).attr("id");
        $('#row'+button_id+'').remove();
    });

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });


    $('#submit').click(function(){
        $.ajax({
            url:"/stocks/add_items",
            method:"POST",
            data:$('#add_item').serialize(),
            type:'json',
            success:function(data)
            {
                if(data.error){
                    printErrorMsg(data.error);
                }else{
                    i=1;
                    $('.dynamic-added').remove();
                    $('#add_item')[0].reset();
                }
            }
        });
    });

    function printErrorMsg (msg) {
        $(".print-error-msg").find("ul").html('');
        $(".print-error-msg").css('display','block');
        $(".print-success-msg").css('display','none');
        $.each( msg, function( key, value ) {
            $(".print-error-msg").find("ul").append('<li>'+value+'</li>');
        });
    }
});
function Calculate(){
    var bal1 = parseFloat(document.getElementById("cost_unit").value);
    var bal2 = parseInt(document.getElementById("quantity").value);

    return parseFloat(bal1 * bal2);
}
function cal(){
    if(document.getElementById("cost_unit")||document.getElementById("quantity")){
        document.getElementById("total_cost").value=Calculate();
    }
}
