<?php

use App\StatusCode;
use App\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $users = [
            ['name' => 'Inputter', 'email' => 'Inputter@premier.co.zw', 'password' => Hash::make('12345678'), 'role' => 'Inputter'],
            ['name' => 'Authoriser', 'email' => 'Authoriser@premier.co.zw', 'password' => Hash::make('12345678'), 'role' => 'Authoriser'],
            ['name' => 'Cephas', 'email' => 'muna@premier.co.zw', 'password' => Hash::make('12345678'), 'role' => 'Authoriser'],
            ['name' => 'Sanyaz', 'email' => 'sanyaz@premier.co.zw', 'password' => Hash::make('12345678'), 'role' => 'Authoriser'],
            ['name' => 'Cephas', 'email' => 'cziteya@agribank.co.zw', 'password' => Hash::make('Password@6'), 'role' => 'Administrator'],
            ['name' => 'General', 'email' => 'General@premier.co.zw', 'password' => Hash::make('12345678'), 'role' => 'General'],
        ];
        $statuses = [
            ['code' => '0', 'description' => 'Awaiting Authorisation'],
            ['code' => '1', 'description' => 'Partly Authorised'],
            ['code' => '2', 'description' => 'Sent to Agribank for Processing'],
            ['code' => '3', 'description' => 'Processed']
        ];
        foreach ($users as $user) {
            User::query()->create($user);
        }

        foreach($statuses as $status){
            StatusCode::query()->firstOrCreate($status);
        }
    }
}
