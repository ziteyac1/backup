<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRecordsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('records', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('batch_id');
            $table->date('date');
            $table->string('batch_reference');
            $table->string('remitter_account_number');
            $table->string('remitter_name');
            $table->string('beneficiary_bank_name');
            $table->string('beneficiary_bank_code');
            $table->string('beneficiary_account_number');
            $table->string('beneficiary_name');
            $table->double('amount');
            $table->string('currency');
            $table->string('reference');
            $table->string('respose')->nullable();
            $table->string('result')->nullable();
            $table->foreign('batch_id')->references('id')->on('batches')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('records');
    }
}