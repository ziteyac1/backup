<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('record_id');
            $table->double('amount');
            $table->integer('retry_count')->default(0);
            $table->string('batch_id')->nullable();
            $table->boolean('retry')->default(false);
            $table->timestamp('start')->nullable();
            $table->timestamp('end')->nullable();
            $table->integer('state')->nullable();
            $table->string('error')->nullable();
            $table->string('reference')->nullable();
            $table->text('adapter_reference')->nullable();
            $table->string('trans_type')->nullable();
            $table->timestamps();
            $table->foreign('record_id')->references('id')->on('records');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transactions');
    }
}
