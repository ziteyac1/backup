

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <form action="<?php echo e(route('searchBatch')); ?>" method="post" class="sidebar-form">
                        <?php echo csrf_field(); ?>
                        <div class="input-group">
                            <input type="text" name="searchBatch" class="form-control alert-warning" placeholder="Search by batch number or credit account e.g SALPO20200110006" required>
                            <span class="input-group-btn">
                        <button type="submit" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i></button>
                    </span>
                        </div>
                    </form>
                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <table class="table table-hover table-sm table-responsive-sm">
                            <thead class="table-dark">
                            <tr>
                                <th>Batch</th>
                                <th>Beneficiary</th>
                                <th>Amount</th>
                                <th>Debit Account</th>
                                <th>Credit Account</th>
                                <th>Response</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr <?php if(($record->result=="1")): ?> class="alert-success" <?php elseif(($record->result=="0")): ?>class="alert-danger" <?php else: ?> class="bg-warning" <?php endif; ?>>
                                    <td><?php echo e($record->batch_reference); ?></td>
                                    <td><?php echo e($record->beneficiary_name); ?></td>
                                    <td><?php echo e(number_format($record->amount,2)); ?></td>
                                    <td><?php echo e($record->debit_account); ?></td>
                                    <td><?php echo e($record->credit_account); ?></td>
                                    <td><?php echo e($record->response); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zuvarashe\PhpstormProjects\salaries\resources\views/home.blade.php ENDPATH**/ ?>