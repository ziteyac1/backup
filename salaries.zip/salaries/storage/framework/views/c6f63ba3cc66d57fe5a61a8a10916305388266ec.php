
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css"/>
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.6.0/css/buttons.dataTables.min.css"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card-box">
                <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php elseif(session('error')): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <h4 class="card-title">Batches Pending Authorisations<a href="<?php echo e(route('createBatch')); ?>" class="btn text-white btn-rounded pull-right" style="background-color: rgb(0,100, 0);"><i class="fa fa-upload"></i> New Upload</a></h4>
                <table id="user" class="table table-striped table-hover table-condensed table-sm">
                    <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Batch</th>
                        <th>Currency</th>
                        <th>Remaining Authorisations</th>
                        <th>Uploaded By</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($batch->id); ?></td>
                            <td><?php echo e($batch->batch_reference); ?></td>
                            <td><?php echo e($batch->currency); ?></td>
                            <td><?php echo e($batch->remaining_authorisations); ?></td>
                            <td><?php echo e($batch->inputter); ?></td>
                            <td><?php echo e($batch->status?$batch->code($batch->status):$batch->code($batch->status)); ?></td>
                            <td>
                                <div class="dropdown dropdown-action">
                                    <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <a class="dropdown-item" href="/showBatch/<?php echo e($batch->id); ?>"><i class="custom-badge status-green fa fa-eye m-r-5">&nbsp; View</i></a>
                                        <a class="dropdown-item" href="/deleteBatch/<?php echo e($batch->id); ?>"><i class="custom-badge status-red fa fa-refresh m-r-5">&nbsp;Rollback</i></a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascripts'); ?>
    <script src=" https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src=" https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src=" https://cdn.datatables.net/buttons/1.6.0/js/dataTables.buttons.min.js"></script>
    <script src=" https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src=" https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src=" https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src=" https://cdn.datatables.net/buttons/1.6.0/js/buttons.html5.min.js"></script>
    <script src=" https://cdn.datatables.net/buttons/1.4.2/js/buttons.print.js"></script>
    <script src=" https://cdn.datatables.net/buttons/1.6.1/js/buttons.colVis.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#user').DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'pageLength','colvis',
                    {
                        extend: 'copyHtml5',
                        exportOptions: {
                            columns: [ 0, ':visible' ]
                        }
                    },
                    {
                        extend: 'excelHtml5',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },
                    {
                        extend: 'pdfHtml5',
                        filename: 'batches',
                        title:'Uploaded Batches Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3,4,5]
                        }
                    },
                    {
                        extend: 'print',
                        orientation:'landscape',
                        title:'Uploaded Batches Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3 ,4,5]
                        }
                    }
                ]
            } );
        } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zuvarashe\PhpstormProjects\salaries\resources\views/batches/index.blade.php ENDPATH**/ ?>