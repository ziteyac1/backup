<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::post('/searchBatch','HomeController@searchBatch')->name('searchBatch');
//Users Routes
Route::get('/users','UsersController@index')->name('users');
Route::get('/createUser','UsersController@create')->name('createUser');
Route::get('/editUser/{user}','UsersController@edit')->name('editUser');
Route::put('/updateUser/{user}','UsersController@update')->name('updateUser');
Route::get('/deleteUser/{user}','UsersController@destroy')->name('deleteUser');
Route::post('/saveUser','UsersController@store')->name('saveUser');
//Auth Count Routes
Route::get('/authorisations','AuthCountController@index')->name('authorisations');
Route::get('/createAuth','AuthCountController@create')->name('createAuth');
Route::get('/editAuth/{authCount}','AuthCountController@edit')->name('editAuth');
Route::put('/updateAuth/{authCount}','AuthCountController@update')->name('updateAuth');
Route::get('/deleteAuth/{authCount}','AuthCountController@destroy')->name('deleteAuth');
Route::post('/saveAuth','AuthCountController@store')->name('saveAuth');
//Batch Upload Routes
Route::get('/batches','BatchController@index')->name('batches');
Route::get('/createBatch','BatchController@create')->name('createBatch');
Route::get('/showBatch/{batch}','BatchController@show')->name('showBatch');
Route::put('/updateBatch/{batch}','BatchController@update')->name('updateBatch');
Route::get('/deleteBatch/{batch}','BatchController@destroy')->name('deleteBatch');
Route::get('/authorizeBatch/{batch}','BatchController@authorizeBatch')->name('authorizeBatch');
Route::post('/saveBatch','BatchController@store')->name('saveBatch');
//Destination Debit Account Routes
Route::get('/accounts','DebitDestinationAccountController@index')->name('accounts');
Route::get('/createAccount','DebitDestinationAccountController@create')->name('createAccount');
Route::get('/showAccount/{account}','DebitDestinationAccountController@show')->name('showAccount');
Route::put('/updateAccount/{account}','DebitDestinationAccountController@update')->name('updateAccount');
Route::get('/deleteAccount/{account}','DebitDestinationAccountController@destroy')->name('deleteAccount');
Route::post('/saveAccount','DebitDestinationAccountController@store')->name('saveAccount');
//Batch Report Routes
Route::get('/batchesReport','ReportController@index')->name('batchesReport');
Route::get('/showBatchReport/{batch}','ReportController@show')->name('showBatchReport');

Route::get('/refresh/allBatches', 'RefreshBatchController@refresh')->name('refreshBatches');
