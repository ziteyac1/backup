@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <form action="{{route('searchBatch')}}" method="post" class="sidebar-form">
                        @csrf
                        <div class="input-group">
                            <input type="text" name="searchBatch" class="form-control alert-warning" placeholder="Search by batch number or credit account e.g SALPO20200110006" required>
                            <span class="input-group-btn">
                        <button type="submit" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i></button>
                    </span>
                        </div>
                    </form>
                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif
                        <table class="table table-hover table-sm table-responsive-sm">
                            <thead class="table-dark">
                            <tr>
                                <th>Batch</th>
                                <th>Beneficiary</th>
                                <th>Amount</th>
                                <th>Debit Account</th>
                                <th>Credit Account</th>
                                <th>Response</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($records as $record)
                                <tr @if(($record->result=="1")) class="alert-success" @elseif(($record->result=="0"))class="alert-danger" @else class="bg-warning" @endif>
                                    <td>{{$record->batch_reference}}</td>
                                    <td>{{$record->beneficiary_name}}</td>
                                    <td>{{number_format($record->amount,2)}}</td>
                                    <td>{{$record->debit_account}}</td>
                                    <td>{{$record->credit_account}}</td>
                                    <td>{{$record->response}}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
