@extends('layouts.app')
@section('content')
    <div class="row">
        <div class="col-lg-12">
            <div class="card-box">
                @if (session('status'))
                    <div class="alert alert-success" role="alert">
                        {{ session('status') }}
                    </div>
                @endif
                <h4 class="card-title">New Authorisation Count Configuration<a href="{{route('authorisations')}}" style="background-color: rgb(0,100, 0);" class="btn text-white btn-rounded pull-right"><i
                            class="fa fa-backward"></i> Back</a></h4>
                <form method="post" action="{{route('saveAuth')}}">
                    @csrf
                    <div class="form-group row">
                        <label class="col-form-label col-sm-3">Required Batch Authorisations</label>
                        <div class="col-sm-9">
                            <select id="auth_count" class="form-control @error('auth_count') is-invalid @enderror" name="auth_count"
                                    value="{{ old('auth_count') }}" autocomplete="auth_count" autofocus>
                                <option value="">Select Authorisation Count</option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                                <option value="4">Four</option>
                                <option value="5">Five</option>
                            </select>
                            @error('auth_count')
                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-form-label col-sm-2"></label>
                        <div class="col-sm-10">
                            <button class="btn text-white form-control" style="background-color: rgb(0,100, 0);"  type="submit">{{ __('Configure New Auth Count') }}</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
