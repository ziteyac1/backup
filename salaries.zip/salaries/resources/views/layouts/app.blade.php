<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <link rel="shortcut icon" type="image/x-icon" href="{{asset('frontend/assets/img/favi.ico')}}">
    <title>Agri-Bank Salaries </title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('frontend/assets/css/bootstrap.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('frontend/assets/css/font-awesome.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('frontend/assets/css/style.css')}}">
    <!--[if lt IE 9]>
    <script src="{{asset('frontend/assets/js/html5shiv.min.js')}}"></script>
    <script src="{{asset('frontend/assets/js/respond.min.js')}}"></script>
    <![endif]-->
    @yield('styles')
</head>

<body>
<div class="main-wrapper">
    <div class="header" style="background-color: rgb(0,100,0);">
        <div class="header-left bg-white">
            <a href="{{route('home')}}" class="logo">
                <img src="{{asset('frontend/assets/img/Agribank--Logo.png')}}" width="80%" height="80%" alt="">&nbsp;&nbsp;&nbsp;&nbsp;<span></span>
            </a>
        </div>
        <a id="toggle_btn" href="javascript:void(0);"><i class="fa fa-bars"></i></a>
        <a id="mobile_btn" class="mobile_btn float-left" href="#sidebar"><i class="fa fa-bars"></i></a> 
        <ul class="nav user-menu float-left">     
            <li>
                <a href="" class="text-center"> Agri-Bank Salaries Payments</a>
            </li>
        </ul>
        <ul class="nav user-menu float-right">
            
            <li class="nav-item dropdown has-arrow">
                <a href="#" class="dropdown-toggle nav-link user-link" data-toggle="dropdown">
                        <span class="user-img">
							<img class="rounded-circle" src="{{asset('frontend/assets/img/user.jpg')}}" width="24"
                                 alt="Admin">
							<span class="status online"></span>
						</span>
                    <span>{{auth()->user()->name}}</span>
                </a>
                <div class="dropdown-menu">
                    <i class="status-orange">Role: {{auth()->user()->role}}</i>
                    <a class="dropdown-item custom-badge badge-danger" href="{{ route('logout') }}"
                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        {{ __('Logout') }}
                    </a>

                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                        @csrf
                    </form>
                </div>
            </li>
        </ul>
    </div>
    <div class="sidebar" id="sidebar" style="background-color: rgb(0,100,0);">
        <div class="sidebar-inner slimscroll" >
            <div id="sidebar-menu" class="sidebar-menu" >
                <ul>
                    <li class="menu-title">Main</li>
                    <li class="active">
                        <a href="{{route('home')}}" ><i class="fa fa-dashboard text-white"></i> <span>Dashboard</span></a>
                    </li>
                    @canany('create',App\User::class,App\DebitDestinationAccount::class)
                        <li class="submenu">
                            <a href="#"><i class="fa fa-cogs text-white"></i> <span> Configurables </span> <span
                                    class="menu-arrow"></span></a>
                            <ul style="display: none;">
                                <li><a href="{{route('users')}}"><i class="fa fa-users text-white"></i>
                                        <span>Users</span></a></li>
                                <li><a href="{{route('authorisations')}}"><i class="fa fa-gears text-white"></i>
                                        <span>Authorisations</span></a></li>
                                <li><a href="{{route('accounts')}}"><i class="fa fa-lock text-white"></i>
                                        <span>Debit Accounts</span></a></li>
                            </ul>
                        </li>
                    @endcanany
                    <li class="submenu">
                        <a href="#"><i class="fa fa-tasks text-white"></i> <span> My Activities </span> <span
                                class="menu-arrow"></span></a>
                        <ul style="display: none;">
                            <li><a href="{{route('batches')}}"><i class="fa fa-file-excel-o text-white"></i><span>  Batch Authorisations</span></a>
                            </li>
                            @can('create',App\Batch::class)
                                <li><a href="{{route('createBatch')}}"><i class="fa fa-upload text-white"></i><span>  Upload Batch</span></a>
                                </li>
                            @endcan
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#"><i class="fa fa-flag-o text-white"></i> <span> Reports </span> <span
                                class="menu-arrow"></span></a>
                        <ul style="display: none;">
                            <li><a href="{{route('batchesReport')}}"><i class="fa fa-bars text-white"></i> <span>&nbsp;Uploads</span></a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="page-wrapper">
        <div class="content">
            @yield('content')
        </div>
    </div>
</div>
<div class="sidebar-overlay" data-reff=""></div>
<script src="{{asset('frontend/assets/js/jquery-3.2.1.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/popper.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/bootstrap.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/jquery.slimscroll.js')}}"></script>
<script src="{{asset('frontend/assets/js/Chart.bundle.js')}}"></script>
<script src="{{asset('frontend/assets/js/chart.js')}}"></script>
<script src="{{asset('frontend/assets/js/app.js')}}"></script>
@yield('javascripts')
</body>
</html>
