@extends('layouts.app')
@section('styles')
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css"/>
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.6.0/css/buttons.dataTables.min.css"/>
@endsection
@section('content')
    <div class="content">
        <div class="row">
            <div class="col-lg-12">
                <h4 class="page-title"><a href="{{route('batches')}}" class="btn text-white btn-rounded pull-right" style="background-color: rgb(0,100, 0);"><i
                            class="fa fa-backward"></i> Back</a> <a href="#" onclick="printInvoice('printable')"><i
                            class="custom-badge status-orange fa fa-print m-r-5">&nbsp Print</i></a></h4>
            </div>
        </div>
        <div class="row" id="printable">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row custom-invoice">
                            <div class="col-6 col-sm-6 m-b-20">
                                <img src="{{asset('frontend/assets/img/Agribank--Logo.png')}}" class="inv-logo" alt="" >
                            </div>
                            <div class="col-6 col-sm-6 m-b-20">
                                <div class="invoice-details">
                                    <table class="table table-sm table-condensed">
                                        <thead>
                                        <tr>
                                            <th colspan="2" class="text-center">Authorisers</th>
                                        </tr>
                                        <tr>
                                            <th>Authoriser</th>
                                            <th>Status</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($authorisers as $authoriser)
                                        <tr>
                                            <td class="text-left">{{$authoriser->name}}</td>
                                            @if($authoriser->checkStatus($authoriser->name,$batch->batch_reference))<td class="text-right">Yes</td>@else <td class="text-right badge badge-danger"><i class="fa fa-times"></i></td> @endif
                                        </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                                <div>
                                    <h3 class="text-lowercasecase">Batch #{{$batch->batch_reference}}</h3>
                                    <ul class="list-unstyled">
                                        <li>Upload Date: <span>{{$batch->created_at}}</span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-6 col-lg-6 m-b-20">

                                <h5>Payment Prepared at:</h5>
                                <ul class="list-unstyled">
                                    <li>
                                        <h5><strong>Agribank</strong></h5>
                                    </li>
                                    <li>Address: Hurudza House, 14/16 Nelson Mandela Avenue, Harare</li>
                                    <li>Tel: +263 4 774400-7 / +263 4 774409-19</li>
                                    <li><a href="#">Email: customercare@agribank.co.zw</a></li>
                                    <li><a href="#">Website: www.agribank.co.zw</a></li>
                                </ul>

                            </div>
                            <div class="col-sm-6 col-lg-6 m-b-20">
                                <div class="invoices-view">
                                    <span class="text-muted"> <b><u> Batch Details:</u></b></span>
                                    <ul class="list-unstyled invoice-payment-details">
                                        <li>Uploaded By: <span>{{$batch->inputter}}</span></li>
                                        <li>Status:
                                            <span>{{$batch->status?$batch->code($batch->status):$batch->code($batch->status)}}</span>
                                        </li>
                                        <li>Authorisations Remaining: <span>{{$batch->remaining_authorisations}}</span>
                                        </li>
                                        <li>Currency: <span>{{$batch->currency}}</span></li>
                                        <li>Total Records:<span class="badge badge-info">{{$total}}</span></li>
                                        <li>Successful Transactions:<span class="badge badge-success">{{$success}}</span></li>
                                        <li>Failed Transactions:<span class="badge badge-danger">{{$failed}}</span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                         <div class="table-responsive">
                            <table class="table table-condensed table-hover table-sm" id="user">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Date</th>
                                    <th>Remmitter</th>
                                    <th>Credit</th>
                                    <th>Beneficiary</th>
                                    <th>Amount</th>
                                    <th>Reference</th>
                                    <th>Response</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($batch->records as $record)
                                    <tr  @if(($record->result=="1")) class="alert-success" @elseif(($record->result=="0"))class="alert-danger" @else class="bg-warning" @endif>
                                        <td><b>{{$record->id}}</b></td>
                                        <td><b>{{ $record->date }}</b></td>
                                        <td>
                                            <small> Acc : <b> {{$record->remitter_account_number}} </b> </small>
                                            <br>
                                            <small> Name : <b> {{$record->remitter_name}} </b> </small>

                                        </td>
                                        <td>
                                            <small> Acc : <b> {{$record->beneficiary_account_number}} </b> </small>
                                            <br>
                                            <small> Bank : <b> {{$record->beneficiary_bank_name}} </b> </small>
                                        </td>
                                        <td>
                                            {{ $record->beneficiary_name }}
                                        </td>
                                        <td>{{number_format($record->amount,2)}}</td>
                                        <td>{{$record->reference }}</td>
                                        <td>{{$record->respose }}</td>                                       
                                    </tr>
                                    
                                @endforeach                                                            
                                </tbody>
                            </table>
                        </div>
                        <div>
                            <div class="row invoice-payment">
                                <div class="col-sm-7">
                                </div>
                                <div class="col-sm-5">
                                    <div class="m-b-20">
                                        <h6>Payment Breakdown</h6>
                                        <div class="table-responsive no-border">
                                            <table class="table mb-0">
                                                <tbody>
                                                <tr>
                                                    <th>Batch Total:</th>
                                                    <td class="text-right text-primary">
                                                        <h5>{{number_format($sum,2)}}</h5>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th>Success Total:</th>
                                                    <td class="text-right text-primary">
                                                        <h5>{{number_format($successSum,2)}}</h5>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th>Failed Total:</th>
                                                    <td class="text-right text-primary">
                                                        <h5>{{number_format($failedSum,2)}}</h5>
                                                    </td>
                                                </tr>
                                                </tbody>
                                                <tr>
                                                    <td><a class="dropdown-item" href="/deleteBatch/{{$batch->id}}"><i
                                                                class="custom-badge status-red fa fa-thumbs-down m-r-5">&nbsp
                                                                Reject</i></a></td>
                                                    <td class="text-right">
                                                        @can('authorizeBatch',App\Batch::class)   <a
                                                            class="dropdown-item" href="/authorizeBatch/{{$batch->id}}"><i
                                                                class="custom-badge status-green fa fa-thumbs-up m-r-5">&nbsp
                                                                Authorize</i></a>
                                                        @endcan
                                                    </td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                {{--                                <div class="col-lg-12 bg-warning">--}}
                                {{--                                    <p>Additional Info</p>--}}
                                {{--                                </div>--}}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
{{--@section('javascripts')--}}
{{--    <script type="text/javascript">--}}
{{--        function printInvoice(divName) {--}}
{{--            var printContents = document.getElementById(divName).innerHTML;--}}
{{--            var originalContents = document.body.innerHTML;--}}
{{--            document.body.innerHTML = printContents;--}}
{{--            window.print();--}}
{{--            document.body.innerHTML = originalContents;--}}
{{--        }--}}
{{--    </script>--}}
{{--@endsection--}}
@section('javascripts')
    <script src=" https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src=" https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src=" https://cdn.datatables.net/buttons/1.6.0/js/dataTables.buttons.min.js"></script>
    <script src=" https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src=" https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src=" https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src=" https://cdn.datatables.net/buttons/1.6.0/js/buttons.html5.min.js"></script>
    <script src=" https://cdn.datatables.net/buttons/1.4.2/js/buttons.print.js"></script>
    <script src=" https://cdn.datatables.net/buttons/1.6.1/js/buttons.colVis.min.js"></script>
    <script>
        function printInvoice(divName) {
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
        }
        $(document).ready(function() {
            $('#user').DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'pageLength','colvis',
                    {
                        extend: 'copyHtml5',
                        exportOptions: {
                            columns: [ 0, ':visible' ]
                        }
                    },
                    {
                        extend: 'excelHtml5',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },
                    {
                        extend: 'pdfHtml5',
                        filename: 'batches',
                        title:'Uploaded Batches Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3,4,5,6,7,8]
                        }
                    },
                    {
                        extend: 'print',
                        orientation:'landscape',
                        title:'Uploaded Batches Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3 ,4,5,6,7,8]
                        }
                    }
                ]
            } );
        } );
    </script>
@endsection
