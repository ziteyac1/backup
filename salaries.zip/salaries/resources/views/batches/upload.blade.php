@extends('layouts.app')
@section('content')
    <div class="row">
        <div class="col-lg-12">
            <div class="card-box">
                @if (session('status'))
                    <div class="alert alert-success" role="alert">
                        {{ session('status') }}
                    </div>
                @endif
                    @if (session('error'))
                        <div class="alert alert-danger" role="alert">
                            {{ session('error') }}
                        </div>
                    @endif
                <h4 class="card-title">Payment Batch Upload<a href="{{route('batches')}}"
                  style="background-color: rgb(0,100, 0);"  class="btn text-white btn-rounded pull-right"><i
                            class="fa fa-backward"></i> Back</a></h4>
                <form method="post" action="{{route('saveBatch')}}" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group row">
                        <label class="col-form-label col-sm-3">Batch</label>
                        <div class="col-sm-9">
                            <input id="batchFile" type="file" class="form-control @error('batchFile') is-invalid @enderror" name="batch_reference"
                                    value="{{ old('batchFile') }}" autocomplete="batchFile" autofocus>
                            @error('batchFile')
                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-form-label col-sm-3">Batch Payment Type</label>
                        <div class="col-sm-9">
                            <select id="batch_currency" class="form-control @error('batch_currency') is-invalid @enderror" name="batch_currency"
                                    value="{{ old('batch_currency') }}" autocomplete="auth_count" autofocus>
                                <option value="">Select Batch Currency</option>
                                <option value="ZWL">ZWL</option>
                                <option value="USD">USD</option>
                            </select>
                            @error('batch_currency')
                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-form-label col-sm-3">Destination Bank Name</label>
                        <div class="col-sm-9">
                            <select id="batch_currency" class="form-control @error('destination_account') is-invalid @enderror" name="destination_account"
                                    value="{{ old('destination_account') }}" autocomplete="destination_account" autofocus>
                                <option value="">Destination Bank</option>
                               @foreach($accounts as $account)
                                <option value="{{$account->account_name}}">{{$account->account_name}}</option>
                               @endforeach
                            </select>
                            @error('destination_account')
                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-form-label col-sm-3">Unique Batch Reference / Name <br>
                             <small class="text-danger"><strong>(e.g. AGRISALPM20200601001)</strong></small>
                        </label>
                       
                        <div class="col-sm-9">
                            <input type="text" name="batch_name" class="form-control" minlength="4" required="">
                            @error('batch_name')
                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-form-label col-sm-2"></label>
                        <div class="col-sm-10">
                            <button class="btn text-white form-control" style="background-color: rgb(0,100, 0);"
                                    type="submit">{{ __('Upload Payment Batch') }}</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
