<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Batch extends Model
{
    protected $guarded = [];

    public function records()
    {
        return $this->hasMany(Record::class, 'batch_id');
    }

    public function code($code)
    {
        $desc = StatusCode::query()->where('code', $code)->first();
        return $desc->description;
    }
}
