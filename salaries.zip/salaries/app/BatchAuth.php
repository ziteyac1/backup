<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BatchAuth extends Model
{
    protected $guarded=[];
}
