<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AuthCount extends Model
{
    protected $guarded=[];
}
