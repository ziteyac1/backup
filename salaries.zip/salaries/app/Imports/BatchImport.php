<?php

namespace App\Imports;

use App\AuthCount;
use App\Batch;
use App\Record;
use Log;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\SkipsFailures;
use Maatwebsite\Excel\Concerns\SkipsOnFailure;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithBatchInserts;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\WithCustomCsvSettings;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;

class BatchImport implements ToModel, WithBatchInserts, WithChunkReading, WithHeadingRow, WithValidation, SkipsOnFailure, WithCustomCsvSettings
{
    /**
     * @param Collection $collection
     */
    use Importable, SkipsFailures;
    private $batchName;
    public function __construct($batchName)
    {
        $this->batchName = $batchName;
    }

    public function model(array $row)
    {
            $authCount = AuthCount::query()->latest()->first();
            $batch_id = Batch::query()->firstOrCreate([
                'batch_reference' => $this->batchName,
                'inputter' => auth()->user()->name,
                'currency' => $row["currency"],
                'remaining_authorisations' => $authCount->auth_count,
                'status' => '0'
            ]);

            $dt = strtotime($row["date"]);
            $date = date('Y-m-d',$dt);

            Log::info($date);
            return new Record([
                'batch_id' => $batch_id->id,
                'batch_reference'  => $this->batchName,
                'date' => $date,
                'remitter_account_number' => $row["remitter_account_number"],                
                'remitter_name' => $row["remitter_name"],
                'beneficiary_bank_name' => $row["beneficiary_bank_name"],
                'beneficiary_bank_code' => $row["beneficiary_bank_code"],
                'beneficiary_account_number' => $row["beneficiary_account_number"],
                'beneficiary_name' => $row["beneficiary_name"],
                'amount' => $row["amount"],
                'currency' => $row["currency"],
                'reference' => $row["reference"],
            ]);

    }

    public function batchSize(): int
    {
        return 100;
    }

    public function chunkSize(): int
    {
        return 100;
    }

    public function rules(): array
    {
        return [
//            'asset_number'=>'required|unique:assets',
//            '*.asset_number'=>'required|unique:assets'
        ];
    }

    public function getCsvSettings(): array
    {
        return [
            'input_encoding' => 'ISO-8859-1'
        ];
    }
}
