<?php

namespace App\Jobs;

use Log;
use App\BatchParameter;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;

class PostBatchJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    private $batch;
    public function __construct($batch)
    {
        $this->batch=$batch;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
       Log::info('Job has been posted. Batch ID :'.$this->batch->batch_reference);
       $param=BatchParameter::query()->where('batch_reference',$this->batch->batch_reference)->first();
       $bank=$param->destination_bank;
       $currency=$param->currency;
        $response = Http::asForm()->post('http://www.tobacco_api.com/api/fetchToken', [
            'username' => 'Salaries',
            'password' => 'salaries1@payments2'
        ])->body();
        $token = json_decode($response);
        Http::attach('batch_reference', Storage::disk('UploadPath')
            ->get($this->batch->batch_reference . ".csv"), $this->batch->batch_reference)
            ->withToken($token)
            ->post('http://www.tobacco_api.com/api/upload/salaries')->body();
    }
}
