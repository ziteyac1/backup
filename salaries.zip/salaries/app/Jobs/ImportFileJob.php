<?php

namespace App\Jobs;
use App\AuthCount;
use App\Batch;
use App\Record;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Auth;

class ImportFileJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $batch_reference;
    private $currencyCode;
    private $username;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($batch_reference, $currencyCode, $username)
    {
        //
        $this->batch_reference = $batch_reference;
        $this->currencyCode = $currencyCode;
        $this->username = $username;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {

        $file_path = base_path('public/uploads/batches/'.$this->batch_reference);

        $obtain_filename = basename($file_path);
        $batchName = explode(".", $obtain_filename)[0];

        $authCount = AuthCount::query()->latest()->first();
        $batch = Batch::query()->firstOrCreate(
           [
                'batch_reference' => $batchName,
                'inputter'  => $this->username, 
                'currency' => $this->currencyCode,
                'remaining_authorisations' => $authCount->auth_count,
                'status' => '0'
           ]
        );

        
        $lines = file($file_path ,  FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $key => $line) {

            if ($key === 0) {
                continue;
            }

            $array = explode(",", $line);
            list($date, 
                $remitter_account_number, 
                $beneficiary_bank_name, 
                $beneficiary_bank_code, 
                $beneficiary_account_number,
                $beneficiary_name,
                $amount, 
                $currency, 
                $reference, 
                $remitter_name) = $array;

            $result = null;
            $desc = null;
            $dt = strtotime($date);
            $newdate = date('Y-m-d',$dt);

            /** @var Payment $p */
            $p =  Record::query()->create(
                [
                    'batch_id' => $batch->id,
                    'date' => $newdate,
                    'batch_reference' => $batchName,
                    'remitter_account_number' => $remitter_account_number,                        
                    'remitter_name' =>  $remitter_name,
                    'beneficiary_bank_name'  =>  $beneficiary_bank_name,
                    'beneficiary_bank_code' => $beneficiary_bank_code,
                    'beneficiary_account_number' => $beneficiary_account_number,
                    'beneficiary_name' => $beneficiary_name,
                    'amount' => $amount,                        
                    'currency' => $currency,
                    'reference'=> $reference,
                    'respose' => $desc,
                    'result' => $result
                ]
            );
            
        }
    }
}
