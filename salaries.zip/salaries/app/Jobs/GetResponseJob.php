<?php

namespace App\Jobs;

use App\Batch;
use App\Record;
use App\Parameters;
use Illuminate\Bus\Queueable;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class GetResponseJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

     private $record;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($record)
    {
        //
        $this->record =$record;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $response = Http::asForm()->post('http://www.tobacco_api.com/api/fetchToken', [
            'username' => 'Salaries',
            'password' => 'salaries1@payments2'
        ])->body();
        $token = json_decode($response);

        $reco = Http::withToken($token)->asForm()->post('http://www.tobacco_api.com/api/search/salaries', [
                'batch_number' => trim($this->record->batch_reference),
                'credit_acc' => $this->record->beneficiary_account_number,
                'amount' => $this->record->amount,
            ]);
            $output = json_decode($reco->body());
            $response = null;
            $result = null;         
            Log::info($output);
            if(!empty($output))
            {
                
                if($output[0]->result== 1)
                {
                    $response = $output[0]->response;     
                    $result = $output[0]->result;               
                }
                else
                {                                   
                    $desc = $output[0]->response;
                    if ($desc == '') {
                        # code...
                        $response = null;
                        $result = null;
                    }
                    else
                    {
                        $response = $desc;
                        $result = $output[0]->result;
                    }
                    
                }               
                Record::query()
                        ->where('batch_reference', $this->record->batch_reference)
                        ->where('beneficiary_account_number', $this->record->beneficiary_account_number)
                        ->where('amount', $this->record->amount)
                        ->update([
                            'respose' => $response,
                            'result'=>$result
                       ]);

            }            

    }
}
