<?php

namespace App\Jobs;

use App\Record;
use App\Transaction;
use App\ClientIDs;
use App\GetClient;
use DB;
use Auth;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;


class ProcessPaymentJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    private $record;
    private $transaction;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(Record $record, Transaction $transaction)
    {
        $this->record = $record;
        $this->transaction = $transaction;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        //checking the bank code before processing the record
        //Bank Code AGRZZWHA is for Agribank , this means its an Internal Transfer     
        $con = new ClientIDs();
        
        $res = Http::post($con->connetion, $this->InternalTransferData());
        $output = json_decode($res->body());
        $isT24uP  = $output->success;
        $trans_type = $con->internalTransfer;
        $adp_ref = "/transaction/transfer";

        if($isT24uP)
        {
            $success_res = $output->body->result->success;
            $ft = $output->body->result->ft;

            if ($success_res == 1) {
                $this->record->update([
                    'result' => $success_res,
                    'respose' => 'Payment succeded with ft code : ' . $ft,
                ]);

                $this->SuccessfulTransactionUpdate($ft, $trans_type, $adp_ref);

            }
            else
            {
                $info = json_encode($output->body);
                $retry = $output->body->result->retry;
                $ref = $output->body->reference;
                $error =$output->body->result->error;

                $state = ($retry)? 3 : 99;
                $this->record->update([
                    'result' => $success_res,
                    'respose' => $error,
                ]);

                $this->UpdateWithRetry($state, $retry, $error, $ref, $trans_type, $adp_ref);

            }
        }
        else
        {
            //skip the transaction t24 is down
            $this->UpdateIfT24Down($trans_type, $adp_ref);
        }

    }

    private function InternalTransferData()
    {
        # code...
        $con = new ClientIDs();

        return [
                'debit' => $this->record->beneficiary_account_number,
                'credit' => $this->record->remitter_account_number,
                'amount' => $this->record->amount,
                'currency' => $this->record->currency,
                'reference' =>'IB Transfer',
                'version' => $con->versionInternal,
                'auth' => '0',
                'details' =>  [
                    [
                        "field" => "PAYMENT.DETAILS:2",
                        "value" => $this->record->reference,
                    ],
                    [
                        "field" => "DebitNarr::",
                       "value" => Str::limit( 'IB-' . $this->record->remitter_account_number ,  16),
                    ],
                    [
                        "field" => "CreditNarr::",
                        "value" => Str::limit( 'IB-' . $this->record->beneficiary_account_number,  16),
                    ],
                ]
            ];
            
       /* return [
            'debit' => $this->record->beneficiary_account_number,
            'credit' => $this->record->remitter_account_number,
            'amount' => $this->record->amount,
            'currency' => $this->record->currency,
            'reference' =>'IB Transfer',
            'version' => $con->versionInternal,
            'auth' => '0',
            'id' => $this->record->id,
            'application' => $con->application,
            'details' =>  [
                [
                    "field" => "PAYMENT.DETAILS:2",
                    "value" => $this->record->reference,
                ],
                
                [
                    "field" => "DebitNarr::",
                    "value" => Str::limit( 'IB-' . $this->record->remitter_account_number ,  16),
                ],
                [
                    "field" => "CreditNarr::",
                    "value" => Str::limit( 'IB-' . $this->record->beneficiary_account_number,  16),
                ],
                [
                    "field" =>"CREDIT.CURRENCY",
                    "value" => $this->record->currency,
                ],
            ]

        ];*/
    }

    private function RTGSTransferData()
    {
        # code...
        $con = new ClientIDs();
        return [
            'debit' => $this->record->remitter_account_number,
            'version' => $con->versionRTGS,
            'amount' => $this->record->amount,
            'currency' => $this->record->currency,
            'bankId' => $con->getBankID($this->record->beneficiary_bank_code),
            'name' => $this->record->beneficiary_name,
            'receive' => $this->record->beneficiary_account_number,
            'bankCode' => $this->record->beneficiary_bank_code,
            'reason' => 'Payment',
            'id' => $this->record->id,
            'application' => $con->application,
            'details' => [
                [
                    "field" => "DEBIT.THEIR.REF",
                    "value" => Str::limit('' . $this->record->beneficiary_name, 16, ''),
                ],
                [
                    "field" => "CREDIT.THEIR.REF",
                    "value" => Str::limit('' . $this->record->reference,16,  ''),
                ],
            ]

        ];

    }

    private function UpdateIfT24Down($trans_type, $adapter_reference)
    {
        # code...
        $this->transaction->update([
            'state' => 3,
            'end' => now(),
            'error' => 'T24 System Offline',
            'retry' => true,
            'reference' => "",
            'trans_type' => $trans_type,
            'adapter_reference' => $adapter_reference,
        ]);

    }
    public function ValidateBankCode()
    {
       $con = new ClientIDs();
       $bankcode =  $con->getBankID($this->record->beneficiary_bank_code);

       return $bankcode;
    }
    private function UpdateWithRetry($state, $retry, $error, $ref, $trans_type, $adapter_reference)
    {
        # code...
        $this->transaction->update([
            'state' => $state,
            'start' => now(),
            'end' => now(),
            'retry' => $retry,
            'error' => $error,
            'reference' => $ref,
            'trans_type' => $trans_type,
            'adapter_reference' => $adapter_reference,
        ]);
    }

    private function SuccessfulTransactionUpdate($ft, $trans_type, $adapter_reference)
    {
        # code...
        $this->transaction->update([
            'state' => 99,
            'start' => now(),
            'end' => now(),
            'retry' => false,
            'error' => null,
            'reference' => $ft,
            'trans_type' => $trans_type,
            'adapter_reference' => $adapter_reference,
        ]);
    }

}
