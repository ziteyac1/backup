<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DebitDestinationAccount extends Model
{
    protected $guarded=[];
}
