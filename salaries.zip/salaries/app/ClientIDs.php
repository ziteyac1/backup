<?php
namespace App;
use App\User;
use App\Account;
use App\Bank;

class ClientIDs
{
   private $agribank = "agribank";
   
    //live connections
    public $connetion = "http://192.168.0.33:9020/transaction/transfer";
    public $rtgsCon = "http://192.168.0.33:9020/transaction/rtgs";

    public  $application = 'tobacco-api';

    public $versionInternal = 'INT.TSF';
    public $versionRTGS = 'RTGS.TSF';

    public $internalTransfer = "internal transfer";
    public $rtgsTransfer = "rtgs transfer";

    public function agribankName()
    {
        return $this->agribank;
    }
    public function GetAllAccounts($user_id)
    {
        $accounts = Account::query()->where('user_id', $user_id)->get();
        return $accounts;
    }
    public function GetClientAccount($debit_account, $user_id)
    {
        $account = Account::query()->where('account_number', $debit_account)->where('user_id', $user_id)->get();
        return $account;
    }

    public function getBankID($swiftCode)
    {
        $bank = Bank::query()->where('swift_code', $swiftCode)->first();
        if($bank)
        {
            $bank_id = $bank->bank_id;
            return $bank_id;
        }
        else
        {
            return false;
        }
       
    }
}
