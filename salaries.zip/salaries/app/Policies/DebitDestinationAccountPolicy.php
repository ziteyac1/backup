<?php

namespace App\Policies;

use App\DebitDestinationAccount;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class DebitDestinationAccountPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any debit destination accounts.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return $user->role=="Administrator"?$this->allow():$this->deny("Hey ".$user->name." you are not allowed to view accounts");
    }

    /**
     * Determine whether the user can view the debit destination account.
     *
     * @param  \App\User  $user
     * @param  \App\DebitDestinationAccount  $debitDestinationAccount
     * @return mixed
     */
    public function view(User $user, DebitDestinationAccount $debitDestinationAccount)
    {

    }

    /**
     * Determine whether the user can create debit destination accounts.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function create(User $user)
    {
        return $user->role=="Administrator"?$this->allow():$this->deny("Hey ".$user->name." you are not allowed to configure accounts");
    }

    /**
     * Determine whether the user can update the debit destination account.
     *
     * @param  \App\User  $user
     * @param  \App\DebitDestinationAccount  $debitDestinationAccount
     * @return mixed
     */
    public function update(User $user, DebitDestinationAccount $debitDestinationAccount)
    {
        //
    }

    /**
     * Determine whether the user can delete the debit destination account.
     *
     * @param  \App\User  $user
     * @param  \App\DebitDestinationAccount  $debitDestinationAccount
     * @return mixed
     */
    public function delete(User $user, DebitDestinationAccount $debitDestinationAccount)
    {
        return $user->role=="Administrator"?$this->allow():$this->deny("Seek authority to remove account ".$debitDestinationAccount->account_name." = ".$debitDestinationAccount->account_number);
    }

    /**
     * Determine whether the user can restore the debit destination account.
     *
     * @param  \App\User  $user
     * @param  \App\DebitDestinationAccount  $debitDestinationAccount
     * @return mixed
     */
    public function restore(User $user, DebitDestinationAccount $debitDestinationAccount)
    {
        //
    }

    /**
     * Determine whether the user can permanently delete the debit destination account.
     *
     * @param  \App\User  $user
     * @param  \App\DebitDestinationAccount  $debitDestinationAccount
     * @return mixed
     */
    public function forceDelete(User $user, DebitDestinationAccount $debitDestinationAccount)
    {
        //
    }
}
