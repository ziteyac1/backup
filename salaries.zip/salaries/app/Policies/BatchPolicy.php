<?php

namespace App\Policies;

use App\Batch;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class BatchPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any batches.
     *
     * @param \App\User $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        //
    }

    /**
     * Determine whether the user can view the batch.
     *
     * @param \App\User $user
     * @param \App\Batch $batch
     * @return mixed
     */
    public function view(User $user, Batch $batch)
    {

    }

    /**
     * Determine whether the user can create batches.
     *
     * @param \App\User $user
     * @return mixed
     */
    public function create(User $user)
    {
        return $user->role == "Inputter" ? $this->allow() : $this->deny("you are not allowed to do uploads");
    }

    public function authorizeBatch(User $user)
    {
        return $user->role == "Authoriser" ? $this->allow() : $this->deny("you are not allowed to authorize batches");
    }

    /**
     * Determine whether the user can update the batch.
     *
     * @param \App\User $user
     * @param \App\Batch $batch
     * @return mixed
     */
    public function update(User $user, Batch $batch)
    {
        $user->role == "Inputter" ? $this->allow() : $this->deny("you are not allowed to do uploads");
    }

    /**
     * Determine whether the user can delete the batch.
     *
     * @param \App\User $user
     * @param \App\Batch $batch
     * @return mixed
     */
    public function delete(User $user, Batch $batch)
    {
        //
    }

    /**
     * Determine whether the user can restore the batch.
     *
     * @param \App\User $user
     * @param \App\Batch $batch
     * @return mixed
     */
    public function restore(User $user, Batch $batch)
    {
        //
    }

    /**
     * Determine whether the user can permanently delete the batch.
     *
     * @param \App\User $user
     * @param \App\Batch $batch
     * @return mixed
     */
    public function forceDelete(User $user, Batch $batch)
    {
        //
    }
}
