<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class BatchRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'batch_reference'=>'required|mimes:csv,txt|unique:batches,batch_reference',
            'batch_currency'=>'required',
            'destination_account'=>'required',
            'batch_name'=>'required',
        ];
    }
}
