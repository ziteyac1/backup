<?php

namespace App\Http\Controllers;

use App\AuthCount;
use App\Batch;
use App\Record;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
class ReportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
     $this->UpdateBacthStatus();   
        $batches = Batch::query()->latest()->get();
        return view('reports.batches.index', compact('batches'));
    }


    public function UpdateBacthStatus()
    {
        $checkBatch = Batch::query()->where('status', 2)->get();
        foreach ($checkBatch as $checkB) {
            $records = count(Record::query()->where('batch_reference',$checkB->batch_reference)->get());           
            $responseNum = count(Record::query()->where('batch_reference',$checkB->batch_reference)
                    ->where('respose', '<>' , '')->get());
            Log::info($records);
            Log::info($responseNum);
           
            if($records == $responseNum)
            {
                 $checkB->update([
                    'status' => 3
                ]);
            }
        }

        return;
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

//        $response = Http::asForm()->get('http://196.2.66.6:8010/api/fetchToken', [
//            'username' => 'Premier',
//            'password' => 'premier@apiagribank'
//        ])->body();
//        $token = json_decode($response);
//        $checkBatch = Batch::query()->where('status', 2)->get();
//        foreach ($checkBatch as $checkB) {
//            $records = Record::query()->where('batch_reference',$checkB->batch_reference)->where('response', '=', "")->orWhere('response', '=', null)->get();
//            foreach ($records as $record) {
//                $reco = Http::withToken($token)->asForm()->post('http://196.2.66.6:8010/api/search/premier', [
//                    'batch_number' => trim($record->batch_reference),
//                    'credit_acc' => $record->credit_account
//                ])->body();
//                $rec = json_decode($reco);
//                dd($rec);
//                if($rec[0]->result==1){
//                    $response=$rec[0]->description;
//                    $result=$rec[0]->result;
//                }
//                else{
//                    $res=explode(',',$rec[0]->description);
//                    $response=$res[2];
//                    $result=$rec[0]->result;
//                }
//                $record->update([
//                    'response' => $response,
//                    'result'=>$result
//                ]);
//            }
//            $verify=Record::query()->where('batch_reference', $checkB->batch_reference)->where('response', '=', "")->orWhere('response', '=', null)->count();
//            if ($verify<=0) {
//                $checkB->update([
//                    'status' => 3
//                ]);
//            }
//        }


//        $response = Http::asForm()->post('http://196.2.66.6:8010/api/fetchToken', [
//            'username' => 'Premier',
//            'password' => 'premier@apiagribank'
//        ])->body();
//        $token = json_decode($response);
//
//        dd($token);


        $batch = Batch::query()->with('records')->where('id', $id)->first();
        $sum = Record::query()->where('batch_reference', $batch->batch_reference)->sum('amount');
        $total = Record::query()->where('batch_reference', $batch->batch_reference)->count();
        $success = Record::query()->where('batch_reference', $batch->batch_reference)->where('result', "1")->count();
        $failed = Record::query()->where('batch_reference', $batch->batch_reference)->where('result', "0")->count();
        $authCount = AuthCount::query()->value("auth_count");
        $successSum = Record::query()->where('batch_reference', $batch->batch_reference)->where('result', "1")->sum('amount');
        $failedSum = Record::query()->where('batch_reference', $batch->batch_reference)->where('result', "0")->sum('amount');
        $authorisers = User::query()->where('role', "Authoriser")->get();//->take($authCount);
        return view('reports.batches.show', compact('batch', 'sum', 'authorisers', 'total', 'success', 'failed', 'failedSum', 'successSum'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
