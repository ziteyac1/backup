<?php

namespace App\Http\Controllers;

use App\AuthCount;
use App\Http\Requests\AuthRequest;
use Illuminate\Http\Request;

class AuthCountController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $authorisation=AuthCount::all();
        return view('AuthCount.index',compact('authorisation'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('AuthCount.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AuthRequest $request)
    {
        AuthCount::query()->firstOrCreate([
            'auth_count'=>$request['auth_count']
        ]);

        return redirect()->route('authorisations')->withStatus("Auth Count Successfully set");
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\AuthCount  $authCount
     * @return \Illuminate\Http\Response
     */
    public function show(AuthCount $authCount)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\AuthCount  $authCount
     * @return \Illuminate\Http\Response
     */
    public function edit(AuthCount $authCount)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\AuthCount  $authCount
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AuthCount $authCount)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\AuthCount  $authCount
     * @return \Illuminate\Http\Response
     */
    public function destroy(AuthCount $authCount)
    {
        try{
            $authCount->delete();
            return redirect()->route('authorisations')->withStatus("Batch Authorisation Count Removed From the System");
        }
        catch(\Exception $ex){

        }
    }
}
