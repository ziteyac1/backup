<?php

namespace App\Http\Controllers;

use App\AuthCount;
use App\Batch;
use App\BatchAuth;
use App\BatchParameter;
use App\Transaction;
use App\DebitDestinationAccount;
use App\Http\Requests\BatchRequest;
use App\Imports\BatchImport;
use App\Jobs\PostBatchJob;
use App\Record;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;
use App\Jobs\ImportFileJob;
use App\Jobs\ProcessPaymentJob;
use Auth;
class BatchController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        $batches = Batch::query()->where('remaining_authorisations', '>', 0)->get();
        return view('batches.index', compact('batches'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function create()
    {
        $this->authorize('create', Batch::class);
        $accounts = DebitDestinationAccount::all();
        return view('batches.upload', compact('accounts'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(BatchRequest $request)
    {
        if ($file = $request->File('batch_reference')) {
            /*$bk = $request->file('statement');
            $bk_state = date('YmdHis').$id."bk.". $bk->getClientOriginalExtension();*/
            $batchName = $request->input('batch_name');

            /*$today = date('Ymdhis');
            $autoBatchName = "SALPM".$today."001";*/

            $name = $file->getClientOriginalName();
            $ext = $file->getClientOriginalExtension();

            $newBatchName = $batchName.".".$ext;
            
            $ref=explode('.',$newBatchName);
            
            $check=Batch::query()->where('batch_reference',$ref[0])->exists();
            
            if(!$check) {                             
                //Excel::import(new BatchImport($ref[0]), request()->file('batch_reference')); 
                /*InportFileJob::dispatch($ref[0]); */                   
                BatchParameter::query()->firstOrCreate([
                    'batch_reference' => $ref[0],
                    'currency' => $request->input('batch_currency'),
                    'destination_bank' => $request->input('destination_account')
                ]);
                
                $file->move('uploads/batches', $newBatchName);
                //ImportFileJob::dispatch($newBatchName, $request->input('batch_currency'), auth::user()->name);
                $this->RecordBatch($newBatchName, $request->input('batch_currency'), auth::user()->name ,$batchName );
                return redirect()->route('batches')->withStatus('Batch successfully uploaded');
            }
            else{
                return redirect()->route('createBatch')->withError('This Batch already exists in the system, please verify and re-upload');
            }
        }
    }

    private function RecordBatch($batch_reference, $currencyCode, $username, $batch_name_original)
    {
        # code...
        $file_path = base_path('public/uploads/batches/'.$batch_reference);

        $obtain_filename = basename($file_path);
        $batchName = explode(".", $obtain_filename)[0];

        $authCount = AuthCount::query()->latest()->first();
        $batch_param = BatchParameter::query()->where('batch_reference', $batch_name_original)->first();
        $debits = DebitDestinationAccount::query()->where('account_name', $batch_param->destination_bank)->first();
        $batch = Batch::query()->firstOrCreate(
           [
                'batch_reference' => $batchName,
                'inputter'  => $username, 
                'currency' => $currencyCode,
                'remaining_authorisations' => $authCount->auth_count,
                'status' => '0'
           ]
        );

        
        $lines = file($file_path ,  FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $key => $line) {

            if ($key === 0) {
                continue;
            }

            $array = explode(",", $line);
            list($date, 
                $remitter_account_number, 
                $beneficiary_bank_name, 
                $beneficiary_bank_code, 
                $beneficiary_account_number,
                $beneficiary_name,
                $amount, 
                $currency, 
                $reference, 
                $remitter_name) = $array;

            $result = null;
            $desc = null;
            $dt = strtotime($date);
            $newdate = date('Y-m-d',$dt);

            /** @var Payment $p */
            $p =  Record::query()->create(
                [
                    'batch_id' => $batch->id,
                    'date' => $newdate,
                    'batch_reference' => $batchName,
                    'remitter_account_number' => $debits->account_number,                        
                    'remitter_name' =>  $remitter_name,
                    'beneficiary_bank_name'  =>  $beneficiary_bank_name,
                    'beneficiary_bank_code' => $beneficiary_bank_code,
                    'beneficiary_account_number' => $beneficiary_account_number,
                    'beneficiary_name' => $beneficiary_name,
                    'amount' => $amount,                        
                    'currency' => $batch_param->currency,
                    'reference'=> $reference,
                    'respose' => $desc,
                    'result' => $result
                ]
            );
            
        }
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $batch = Batch::query()->with('records')->where('id', $id)->first();
        $sum = Record::query()->where('batch_reference', $batch->batch_reference)->sum('amount');
        $total=Record::query()->where('batch_reference',$batch->batch_reference)->count();
        $success=Record::query()->where('batch_reference',$batch->batch_reference)->where('result',"1")->count();
        $failed=Record::query()->where('batch_reference',$batch->batch_reference)->where('result',"0")->count();
        $successSum=Record::query()->where('batch_reference',$batch->batch_reference)->where('result',"1")->sum('amount');
        $failedSum=Record::query()->where('batch_reference',$batch->batch_reference)->where('result',"0")->sum('amount');
        $authCount=AuthCount::query()->value("auth_count");
        $authorisers=User::query()->where('role',"Authoriser")->get();//->take($authCount);
        return view('batches.show', compact('batch', 'sum','authorisers','total','success','failed','successSum','failedSum'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Batch $batch)
    {
        try {
            if (($batch->status == "0") and (auth()->user()->role != "General")) {
                $batch->delete();
                BatchParameter::query()->where('batch_reference',$batch->batch_reference)->delete();
                Storage::disk('UploadPath')->delete($batch->batch_reference . ".csv");
                return redirect()->route('batches')->withStatus("Batch Successfully Rolled Back");
            }
            elseif ((auth()->user()->role == "Authoriser") and ($batch->remaining_authorisations != 0)) {
                $batch->delete();
                BatchParameter::query()->where('batch_reference',$batch->batch_reference)->delete();
                Storage::disk('UploadPath')->delete($batch->batch_reference . ".csv");
                BatchAuth::query()->where('batch',$batch->batch_reference)->delete();
                return redirect()->route('batches')->withStatus("Batch Successfully Rolled Back");
            } else {
                return redirect()->route('batches')->withError("Rolling back not allowed");
            }
        } catch (\Exception $ex) {

        }
    }

    public function authorizeBatch(Batch $batch)
    {
        $this->authorize('authorizeBatch', Batch::class);
        $remain = $batch->remaining_authorisations;
        $check = BatchAuth::query()->where('batch', $batch->batch_reference)->where('authoriser', auth()->user()->name)->first();
        if (auth()->user()->role != "Authoriser") {
            return redirect()->route('batches')->withError("Only authorisers are allowed to authorize uploads");
        } elseif ($check) {
            return redirect()->route('batches')->withError("You previously authorised this batch, ask other authorisers to do the same");
        } elseif ($batch->remaining_authorisations == 0) {
            return redirect()->route('batches')->withError("All required authorisations for this batch were done before");
        } else {
            BatchAuth::query()->create([
                'batch' => $batch->batch_reference,
                'authoriser' => auth()->user()->name,
            ]);

/*            if($batch->remaining_authorisations == 1)
            {
                $response = Http::asForm()->post('http://196.2.66.6:8010/api/fetchToken', [
                    'username' => 'Premier',
                    'password' => 'premier@apiagribank'
                ])->body();
                $token = json_decode($response);
            }*/
            $batch->update([
                'remaining_authorisations' => $remain - 1,
                'status' => '1'
            ]);
            if ($batch->remaining_authorisations == 0) {
                $batch->update([
                    'status' => '2'
                ]);
                //call the service thats gona send the batch to a remote service
               // PostBatchJob::dispatch($batch);
                $records = Record::query()->where('batch_reference', $batch->batch_reference)->get();
                foreach ($records as $record) {
                    # code...nsac
                    $tr = Transaction::query()->create([
                        'record_id'  => $record->id,                        
                        'amount' => $record->amount,
                        'batch_id' => $record->batch_reference,
                    ]);

                    ProcessPaymentJob::dispatch($record, $tr);
                }
                return redirect()->route('batches')->withStatus("Batch Successfully Authorised");
            }
            return redirect()->route('batches')->withStatus("Batch Successfully Authorised");
        }
    }

}
