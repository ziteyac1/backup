<?php

namespace App\Http\Controllers;

use App\DebitDestinationAccount;
use App\Http\Requests\DebitDestinationAccountRequest;
use Illuminate\Http\Request;

class DebitDestinationAccountController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function index()
    {
        $this->authorize('viewAny',DebitDestinationAccount::class);
        $accounts = DebitDestinationAccount::all();
        return view('debits.index', compact('accounts'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function create()
    {
        $this->authorize('create',DebitDestinationAccount::class);
        return view('debits.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function store(DebitDestinationAccountRequest $request)
    {
        $this->authorize('create',DebitDestinationAccount::class);
        DebitDestinationAccount::query()->create([
            'account_name'=>$request['account_name'],
            'account_number'=>$request['account_number']
        ]);
        return redirect()->route('accounts')->withStatus("Account Successfully Created");
    }

    /**
     * Display the specified resource.
     *
     * @param \App\DebitDestinationAccount $debitDestinationAccount
     * @return \Illuminate\Http\Response
     */
    public function show(DebitDestinationAccount $debitDestinationAccount)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param \App\DebitDestinationAccount $debitDestinationAccount
     * @return \Illuminate\Http\Response
     */
    public function edit(DebitDestinationAccount $debitDestinationAccount)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param \App\DebitDestinationAccount $debitDestinationAccount
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DebitDestinationAccount $debitDestinationAccount)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param \App\DebitDestinationAccount $debitDestinationAccount
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function destroy(DebitDestinationAccount $account)
    {
        $this->authorize('delete',$account);
        try{
            $account->delete();
            return redirect()->route('accounts')->withStatus("Account Successfully Removed");

    }catch(\Exception $ex){

    }
    }
}
