<?php

namespace App\Http\Controllers;
use App\Batch;
use App\Record;
use App\Jobs\GetResponseJob;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use GuzzleHttp\Psr7;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Exception\ClientException;
class RefreshBatchController extends Controller
{
       /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function refresh()
    {   
        $records = DB::select('SELECT * from records where result IS NULL and respose IS NULL');
        foreach ($records as $record) {          
            GetResponseJob::dispatch($record);
        } 
        $this->UpdateBacthStatus();
        //dd("Success");
        return redirect()->back()->withStatus('Your batches have been refreshed.!');
    }

    public function UpdateBacthStatus()
    {
        $checkBatch = Batch::query()->where('status', 2)->get();
        foreach ($checkBatch as $checkB) {
            $records = count(Record::query()->where('batch_reference',$checkB->batch_reference)->get());           
            $responseNum = count(Record::query()->where('batch_reference',$checkB->batch_reference)
                    ->where('respose', '<>' , '')->get());
           
            if($records == $responseNum)
            {
                 $checkB->update([
                    'status' => 3
                ]);
            }
        }

        return redirect()->back()->withSuccessMessage('Your batches have been refreshed.!');
    }

    public function ReturnData()
    {
         return [
              'destination_acc' => '0011000100000',
              'transaction_type' => 'ACPT',
              'beneficiary' => 'Rosyna Jani',
              'currency' => 'ZWL',
              'credit_account' => '0011000100030',
              'transaction_date' => '19-05-2020',
              'amount' => 3400,
              'debit_acount' => '100010001000',
              'company_name' => 'Boka',
              'batch_reference' => '1002546',
              'transaction_id' => '2166',
              'bank_code' => 'AGRZZWHA'
         ];

    }

    public function JsonData()
    {
         return json_encode([
              'destination_acc' => '0011000100000',
              'transaction_type' => 'ACPT',
              'beneficiary' => 'Rosyna Jani',
              'currency' => 'ZWL',
              'credit_account' => '0011000100030',
              'transaction_date' => '19-05-2020',
              'amount' => 3400,
              'debit_acount' => '100010001000',
              'company_name' => 'Boka',
              'batch_reference' => '1002546',
              'transaction_id' => '2166',
              'bank_code' => 'AGRZZWHA'
         ]);

    }

    public function storeRecord($data)
    {

        $transType = Arr::get($data, 'transaction_type');
        $beneficiary = Arr::get($data, 'beneficiary');
        $currency = Arr::get($data, 'currency');
        $credit_account = Arr::get($data, 'credit_account');
        $transaction_date = Arr::get($data, 'transaction_date');
        $amount = Arr::get($data, 'amount');
        $debit_acount = Arr::get($data, 'debit_acount');
        $company_name = Arr::get($data, 'company_name');
        $batch_reference = Arr::get($data, 'batch_reference');
        $transaction_id = Arr::get($data, 'transaction_id');
        $bank_code = Arr::get($data, 'bank_code');

        $checkExists = DB::select('select * from test_payments where credit_acc = ? and payment_details = ? and amount = ? ', 
          [
            $credit_account, 
            $batch_reference, 
            $amount
          ]);
        if(count($checkExists) > 0 )
        {
          return;
        }

        $payment = DB::insert('insert into test_payments
         values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
          [
              $transType,
              $beneficiary,
              $currency,
              $credit_account,
              $transaction_date,
              $amount, 
              $debit_acount,
              $company_name,
              $batch_reference,
              $transaction_id,
              $bank_code
          ]);  

    }
}
