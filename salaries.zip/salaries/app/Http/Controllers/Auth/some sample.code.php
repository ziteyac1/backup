<?php


        return redirect()->back();
        try {
                $client = new Client();
                $request = $client->request('POST', 'http://196.2.66.6:8010/api/fetchToken',
                [
                    'username' => 'Premier',
                    'password' => 'premier@apiagribank'
                ])->body();

                if($client)
                {
                    echo "connected to the net";
                }

                 //$status = $request->getStatusCode();
                 echo $request;
            } 
            catch (RequestException $e) 
            {
                echo Psr7\str($e->getRequest());
                if ($e->hasResponse()) {
                    echo Psr7\str($e->getResponse());
                }
                echo  $e->getResponse()->getStatusCode();
            }
             catch (ClientException $e) {
            // This will catch all 400 level errors.
                return $e->getResponse()->getStatusCode();
            }
           

        /*$connected = @fsockopen("http://196.2.66.6:8010/", 80); 
                                            //website, port  (try 80 or 443)
        if ($connected){
            $is_conn = true; //action when connected
            echo "connected";
            fclose($connected);
        }else{
            $is_conn = false; //action in connection failure
            echo "not connected";
        }*/
        return;

       /*
        $response = Http::asForm()->post('http://196.2.66.6:8010/api/fetchToken', [
            'username' => 'Premier',
            'password' => 'premier@apiagribank'
        ])->body();
        $token = json_decode($response);
        if (!$token) {
            # code...
            return redirect()->back()->withError('Your are not connected to the internet contact your network administrator.!');
        }*/

        $data = $this->ReturnData();
        $cdacc = $data['credit_account'];
        $dtcc = Arr::get($data, 'destination_acc');
        echo($cdacc.'<br>');
        echo($dtcc);

        $json = $this->JsonData();
        dd($json);