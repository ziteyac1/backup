<?php

namespace App\Http\Controllers;

use App\BatchAuth;
use Illuminate\Http\Request;

class BatchAuthController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\BatchAuth  $batchAuth
     * @return \Illuminate\Http\Response
     */
    public function show(BatchAuth $batchAuth)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\BatchAuth  $batchAuth
     * @return \Illuminate\Http\Response
     */
    public function edit(BatchAuth $batchAuth)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\BatchAuth  $batchAuth
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, BatchAuth $batchAuth)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\BatchAuth  $batchAuth
     * @return \Illuminate\Http\Response
     */
    public function destroy(BatchAuth $batchAuth)
    {
        //
    }
}
