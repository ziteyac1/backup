<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BatchParameter extends Model
{
    protected $guarded=[];
}
