<?php

namespace App\Console\Commands;

use DB;
use App\Batch;
use App\Record;
use App\Jobs\GetResponseJob;
use Illuminate\Support\Facades\Log;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Http;

class CheckResponse extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'check:response';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Check responses for uploaded batch records';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
   public function handle()
    {        
       $records = DB::select('SELECT * from records where result IS NULL and respose IS NULL');
        foreach ($records as $record) {          
            GetResponseJob::dispatch($record);
        }
        $this->UpdateBacthStatus();
    }

    public function UpdateBacthStatus()
    {
        $checkBatch = Batch::query()->where('status', 2)->get();
        foreach ($checkBatch as $checkB) {
            $records = count(Record::query()->where('batch_reference',$checkB->batch_reference)->get());
            $responseNum = count(Record::query()->where('batch_reference',$checkB->batch_reference)
                    ->where('respose', '<>' , '')->get());
            if($records == $responseNum)
            {
                 $checkB->update([
                    'status' => 3
                ]);
            }
        }
    }
}
