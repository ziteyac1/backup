package zw.agribank.echannels;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EchannelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
