package zw.agribank.echannels.core;

public class Config {
    public static String host = "192.168.0.197";
}
