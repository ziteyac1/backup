package zw.agribank.echannels.requests.balance;

import org.jpos.iso.ISOChannel;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOField;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.channel.PostChannel;
import org.jpos.iso.packager.GenericPackager;
import org.springframework.core.io.ClassPathResource;
import zw.agribank.echannels.core.Config;
import zw.agribank.echannels.core.Helper;
import zw.agribank.echannels.core.PostilionAdapterRequest;

import javax.validation.constraints.NotBlank;
import java.io.IOException;
import java.util.HashMap;

public class Request {

    @NotBlank
    private String pan;

    @NotBlank
    private String phone;

    @NotBlank
    private String id;

    @NotBlank
    private String application;

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public PostilionAdapterRequest build() throws ISOException, IOException {

        GenericPackager packager = new GenericPackager(new ClassPathResource("iso/mobile.xml").getInputStream());
        ISOChannel isoChannel = new PostChannel(
                Config.host,
                8000,
                packager
        );

        HashMap<String,String> map = new HashMap<>();
        map.put("MSDN" , this.getPhone());
        map.put("Channel" , "IB");
        String structuredData = Helper.buildStructuredData(map);

        ISOMsg message = new ISOMsg();
        message.setMTI("0200");
        message.setPackager(packager);
        message.set(2 ,this.getPan());
        message.set(new ISOField(3, "310000"));
        message.set(new ISOField(4, "0"));
        message.set(new ISOField(7, Helper.getFormattedDate("MMddHHmmss")));
        message.set(new ISOField(11, this.getId()));
        message.set(new ISOField(12, Helper.getFormattedDate("HHmmss")));
        message.set(new ISOField(13, Helper.getFormattedDate("MMdd")));
        message.set(new ISOField(14, "2612"));
        message.set(new ISOField(22, "000"));
        message.set(new ISOField(25, "00000771"));
        message.set(new ISOField(41, "00000771"));
        message.set(new ISOField(42, "000000000000251"));
        message.set(new ISOField(49, "840"));
        message.set(new ISOField(123, "100450100130021"));
        message.set("127.2" , this.getId());
        message.set("127.22" , structuredData);

        return  new PostilionAdapterRequest(message , isoChannel , this.getId() , this.getApplication());

    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getApplication() {
        return application;
    }

    public void setApplication(String application) {
        this.application = application;
    }
}
