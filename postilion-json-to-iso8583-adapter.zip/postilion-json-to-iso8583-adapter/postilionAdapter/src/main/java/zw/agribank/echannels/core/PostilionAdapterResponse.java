package zw.agribank.echannels.core;

import org.jpos.iso.ISOMsg;
import zw.agribank.echannels.entity.Transaction;

public class PostilionAdapterResponse {

    private ISOMsg response;
    private Transaction transaction;

    public PostilionAdapterResponse(ISOMsg response , Transaction transaction)
    {
        this.response = response;
        this.transaction = transaction;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public ISOMsg getResponse() {
        return response;
    }

    public void setResponse(ISOMsg response) {
        this.response = response;
    }
}
