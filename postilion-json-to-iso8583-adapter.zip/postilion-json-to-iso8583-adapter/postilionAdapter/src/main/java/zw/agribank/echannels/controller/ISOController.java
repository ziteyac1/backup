package zw.agribank.echannels.controller;

import org.jpos.iso.ISOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import zw.agribank.echannels.core.ApiResponse;
import zw.agribank.echannels.core.PostilionAdapterResponse;
import zw.agribank.echannels.service.Adapter;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.IOException;

@RestController
public class ISOController {

    private static final Logger logger = LoggerFactory.getLogger(ISOController.class);

    @Autowired
    private Adapter adapter;

    @GetMapping("/welcome")
    public ResponseEntity<Object> welcome()
    {
        return ApiResponse.start()
                    .success()
                    .message("Welcome to the JSON to IS0 Postilion Adapter")
                .build();
    }

    @PostMapping("/enquiry/balance")
    public  ResponseEntity<Object> balance(@Valid @RequestBody zw.agribank.echannels.requests.balance.Request request, HttpServletRequest header) throws IOException, ISOException {

        logger.info("Incoming balance request for card : "  + request.getPan());

        PostilionAdapterResponse response =  this.adapter.send(request.build() , header);

        return  ApiResponse.start().success(response.getTransaction().hasError() , response.getTransaction().getError())
                    .data("reference" , response.getTransaction().getId())
                    .data("result" , new zw.agribank.echannels.requests.balance.Response(response))
                .build();
    }


    @PostMapping("/transfer/agriplus")
    public  ResponseEntity<Object> agriplus(@Valid @RequestBody zw.agribank.echannels.requests.agriplus.Request request, HttpServletRequest header) throws IOException, ISOException {

        logger.info("Incoming Agriplus Transfer to card : "  + request.getPan());

        PostilionAdapterResponse response =  this.adapter.send(request.build() , header);

        return  ApiResponse.start().success(response.getTransaction().hasError() , response.getTransaction().getError())
                    .data("reference" , response.getTransaction().getId())
                    .data("result" , new zw.agribank.echannels.requests.agriplus.Response(response))
                .build();

    }
}
