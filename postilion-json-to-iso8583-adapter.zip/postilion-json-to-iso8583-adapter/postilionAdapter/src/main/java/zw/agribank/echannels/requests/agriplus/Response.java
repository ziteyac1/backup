package zw.agribank.echannels.requests.agriplus;

import org.jpos.iso.ISOMsg;
import zw.agribank.echannels.core.Helper;
import zw.agribank.echannels.core.PostilionAdapterResponse;

public class Response {

    private String tranNr;
    private String error;
    private boolean success;
    private boolean retry = false;

    public Response(PostilionAdapterResponse response)
    {
        ISOMsg message = response.getResponse();
        if (message != null)
        {
            this.tranNr = message.getString("37");
            this.success = message.getString("39").equals("00");
            if (!this.success)
            {
                this.error = Helper.getErrorFromRspCode(message.getString("39"));
            }

            if (message.getString("37").equals("51"))
            {
                this.retry = true;
            }

        }
    }

    public String getTranNr() {
        return tranNr;
    }

    public void setTranNr(String tranNr) {
        this.tranNr = tranNr;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public boolean isRetry() {
        return retry;
    }

    public void setRetry(boolean retry) {
        this.retry = retry;
    }
}
