package zw.agribank.echannels.core;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.jpos.iso.ISOChannel;
import org.jpos.iso.ISOMsg;

public class PostilionAdapterRequest {
    private ISOMsg message;
    private ISOChannel channel;
    private  String id;
    private  String application;

    public PostilionAdapterRequest(ISOMsg message, ISOChannel channel , String id , String application) {
        this.message = message;
        this.channel = channel;
        this.id = id;
        this.application = application;
    }

    public ISOMsg getMessage() {
        return message;
    }

    public void setMessage(ISOMsg message) {
        this.message = message;
    }

    public ISOChannel getChannel() {
        return channel;
    }

    public void setChannel(ISOChannel channel) {
        this.channel = channel;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getApplication() {
        return application;
    }

    public void setApplication(String application) {
        this.application = application;
    }
}
