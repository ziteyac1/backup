package zw.agribank.echannels.requests.agriplus;

import org.hibernate.validator.constraints.Length;
import org.jpos.iso.*;
import org.jpos.iso.channel.PostChannel;
import org.jpos.iso.packager.GenericPackager;
import org.springframework.core.io.ClassPathResource;
import zw.agribank.echannels.core.Config;
import zw.agribank.echannels.core.Helper;
import zw.agribank.echannels.core.PostilionAdapterRequest;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;

public class Request {

    @Length(min = 16 , max = 16)
    private String pan;

    @NotBlank
    private String id;

    @NotNull
    private String amount;

    @NotNull
    private String application;

    public PostilionAdapterRequest build() throws ISOException, IOException {

        GenericPackager packager = new GenericPackager(new ClassPathResource("iso/agri-pay.xml").getInputStream());

        ISOChannel isoChannel = new PostChannel(
                Config.host,
                65501,
                packager
        );

        HashMap<String,String> map = new HashMap<>();
        map.put("VasApplication" , "DirectInject");
        map.put("BatchId" , "000001");
        String structuredData = Helper.buildStructuredData(map);

        ISOMsg message = new ISOMsg();
        message.setMTI("0200");
        message.setPackager(packager);
        message.set(new ISOField(2, "5048750000160006"));
        message.set(new ISOField(3, "500000"));
        message.set(new ISOField(4, ISOUtil.padleft(this.getAmount(),12, '0') ));
        message.set(new ISOField(7, Helper.getFormattedDate("MMddHHmmss")));
        message.set(new ISOField(11, "000001"));
        message.set(new ISOField(12, Helper.getFormattedDate("HHmmss")));
        message.set(new ISOField(13, Helper.getFormattedDate("MMdd")));
        message.set(new ISOField(14, "2612"));
        message.set(new ISOField(22, "000"));
        message.set(new ISOField(25, "00"));
        message.set(new ISOField(41, "AGRPAY01"));
        message.set(new ISOField(42, "0000000AGRPAY01"));
        message.set(new ISOField(49, "932")); // Currency
        message.set(new ISOField(98, ISOUtil.padleft(this.getPan() , 16 , '0')));
        message.set(new ISOField(100, "900"));
        message.set(new ISOField(102, "101000006638"));
        message.set(new ISOField(103, ISOUtil.padleft(this.getPan() , 16 , '0')));
        message.set(new ISOField(123, "100450100130021"));
        Random rn = new Random();
        message.set("127.2" , "0200:AGRPAY01:"+ ISOUtil.padleft(String.valueOf(rn.nextInt(999 - 100 + 1) + 100) + this.getId().toString()   , 12 , '0'));
        message.set("127.22" , structuredData);
        message.set("127.33" , "6001");

        return  new PostilionAdapterRequest(message , isoChannel , this.getId() , this.getApplication());

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public @NotNull String getAmount() {
        return amount;
    }

    public void setAmount(@NotNull String amount) {
        this.amount = amount;
    }

    public String getApplication() {
        return application;
    }

    public void setApplication(String application) {
        this.application = application;
    }
}
