package zw.agribank.echannels.service;

import org.jpos.iso.ISOChannel;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import zw.agribank.echannels.core.Helper;
import zw.agribank.echannels.core.PostilionAdapterResponse;
import zw.agribank.echannels.core.PostilionAdapterRequest;
import zw.agribank.echannels.entity.Transaction;
import zw.agribank.echannels.repository.TransactionRepository;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Date;

@Service
public class Adapter {

    @Autowired
    TransactionRepository transactionRepository;

    private static final Logger logger = LoggerFactory.getLogger(Adapter.class);

    public PostilionAdapterResponse send(PostilionAdapterRequest request, HttpServletRequest header)
    {

        Transaction transaction =  new Transaction();

        // Collect Initiator Information of the Request

        transaction.setAgent(header.getHeader("User-Agent"));
        transaction.setIp(header.getRemoteAddr());
        transaction.setEndPoint(header.getRequestURI());
        transaction.setStart(new Date());
        transaction.setReference(request.getId());
        transaction.setApplication(request.getApplication());

        // Save Transaction XML Details

        transaction.setRequest(Helper.isoXML(request.getMessage()));

        // Start Transaction

        transaction = transactionRepository.save(transaction);

        // Get ISO Channel for the Message

        ISOChannel channel = request.getChannel();

        logger.info("Establishing connection");


        try {

            long start = System.currentTimeMillis();

            // Connect to Postilion
            channel.connect();

            ISOMsg receive = null;

            if (channel.isConnected())
            {
                transaction.setSendTimePostilion(new Date());
                transaction = transactionRepository.save(transaction);

                logger.info("Request \n " +  Helper.isoXML(request.getMessage()) );

                // Send Message to Postilion
                channel.send(request.getMessage());

                // Receive Message to Postilion
                receive = channel.receive();

                channel.disconnect();

                logger.info("Response  \n  " + Helper.isoXML(receive));

                transaction.setRespondTimePostilion(new Date());
                transaction.setResponse(Helper.isoXML(receive));

                long end = System.currentTimeMillis();
                float sec = (end - start) / 1000F;
                transaction.setTime(sec + "");

            } else {

                transaction.setError("Postilion Connection timeout");
                transaction.setEnd(new Date());

            }

            transaction.setEnd(new Date());
            transaction = transactionRepository.save(transaction);
            return new PostilionAdapterResponse(receive , transaction);

        } catch (IOException | ISOException e) {

            transaction.setEnd(new Date());
            transaction.setError(e.getMessage());
            transaction = transactionRepository.save(transaction);
            return new PostilionAdapterResponse(null , transaction);

        }

    }
}
