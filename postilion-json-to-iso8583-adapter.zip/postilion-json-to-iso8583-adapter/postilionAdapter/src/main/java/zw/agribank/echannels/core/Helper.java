package zw.agribank.echannels.core;

import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Helper {

    public static String buildStructuredData(HashMap<String, String> map){

        StringBuilder out = new StringBuilder();

        for (Map.Entry<String, String> entry : map.entrySet())
        {
            String temp = "";

            System.out.println(entry.getKey() + " = " + entry.getValue());
            String key  = entry.getKey();
            String value  = entry.getValue();

            // Get length of key
            byte[] utf8Bytes = getBytes(key);
            int lengthOfKey = utf8Bytes.length;

            // Get length of lengthOfKey in bytes
            utf8Bytes = getBytes(Integer.toString(lengthOfKey));
            int lengthOfLengthOfKey = utf8Bytes.length;
            temp += Integer.toString(lengthOfLengthOfKey);
            temp += Integer.toString(lengthOfKey);
            temp += key;

            // Get length of value
            utf8Bytes = getBytes(value);
            int lengthOfValue = utf8Bytes.length;

            // Get length of lengthOfValue in bytes
            utf8Bytes = getBytes(Integer.toString(lengthOfValue));
            int lengthOfLengthOfValue = utf8Bytes.length;

            temp += Integer.toString(lengthOfLengthOfValue);
            temp += Integer.toString(lengthOfValue);
            temp += value;

            System.out.println(temp);
            out.append(temp);

        }

        return out.toString();

    }

    public static String getErrorFromRspCode(String code){

        HashMap<String , String> map = new HashMap<>();

        map.put("00" , "Approved or completed successfully");
        map.put("01" , "Refer to card issuer");
        map.put("02" , "Refer to card issuer, special condition");
        map.put("03" , "Invalid merchant");
        map.put("04" , "Pick-up card");
        map.put("05" , "Do not honor");
        map.put("06" , "Error");
        map.put("07" , "Pick-up card, special condition");
        map.put("08" , "Honor with identification");
        map.put("09" , "Request in progress");
        map.put("10" , "Approved, partial");
        map.put("11" , "Approved, VIP");
        map.put("12" , "Invalid transaction");
        map.put("13" , "Invalid amount");
        map.put("14" , "Invalid card number");
        map.put("15" , "No such issuer");
        map.put("16" , "Approved, update track 3");
        map.put("17" , "Customer cancellation");
        map.put("18" , "Customer dispute");
        map.put("19" , "Re-enter transaction");
        map.put("20" , "Invalid response");
        map.put("21" , "No action taken");
        map.put("22" , "Suspected malfunction");
        map.put("23" , "Unacceptable transaction fee");
        map.put("24" , "File update not supported");
        map.put("25" , "Unable to locate record");
        map.put("26" , "Duplicate record");
        map.put("27" , "File update field edit error");
        map.put("28" , "File update file locked");
        map.put("29" , "File update failed");
        map.put("30" , "Format error");
        map.put("31" , "Bank not supported");
        map.put("32" , "Completed partially");
        map.put("33" , "Expired card, pick-up");
        map.put("34" , "Suspected fraud, pick-up");
        map.put("35" , "Contact acquirer, pick-up");
        map.put("36" , "Restricted card, pick-up");
        map.put("37" , "Call acquirer security, pick-up");
        map.put("38" , "PIN tries exceeded, pick-up");
        map.put("39" , "No credit account");
        map.put("40" , "Function not supported");
        map.put("41" , "Lost card, pick-up");
        map.put("42" , "No universal account");
        map.put("43" , "Stolen card, pick-up");
        map.put("44" , "No investment account");
        map.put("45" , "Account closed");
        map.put("46" , "Identification required");
        map.put("47" , "Identification cross-check required");
        map.put("48" , "No customer record");
        map.put("49" , "Reserved for future Realtime use");
        map.put("50" , "Reserved for future Realtime use");
        map.put("51" , "Not sufficient funds");
        map.put("52" , "No check account");
        map.put("53" , "No savings account");
        map.put("54" , "Expired card");
        map.put("55" , "Incorrect PIN");
        map.put("56" , "No card record");
        map.put("57" , "Transaction not permitted to cardholder");
        map.put("58" , "Transaction not permitted on terminal");
        map.put("59" , "Suspected fraud");
        map.put("60" , "Contact acquirer");
        map.put("61" , "Exceeds withdrawal limit");
        map.put("62" , "Restricted card");
        map.put("63" , "Security violation");
        map.put("64" , "Original amount incorrect");
        map.put("65" , "Exceeds withdrawal frequency");
        map.put("66" , "Call acquirer security");
        map.put("67" , "Hard capture");
        map.put("68" , "Response received too late");
        map.put("69" , "Advice received too late");
        map.put("70" , "Reserved for future Realtime use");
        map.put("71" , "Reserved for future Realtime use");
        map.put("72" , "Reserved for future Realtime use");
        map.put("73" , "Reserved for future Realtime use");
        map.put("74" , "Reserved for future Realtime use");
        map.put("75" , "PIN tries exceeded");
        map.put("76" , "Reserved for future Realtime use");
        map.put("77" , "Intervene, bank approval required");
        map.put("78" , "Intervene, bank approval required for partial amount");
        map.put("79" , "Error");
        map.put("80" , "Error");
        map.put("81" , "Error");
        map.put("82" , "Error");
        map.put("83" , "Error");
        map.put("84" , "Error");
        map.put("85" , "Error");
        map.put("86" , "Error");
        map.put("87" , "Error");
        map.put("88" , "Error");
        map.put("89" , "Error");
        map.put("90" , "Cut-off in progress");
        map.put("91" , "Issuer or switch inoperative");
        map.put("92" , "Routing error");
        map.put("93" , "Violation of law");
        map.put("94" , "Duplicate transaction");
        map.put("95" , "Reconcile error");
        map.put("96" , "System malfunction");
        map.put("97" , "Reserved for future Realtime use");
        map.put("98" , "Exceeds cash limit");
        map.put("99" , "Reserved for future Realtime use");

        return map.getOrDefault(code, "Error");
    }

    public static String getFormattedDate(String format)
    {
        Date date = new Date();
        Format formatter = new SimpleDateFormat(format);
        return  formatter.format(date);
    }

    public static String isoXML(ISOMsg msg)
    {
        try {

            ByteArrayOutputStream os = new ByteArrayOutputStream();
            PrintStream ps = new PrintStream(os);
            msg.dump(ps , "");
            return os.toString("UTF8");

        } catch (Exception e) {
            e.printStackTrace();
        }

        return "";
    }



    private static byte[] getBytes(String s) {
        return s.getBytes(StandardCharsets.UTF_8);
    }

}
