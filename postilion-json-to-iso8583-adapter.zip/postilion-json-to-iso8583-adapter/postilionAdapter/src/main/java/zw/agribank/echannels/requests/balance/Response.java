package zw.agribank.echannels.requests.balance;

import zw.agribank.echannels.core.PostilionAdapterResponse;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Response {

    private String balance;

    public Response(PostilionAdapterResponse response)
    {

    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }
}
