package zw.agribank.echannels.requests.statement;

import zw.agribank.echannels.requests.Config;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.util.ArrayList;

public class Request {

    @NotBlank
    private String account;

    @NotBlank
    private String version;

    private String id;
    private String application;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @NotEmpty
    private ArrayList<Parameter> parameters;

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String build()
    {

        StringBuilder out = new StringBuilder("ENQUIRY.SELECT,," + Config.username + "/" + Config.password + "," + getVersion() + ",ACCT.ID:EQ=" + getAccount());

        for (Parameter parameter : getParameters())
        {
            out.append(",").append(parameter.getField()).append(":").append(parameter.getSign()).append("=").append(parameter.getValue());
        }

        return out.toString();
    }

    public ArrayList<Parameter> getParameters() {
        return parameters;
    }

    public void setParameters(ArrayList<Parameter> parameters) {
        this.parameters = parameters;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getApplication() {
        return application;
    }

    public void setApplication(String application) {
        this.application = application;
    }
}
