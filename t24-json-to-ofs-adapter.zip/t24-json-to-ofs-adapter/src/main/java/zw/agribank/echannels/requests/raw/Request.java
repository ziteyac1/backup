package zw.agribank.echannels.requests.raw;

import javax.validation.constraints.NotBlank;

public class Request {

    @NotBlank
    private String message;

    private String id;
    private String application;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getApplication() {
        return application;
    }

    public void setApplication(String application) {
        this.application = application;
    }
}
