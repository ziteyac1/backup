package zw.agribank.echannels.requests.rtgs;

import zw.agribank.echannels.requests.Config;
import zw.agribank.echannels.requests.transfer.Detail;

import javax.validation.constraints.NotEmpty;
import java.util.ArrayList;

public class Request {

    @NotEmpty
    private String debit;

    @NotEmpty
    private String version;

    @NotEmpty
    private String amount;

    @NotEmpty
    private String currency;

    @NotEmpty
    private String bankId;

    @NotEmpty
    private String name;

    @NotEmpty
    private String receive;

    @NotEmpty
    private String bankCode;

    @NotEmpty
    private String reason;

    private String id;
    private String application;

    private ArrayList<Detail> details;

    public ArrayList<Detail> getDetails() {
        return details;
    }

    public void setDetails(ArrayList<Detail> details) {
        this.details = details;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String build()
    {
        StringBuilder out = new StringBuilder("FUNDS.TRANSFER," + getVersion()
                + "//PROCESS//0,"
                + Config.username + "/" + Config.password
                + ",,DEBIT.ACCT.NO=" + getDebit()
                + ",CREDIT.AMOUNT=" + getAmount()
                + ",CREDIT.CURRENCY=" + getCurrency()
                + ",PAYMENT.DETAILS:1=" + getName()
                + ",PAYMENT.DETAILS:2=" + getReceive()
                + ",PAYMENT.DETAILS:3=" + getBankCode()
                + ",PAYMENT.DETAILS:4=" + getReason()
                + ",BANK.BIC.CODE=" + getBankId()
                + "");

        if (details != null )
        {
            for (Detail parameter : getDetails())
            {
                out.append(",").append(parameter.getField()).append("=").append(parameter.getValue());
            }
        }

        return out.toString();
    }

    public String getDebit() {
        return debit;
    }

    public void setDebit(String debit) {
        this.debit = debit;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getBankId() {
        return bankId;
    }

    public void setBankId(String bankId) {
        this.bankId = bankId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getReceive() {
        return receive;
    }

    public void setReceive(String receive) {
        this.receive = receive;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getApplication() {
        return application;
    }

    public void setApplication(String application) {
        this.application = application;
    }
}
