package zw.agribank.echannels.requests.rtgs;

public class Value {


    private String item;
    private String value;

    public Value(String item , String value){
        this.item = item;
        this.value = value;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }


    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
