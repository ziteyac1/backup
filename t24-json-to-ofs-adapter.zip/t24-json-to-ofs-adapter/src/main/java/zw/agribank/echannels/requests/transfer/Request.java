package zw.agribank.echannels.requests.transfer;

import zw.agribank.echannels.requests.Config;
import zw.agribank.echannels.requests.statement.Parameter;

import javax.validation.constraints.NotEmpty;
import java.util.ArrayList;

public class Request {

    @NotEmpty
    private String debit;
    @NotEmpty
    private String credit;
    @NotEmpty
    private String amount;
    @NotEmpty
    private String currency;
    @NotEmpty
    private String reference;
    @NotEmpty
    private String version;
    @NotEmpty
    private String auth;
    private ArrayList<Detail> details;

    private String id;
    private String application;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String build()
    {
        StringBuilder out = new StringBuilder("FUNDS.TRANSFER," + getVersion() + "//PROCESS//" + getAuth() + "," + Config.username +"/" +Config.password+",,DEBIT.ACCT.NO="+getDebit()+",CREDIT.ACCT.NO="+getCredit()+",DEBIT.AMOUNT=" + getAmount() + ",DEBIT.CURRENCY="+getCurrency()+",PAYMENT.DETAILS:1=" + getReference());

        if (details != null)
        for (Detail parameter : getDetails())
        {
            out.append(",").append(parameter.getField()).append("=").append(parameter.getValue());
        }

        return out.toString();

    }


    public String getDebit() {
        return debit;
    }

    public void setDebit(String debit) {
        this.debit = debit;
    }

    public String getCredit() {
        return credit;
    }

    public void setCredit(String credit) {
        this.credit = credit;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public ArrayList<Detail> getDetails() {
        return details;
    }

    public void setDetails(ArrayList<Detail> details) {
        this.details = details;
    }

    public String getAuth() {
        return auth;
    }

    public void setAuth(String auth) {
        this.auth = auth;
    }

    public String getApplication() {
        return application;
    }

    public void setApplication(String application) {
        this.application = application;
    }
}
