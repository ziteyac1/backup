package zw.agribank.echannels.requests.balance;

import zw.agribank.echannels.requests.Config;

import javax.validation.constraints.NotBlank;

public class Request {

    @NotBlank
    private String account;

    private String id;
    private String application;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String build()
    {
        return  "ENQUIRY.SELECT,," + Config.username + "/" + Config.password + ",BAL.ENQ,ACCOUNT.NUMBER:EQ="+ getAccount();
    }


    public String getApplication() {
        return application;
    }

    public void setApplication(String application) {
        this.application = application;
    }
}
