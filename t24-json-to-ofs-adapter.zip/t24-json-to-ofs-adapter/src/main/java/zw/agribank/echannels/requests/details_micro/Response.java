package zw.agribank.echannels.requests.details_micro;

public class Response {

    private String account;
    private String name;
    private String type;
    private String currency;
    private String branch;
    private String balance;
    private String error = "";

    public Response(String ofs){

        // Ledger

        String[] out = ofs.split(",");

        if (out.length >= 2 )
        {
            String[] details = out[2].split("\"\\.\"");
            if (details.length >= 8)
            {
                this.account = details[1].replaceAll("\"" ,"");
                this.name = details[4].replaceAll("\"" ,"");
                this.type = details[5].replaceAll("\"" ,"");
                this.currency = details[6].replaceAll("\"" ,"");
                this.branch = details[7].replaceAll("\"" ,"");
                this.balance = details[8].replaceAll("\"" ,"");
            } else {
                this.error = out[out.length - 1];
            }
        }
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }
}
