package zw.agribank.echannels.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import zw.agribank.echannels.core.ApiResponse;
import zw.agribank.echannels.entity.Transaction;
import zw.agribank.echannels.service.Adapter;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
public class OFSController {

    private static final Logger logger = LoggerFactory.getLogger(OFSController.class);

    @Autowired
    private Adapter adapter;

    @GetMapping("/welcome")
    public ResponseEntity<Object> welcome()
    {
        return ApiResponse.start()
                    .success()
                    .message("Welcome to the JSON to OFS T24 Adapter")
                .build();
    }

    @PostMapping("/ofs/raw")
    public ResponseEntity<Object> raw(@Valid @RequestBody zw.agribank.echannels.requests.raw.Request request , HttpServletRequest header)
    {
        logger.info("Incoming raw request : "  + request.getMessage());

        Transaction transaction = this.adapter.send(request.getMessage()  , header , request.getId() , request.getApplication());

        return  ApiResponse.start().success(transaction.hasError() , transaction.getError())
                    .data("reference" , transaction.getId())
                    .data("result" , new zw.agribank.echannels.requests.raw.Response(transaction.getResponse()))
                .build();
    }

    @PostMapping("/enquiry/statement")
    public ResponseEntity<Object> statement(@Valid @RequestBody zw.agribank.echannels.requests.statement.Request request, HttpServletRequest header){

        logger.info("Incoming statement request for account : "  + request.getAccount());

        Transaction transaction =  this.adapter.send(request.build() , header , request.getId() , request.getApplication());

        return  ApiResponse.start().success(transaction.hasError() , transaction.getError())
                    .data("reference" , transaction.getId())
                    .data("result" , new zw.agribank.echannels.requests.statement.Response(transaction.getResponse()))
                .build();
    }

    @PostMapping("/enquiry/balance")
    public  ResponseEntity<Object> balance(@Valid @RequestBody zw.agribank.echannels.requests.balance.Request request, HttpServletRequest header){

        logger.info("Incoming balance request for account : "  + request.getAccount());

        Transaction transaction =  this.adapter.send(request.build() , header , request.getId() , request.getApplication());

        return  ApiResponse.start().success(transaction.hasError() , transaction.getError())
                    .data("reference" , transaction.getId())
                    .data("result" , new zw.agribank.echannels.requests.balance.Response(transaction.getResponse()))
                .build();
    }

    @PostMapping("/enquiry/details")
    public  ResponseEntity<Object> details(@Valid @RequestBody zw.agribank.echannels.requests.details.Request request, HttpServletRequest header)
    {
        logger.info("Incoming details request for account : "  + request.getAccount());

        Transaction transaction =  this.adapter.send(request.build() , header , request.getId() , request.getApplication());

        return  ApiResponse.start().success(transaction.hasError() , transaction.getError())
                    .data("reference" , transaction.getId())
                    .data("result" , new zw.agribank.echannels.requests.details.Response(transaction.getResponse()))
                .build();
    }
    @PostMapping("/enquiry/details/micro")
    public  ResponseEntity<Object> detailsMicro(@Valid @RequestBody zw.agribank.echannels.requests.details_micro.Request request, HttpServletRequest header)
    {
        logger.info("Incoming Micro-finance details request for account : "  + request.getAccount());

        Transaction transaction =  this.adapter.send(request.build() , header , request.getId() , request.getApplication());

        return  ApiResponse.start().success(transaction.hasError() , transaction.getError())
                    .data("reference" , transaction.getId())
                    .data("result" , new zw.agribank.echannels.requests.details_micro.Response(transaction.getResponse()))
                .build();
    }

    @PostMapping("/transaction/transfer")
    public  ResponseEntity<Object> transfer(@Valid @RequestBody zw.agribank.echannels.requests.transfer.Request request, HttpServletRequest header)
    {
        logger.info("Incoming transfer request Version : " + request.getVersion() + " Debit : "  + request.getDebit() + " Credit : " + request.getCredit()  + " Amount : " + request.getCredit()  + " Currency : " + request.getCurrency() );

        Transaction transaction =  this.adapter.send(request.build() , header , request.getId() , request.getApplication() );

        return  ApiResponse.start().success(transaction.hasError() , transaction.getError())
                    .data("reference" , transaction.getId())
                    .data("result" , new zw.agribank.echannels.requests.transfer.Response(transaction.getResponse()))
                .build();
    }

    @PostMapping("/transaction/rtgs")
    public  ResponseEntity<Object> rtgs(@Valid @RequestBody zw.agribank.echannels.requests.rtgs.Request request, HttpServletRequest header)
    {
        logger.info("Incoming RTGS Version : " + request.getVersion() + " Debit : "  + request.getDebit() + " Receive : " + request.getReceive()  + " Amount : " + request.getAmount()  + " Currency : " + request.getCurrency() );

        Transaction transaction =  this.adapter.send(request.build() , header , request.getId() , request.getApplication());

        return  ApiResponse.start().success(transaction.hasError() , transaction.getError())
                    .data("reference" , transaction.getId())
                    .data("result" , new zw.agribank.echannels.requests.rtgs.Response(transaction.getResponse()))
                .build();
    }

    @PostMapping("/transaction/reverse")
    public  ResponseEntity<Object> reverse(@Valid @RequestBody zw.agribank.echannels.requests.reversal.Request request, HttpServletRequest header)
    {
        logger.info("Incoming Reversal : " + request.getFt());

        Transaction transaction =  this.adapter.send(request.build() , header , request.getId() , request.getApplication());

        return  ApiResponse.start().success(transaction.hasError() , transaction.getError())
                    .data("reference" , transaction.getId())
                    .data("result" , new zw.agribank.echannels.requests.reversal.Response(transaction.getResponse()))
                .build();
    }

}
