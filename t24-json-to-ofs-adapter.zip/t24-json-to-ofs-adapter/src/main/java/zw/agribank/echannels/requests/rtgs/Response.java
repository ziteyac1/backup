package zw.agribank.echannels.requests.rtgs;
import java.util.Arrays;
import java.util.HashMap;

public class Response {

    private String ft;
    private String error;
    private Boolean retry = false;
    private boolean success;
    private HashMap<String, String> values = new HashMap<>();

    public Response(String response) {

        String[] items = response.split(",");
        this.ft = items[0].split("/")[0];

        this.success = true;

        if (items[0].split("/").length > 3 )
        {
            if (items[0].split("/")[3].equals("NO"))
            {
                this.success = false;

                if (response.contains("OVERRIDE Unauthorised overdraft")
                        || response.contains("BAL LESS THAN MIN BAL") || ( response.contains("OVERRIDE") && response.contains("will fall below Locked") ))
                {
                    this.setError("In-sufficient funds");
                    this.setRetry(true);
                }

                if (response.contains("ACCT CCY NOT EQ DEBIT"))
                {
                    this.setError("Currency mismatch between debit and credit account");
                    this.setRetry(false);
                }

                // Invalid Debit Account

                if (( response.contains("ACCOUNT RECORD MISSING") || response.contains("ACCT MUST BE IN") )&& response.contains("DEBIT.ACCT.NO") )
                {
                    this.setError("Invalid Debit Account");
                    this.setRetry(false);
                }

                if (response.contains("OVERRIDE SAME DEBIT AND CREDIT ACCOUNT"))
                {
                    this.setError("Same Debit and credit account");
                    this.setRetry(false);
                }

                // Invalid Debit Account

                if ((response.contains("ACCOUNT RECORD MISSING") || response.contains("ACCT MUST BE IN")  ) && response.contains("CREDIT.ACCT.NO") )
                {
                    this.setError("Invalid Credit Account");
                    this.setRetry(false);
                }

                if (this.error == null )
                {
                    String[] values = response.split(",");
                    this.setError(values[values.length - 1]);
                    this.setRetry(false);
                }
            }
        }

        for (String value : Arrays.copyOfRange(items , 1 , items.length))
        {
            String[] values = value.split("=");
            if (values.length > 1 )
            {
                this.values.put(values[0] , values[1]);
            }
        }

    }

    public String getFt() {
        return ft;
    }

    public void setFt(String ft) {
        this.ft = ft;
    }

    public HashMap<String, String> getValues() {
        return values;
    }

    public void setValues(HashMap<String, String> values) {
        this.values = values;
    }

    public boolean getSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public Boolean getRetry() {
        return retry;
    }

    public void setRetry(Boolean retry) {
        this.retry = retry;
    }
}
