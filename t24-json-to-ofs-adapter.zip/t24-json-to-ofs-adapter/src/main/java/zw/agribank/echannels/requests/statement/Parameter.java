package zw.agribank.echannels.requests.statement;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

public class Parameter {

    @NotEmpty
    @Pattern(regexp = "^(BOOKING\\.DATE|VALUE\\.DATE)")
    private String field;
    @NotEmpty
    @Pattern(regexp = "^(LT|GT|EQ)")
    private String sign;
    @NotEmpty
    private String value;

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
