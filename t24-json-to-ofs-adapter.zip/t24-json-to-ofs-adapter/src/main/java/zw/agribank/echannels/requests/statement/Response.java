package zw.agribank.echannels.requests.statement;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Response {

    private String start;
    private String end;
    private Integer transactionsCount;
    private Integer ftsCount;
    private ArrayList<Object> transactions =  new ArrayList<>();

    public Response(String ofs) {

        // Start Balance

        Pattern pattern = Pattern.compile("\"Balance at Period Start\".\"-?(?:\\d{1,3},)*\\d{1,3}(?:\\.\\d+)?\"");
        Matcher matcher = pattern.matcher(ofs);
        while (matcher.find())
        {
            start = matcher.group().replaceAll("\"" , "").replaceAll("Balance at Period Start" , "").replace("," , "").replace("." , "").replace(" " , "");
        }

        if (start != null )
        {
                // End Balance

                pattern = Pattern.compile("\"Balance at Period End\".\"-?(?:\\d{1,3},)*\\d{1,3}(?:\\.\\d+)?\"");
                matcher = pattern.matcher(ofs);
                while (matcher.find())
                {
                    end  = matcher.group().replaceAll("\"" , "").replaceAll("Balance at Period End" , "").replace("," , "").replace("." , "").replace(" " , "");
                }

                // Transactions

                int i = ofs.indexOf("Balance at Period Start");
                ofs = ofs.substring(i);
                pattern = Pattern.compile("\"\\d{2}\\s\\w{3}\\s\\d{2}\"\\.\"((FT.{0,20}\\\\{0,3})|(AA.{0,50})|(TT.{0,50})|(FT.{0,50}))\"\\.\".{0,50}\"\\.\".{0,50}\"\\.\".{0,50}\"\\.\"(-?(?:\\d{1,3},)*\\d{1,3}(?:\\.\\d+)?|)\"\\.\"(-?(?:\\d{1,3},)*\\d{1,3}(?:\\.\\d+)?|)\"\\.\"-?(?:\\d{1,3},)*\\d{1,3}(?:\\.\\d+)?\"");
                //pattern = Pattern.compile("\"\\d{2}\\s\\w{3}\\s\\d{2}\"\\.\"((FT.{0,20}\\\\{0,3})|(AA.{0,50}))\"\\.\".{0,50}\"\\.\".{0,50}\"\\.\".{0,50}\"\\.\"(-?(?:\\d{1,3},)*\\d{1,3}(?:\\.\\d+)?|)\"\\.\"(-?(?:\\d{1,3},)*\\d{1,3}(?:\\.\\d+)?|)\"\\.\"-?(?:\\d{1,3},)*\\d{1,3}(?:\\.\\d+)?\"");
                matcher = pattern.matcher(ofs);

                while (matcher.find())
                {
                    String txn   = matcher.group();
                    String[] items  = txn.split("\".\"");
                    int elements = items.length;
                    int number = 0;

                    do {
                        String[] contents = Arrays.copyOfRange(items , number == 0 ? 0 : ( number * 8 )  , 8  * ( number + 1 ) );
                        this.transactions.add(new Transaction(contents[0].replace('"' , ' ').trim() ,contents[1] ,contents[2] ,contents[3] ,contents[6] ,contents[5] ,contents[7].replace('"' , ' ').trim()  ,contents[4]));
                        number++;
                        elements  = elements - 8;
                    } while (elements > 7 );

                }

                this.transactionsCount = transactions.size();

                pattern = Pattern.compile("\"\\.\"FT.{0,20}\\\\{0,3}\"\\.\"");
                matcher = pattern.matcher(ofs);
                this.ftsCount = 0;
                while (matcher.find())
                {
                    matcher.group();
                    this.ftsCount++;
                }
        }
    }

    public ArrayList<Object> getTransactions() {
        return transactions;
    }

    public void setTransactions(ArrayList<Object> transactions) {
        this.transactions = transactions;
    }

    public String getEnd() {
        return end;
    }

    public void setEnd(String end) {
        this.end = end;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public Integer getTransactionsCount() {
        return transactionsCount;
    }

    public void setTransactionsCount(Integer transactionsCount) {
        this.transactionsCount = transactionsCount;
    }

    public Integer getFtsCount() {
        return ftsCount;
    }

    public void setFtsCount(Integer ftsCount) {
        this.ftsCount = ftsCount;
    }
}
