package zw.agribank.echannels.requests.statement;

public class Transaction {
    private String valueDate;
    private String bookingDate;
    private String ft;
    private String reference;
    private String location;
    private String credit;
    private String debit;
    private String balance;

    public Transaction(String date, String ft, String reference, String location, String credit , String debit , String balance , String bookingDate) {
        this.valueDate = date;
        this.bookingDate = bookingDate;
        this.ft = ft;
        this.reference = reference;
        this.location = location;
        this.credit = credit;
        this.debit = debit;
        this.balance = balance;
    }


    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getFt() {
        return ft;
    }

    public void setFt(String ft) {
        this.ft = ft;
    }

    public String getValueDate() {
        return valueDate;
    }

    public void setValueDate(String valueDate) {
        this.valueDate = valueDate;
    }

    public String getCredit() {
        return credit;
    }

    public void setCredit(String credit) {
        this.credit = credit;
    }

    public String getDebit() {
        return debit;
    }

    public void setDebit(String debit) {
        this.debit = debit;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public String getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(String bookingDate) {
        this.bookingDate = bookingDate;
    }
}
