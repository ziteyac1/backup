package zw.agribank.echannels.requests;

import java.util.HashMap;

public class Config {
    public static String username = "NDASENDA01";
    public static String password = "Password10";
    public static String host = "192.168.0.191";
    public static int port = 7023;

    public static HashMap<String , Credentials> credentials(){
        return new HashMap<String , Credentials>(){{
            put("internet-banking" , new Credentials(){{
                setName("NDASENDA01");
                setPassword("Password10");
            }});
        }};
    }

}
