package zw.agribank.echannels.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import zw.agribank.echannels.entity.Transaction;
import zw.agribank.echannels.repository.TransactionRepository;
import zw.agribank.echannels.requests.Config;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Date;
import java.util.Scanner;

@Service
public class Adapter {

    @Autowired
    TransactionRepository transactionRepository;

    private static final Logger logger = LoggerFactory.getLogger(Adapter.class);

    public Transaction send(String message , HttpServletRequest request)
    {
        return this.send(message , request , "" , "");
    }

    public Transaction send(String message , HttpServletRequest request , String id , String application)
    {
        // Start Transaction

        Transaction transaction =  new Transaction();
        transaction.setAgent(request.getHeader("User-Agent"));
        transaction.setIp(request.getRemoteAddr());
        transaction.setEndPoint(request.getRequestURI());
        transaction.setStart(new Date());
        transaction.setRequest(message);
        transaction.setApplication(application);
        transaction.setReference(id);

        transaction = transactionRepository.save(transaction);

        // Send to T24

        String host = Config.host;
        int port = Config.port;
        logger.info("Establishing connection with  Host : " + host +  " Port : " + port);

        Socket client = null;
        String response = "";

        try {

            long start = System.currentTimeMillis();

            client = new Socket();
            client.connect(new InetSocketAddress(host, port), 1000 * 10);

            Scanner scn = new Scanner(client.getInputStream());

            logger.info("Performing Handshake");

            while (scn.hasNextLine())
            {
                if (scn.nextLine().contains("exit")) {
                    break;
                }

                long end = System.currentTimeMillis();
                float sec = (end - start) / 1000F;

                if (sec > 30)
                {
                    throw new IOException("OFS Connection timeout");
                }

            }

            transaction.setSendT24(new Date());
            transaction = transactionRepository.save(transaction);

            PrintWriter writer = new PrintWriter(new OutputStreamWriter(client.getOutputStream()) , true);

            logger.info("Request : " +  message );

            writer.println(message);
            writer.flush();

            while(scn.hasNextLine())
            {
                response += scn.nextLine();
                break;
            }

            transaction.setRespondT24(new Date());
            transaction.setResponse(this.clean(response));
            transaction = transactionRepository.save(transaction);

            logger.info("Response : " + this.clean(response) );

            if (this.clean(response).contains("OFSERROR_TIMEOUT"))
            {
                transaction.setError("System Offline");
            }

            if (this.clean(response).contains("NO SIGN ON NAME SUPPLIED"))
            {
                transaction.setError("No Sign On Provided");
            }

            if (this.clean(response).contains("SECURITY VIOLATION"))
            {
                transaction.setError("T24 Security Violation");
            }

            transaction.setEnd(new Date());
            long end = System.currentTimeMillis();
            float sec = (end - start) / 1000F;
            transaction.setTime(sec + "");
            transaction = transactionRepository.save(transaction);
            return transaction;

        } catch (IOException e) {
            transaction.setEnd(new Date());
            transaction.setError(e.getMessage());
            transaction = transactionRepository.save(transaction);
            return transaction;
        }
    }

    public String clean(String input)
    {
        // Remove all Spaces from the strings
        input = input.replaceAll("\\s+" , " ");

        // Remove all spaces before the a quote
        input = input.replaceAll("\\s+?\"" , "\"");

        // Remove all spaces after a quote
        input = input.replaceAll("\"\\s+?" , "\"");

        return input;

    }
}
