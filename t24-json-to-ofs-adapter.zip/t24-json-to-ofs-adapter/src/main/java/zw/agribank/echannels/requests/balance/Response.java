package zw.agribank.echannels.requests.balance;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Response {

    private String available;
    private String ledger;
    private String account;
    private String name;
    private String status;
    private String currency;
    private String id;

    public Response(String ofs){


        // Ledger

        Pattern pattern = Pattern.compile("LEDGER.BALANCE\\s+?:\\d+");
        Matcher matcher = pattern.matcher(ofs);

        while (matcher.find())
        {
            ledger =  matcher.group().replaceAll("LEDGER.BALANCE\\s+?:" , "");
        }

        // Available

        pattern = Pattern.compile("AVAILABLE.BALANCE\\s+?:\\d+");
        matcher = pattern.matcher(ofs);

        while (matcher.find())
        {
            available =  matcher.group().replaceAll("AVAILABLE.BALANCE\\s+?:" , "");
        }

        // Account

        pattern = Pattern.compile("ACCOUNT.NUMBER\\s+?:\\d+");
        matcher = pattern.matcher(ofs);

        while (matcher.find())
        {
            account =  matcher.group().replaceAll("ACCOUNT.NUMBER\\s+?:" , "");
        }

        // Name

        pattern = Pattern.compile("ACCOUNT.TITLE\\s+?:[a-zA-Z ]+");
        matcher = pattern.matcher(ofs);

        while (matcher.find())
        {
            name =  matcher.group().replaceAll("ACCOUNT.TITLE\\s+?:" , "");
        }

        // Currency

        pattern = Pattern.compile("CURRENCY\\s+?:[a-zA-Z ]+");
        matcher = pattern.matcher(ofs);

        while (matcher.find())
        {
            currency =  matcher.group().replaceAll("CURRENCY\\s+?:" , "");
        }

        // Status

        pattern = Pattern.compile("STATUS\\s+?:[0-9 ]+");
        matcher = pattern.matcher(ofs);

        while (matcher.find())
        {
            status =  matcher.group().replaceAll("STATUS\\s+?:" , "");
        }

    }

    public String getAvailable() {
        return available;
    }

    public void setAvailable(String available) {
        this.available = available;
    }

    public String getLedger() {
        return ledger;
    }

    public void setLedger(String ledger) {
        this.ledger = ledger;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }
}
