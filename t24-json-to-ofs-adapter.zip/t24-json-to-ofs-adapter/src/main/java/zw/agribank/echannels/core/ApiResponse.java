package zw.agribank.echannels.core;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;

public class ApiResponse {

    private static ApiResponse apiResponse;
    private HashMap<Object, Object> response = new HashMap<>();
    private HashMap<Object, Object> body = new HashMap<>();
    private Boolean success = false;
    private String message = "";

    private ApiResponse() {

    }

    public static ApiResponse start() {
        apiResponse = new ApiResponse();
        return apiResponse;
    }

    public ApiResponse data(String name, Object data) {
        this.body.put(name, data);
        return this;
    }

    public ApiResponse success(boolean success , String message) {
        this.success = success;
        this.message = message;
        return this;
    }

    public ApiResponse success() {
        this.success = true;
        return this;
    }

    public ApiResponse message(String message) {
        this.message = message;
        return this;
    }

    public ApiResponse fail() {
        this.success = false;
        return this;
    }

    public ResponseEntity<Object> build() {

        response.put("success", this.success);
        response.put("body", this.body);
        if (this.message != null)
            response.put("message", this.message);
        return new ResponseEntity<>(response, HttpStatus.OK);

    }

}
