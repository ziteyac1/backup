package zw.agribank.echannels.requests.reversal;
import java.util.Arrays;
import java.util.HashMap;

public class Response {

    private boolean success;

    public Response(String response)
    {
        this.success = true;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success){
        this.success = success;
    }
}
