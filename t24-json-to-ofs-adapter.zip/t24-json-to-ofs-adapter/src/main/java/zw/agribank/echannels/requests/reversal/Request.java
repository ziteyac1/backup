package zw.agribank.echannels.requests.reversal;

import zw.agribank.echannels.requests.Config;

import javax.validation.constraints.NotEmpty;
import java.util.ArrayList;

public class Request {

    @NotEmpty
    private String ft;

    private String id;
    private String application;

    public String build()
    {
        return "FUNDS.TRANSFER,REV.WD/R/PROCESS," + Config.username +"/" + Config.password + "/,"+ this.getFt() +",";
    }

    public String getFt() {
        return ft;
    }

    public void setFt(String ft) {
        this.ft = ft;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getApplication() {
        return application;
    }

    public void setApplication(String application) {
        this.application = application;
    }
}
