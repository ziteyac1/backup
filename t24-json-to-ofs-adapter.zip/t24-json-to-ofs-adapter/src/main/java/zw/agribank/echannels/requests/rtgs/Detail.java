package zw.agribank.echannels.requests.rtgs;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

public class Detail {

    @NotEmpty
    @Pattern(regexp = "^(PAYMENT\\.DETAILS:1)")
    private String field;
    @NotEmpty
    private String value;

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }


    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
