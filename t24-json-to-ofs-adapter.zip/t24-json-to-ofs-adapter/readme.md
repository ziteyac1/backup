# T24 JSON - OFS Adapter

Available Endpoints 

1 -  **/ofs/raw**  <br><br>
This endpoint is for raw OFS Strings <br>
Input 
 
```json
 {
  	"message" : "ENQUIRY.SELECT,,NDASENDA01/Password10,STMT.ENT.BOOK,ACCT.ID:EQ=040000291287,BOOKING.DATE:GT=20191101,BOOKING.DATE:LT=20191130"
  }   
```

Output

```json
 {
     "success": true,
     "body": {
         "result": {
             "message": ",MSG.ID::MSG.ID/ACCOUNT.NUMBER::ACCOUNT.NUMBER/ACCOUNT.TITLE::ACCOUNT.TITLE/LEDGER.BALANCE::LEDGER.BALANCE/AVAILABLE.BALANCE::AVAILABLE.BALANCE/CURRENCY::CURRENCY/STATUS::STATUS,\"MSG.ID :\".\"ACCOUNT.NUMBER :100001357818\".\"ACCOUNT.TITLE :MERRY PHIRI\".\"LEDGER.BALANCE :140337\".\"AVAILABLE.BALANCE :640337\".\"CURRENCY :ZWL\".\"STATUS : 001\""
         }
     },
     "message": ""
 } 
```


2 -  **/enquiry/balance**  <br><br>
This endpoint is for balance enquiry <br>
Input 
 
```json
 {
 	"account" : "100001357818"
 }   
```

Output

```json
 {
     "success": true,
     "body": {
         "result": {
             "available": "640337",
             "ledger": "140337",
             "account": "100001357818",
             "name": "MERRY PHIRI",
             "status": " 001",
             "currency": "ZWL"
         }
     },
     "message": ""
 }
```


3 -  **/enquiry/statement**  <br><br>
This endpoint is statement Enquiry <br>
Input 
 
```json
{
	"account" : "100001357818",
	"version" : "STMT.ENT.BOOK",
	"parameters" : [
		{
			"field" : "BOOKING.DATE",
			"sign" : "GT",
			"value" : "20191101"
		},
		{
			"field" : "BOOKING.DATE",
			"sign" : "LT",
			"value" : "20191130"
		}
	]
}   
```

Output

```json
{
    "success": true,
    "body": {
        "result": {
            "start": "000",
            "end": "69182",
            "transactions": [
                {
                    "valueDate": "06 NOV 19",
                    "bookingDate": "06 NOV 19",
                    "ft": "FT19310Z2ZPR\\BNK",
                    "reference": "ACCOUNT TRANSFER",
                    "location": "",
                    "credit": "250.00",
                    "debit": "",
                    "balance": "250.00"
                },
                {
                    "valueDate": "06 NOV 19",
                    "bookingDate": "06 NOV 19",
                    "ft": "FT19310G60DR\\BNK",
                    "reference": "Sms Charge",
                    "location": "SMS CHARGE",
                    "credit": "",
                    "debit": "0.25",
                    "balance": "249.75"
                }
            ]
        }
    },
    "message": ""
}
```

4 -  **/transaction/transfer**  <br><br>
This end point is for initiating a Funds Transfer <br>
Input 
 
```json
{
	"debit" : "100001357818",
	"credit" : "100002717028",
	"amount" : "10",
	"currency" : "ZWL",
	"reference" : "Test Trasnfer",
	"version" : "GL.NEW.IB1",
	"auth" : "0",
	"details" : [
		{
			"field" : "PAYMENT.DETAILS:2",
			"value" : "TEST"
		}
	]
}  
```

Output

```json
{
    "success": true,
    "body": {
        "result": {
            "ft": "FT19336XY915",
            "values": {
                "AMOUNT.DEBITED:1:1": "ZWL10.00",
                "CREDIT.COMP.CODE:1:1": "ZW0010040",
                "INPUTTER:1:1": "70394_NDASENDA__OFS_GCS",
                "PAYMENT.DETAILS:2:1": "TEST",
                "DEBIT.COMP.CODE:1:1": "ZW0010040",
                "TOT.REC.CHG:1:1": "0",
                "CURR.NO:1:1": "1",
                "AUTH.DATE:1:1": "20191202",
                "CUST.GROUP.LEVEL:1:1": "10",
                "CURRENCY.MKT.DR:1:1": "1",
                "DEBIT.ACCT.NO:1:1": "100001357818",
                "LOC.AMT.CREDITED:1:1": "10.00",
                "DEBIT.AMOUNT:1:1": "10.00",
                "TOT.REC.COMM:1:1": "0",
                "LOC.AMT.DEBITED:1:1": "10.00",
                "AUTHORISER:1:1": "70394_NDASENDA_OFS_GCS",
                "CR.ADVICE.REQD.Y.N:1:1": "NO",
                "DEBIT.CURRENCY:1:1": "ZWL",
                "POSITION.TYPE:1:1": "TR",
                "CHARGED.CUSTOMER:1:1": "747774",
                "TOT.REC.CHG.CRCCY:1:1": "0",
                "STMT.NOS:4:1": "190717039445518.01",
                "DEBIT.CUSTOMER:1:1": "747774",
                "CREDIT.VALUE.DATE:1:1": "20191202",
                "STMT.NOS:2:1": "1-2",
                "PROCESSING.DATE:1:1": "20191202",
                "DR.ADVICE.REQD.Y.N:1:1": "NO",
                "CURRENCY.MKT.CR:1:1": "1",
                "PAYMENT.DETAILS:1:1": "Test Trasnfer",
                "CHARGE.COM.DISPLAY:1:1": "NO",
                "TOT.REC.CHG.LCL:1:1": "0",
                "PROFIT.CENTRE.CUST:1:1": "747774",
                "DATE.TIME:1:1": "2003181238",
                "TRANSACTION.TYPE:1:1": "ACI1",
                "CREDIT.CURRENCY:1:1": "ZWL",
                "DEPT.CODE:1:1": "1",
                "CHARGES.ACCT.NO:1:1": "100001357818",
                "CO.CODE:1:1": "ZW0010001",
                "COMMISSION.CODE:1:1": "DEBIT PLUS CHARGES",
                "CREDIT.CUSTOMER:1:1": "747774",
                "TOT.REC.COMM.LCL:1:1": "0",
                "AMOUNT.CREDITED:1:1": "ZWL10.00",
                "CREDIT.ACCT.NO:1:1": "100002717028",
                "FED.FUNDS:1:1": "NO",
                "RETURN.TO.DEPT:1:1": "NO",
                "DEBIT.VALUE.DATE:1:1": "20191202",
                "STMT.NOS:5:1": "1-3*1",
                "STMT.NOS:3:1": "ZW0010040",
                "TOT.SND.CHG.CRCCY:1:1": "0.00",
                "STMT.NOS:1:1": "190717039445518.00",
                "RATE.FIXING:1:1": "NO",
                "CHARGE.CODE:1:1": "DEBIT PLUS CHARGES"
            }
        }
    },
    "message": ""
}
```

