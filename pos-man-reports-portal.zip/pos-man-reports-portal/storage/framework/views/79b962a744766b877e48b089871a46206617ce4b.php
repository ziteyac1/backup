<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Agribank POS Reports Portal </title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="user" content="<?php echo e(json_encode($user)); ?>">
    <link rel="shortcut icon" href="images/logo_YDo_icon.ico">
    <link href="/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="/assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <link href="/assets/css/app.css" rel="stylesheet" type="text/css" />
    <link href="/css/app.css" rel="stylesheet" type="text/css" />
</head>
<body data-leftbar-theme="light">
<div id="app" class="wrapper">
    <div class="left-side-menu">
        <div class="h-100"  data-simplebar>
            <router-link to="/" class="logo text-center">
                <span class="logo-lg">
                    <img src="/assets/images/logo.png" alt="" height="43" id="side-main-logo">
                </span>
                <span class="logo-sm">
                    <img src="/assets/images/logo_sm.png" alt="" height="43" id="side-sm-main-logo">
                </span>
            </router-link>
            <ul class="metismenu side-nav">
                <li class="side-nav-title side-nav-item">Navigation</li>
                <li class="side-nav-item">
                    <router-link to="/" class="side-nav-link">
                        <i class="uil-home-alt"></i>
                        <span> Dashboard </span>
                    </router-link>
                </li>
                <li class="side-nav-item">
                    <router-link to="/terminals/account" class="side-nav-link">
                        <i class="uil-dialpad-alt"></i>
                        <span>Terminals </span>
                    </router-link>
                </li>
                <li class="side-nav-item">
                    <router-link to="/transactions" class="side-nav-link">
                        <i class="uil-analysis"></i>
                        <span>Transactions </span>
                    </router-link>
                </li>
                <li class="side-nav-item">
                    <router-link to="/reports" class="side-nav-link">
                        <i class="uil-analytics"></i>
                        <span>Reports </span>
                    </router-link>
                </li>
                <li class="side-nav-item">
                    <router-link to="/settings" class="side-nav-link">
                        <i class="uil-cog"></i>
                        <span> Settings </span>
                    </router-link>
                </li>
                
                <li class="side-nav-item">
                    <form id="logout-form" action="/logout" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                    <a @click.prevent="logout" href="#" class="side-nav-link">
                        <i class="uil-power"></i>
                        <span> Logout</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <div class="content-page">
        <div class="content">
            <div class="navbar-custom">
                <ul class="list-unstyled topbar-right-menu float-right mb-0">
                    <li class="dropdown notification-list">
                        <a class="nav-link dropdown-toggle nav-user arrow-none mr-0" data-toggle="dropdown" href="#" id="topbar-userdrop" role="button" aria-haspopup="false" aria-expanded="false">
                            <span class="account-user-avatar border border-primary rounded-circle">
                                <img src="/images/hiclipart.com.png" alt="user-image" class="rounded-circle">
                            </span>
                            <span>
                                <span class="account-user-name"><?php echo e(\Illuminate\Support\Str::limit(auth()->user()->full_name , 20 , '...')); ?></span>
                                <span class="account-position text-capitalize"><?php echo e(auth()->user()->type); ?></span>
                            </span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated topbar-dropdown-menu profile-dropdown" aria-labelledby="topbar-userdrop">
                            <router-link to="/settings" class="dropdown-item notify-item">
                                <i class="mdi mdi-account-edit mr-1"></i>
                                <span>Settings</span>
                            </router-link>
                            <form id="logout-form" action="/logout" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                            <a @click.prevent="logout" href="#" class="dropdown-item notify-item">
                                <i class="mdi mdi-logout mr-1"></i>
                                <span>Logout</span>
                            </a>
                        </div>
                    </li>
                </ul>
                <button class="button-menu-mobile open-left disable-btn">
                    <i class="mdi mdi-menu"></i>
                </button>
            </div>
            <div class="container-fluid">
                <keep-alive>
                    <transition name="slide-in-left">
                        <router-view></router-view>
                    </transition>
                </keep-alive>
            </div>
        </div>
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6">
                        @ <?php echo e(now()->format('Y')); ?> Agribank POS Management
                    </div>
                </div>
            </div>
        </footer>
    </div>
</div>
<script src="/assets/js/vendor.min.js"></script>
<script src="/assets/js/app.min.js"></script>
<script src="/js/app.js"></script>
</body>

<?php /**PATH C:\Users\zuvarashe\PhpstormProjects\pos-man-reports-portal\resources\views/home.blade.php ENDPATH**/ ?>