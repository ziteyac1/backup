(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[0],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/core/page-index.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/core/page-index.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_data_Data__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core/data/Data */ "./resources/js/core/data/Data.js");

/* harmony default export */ __webpack_exports__["default"] = ({
  name: "page-index",
  props: ['url', 'prefix', 'name'],
  data: function data() {
    return {
      data: new _core_data_Data__WEBPACK_IMPORTED_MODULE_0__["default"]({
        url: this.url,
        prefix: this.prefix
      })
    };
  },
  mounted: function mounted() {
    this.data.fetch();
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/core/page-index.vue?vue&type=template&id=5a881309&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/core/page-index.vue?vue&type=template&id=5a881309& ***!
  \******************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "row mt-4" }, [
    _c("div", { staticClass: "col-lg-12" }, [
      _c("div", { staticClass: "card" }, [
        _c(
          "div",
          { staticClass: "card-body d-flex flex-wrap flex-fill" },
          [
            _vm._t("filters", null, { filters: _vm.data.filters }),
            _vm._v(" "),
            _c("div", { staticClass: "flex-fill mr-2 my-1" }, [
              _c("div", { staticClass: "app-search" }, [
                _c(
                  "form",
                  {
                    on: {
                      submit: function($event) {
                        $event.preventDefault()
                        return _vm.data.fetch()
                      }
                    }
                  },
                  [
                    _c("div", { staticClass: "input-group" }, [
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.data.filters.search,
                            expression: "data.filters.search"
                          }
                        ],
                        staticClass: "form-control",
                        attrs: { type: "text", placeholder: "Search..." },
                        domProps: { value: _vm.data.filters.search },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(
                              _vm.data.filters,
                              "search",
                              $event.target.value
                            )
                          }
                        }
                      }),
                      _vm._v(" "),
                      _c("span", { staticClass: "mdi mdi-magnify" }),
                      _vm._v(" "),
                      _c("div", { staticClass: "input-group-append" }, [
                        _c(
                          "button",
                          {
                            class: [
                              "btn btn-primary",
                              _vm.data.loading ? "btn-loading" : ""
                            ],
                            attrs: { type: "submit" },
                            on: {
                              click: function($event) {
                                $event.preventDefault()
                                return _vm.data.fetch()
                              }
                            }
                          },
                          [_vm._v("Search")]
                        )
                      ])
                    ])
                  ]
                )
              ])
            ]),
            _vm._v(" "),
            _c(
              "div",
              {},
              [
                _c(
                  "button",
                  {
                    class: [
                      "btn btn-primary px-3 my-1",
                      _vm.data.loading ? "btn-loading" : ""
                    ],
                    on: {
                      click: function($event) {
                        return _vm.data.fetch()
                      }
                    }
                  },
                  [_c("i", { staticClass: "mdi mdi-autorenew" })]
                ),
                _vm._v(" "),
                _vm._t("actions")
              ],
              2
            )
          ],
          2
        )
      ])
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "col-lg-12" }, [
      _c("div", { staticClass: "card" }, [
        _c("div", { staticClass: "d-flex align-items-center p-3 flex-wrap" }, [
          _c("div", { staticClass: "h4 m-o" }, [
            _vm._v(
              "\n                    " + _vm._s(_vm.name) + "\n                "
            )
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "ml-auto mr-3 d-flex align-items-center" }, [
            _c("div", { staticClass: "mr-2" }, [_vm._v("Showing")]),
            _vm._v(" "),
            _c("div", { staticClass: "form-group mb-0" }, [
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.data.filters.size,
                      expression: "data.filters.size"
                    }
                  ],
                  staticClass: "custom-select",
                  on: {
                    change: [
                      function($event) {
                        var $$selectedVal = Array.prototype.filter
                          .call($event.target.options, function(o) {
                            return o.selected
                          })
                          .map(function(o) {
                            var val = "_value" in o ? o._value : o.value
                            return val
                          })
                        _vm.$set(
                          _vm.data.filters,
                          "size",
                          $event.target.multiple
                            ? $$selectedVal
                            : $$selectedVal[0]
                        )
                      },
                      function($event) {
                        return _vm.data.fetch()
                      }
                    ]
                  }
                },
                [
                  _c("option", { attrs: { value: "10" } }, [_vm._v("10")]),
                  _vm._v(" "),
                  _c("option", { attrs: { value: "15" } }, [_vm._v("15")]),
                  _vm._v(" "),
                  _c("option", { attrs: { value: "25" } }, [_vm._v("25")]),
                  _vm._v(" "),
                  _c("option", { attrs: { value: "30" } }, [_vm._v("30")]),
                  _vm._v(" "),
                  _c("option", { attrs: { value: "50" } }, [_vm._v("50")]),
                  _vm._v(" "),
                  _c("option", { attrs: { value: "100" } }, [_vm._v("100")])
                ]
              )
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "mr-3 d-flex align-items-center" }, [
            _c("div", { staticClass: "mr-2" }, [_vm._v("Sort By")]),
            _vm._v(" "),
            _c("div", { staticClass: "form-group mb-0" }, [
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.data.sort.field,
                      expression: "data.sort.field"
                    }
                  ],
                  staticClass: "custom-select",
                  on: {
                    change: [
                      function($event) {
                        var $$selectedVal = Array.prototype.filter
                          .call($event.target.options, function(o) {
                            return o.selected
                          })
                          .map(function(o) {
                            var val = "_value" in o ? o._value : o.value
                            return val
                          })
                        _vm.$set(
                          _vm.data.sort,
                          "field",
                          $event.target.multiple
                            ? $$selectedVal
                            : $$selectedVal[0]
                        )
                      },
                      function($event) {
                        return _vm.data.fetch()
                      }
                    ]
                  }
                },
                [
                  _c("option", { attrs: { value: "id" } }, [_vm._v("ID")]),
                  _vm._v(" "),
                  _vm._t("sort-fields")
                ],
                2
              )
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "d-flex align-items-center" }, [
            _c("div", { staticClass: "form-group mb-0" }, [
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.data.sort.direction,
                      expression: "data.sort.direction"
                    }
                  ],
                  staticClass: "custom-select",
                  on: {
                    change: [
                      function($event) {
                        var $$selectedVal = Array.prototype.filter
                          .call($event.target.options, function(o) {
                            return o.selected
                          })
                          .map(function(o) {
                            var val = "_value" in o ? o._value : o.value
                            return val
                          })
                        _vm.$set(
                          _vm.data.sort,
                          "direction",
                          $event.target.multiple
                            ? $$selectedVal
                            : $$selectedVal[0]
                        )
                      },
                      function($event) {
                        return _vm.data.fetch()
                      }
                    ]
                  }
                },
                [
                  _c("option", { attrs: { value: "asc" } }, [
                    _vm._v("Ascending")
                  ]),
                  _vm._v(" "),
                  _c("option", { attrs: { value: "desc" } }, [
                    _vm._v("Descending")
                  ])
                ]
              )
            ])
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "table-responsive font-12" }, [
          _c("table", { staticClass: "table table-centered mb-0" }, [
            _c("thead", { staticClass: "thead-light" }, [
              _c(
                "tr",
                [
                  _c("th"),
                  _vm._v(" "),
                  _vm._t("table-header"),
                  _vm._v(" "),
                  _c("th")
                ],
                2
              )
            ]),
            _vm._v(" "),
            _c(
              "tbody",
              _vm._l(_vm.data.content.data, function(row) {
                return _c(
                  "tr",
                  [
                    _c("td"),
                    _vm._v(" "),
                    _vm._t("table-row", null, { row: row }),
                    _vm._v(" "),
                    _c("td")
                  ],
                  2
                )
              }),
              0
            )
          ])
        ]),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "card-body d-flex align-items-center border-top" },
          [
            _c("div", { staticClass: "mr-auto font-weight-bolder" }, [
              _vm._v(
                "\n                    Showing " +
                  _vm._s(_vm.data.content.data.length) +
                  " of " +
                  _vm._s(_vm.data.content.total) +
                  " Records\n                "
              )
            ]),
            _vm._v(" "),
            _vm.data.content.total !== _vm.data.content.to &&
            _vm.data.content.data.length > 0
              ? _c("div", [
                  _c(
                    "button",
                    {
                      class: [
                        "btn btn-primary",
                        _vm.data.loading ? "btn-loading" : ""
                      ],
                      on: {
                        click: function($event) {
                          return _vm.data.append()
                        }
                      }
                    },
                    [_vm._v("Load More")]
                  )
                ])
              : _vm._e()
          ]
        )
      ])
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/core/page-index.vue":
/*!*****************************************************!*\
  !*** ./resources/js/components/core/page-index.vue ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _page_index_vue_vue_type_template_id_5a881309___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./page-index.vue?vue&type=template&id=5a881309& */ "./resources/js/components/core/page-index.vue?vue&type=template&id=5a881309&");
/* harmony import */ var _page_index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./page-index.vue?vue&type=script&lang=js& */ "./resources/js/components/core/page-index.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _page_index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _page_index_vue_vue_type_template_id_5a881309___WEBPACK_IMPORTED_MODULE_0__["render"],
  _page_index_vue_vue_type_template_id_5a881309___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/core/page-index.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/core/page-index.vue?vue&type=script&lang=js&":
/*!******************************************************************************!*\
  !*** ./resources/js/components/core/page-index.vue?vue&type=script&lang=js& ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_page_index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./page-index.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/core/page-index.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_page_index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/core/page-index.vue?vue&type=template&id=5a881309&":
/*!************************************************************************************!*\
  !*** ./resources/js/components/core/page-index.vue?vue&type=template&id=5a881309& ***!
  \************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_page_index_vue_vue_type_template_id_5a881309___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./page-index.vue?vue&type=template&id=5a881309& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/core/page-index.vue?vue&type=template&id=5a881309&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_page_index_vue_vue_type_template_id_5a881309___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_page_index_vue_vue_type_template_id_5a881309___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/core/data/Data.js":
/*!****************************************!*\
  !*** ./resources/js/core/data/Data.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var Data = /*#__PURE__*/function () {
  function Data(data) {
    _classCallCheck(this, Data);

    // Url and the prefix
    // For fetching data
    this.url = data.url;
    this.prefix = data.prefix;
    this.filters = {}; // Default sort

    this.sort = {
      field: 'id',
      direction: 'desc'
    }; // Size

    this.filters.size = 10; // Search

    this.filters.search = ""; // Loading state

    this.loading = false; // Global

    this.global = ''; // Start Default Pages number

    this.page = 1; // Default Content

    this.content = {
      current_page: 1,
      data: [],
      total: 0,
      to: 0
    };
  } // Building the url for sending on the ajax requests


  _createClass(Data, [{
    key: "build",
    value: function build() {
      // Start url
      var url = "".concat(window.location.origin).concat(this.url, "?page=").concat(this.page);

      for (var property in this.filters) {
        if (this.filters[property] !== undefined) {
          url += "&".concat(property, "=").concat(this.filters[property]);
        }
      } // Adding Sort , Search , Page number  to the url


      return url + "&sort=".concat(this.sort.field, ",").concat(this.sort.direction).concat(this.global);
    }
  }, {
    key: "fetch",
    value: function fetch() {
      this.load(false);
    }
  }, {
    key: "setGlobal",
    value: function setGlobal(string) {
      this.global = string;
    }
  }, {
    key: "append",
    value: function append() {
      this.load(true);
    } // Send Ajax Requests to the server and the assign values

  }, {
    key: "load",
    value: function load(append) {
      var _this = this;

      // Open the loader
      this.openLoader(); // Assign the page number based on request

      this.page = append ? this.page + 1 : 1;
      window.axios.get(this.build()).then(function (response) {
        // Append Content
        if (append) {
          // Push items to content
          response.data.body[_this.prefix].data.forEach(function (value) {
            _this.content.data.push(value);
          }); // Update all content data remaining


          _this.content.to = response.data.body[_this.prefix].to;
          _this.content.total = response.data.body[_this.prefix].total;
          return;
        } // Replace all content data


        _this.content = response.data.body[_this.prefix];
      })["catch"](function (error) {})["finally"](function () {
        _this.closeLoader();
      });
    } // Sets the loader to loading state

  }, {
    key: "openLoader",
    value: function openLoader() {
      this.loading = true;
    } // Sets the loader to closed state

  }, {
    key: "closeLoader",
    value: function closeLoader() {
      this.loading = false;
    }
  }]);

  return Data;
}();

/* harmony default export */ __webpack_exports__["default"] = (Data);

/***/ })

}]);