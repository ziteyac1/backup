(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[1],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/dashboard/dashboard.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/dashboard/dashboard.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  name: "dashboard",
  data: function data() {
    return {
      account: '',
      transactions: [],
      account_details: [],
      accounts: window.user.accounts,
      loading: false,
      transactionsLoading: false,
      auth: window.user
    };
  },
  mounted: function mounted() {
    this.init();

    if (this.accounts.length > 0) {
      this.account = this.accounts[0].id;
    }
  },
  watch: {
    account: function account(n, o) {
      var _this = this;

      this.loading = true;
      window.axios.get("".concat(window.location.origin, "/dashboard/").concat(n, "/details")).then(function (response) {
        _this.account_details = response.data.body.terminals;
      })["finally"](function () {
        _this.loading = false;
      });
    }
  },
  methods: {
    init: function init() {
      var _this2 = this;

      this.transactionsLoading = true;
      window.axios.get("".concat(window.location.origin, "/term_transactions")).then(function (response) {
        _this2.transactions = response.data.body.transactions;
      })["finally"](function () {
        _this2.loading = false;
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/dashboard/dashboard.vue?vue&type=template&id=96ac3b44&scoped=true&":
/*!**********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/dashboard/dashboard.vue?vue&type=template&id=96ac3b44&scoped=true& ***!
  \**********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "py-3" }, [
    _c("div", { staticClass: "row" }, [
      _c("div", { staticClass: "col-lg-12" }, [
        _c("div", { staticClass: "row" }, [
          _c("div", { staticClass: "col-lg-5" }, [
            _c("div", { staticClass: "row" }, [
              _c("div", { staticClass: "col-12" }, [
                _c(
                  "div",
                  {
                    staticClass: "card cta-box bg-primary text-white",
                    staticStyle: { "min-height": "135px" }
                  },
                  [
                    _c("div", { staticClass: "card-body" }, [
                      _c("div", { staticClass: "media align-items-center" }, [
                        _c("div", { staticClass: "media-body" }, [
                          _c(
                            "h3",
                            {
                              staticClass:
                                "m-0 font-weight-normal cta-box-title"
                            },
                            [
                              _vm._v("Welcome back , "),
                              _c("b", [
                                _vm._v(" " + _vm._s(_vm.auth.name) + " ")
                              ]),
                              _vm._v(" " + _vm._s(_vm.auth.last_name)),
                              _c("br"),
                              _vm._v(" Agribank POS Terminal Management")
                            ]
                          ),
                          _vm._v(" "),
                          _vm._m(0)
                        ]),
                        _vm._v(" "),
                        _c("img", {
                          staticClass: "ml-3",
                          attrs: {
                            src: "/assets/images/email-campaign.svg",
                            width: "120",
                            alt: "Generic placeholder image"
                          }
                        })
                      ])
                    ])
                  ]
                )
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-12" }, [
                _c("div", { staticClass: "card bg-white text-primary" }, [
                  _c(
                    "div",
                    {
                      staticClass:
                        "card-body profile-user-box d-flex align-items-center"
                    },
                    [
                      _c(
                        "div",
                        { staticClass: "row align-items-center flex-fill" },
                        [
                          _c("div", { staticClass: "col-sm-8" }, [
                            _c(
                              "div",
                              { staticClass: "media align-items-center" },
                              [
                                _vm._m(1),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  {
                                    staticClass: "media-body border-left pl-3"
                                  },
                                  [
                                    _c(
                                      "h4",
                                      {
                                        staticClass: "mt-1 mb-1 text-capitalize"
                                      },
                                      [
                                        _vm._v(
                                          _vm._s(_vm.auth.name) +
                                            " " +
                                            _vm._s(_vm.auth.last_name)
                                        )
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c("p", { staticClass: "font-13 mb-2" }, [
                                      _vm._v(
                                        " " + _vm._s(_vm.auth.email) + " "
                                      ),
                                      _c("br"),
                                      _vm._v(" " + _vm._s(_vm.auth.phone))
                                    ]),
                                    _vm._v(" "),
                                    _c("p", { staticClass: "mb-1" }, [
                                      _c(
                                        "span",
                                        {
                                          staticClass:
                                            "badge badge-light px-2 py-1 font-12"
                                        },
                                        [_vm._v(_vm._s(_vm.auth.type))]
                                      )
                                    ])
                                  ]
                                )
                              ]
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "col-sm-4" }, [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "text-center mt-sm-0 mt-3 text-sm-right"
                              },
                              [
                                _c(
                                  "router-link",
                                  {
                                    staticClass: "btn btn-light mb-2",
                                    attrs: { to: "/settings", type: "button" }
                                  },
                                  [
                                    _c("i", {
                                      staticClass: "mdi mdi-account-edit mr-1"
                                    }),
                                    _vm._v(
                                      " Edit Profile\n                                                "
                                    )
                                  ]
                                )
                              ],
                              1
                            )
                          ])
                        ]
                      )
                    ]
                  )
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "col-12" }, [
                _c("div", { staticClass: "row" }, [
                  _c(
                    "div",
                    { staticClass: "col-md-6" },
                    [
                      _c(
                        "router-link",
                        { staticClass: "card", attrs: { to: "/terminals" } },
                        [
                          _c("div", { staticClass: "card-body py-0" }, [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "d-flex align-items-center px-3 py-1"
                              },
                              [
                                _c("div", { staticClass: "flex-fill" }, [
                                  _c(
                                    "h5",
                                    { staticClass: "my-2 py-1 text-center" },
                                    [_vm._v("My Terminals ")]
                                  )
                                ]),
                                _vm._v(" "),
                                _c("div", {}, [
                                  _c("i", {
                                    staticClass:
                                      "font-28  uil-dialpad-alt display-4 text-primary"
                                  })
                                ])
                              ]
                            )
                          ])
                        ]
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "col-md-6 " },
                    [
                      _c(
                        "router-link",
                        { staticClass: "card", attrs: { to: "/reports" } },
                        [
                          _c("div", { staticClass: "card-body py-0" }, [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "d-flex align-items-center px-3 py-1"
                              },
                              [
                                _c("div", { staticClass: "flex-fill" }, [
                                  _c(
                                    "h5",
                                    { staticClass: "my-2 py-1 text-center" },
                                    [_vm._v("Report Generation ")]
                                  )
                                ]),
                                _vm._v(" "),
                                _c("div", {}, [
                                  _c("i", {
                                    staticClass:
                                      "font-28  uil-folder-download display-4 text-primary"
                                  })
                                ])
                              ]
                            )
                          ])
                        ]
                      )
                    ],
                    1
                  )
                ])
              ])
            ])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "col-lg-7" }, [
            _c("div", { staticClass: "col-12" }, [
              _c("div", { class: ["dimmer", _vm.loading ? "active" : ""] }, [
                _c("div", { staticClass: "loader" }),
                _vm._v(" "),
                _c("div", { staticClass: "dimmer-content" }, [
                  _c("div", { staticClass: "card" }, [
                    _c("div", { staticClass: "card-body d-flex flex-column" }, [
                      _c(
                        "select",
                        {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.account,
                              expression: "account"
                            }
                          ],
                          staticClass: "form-control form-control-sm",
                          attrs: {
                            name: "",
                            disabled: _vm.accounts.length < 2,
                            id: ""
                          },
                          on: {
                            change: function($event) {
                              var $$selectedVal = Array.prototype.filter
                                .call($event.target.options, function(o) {
                                  return o.selected
                                })
                                .map(function(o) {
                                  var val = "_value" in o ? o._value : o.value
                                  return val
                                })
                              _vm.account = $event.target.multiple
                                ? $$selectedVal
                                : $$selectedVal[0]
                            }
                          }
                        },
                        _vm._l(_vm.accounts, function(item) {
                          return _c(
                            "option",
                            { domProps: { value: item.id } },
                            [_vm._v(_vm._s(item.account))]
                          )
                        }),
                        0
                      ),
                      _vm._v(" "),
                      _vm.account_details
                        ? _c(
                            "div",
                            {
                              staticClass:
                                "row align-items-center mt-2 flex-fill",
                              staticStyle: {
                                "max-height": "360px",
                                "overflow-y": "auto"
                              }
                            },
                            [
                              _c(
                                "table",
                                {
                                  staticClass: "table table-vcenter table-hover"
                                },
                                [
                                  _vm._m(2),
                                  _vm._v(" "),
                                  _c(
                                    "tbody",
                                    _vm._l(_vm.account_details, function(
                                      terminal
                                    ) {
                                      return _c("tr", [
                                        _c("td", {}, [
                                          _c("div", [
                                            _c(
                                              "span",
                                              { staticClass: "text-muted" },
                                              [_vm._v("ID : ")]
                                            ),
                                            _vm._v(_vm._s(terminal.terminal_id))
                                          ])
                                        ]),
                                        _vm._v(" "),
                                        _c("td", [
                                          _c("div", [
                                            _c(
                                              "span",
                                              { staticClass: "text-muted" },
                                              [_vm._v("Term type : ")]
                                            ),
                                            _vm._v(_vm._s(terminal.term_type))
                                          ])
                                        ]),
                                        _vm._v(" "),
                                        _c("td", [
                                          terminal.active
                                            ? _c(
                                                "div",
                                                {
                                                  staticClass:
                                                    "px-2 border border-success text-success small"
                                                },
                                                [_vm._v("Active")]
                                              )
                                            : !terminal.active
                                            ? _c(
                                                "div",
                                                {
                                                  staticClass:
                                                    "px-2 border border-danger text-danger small"
                                                },
                                                [_vm._v("De-Active")]
                                              )
                                            : _vm._e()
                                        ]),
                                        _vm._v(" "),
                                        _c("td", [
                                          _c(
                                            "div",
                                            [
                                              _c(
                                                "router-link",
                                                {
                                                  staticClass:
                                                    "text-center action-icon text-primary",
                                                  attrs: {
                                                    to:
                                                      "/terminals/" +
                                                      terminal.terminal_id +
                                                      "/view"
                                                  }
                                                },
                                                [
                                                  _c("i", {
                                                    staticClass:
                                                      "mdi mdi-eye mdi-24px"
                                                  })
                                                ]
                                              )
                                            ],
                                            1
                                          )
                                        ])
                                      ])
                                    }),
                                    0
                                  )
                                ]
                              )
                            ]
                          )
                        : _c(
                            "div",
                            {
                              staticClass:
                                "d-flex card-body justify-content-center align-items-center h-100"
                            },
                            [_vm._m(3)]
                          )
                    ])
                  ])
                ])
              ])
            ])
          ])
        ])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "col-lg-12" }, [
        _c(
          "div",
          {
            staticClass: "card",
            staticStyle: { height: "500px", "overflow-y": "auto" }
          },
          [
            _vm._m(4),
            _vm._v(" "),
            _c("div", { staticClass: "table-responsive font-12" }, [
              _c("table", { staticClass: "table table-centered mb-0" }, [
                _vm._m(5),
                _vm._v(" "),
                _c(
                  "tbody",
                  _vm._l(_vm.transactions, function(transaction) {
                    return _vm.transactions
                      ? _c("tr", [
                          _c("td", [
                            _c("div", [
                              _c("span", { staticClass: "text-muted" }, [
                                _vm._v("Tran Number : ")
                              ]),
                              _vm._v(_vm._s(transaction._source.tran_nr))
                            ]),
                            _vm._v(" "),
                            _c("div", [
                              _c("span", { staticClass: "text-muted" }, [
                                _vm._v("State : ")
                              ]),
                              _vm._v(_vm._s(transaction._source.state))
                            ]),
                            _vm._v(" "),
                            _c("div", [
                              _c("span", { staticClass: "text-muted" }, [
                                _vm._v("Source Node : ")
                              ]),
                              _vm._v(_vm._s(transaction._source.source_node))
                            ]),
                            _vm._v(" "),
                            _c("div", [
                              _c("span", { staticClass: "text-muted" }, [
                                _vm._v("Sink Node : ")
                              ]),
                              _vm._v(_vm._s(transaction._source.source_node))
                            ])
                          ]),
                          _vm._v(" "),
                          _c("td", [
                            _c("div", [
                              _c("span", { staticClass: "text-muted" }, [
                                _vm._v("Amount : ")
                              ]),
                              _vm._v(_vm._s(transaction._source.amount))
                            ]),
                            _vm._v(" "),
                            _c("div", [
                              _c("span", { staticClass: "text-muted" }, [
                                _vm._v("Pan : ")
                              ]),
                              _vm._v(_vm._s(transaction._source.pan))
                            ]),
                            _vm._v(" "),
                            _c("div", [
                              _c("span", { staticClass: "text-muted" }, [
                                _vm._v("Expiry Date : ")
                              ]),
                              _vm._v(_vm._s(transaction._source.expiry_date))
                            ]),
                            _vm._v(" "),
                            _c("div", [
                              _c("span", { staticClass: "text-muted" }, [
                                _vm._v("RRN : ")
                              ]),
                              _vm._v(_vm._s(transaction._source.ret_ref_no))
                            ])
                          ]),
                          _vm._v(" "),
                          _c("td", [
                            _c("div", [
                              _c("span", { staticClass: "text-muted" }, [
                                _vm._v("Terminal ID : ")
                              ]),
                              _vm._v(
                                _vm._s(transaction._source.card_acceptor_id)
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", [
                              _c("span", { staticClass: "text-muted" }, [
                                _vm._v("Location : ")
                              ]),
                              _vm._v(
                                _vm._s(
                                  transaction._source.card_acceptor_name_loc
                                )
                              )
                            ]),
                            _vm._v(" "),
                            _c("div", [
                              _c("span", { staticClass: "text-muted" }, [
                                _vm._v("Account From : ")
                              ]),
                              _vm._v(_vm._s(transaction._source.account_id_1))
                            ])
                          ]),
                          _vm._v(" "),
                          _c("td", [
                            _c("div", [
                              _c("span", { staticClass: "text-muted" }, [
                                _vm._v("Sponsor Bank : ")
                              ]),
                              _vm._v(_vm._s(transaction._source.sponsor_bank))
                            ]),
                            _vm._v(" "),
                            _c("div", [
                              _c("span", { staticClass: "text-muted" }, [
                                _vm._v("Date : ")
                              ]),
                              _vm._v(_vm._s(transaction._source.in_req))
                            ]),
                            _vm._v(" "),
                            _c("div", [
                              _c("span", { staticClass: "text-muted" }, [
                                _vm._v("Tran Type : ")
                              ]),
                              _vm._v(_vm._s(transaction._source.tran_type))
                            ]),
                            _vm._v(" "),
                            _c("div", [
                              _c("span", { staticClass: "text-muted" }, [
                                _vm._v("Rsp Code : ")
                              ]),
                              _vm._v(_vm._s(transaction._source.response_code))
                            ])
                          ])
                        ])
                      : _c("tr", [
                          _c("td", { attrs: { colspan: "5" } }, [
                            _vm._v(" No Transactions Found")
                          ])
                        ])
                  }),
                  0
                )
              ])
            ])
          ]
        )
      ])
    ])
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("p", { staticClass: "mt-2" }, [
      _vm._v("Stay home and Bank with us "),
      _c("br")
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("span", { staticClass: "float-left m-3" }, [
      _c("img", {
        staticClass: "rounded-circle img-thumbnail",
        staticStyle: { height: "90px" },
        attrs: { src: "/images/hiclipart.com.png", alt: "" }
      })
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", [
      _c("tr", [
        _c("th", [_vm._v("INFO")]),
        _vm._v(" "),
        _c("th", [_vm._v("INFO")]),
        _vm._v(" "),
        _c("th", [_vm._v("STATUS")]),
        _vm._v(" "),
        _c("th", [_vm._v("MORE")])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("h5", { staticClass: "text-center" }, [
      _vm._v("\n                                        Internet Banking "),
      _c("br"),
      _vm._v(" Offline\n                                    ")
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", {}, [
      _c("h6", { staticClass: "text-muted px-3 py-2 text-uppercase" }, [
        _vm._v("Recent Transactions From The Terminals")
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", { staticClass: "thead-light" }, [
      _c("tr", [
        _c("th", [_vm._v("Info")]),
        _vm._v(" "),
        _c("th", [_vm._v("Info")]),
        _vm._v(" "),
        _c("th", [_vm._v("Info")]),
        _vm._v(" "),
        _c("th", [_vm._v("Info")]),
        _vm._v(" "),
        _c("th")
      ])
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/dashboard/dashboard.vue":
/*!*********************************************************!*\
  !*** ./resources/js/components/dashboard/dashboard.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _dashboard_vue_vue_type_template_id_96ac3b44_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard.vue?vue&type=template&id=96ac3b44&scoped=true& */ "./resources/js/components/dashboard/dashboard.vue?vue&type=template&id=96ac3b44&scoped=true&");
/* harmony import */ var _dashboard_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dashboard.vue?vue&type=script&lang=js& */ "./resources/js/components/dashboard/dashboard.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _dashboard_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _dashboard_vue_vue_type_template_id_96ac3b44_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _dashboard_vue_vue_type_template_id_96ac3b44_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "96ac3b44",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/dashboard/dashboard.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/dashboard/dashboard.vue?vue&type=script&lang=js&":
/*!**********************************************************************************!*\
  !*** ./resources/js/components/dashboard/dashboard.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_dashboard_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./dashboard.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/dashboard/dashboard.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_dashboard_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/dashboard/dashboard.vue?vue&type=template&id=96ac3b44&scoped=true&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/components/dashboard/dashboard.vue?vue&type=template&id=96ac3b44&scoped=true& ***!
  \****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_dashboard_vue_vue_type_template_id_96ac3b44_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./dashboard.vue?vue&type=template&id=96ac3b44&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/dashboard/dashboard.vue?vue&type=template&id=96ac3b44&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_dashboard_vue_vue_type_template_id_96ac3b44_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_dashboard_vue_vue_type_template_id_96ac3b44_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);