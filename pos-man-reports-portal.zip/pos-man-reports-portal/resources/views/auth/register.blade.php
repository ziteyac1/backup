<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Agribank</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="shortcut icon" href="images/logo_YDo_icon.ico">
    <link href="/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="/assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <link href="/assets/css/app.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div>
    <div class="account-pages pt-5 pb-5">
        <div id="app" class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="card">
                        <div class="card-header pt-3 pb-3 text-center bg-primary border-bottom-0">
                            <a href="/">
                                <span><img src="{{ asset('images/app-logo-on-green.png') }}" alt="" height="75"></span>
                            </a>
                        </div>
                        <register></register>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer footer-alt">
        {{ now()->format('Y') }} © AgriBank Zimbabwe
    </footer>
</div>

<script src="/assets/js/vendor.min.js"></script>
<script src="/assets/js/app.min.js"></script>
<script src="/js/app.js"></script>
</body>
</html>

