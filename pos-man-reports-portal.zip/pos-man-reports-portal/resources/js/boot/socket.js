import Echo from 'laravel-echo';
window.io = require('socket.io-client');
window.Echo = new Echo({
    broadcaster: 'socket.io',
    host: window.location.hostname + ":" + window.laravel_echo_port
});

//
// window.Echo.private('test-channel')
//     .listen('TestEvent', (e) => {
//         console.log(new Date());
//         console.log(e);
//     });
