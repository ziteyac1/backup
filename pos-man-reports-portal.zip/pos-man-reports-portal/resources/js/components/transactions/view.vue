<template>
    <div class="py-3">
        <div class="row">
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <table class="card-table table bg-white shadow-sm table-hover">
                                    <tbody >
                                    <tr>
                                        <td class="small"><strong>Transaction Number :</strong></td>
                                        <td class="text-right">{{ terminal_transaction.tran_nr }}</td>
                                    </tr>
                                    <tr>
                                        <td class="small"><strong>Transaction Type :</strong></td>
                                        <td class="text-right">{{ terminal_transaction.tran_type }}</td>
                                    </tr>
                                    <tr>
                                        <td class="small"><strong>Transaction Response :</strong></td>
                                        <td class="text-right">{{  terminal_transaction.response_code }}</td>
                                    </tr>
                                    <tr>
                                        <td class="small"><strong>Transaction Date :</strong></td>
                                        <td class="text-right">{{ terminal_transaction.in_req }}</td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-12">
                                <table class="card-table table bg-white shadow-sm table-hover">
                                    <tbody >
                                    <tr>
                                        <td class="small"><strong>Terminal ID :</strong></td>
                                        <td class="text-right">{{ terminal_transaction.card_acceptor_id }}</td>
                                    </tr>
                                    <tr>
                                        <td class="small"><strong>Location :</strong></td>
                                        <td class="text-right">{{  terminal_transaction.card_acceptor_name_loc }}</td>
                                    </tr>
                                    <tr>
                                        <td class="small"><strong>Sponsor Bank :</strong></td>
                                        <td class="text-right">{{ terminal_transaction.sponsor_bank }}</td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-12">
                                <table class="card-table table bg-white shadow-sm table-hover">
                                    <tbody >
                                    <tr>
                                        <td class="small"><strong>Amount :</strong></td>
                                        <td class="text-right">$ {{ terminal_transaction.amount }}</td>
                                    </tr>
                                    <tr>
                                        <td class="small"><strong>Card Number :</strong></td>
                                        <td class="text-right">{{ terminal_transaction.pan }}</td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                terminal_transaction: { },
                loading: true,
                auth : window.user,
            };
        },
        methods: {
            init(){
                this.loading = true;
                window.axios.get(`${window.location.origin}/transactions/${this.$route.params.id}/get`).then((response) => {
                    this.terminal_transaction = response.data.body.terminal_transaction;
                }).finally(() => {
                    this.loading = false;
                });
            },
        },
        mounted() {
            this.init();
        }
    }
</script>
