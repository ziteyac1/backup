<template>
    <page-index name="Transactions" url="/transactions/all" prefix="transactions">
        <template slot="table-header">
            <th>Info</th>
            <th>Info</th>
            <th>Info</th>
            <th>Info</th>
        </template>
        <template slot="table-row" slot-scope="data">
            <td>
                <div><span class="text-muted">Tran Number : </span>{{ data.row._source.tran_nr }}</div>
                <div><span class="text-muted">State : </span>{{ data.row._source.state }}</div>
                <div><span class="text-muted">Source Node : </span>{{ data.row._source.source_node }}</div>
                <div><span class="text-muted">Sink Node : </span>{{ data.row._source.sink_node }}</div>
            </td>
            <td>
                <div><span class="text-muted">Amount : </span>{{ data.row._source.amount }}</div>
                <div><span class="text-muted">Pan : </span>{{ data.row._source.pan }}</div>
                <div><span class="text-muted">Expiry Date : </span>{{ data.row._source.expiry_date }}</div>
                <div><span class="text-muted">RRN : </span>{{ data.row._source.ret_ref_no }}</div>
            </td>
            <td>
                <div><span class="text-muted">Terminal ID : </span>{{ data.row._source.card_acceptor_id }}</div>
                <div><span class="text-muted">Location : </span>{{ data.row._source.card_acceptor_name_loc }}</div>
                <div><span class="text-muted">Account From : </span>{{ data.row._source.account_id_1 }}</div>
            </td>
            <td>
                <div><span class="text-muted">Sponsor Bank : </span>{{ data.row._source.sponsor_bank }}</div>
                <div><span class="text-muted">Date : </span>{{ data.row._source.in_req }}</div>
                <div><span class="text-muted">Tran Type : </span>{{ data.row._source.tran_type }}</div>
                <div><span class="text-muted">Rsp Code : </span>{{ data.row._source.response_code }}</div>
            </td>
            <td>
                <div>
                    <router-link :to="`/transactions/${data.row._source.tran_nr}/view`" class="action-icon text-primary">
                        <i class="mdi mdi-eye mdi-24px"/>
                    </router-link>
                </div>
            </td>
        </template>
    </page-index>
</template>
<script>
    import PageIndex from "../core/page-index";
    export default {
        name: "index",
        components: {PageIndex},
        data(){
            return {
                win : window
            }
        }
    }
</script>
