<template>
    <page-index name="Reports" url="/reports/all" prefix="reports">
        <template slot="table-header">
            <th></th>
            <th>REPORT TYPE</th>
            <th>REPORT NAME</th>
            <th>GENERATION DATE</th>
            <th>ACTION</th>
        </template>
        <template slot="table-row" slot-scope="data">
            <td><div><span class="text-muted">ID : </span>{{ data.row.id }}</div></td>
            <td><div><span class="text-muted">Type : </span>{{ data.row.section }}</div></td>
            <td>
                <div><span class="text-muted">Name : </span>{{ data.row.name }}</div>
                <div><span class="text-muted">Description : </span>{{ data.row.description }}</div>
            </td>
            <td>
                <div><span class="text-muted">Created : </span>{{ data.row.created_at }}</div>
            </td>
            <td>
                <div>
                    <a :href="`/reports/${data.row.id}/download`" class="action-icon text-primary">
                        <i class="mdi mdi-download mdi-24px"/>
                    </a>
                </div>
            </td>
        </template>
    </page-index>
</template>
<script>
    import PageIndex from "../core/page-index";
    export default {
        name: "index",
        components: {PageIndex},
        data(){
            return {
                win : window
            }
        }
    }
</script>
<style scoped>

</style>
