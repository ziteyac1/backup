<template>
    <div class="py-3">
        <div class="row">
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="row">
                            <div class="col-12">
                                <div style="min-height: 135px" class="card cta-box bg-primary text-white">
                                    <div class="card-body">
                                        <div class="media align-items-center">
                                            <div class="media-body">
                                                <h3 class="m-0 font-weight-normal cta-box-title">Welcome back , <b> {{auth.name}} </b> {{auth.last_name}}<br> Agribank POS Terminal Management</h3>
                                                <p class="mt-2">Stay home and Bank with us <br></p>
                                            </div>
                                            <img class="ml-3" src="/assets/images/email-campaign.svg" width="120" alt="Generic placeholder image">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div  class="card bg-white text-primary">
                                    <div class="card-body profile-user-box d-flex align-items-center">
                                        <div class="row align-items-center flex-fill">
                                            <div class="col-sm-8">
                                                <div class="media align-items-center">
                                                    <span class="float-left m-3"><img src="/images/hiclipart.com.png" style="height: 90px;" alt="" class="rounded-circle img-thumbnail"></span>
                                                    <div class="media-body border-left pl-3">
                                                        <h4 class="mt-1 mb-1 text-capitalize">{{ auth.name }} {{ auth.last_name}}</h4>
                                                        <p class="font-13 mb-2"> {{ auth.email }} <br> {{ auth.phone }}</p>
                                                        <p class="mb-1"> <span class="badge badge-light px-2 py-1 font-12">{{ auth.type }}</span> </p>
                                                    </div>
                                                </div>
                                            </div> <!-- end col-->
                                            <div class="col-sm-4">
                                                <div class="text-center mt-sm-0 mt-3 text-sm-right">
                                                    <router-link to="/settings" type="button" class="btn btn-light mb-2">
                                                        <i class="mdi mdi-account-edit mr-1"></i> Edit Profile
                                                    </router-link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="row">
                                    <div class="col-md-6">
                                        <router-link to="/terminals" class="card">
                                            <div class="card-body py-0">
                                                <div class="d-flex align-items-center px-3 py-1">
                                                    <div class="flex-fill">
                                                        <h5 class="my-2 py-1 text-center">My Terminals </h5>
                                                    </div>
                                                    <div class="">
                                                        <i class="font-28  uil-dialpad-alt display-4 text-primary"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </router-link>
                                    </div>
                                    <div class="col-md-6 ">
                                        <router-link to="/reports" class="card">
                                            <div class="card-body py-0">
                                                <div class="d-flex align-items-center px-3 py-1">
                                                    <div class="flex-fill">
                                                        <h5 class="my-2 py-1 text-center">Report Generation </h5>
                                                    </div>
                                                    <div class="">
                                                        <i class="font-28  uil-folder-download display-4 text-primary"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </router-link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="col-12">
                            <div :class="['dimmer' , loading ? 'active' : '']">
                                <div class="loader"></div>
                                <div class="dimmer-content">
                                    <div class="card">
                                <div class="card-body d-flex flex-column">
                                    <select v-model="account" name="" :disabled="accounts.length < 2" class="form-control form-control-sm" id="">
                                        <option v-for="item in accounts" :value="item.id">{{ item.account }}</option>
                                    </select>
                                    <div v-if="account_details" class="row align-items-center mt-2 flex-fill" style="max-height: 360px;overflow-y: auto">
                                        <table class="table table-vcenter table-hover">
                                            <thead>
                                            <tr>
                                                <th>INFO</th>
                                                <th>INFO</th>
                                                <th>STATUS</th>
                                                <th>MORE</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr v-for="terminal in account_details">

                                                <td class="">
                                                    <div><span class="text-muted">ID : </span>{{ terminal.terminal_id }}</div>
                                                </td>
                                                <td>
                                                    <div><span class="text-muted">Term type : </span>{{ terminal.term_type }}</div>
                                                </td>
                                                <td>
                                                    <div v-if="terminal.active" class="px-2 border border-success text-success small">Active</div>
                                                    <div v-else-if="!terminal.active" class="px-2 border border-danger text-danger small">De-Active</div>
                                                </td>
                                                <td>
                                                    <div>
                                                        <router-link :to="`/terminals/${terminal.terminal_id}/view`" class="text-center action-icon text-primary">
                                                            <i class="mdi mdi-eye mdi-24px"/>
                                                        </router-link>
                                                    </div>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div v-else class="d-flex card-body justify-content-center align-items-center h-100">
                                        <h5 class="text-center">
                                            Internet Banking <br> Offline
                                        </h5>
                                    </div>
                                </div>
                            </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div style="height: 500px;overflow-y: auto"  class="card">
                    <div class="">
                        <h6 class="text-muted px-3 py-2 text-uppercase">Recent Transactions From The Terminals</h6>
                    </div>
                    <div class="table-responsive font-12">
                        <table class="table table-centered mb-0">
                            <thead class="thead-light">
                            <tr>
                                <th>Info</th>
                                <th>Info</th>
                                <th>Info</th>
                                <th>Info</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>

                            <tr v-if="transactions"  v-for="transaction in transactions">
                                <td>
                                    <div><span class="text-muted">Tran Number : </span>{{ transaction._source.tran_nr }}</div>
                                    <div><span class="text-muted">State : </span>{{ transaction._source.state }}</div>
                                    <div><span class="text-muted">Source Node : </span>{{ transaction._source.source_node }}</div>
                                    <div><span class="text-muted">Sink Node : </span>{{ transaction._source.source_node }}</div>
                                </td>
                                <td>
                                    <div><span class="text-muted">Amount : </span>{{ transaction._source.amount }}</div>
                                    <div><span class="text-muted">Pan : </span>{{ transaction._source.pan }}</div>
                                    <div><span class="text-muted">Expiry Date : </span>{{ transaction._source.expiry_date }}</div>
                                    <div><span class="text-muted">RRN : </span>{{ transaction._source.ret_ref_no }}</div>
                                </td>
                                <td>
                                    <div><span class="text-muted">Terminal ID : </span>{{ transaction._source.card_acceptor_id }}</div>
                                    <div><span class="text-muted">Location : </span>{{ transaction._source.card_acceptor_name_loc }}</div>
                                    <div><span class="text-muted">Account From : </span>{{ transaction._source.account_id_1 }}</div>
                                </td>
                                <td>
                                    <div><span class="text-muted">Sponsor Bank : </span>{{ transaction._source.sponsor_bank }}</div>
                                    <div><span class="text-muted">Date : </span>{{ transaction._source.in_req }}</div>
                                    <div><span class="text-muted">Tran Type : </span>{{ transaction._source.tran_type }}</div>
                                    <div><span class="text-muted">Rsp Code : </span>{{ transaction._source.response_code }}</div>
                                </td>
                            </tr>
                            <tr v-else>
                                <td colspan="5"> No Transactions Found</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        name: "dashboard",
        data()
        {
            return {
                account : '',
                transactions : [],
                account_details : [],
                accounts : window.user.accounts ,
                loading : false,
                transactionsLoading:false,
                auth : window.user,
            }
        },
        mounted() {
            this.init();
            if (this.accounts.length > 0)
            {
                this.account = this.accounts[0].id
            }
        },
        watch : {
            account : function (n , o)
            {
                this.loading = true;
                window.axios.get(`${window.location.origin}/dashboard/${n}/details`).then((response) => {
                    this.account_details = response.data.body.terminals;
                }).finally(() => {
                    this.loading = false;
                });

            }
        },
        methods : {
            init()
            {
                this.transactionsLoading = true;
                window.axios.get(`${window.location.origin}/term_transactions`).then((response) => {
                    this.transactions = response.data.body.transactions;
                }).finally(() => {
                    this.loading = false;
                });
            }
        }
    }
</script>

<style scoped>

</style>
