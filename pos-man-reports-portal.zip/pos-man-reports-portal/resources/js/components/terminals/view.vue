<template>
    <div class="py-3">
        <div class="row">
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <table class="card-table table bg-white shadow-sm table-hover">
                            <tbody>
                            <tr>
                                <td class="small"><strong>ID :</strong></td>
                                <td class="text-right">{{ terminal.id }} -
                                    <span v-if="terminal.active" class="px-2 border border-success text-success small ml-2">Active</span>
                                    <span v-else class="px-2 border border-danger text-danger small ml-2">Deactivated</span>
                                </td>
                            </tr>
                            <tr>
                                <td class="small"><strong>Terminal ID :</strong></td>
                                <td class="text-right">{{ terminal.terminal_id }}</td>
                            </tr>
                            <tr>
                                <td class="small"><strong>Account :</strong></td>
                                <td class="text-right">{{ terminal.account_id }}</td>
                            </tr>
                            <tr>
                                <td class="small"><strong>Trade name :</strong></td>
                                <td class="text-right">{{ terminal.trade_name }}</td>
                            </tr>
                            <tr>
                                <td class="small"><strong>Location :</strong></td>
                                <td class="text-right">{{ terminal.location }}</td>
                            </tr>
                            <tr>
                                <td class="small"><strong>Term Type  :</strong></td>
                                <td class="text-right">{{ terminal.override_term_type }} - {{ terminal.term_type }}</td>
                            </tr>
                            <tr>
                                <td class="small"><strong>Model :</strong></td>
                                <td class="text-right">{{ terminal.model }}</td>
                            </tr>
                            <tr>
                                <td class="small"><strong>Serial Number :</strong></td>
                                <td class="text-right">{{ terminal.serial_number }}</td>
                            </tr>
                            <tr>
                                <td class="small"><strong>System Serial Number :</strong></td>
                                <td class="text-right">{{ terminal.system_serial_number }}</td>
                            </tr>
                            <tr>
                                <td class="small"><strong>Created :</strong></td>
                                <td class="text-right">{{ terminal.created_at }}</td>
                            </tr>
                            <tr>
                                <td class="small"><strong>Updated :</strong></td>
                                <td class="text-right">{{ terminal.updated_at }}</td>
                            </tr>
                            <tr>
                                <td class="small"><strong>Total Transactions :</strong></td>
                                <td class="text-right">{{transactions.length}}</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card">
                        <div class="card-body d-flex align-items-start">
                                <div class="app-search m-2 flex-fill">
                                    <div class="input-group">
                                        <input type="date" :value="dateToYYYYMMDD(myStartDate)"
                                               @input="myStartDate = $event.target.valueAsDate"
                                               class="form-control bg-white border">
                                        <span class="mdi mdi mdi-calendar-arrow-right"></span>
                                        <div class="input-group-append">
                                            <button type="submit" disabled class="btn btn-primary shadow-none">Start Date</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="app-search m-2 flex-fill">
                                    <div class="input-group">
                                        <input type="date" :value="dateToYYYYMMDD(myEndDate)"
                                               @input="myEndDate = $event.target.valueAsDate"
                                               class="form-control bg-white border">
                                        <span class="mdi mdi mdi-calendar-arrow-left"></span>
                                        <div class="input-group-append">
                                            <button type="submit" disabled class="btn btn-primary shadow-none">End Date</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="m-2">
                                    <button @click.prevent="submit" type="submit" class="btn btn-primary">Run</button>
                                </div>
                                <div class="m-2">
                                    <button @click.prevent="generateReport" class="btn btn-light mr-2"><i class="mdi mdi-download mr-1"/>Generate Report</button>
                                </div>
                        </div>
                    </div>
                <div class="card" style="height: 800px;overflow-y: auto">
                    <div class="">
                        <p v-if="message" :class="['alert text-center mb-0 rounded-0 mb-3 px-3' , error ? 'alert-danger' : 'alert-success']">
                            {{ message }}
                        </p>
                        <h6 class="text-muted px-3 py-2 text-uppercase">Recent Transactions From The Terminals</h6>
                    </div>
                    <div :class="['dimmer' ,loading ? 'active' : '']">
                        <div class="loader"></div>
                        <div class="dimmer-content">
                            <div class="table-responsive font-12">
                        <table class="table table-centered mb-0">
                                <thead class="thead-light">
                                <tr>
                                    <th>Info</th>
                                    <th>Info</th>
                                    <th>Info</th>
                                    <th>Info</th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>

                                <tr v-if="transactions.length > 0" v-for="transaction in transactions">
                                    <td>
                                        <div><span class="text-muted">Tran Number : </span>{{ transaction._source.tran_nr }}</div>
                                        <div><span class="text-muted">State : </span>{{ transaction._source.state }}</div>
                                        <div><span class="text-muted">Source Node : </span>{{ transaction._source.source_node }}</div>
                                        <div><span class="text-muted">Sink Node : </span>{{ transaction._source.source_node }}</div>
                                    </td>
                                    <td>
                                        <div><span class="text-muted">Amount : </span>{{ transaction._source.amount }}</div>
                                        <div><span class="text-muted">Pan : </span>{{ transaction._source.pan }}</div>
                                        <div><span class="text-muted">Expiry Date : </span>{{ transaction._source.expiry_date }}</div>
                                        <div><span class="text-muted">RRN : </span>{{ transaction._source.ret_ref_no }}</div>
                                    </td>
                                    <td>
                                        <div><span class="text-muted">Terminal ID : </span>{{ transaction._source.card_acceptor_id }}</div>
                                        <div><span class="text-muted">Location : </span>{{ transaction._source.card_acceptor_name_loc }}</div>
                                        <div><span class="text-muted">Account From : </span>{{ transaction._source.account_id_1 }}</div>
                                    </td>
                                    <td>
                                        <div><span class="text-muted">Sponsor Bank : </span>{{ transaction._source.sponsor_bank }}</div>
                                        <div><span class="text-muted">Date : </span>{{ transaction._source.in_req }}</div>
                                        <div><span class="text-muted">Tran Type : </span>{{ transaction._source.tran_type }}</div>
                                        <div><span class="text-muted">Rsp Code : </span>{{ transaction._source.response_code }}</div>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                    </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import Form from "../../core/forms/form";

    export default {
        data() {
            return {
                transactions : [],
                fields: {},
                message:'',
                myStartDate: new Date(),
                myEndDate: new Date(),
                terminal : {},
                requested_transactions: [],
                loading: true,
                search_term_id: this.$route.params.id,
                transactionsLoading: true,
                terminalLoading:true,
                auth : window.user,
                form : new Form({
                    start : new Date().toISOString().slice(0,10),
                    end : new Date().toISOString().slice(0,10),
                })
            };
        },
        methods: {
            init(){
                this.loading = true;
                window.axios.get(`${window.location.origin}/terminals/${this.$route.params.id}/transactions`).then((response) => {
                    this.transactions = response.data.body.transactions.data;
                }).finally(() => {
                    this.loading = false;
                });

                this.terminalLoading = true;
                window.axios.get(`${window.location.origin}/terminals/${this.$route.params.id}/terminal_info`).then((response) => {
                    this.terminal = response.data.body.terminal;
                }).finally(() => {
                    this.terminalLoading = false;
                });
            },
            submit() {
                this.errors = {};
                this.loading = true
                window.axios.get('/transactions/retrieve', {params: {start: this.myStartDate.toLocaleDateString(), end: this.myEndDate.toLocaleDateString(),search_term_id: this.search_term_id}}).then(response => {
                    this.transactions = response.data.body.requested_transactions.data;
                }).catch(error => {
                    if (error.response.status === 422) {
                        this.loading = false;
                        this.errors = error.response.data.errors || {};
                    }
                }).finally(() => {
                    this.loading = false;
                });;
            },
            generateReport() {
                this.errors = {};
                this.loading = true;
                window.axios.get('/reports/terminal/transactions/report', {params: {start: this.myStartDate.toLocaleDateString(), end: this.myEndDate.toLocaleDateString(),search_term_id: this.search_term_id}}).then(response => {
                    this.message = response.data.message;
                }).catch(error => {
                    if (error.response.status === 422) {
                        this.loading = false;
                        this.errors = error.response.data.errors || {};
                    }
                }).finally(() => {
                    this.loading = false;
                });;
            },
            dateToYYYYMMDD(d) {
                return d && new Date(d.getTime()-(d.getTimezoneOffset()*60*1000)).toISOString().split('T')[0]
            },
            request(){
                window.Swal.fire({
                    title: 'Are you sure ?',
                    text: `Get Transactions from ${this.form.start} to ${this.form.end}`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#1c4b27',
                    cancelButtonColor: '#d33',
                    confirmButtonText: `Yes, Request!`
                }).then((result) => {
                    if (result.value) {
                        this.form.submit('/transactions/retrieve').then((response) => {
                            if (response.data.success === true){
                                this.transactions  = response.data.body.requested_transactions;
                            } else {
                                window.alerts.error(response).then((response) => {
                                });
                            }
                        }).catch((error) => {
                        });
                    }
                });
            }
        },
        mounted() {
            this.init();
        }
    }
</script>
