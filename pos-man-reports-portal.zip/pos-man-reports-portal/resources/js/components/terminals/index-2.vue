<template>
    <div class="py-3">
        <div class="row">
            <div class="col-lg-12">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-3">
                            <select v-model="account" name="" :disabled="accounts.length < 2" class="form-control form-control-sm justify-content-end" id="">
                                <option v-for="item in accounts" :value="item.id">{{ item.account }}</option>
                            </select>
                        </div>
                        <div class="col-lg-5">
                            <span v-if="accounts.length < 1">
                                <h6>Please select the account to view terminals</h6>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div :class="['dimmer' , loading ? 'active' : '']">
                <div class="loader"></div>
                <div class="dimmer-content">
                    <div class="card">
                        <div class="card-body d-flex flex-column">
                            <div v-if="account_details" class="row align-items-center mt-2 flex-fill" style="max-height: 700px;overflow-y: auto">
                                <table class="table table-vcenter table-hover">
                                    <thead>
                                    <tr>
                                        <th>INFO</th>
                                        <th>INFO</th>
                                        <th>STATUS</th>
                                        <th>MORE</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr v-for="terminal in account_details">

                                        <td class="">
                                            <div><span class="text-muted">ID : </span>{{ terminal.terminal_id }}</div>
                                        </td>
                                        <td>
                                            <div><span class="text-muted">Term type : </span>{{ terminal.term_type }}</div>
                                        </td>
                                        <td>
                                            <div v-if="terminal.active" class="px-2 border border-success text-success small">Active</div>
                                            <div v-else-if="!terminal.active" class="px-2 border border-danger text-danger small">De-Active</div>
                                        </td>
                                        <td>
                                            <div>
                                                <router-link :to="`/terminals/${terminal.terminal_id}/view`" class="text-center action-icon text-primary">
                                                    <i class="mdi mdi-eye mdi-24px"/>
                                                </router-link>
                                            </div>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div v-else class="d-flex card-body justify-content-center align-items-center h-100">
                                <h5 class="text-center">
                                    Internet Banking <br> Offline
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
        </div>
    </div>
</template>
<script>
export default {
    name: "index-2",
    data(){
        return {
            loading : false,
            account : '',
            account_details : [],
            accounts : window.user.accounts ,
            auth : window.user,
            win : window
        }
    },
    mounted() {
        if (this.accounts.length > 0)
        {
            this.account = this.accounts[0].id
        }
    },
    watch : {
        account : function (n , o)
        {
            this.loading = true;
            window.axios.get(`${window.location.origin}/dashboard/${n}/details`).then((response) => {
                this.account_details = response.data.body.terminals;
            }).finally(() => {
                this.loading = false;
            });

        }
    },
}
</script>
<style scoped>

</style>
