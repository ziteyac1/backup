<template>
    <page-index name="Terminals" url="/terminals/all" prefix="terminals">
        <template slot="table-header">
            <th>#ID</th>
            <th>TERMINAL INFO</th>
            <th>ACCOUNT INFO</th>
            <th>ACTION</th>
        </template>
        <template slot="table-row" slot-scope="data">
            <td>
                <div><span class="text-muted"></span>{{ data.row.id }}</div>
            </td>
            <td>
                <div><span class="text-muted">ID : </span>{{ data.row.terminal_id }}</div>
                <div><span class="text-muted">Model : </span>{{ data.row.model }}</div>
                <div><span class="text-muted">Term type : </span>{{ data.row.override_term_type }}</div>
                <div><span class="text-muted">Created : </span>{{ data.row.created_at }}</div>
            </td>
            <td>
                <div><span class="text-muted">Trade Name : </span>{{ data.row.trade_name }}</div>
                <div><span class="text-muted">Location : </span>{{ data.row.location }}</div>
                <div><span class="text-muted">Serial Number : </span>{{ data.row.serial_number }}</div>
            </td>
            <td>
                <div><span class="text-muted">Account : </span>{{ data.row.account.account }}</div>
                <div><span class="text-muted">Branch Name : </span>{{ data.row.account.branch.name }}</div>
                <div><span class="text-muted">Branch Code : </span>{{ data.row.account.branch.branch_code  }}</div>
                <div><span class="text-muted">Customer Name :  </span> {{ data.row.account.customer.full_name }} </div>
            </td>
            <td>
                <div>
                    <router-link :to="`/terminals/${data.row.terminal_id}/view`" class="action-icon text-primary">
                        <i class="mdi mdi-eye mdi-24px"/>
                    </router-link>
                </div>
            </td>
        </template>
    </page-index>
</template>
<script>
import PageIndex from "../core/page-index";
export default {
    name: "index",
    components: {PageIndex},
    data(){
        return {
            win : window
        }
    }
}
</script>
<style scoped>

</style>
