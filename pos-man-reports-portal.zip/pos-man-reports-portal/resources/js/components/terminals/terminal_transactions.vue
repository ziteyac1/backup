<template>
    <div class="py-3">
    <div class="row">
        <div class="col-lg-7">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive font-12">
                        <table class="table table-centered mb-0">
                            <thead class="thead-light">
                            <tr>
                                <th>Info</th>
                                <th>Info</th>
                                <th>Info</th>
                                <th>Info</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr  v-for="transaction in transactions">
                                <td>
                                    <div><span class="text-muted">Tran Number : </span>{{ transaction._source.tran_nr }}</div>
                                    <div><span class="text-muted">State : </span>{{ transaction._source.state }}</div>
                                    <div><span class="text-muted">Source Node : </span>{{ transaction._source.source_node }}</div>
                                    <div><span class="text-muted">Sink Node : </span>{{ transaction._source.source_node }}</div>
                                </td>
                                <td>
                                    <div><span class="text-muted">Amount : </span>{{ transaction._source.amount }}</div>
                                    <div><span class="text-muted">Pan : </span>{{ transaction._source.pan }}</div>
                                    <div><span class="text-muted">Expiry Date : </span>{{ transaction._source.expiry_date }}</div>
                                    <div><span class="text-muted">RRN : </span>{{ transaction._source.ret_ref_no }}</div>
                                </td>
                                <td>
                                    <div><span class="text-muted">Terminal ID : </span>{{ transaction._source.card_acceptor_id }}</div>
                                    <div><span class="text-muted">Location : </span>{{ transaction._source.card_acceptor_name_loc }}</div>
                                    <div><span class="text-muted">Account From : </span>{{ transaction._source.account_id_1 }}</div>
                                </td>
                                <td>
                                    <div><span class="text-muted">Sponsor Bank : </span>{{ transaction._source.sponsor_bank }}</div>
                                    <div><span class="text-muted">Date : </span>{{ transaction._source.in_req }}</div>
                                    <div><span class="text-muted">Tran Type : </span>{{ transaction._source.tran_type }}</div>
                                    <div><span class="text-muted">Rsp Code : </span>{{ transaction._source.response_code }}</div>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-body d-flex align-items-center border-top">
                        <div class="mr-auto font-weight-bolder">
                            Showing {{ transactions.length }} of {{ transactions.totalHits }} Records
                        </div><!--
                        <div v-if="data.content.total !== data.content.to && data.content.data.length > 0" >
                            <button @click="data.append()" :class="['btn btn-primary' , data.loading ? 'btn-loading' : '' ]" >Load More</button>
                        </div>-->
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                transactions : [],
                loading: true,
                auth : window.user,
            };
        },
        methods: {
            init(){
                this.loading = true;
                window.axios.get(`${window.location.origin}/transactions/all`).then((response) => {
                    this.transactions = response.data.body.transactions;
                }).finally(() => {
                    this.loading = false;
                });
            },
        },
        mounted() {
            this.init();
        }
    }
</script>
