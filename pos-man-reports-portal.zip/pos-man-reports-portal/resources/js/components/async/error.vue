<template>

    <div class="dimmer">
        <div class="loader"></div>
        <div class="dimmer-content">
            <div style="min-height: 60vh;" class="row pt-4 d-flex align-items-center justify-content-center">
                <div class="col-lg-12 h-100 d-flex align-items-center justify-content-center">
                    <div class="display-4 text-center">
                        Error Kindly Refresh Page
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>

<script>
    export default {
        name: "loading"
    }
</script>

<style scoped>

</style>
