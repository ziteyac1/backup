<script>
    import Form from "../../core/forms/form";
    export default {
        name: "internal",
        mounted() {
            this.init();
        },
        data()
        {
            return {
                loading : true,
                accounts : [],
                form : new Form({
                    number_of_auth : '',
                })
            }
        },
        methods : {
            init (){
                this.loading = true;
                window.axios.get(`${window.location.origin}/corporates/settings`).then((response) => {
                    this.form.number_of_auth = response.data.body.settings.number_of_auth;
                }).finally(() => {
                    this.loading = false;
                });
            },
            submit(){
                window.Swal.fire({
                    title: 'Are you sure ?',
                    text: `You want to update Settings`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#1c4b27',
                    cancelButtonColor: '#d33',
                    confirmButtonText: `Yes, Update!`
                }).then((result) => {
                    if (result.value) {
                        this.form.submit('/corporates/settings').then((response) => {
                            window.alerts.success(response);
                        }).catch((error) => {
                        });
                    }
                });
            }
        }
    }
</script>
<template>
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div :class="['dimmer' , loading || form.loading ? 'active' : '']">
                        <div class="loader"></div>
                        <div class="dimmer-content">
                            <div class="form-group mb-0 justify-content-end row">
                                <div class="col-lg-9 mb-3">
                                    <h4 class="header-title mb-2">Corporate Settings</h4>
                                </div>
                            </div>
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label">Number of Authorizers</label>
                                <div class="col-lg-9">
                                    <input type="text" name="name" v-model="form.number_of_auth" :class="[ 'form-control mw-400' , form.errors.get('number_of_auth') ? 'is-invalid' : '' ]" placeholder="Number of Auth">
                                    <div v-text="form.errors.get('number_of_auth')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="form-group mb-0 justify-content-end row">
                                <div class="col-lg-9">
                                    <button type="submit" @click.prevent="submit" :class="['btn btn-primary' , form.loading ? 'btn-loading' : '']">Update Settings</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

