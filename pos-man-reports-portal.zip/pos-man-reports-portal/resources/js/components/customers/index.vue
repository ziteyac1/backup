<template>
    <page-index name="Customers" url="/customers/all" prefix="customers">
        <template slot="table-header">
            <th>INFO</th>
            <th>CONTACT INFO</th>
            <th>DETAILS</th>
        </template>
        <template slot="table-row" slot-scope="data">
            <td>
                <div><span class="text-muted">ID : </span>{{ data.row.id }}</div>
                <div><span class="text-muted">Name : </span>{{ data.row.name }}</div>
                <div><span class="text-muted">Last Name : </span>{{ data.row.last_name }}</div>
            </td>
            <td>
                <div><span class="text-muted">Phone : </span>{{ data.row.phone }}</div>
                <div><span class="text-muted">Email : </span>{{ data.row.email }}</div>
                <div><span class="text-muted">Address : </span>{{ data.row.address }}</div>
            </td>
            <td>
                <div><span class="text-muted">Created : </span>{{ data.row.created_at }}</div>
                <div><span class="text-muted">Updated_at : </span>{{ data.row.updated_at }}</div>
            </td>
            <td>
                <div>
                    <router-link :to="`/customers/${data.row.id}/view`" class="action-icon text-primary">
                        <i class="mdi mdi-eye mdi-24px"/>
                    </router-link>
                </div>
            </td>
        </template>
    </page-index>
</template>
<script>
    import PageIndex from "../core/page-index";
    export default {
        name: "index",
        components: {PageIndex},
        data(){
            return {
                win : window
            }
        }
    }
</script>
<style scoped>

</style>
