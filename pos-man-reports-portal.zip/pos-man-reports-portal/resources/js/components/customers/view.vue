<template>
    <div class="row">
        <div class="col-lg-5">
            <div class="card bg-transparent border-0 rounded-0 shadow-none">
                <div class="card-header">
                    <h5 class="card-title">Customer Info</h5>
                </div>
                <table class="card-table table bg-white shadow-sm table-hover">
                    <tbody>
                    <tr>
                        <td class="small"><strong>ID :</strong></td>
                        <td class="text-right">{{ customer.id }}</td>
                    </tr>
                    <tr>
                        <td class="small"><strong>Name :</strong></td>
                        <td class="text-right">{{ customer.name }}</td>
                    </tr>
                    <tr>
                        <td class="small"><strong>Last Name :</strong></td>
                        <td class="text-right">{{ customer.last_name }}</td>
                    </tr>
                    <tr>
                        <td class="small"><strong>Email :</strong></td>
                        <td class="text-right">{{ customer.email }}</td>
                    </tr>
                    <tr>
                        <td class="small"><strong>Phone :</strong></td>
                        <td class="text-right">{{ customer.phone }}</td>
                    </tr>
                    <tr>
                        <td class="small"><strong>Address :</strong></td>
                        <td class="text-right">{{ customer.address }}</td>
                    </tr>
                    <tr>
                        <td class="small"><strong>Created :</strong></td>
                        <td class="text-right">{{ customer.created_at }}</td>
                    </tr>
                    <tr>
                        <td class="small"><strong>Updated :</strong></td>
                        <td class="text-right">{{ customer.updated_at }}</td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="card">
                <div class="card-body">
                    <table class=" table table-vcenter table-hover">
                        <thead>
                        <tr>
                            <th>Account</th>
                            <th>Branch</th>
                            <th class="text-center">Terminals</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr v-for="account in customer.accounts">
                            <td>
                                <div><span class="text-muted">ID : </span>{{ account.account }}</div>
                                <div><span class="text-muted">Created : </span>{{ account.created_at }}</div>
                            </td>
                            <td>
                                <div><span class="text-muted">Short Name : </span>{{ account.branch.short_name }}</div>
                                <div><span class="text-muted">Name : </span>{{ account.branch.name }}</div>
                            </td>
                            <td class="text-center">
                                {{ account.terminals_limit.length }}
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                customer: {
                    accounts : [],
                    terminals_limit : [],
                },
                loading: true,
                auth : window.user,
            };
        },
        methods: {
            init(){
                this.loading = true;
                window.axios.get(`${window.location.origin}/customers/${this.$route.params.id}/view`).then((response) => {
                    this.customer = response.data.body.customer;
                }).finally(() => {
                    this.loading = false;
                });
            },
        },
        mounted() {
            this.init();
        }
    }
</script>
