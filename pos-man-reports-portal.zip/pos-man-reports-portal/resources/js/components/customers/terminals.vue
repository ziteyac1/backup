<template>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h6>Terminal Details</h6>
                </div>
                <div class="card-body">
                    <table class="table table-vcenter table-hover">
                        <thead>
                        <tr>
                            <th>INFO</th>
                            <th>INFO</th>
                            <th>STATUS</th>
                            <th>TRANSACTIONS</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr v-for="terminal in customer.terminals">

                            <td class="">
                                <div><span class="text-muted">ID : </span>{{ terminal.terminal_id }}</div>
                                <div><span class="text-muted">Trade Name : </span>{{ terminal.trade_name }}</div>
                                <div><span class="text-muted">Location : </span>{{ terminal.location }}</div>
                            </td>
                            <td>
                                <div><span class="text-muted">Term type : </span>{{ terminal.override_term_type }}</div>
                                <div><span class="text-muted">Location : </span>{{ terminal.location }}</div>
                                <div><span class="text-muted">Serial Number : </span>{{ terminal.serial_number }}</div>

                            </td>
                            <td>
                                <div v-if="terminal.active" class="px-2 border border-success text-success small">Active</div>
                                <div v-else-if="!terminal.active" class="px-2 border border-danger text-danger small">De-Active</div>
                            </td>
                            <td>
                                <div>
                                    <router-link :to="`/terminal/${terminal.terminal_id}/transactions`" class="action-icon text-primary">
                                        <i class="mdi mdi-eye mdi-24px"/>
                                    </router-link>
                                </div>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                customer: {
                    accounts : [],
                    terminals : [],
                },
                loading: true,
                auth : window.user,
            };
        },
        methods: {
            init(){
                this.loading = true;
                window.axios.get(`${window.location.origin}/customers/${this.$route.params.id}/terminals`).then((response) => {
                    this.customer = response.data.body.customer;
                }).finally(() => {
                    this.loading = false;
                });
            },
        },
        mounted() {
            this.init();
        }
    }
</script>
