import loading from "../components/async/loading";
import error from "../components/async/error";

const Index = () => ({
    component : import(/* webpackChunkName: "transactions" */ "../components/transactions/index"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const Open = () => ({
    component : import(/* webpackChunkName: "transactions" */ "../components/transactions/open"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const View = () => ({
    component : import(/* webpackChunkName: "transactions" */ "../components/transactions/view"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const routes = [
    {
      path : '/transactions',
      component : Index
    },
    {
        path : '/transactions/:id/view',
        component : Open,
        children : [
            {
                path : '/transactions/:id/view',
                component : View,
            },
        ]
    },
];
export default routes;
