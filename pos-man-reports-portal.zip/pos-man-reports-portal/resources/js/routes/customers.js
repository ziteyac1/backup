import loading from "../components/async/loading";
import error from "../components/async/error";

const Index = () => ({
    component : import(/* webpackChunkName: "terminal" */ "../components/customers/index"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const View = () => ({
    component : import(/* webpackChunkName: "users" */ "../components/customers/view"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});


const Open = () => ({
    component : import(/* webpackChunkName: "users" */"../components/customers/open"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});
const Terminals = () => ({
    component : import(/* webpackChunkName: "users" */"../components/customers/terminals"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const Corporate = () => ({
    component : import(/* webpackChunkName: "settings" */"../components/settings/corporate"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const Password = () => ({
    component : import(/* webpackChunkName : "settings" */ "../components/settings/password"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const Profile = () => ({
    component : import(/* webpackChunkName : "settings" */ "../components/settings/profile"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const SettingsOpen = () => ({
    component : import(/* webpackChunkName: "settings" */ "../components/settings/open"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const routes = [
    {
        path : '/customers',
        component : Index
    },
    {
        path : '/settings',
        component : SettingsOpen,
        children : [
            {
                path : '/settings',
                component : Profile,
            },
            {
                path : '/password',
                component : Password,
            },
            {
                path : '/corporate',
                component : Corporate,
            },
        ]
    },
    {
        path: '/customers/:id/view',
        component: Open,
        children: [
            {
                path: '/customers/:id/view',
                component: View,
            },
            {
                path: '/customers/:id/terminals',
                component: Terminals
            },
        ],
    }
];
export default routes;
