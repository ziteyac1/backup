import loading from "../components/async/loading";
import error from "../components/async/error";

const Index = () => ({
    component : import(/* webpackChunkName: "terminal" */ "../components/terminals/index"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});
const AccountTerminals = () => ({
    component : import(/* webpackChunkName: "terminal" */ "../components/terminals/index-2"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});
const View = () => ({
    component : import(/* webpackChunkName: "terminal" */ "../components/terminals/view"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});
const Open = () => ({
    component : import(/* webpackChunkName: "users" */"../components/terminals/open"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});


const routes = [
    {
        path : '/terminals',
        component : Index
    },
    {
        path: '/terminals/account',
        component: AccountTerminals,
    },
    {
        path: '/terminals/:id/view',
        component: Open,
        children: [
            {
                path: '/terminals/:id/view',
                component: View,
            },
        ],
    },

];
export default routes;
