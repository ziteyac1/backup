import loading from "../components/async/loading";
import error from "../components/async/error";

const Index = () => ({
    component : import(/* webpackChunkName : "dash" */ "../components/dashboard/dashboard"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const routes = [
    {
        path : '/',
        component : Index
    },
];
export default routes;
