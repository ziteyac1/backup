import VueRouter from "vue-router";
import Vue from "vue";

Vue.use(VueRouter);

let routes = [];


import dash from "../dash";
routes = routes.concat(dash);

import terminal from "../terminal";
routes = routes.concat(terminal);

import customers from "../customers";
routes = routes.concat(customers);
import reports from "../reports";
routes = routes.concat(reports);

import transactions from "../transactions"
routes = routes.concat(transactions)
const router = new VueRouter({
    routes :  routes
});

router.beforeEach((to, from, next) => {
    window.scrollTo( 0 , 0 );
    next();
});

export default router;
