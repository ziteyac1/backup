<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CustomerReportController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ReportsController;
use App\Http\Controllers\TerminalsReportController;
use App\Http\Controllers\TransactionsReportController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/',[AuthController::class,'landing']);
Auth::routes();
Route::post('/register',[UserController::class,'create']);
Route::post('/logout',[AuthController::class,'logout']);
Route::middleware('auth')->group(function (){

    Route::get('/',[DashboardController::class,'index']);
    Route::get('/term_transactions',[DashboardController::class,'term_transactions']);
    Route::get('/dashboard/{model}/details',[DashboardController::class,'details']);
    Route::get('/users/get',[DashboardController::class,'users']);


    Route::prefix('/terminals')->group(function () {
        Route::get('/all', [TerminalsReportController::class, 'index']);
        Route::get('/{account}/all', [TerminalsReportController::class, 'account_terminals']);
        Route::get('/{terminal}/transactions', [TerminalsReportController::class, 'transactions']);
        Route::get('/{terminal}/terminal_info', [TerminalsReportController::class, 'info']);
    });

    Route::prefix('/customers')->group(function () {
        Route::get('/all', [CustomerReportController::class, 'customers']);
        Route::get('/{customer}/view', [CustomerReportController::class, 'show']);
        Route::get('/{customer}/terminals', [CustomerReportController::class, 'terms']);
    });

    Route::prefix('/transactions')->group(function () {
        Route::get('/all', [TransactionsReportController::class, 'index']);
        Route::get('/{id}/get', [TransactionsReportController::class, 'transaction']);
        Route::get('/retrieve', [TransactionsReportController::class, 'transactions_request']);
    });

    Route::prefix('/reports')->group(function () {
        Route::get('/all', [ReportsController::class, 'index']);
        Route::get('/terminal/transactions/report', [ReportsController::class, 'report']);
        Route::get('/{report}/download', [ReportsController::class, 'download']);
    });




});
