<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property mixed name
 */
class Branch extends Model
{
    protected $connection = 'sqlsrv_pos';
    protected $table = 'branches';
}
