<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 2/11/2019
 * Time: 9:15 AM
 */

namespace App\core;


use App\elastic\TransactionFilters;
use App\elastic\TransactionsService;
use App\models\Branch;
use App\models\ResponseCode;
use App\models\Terminal;
use App\models\Transaction;
use App\models\TransactionType;
use Illuminate\Support\Facades\Cache;

class Helper
{

    /**
     * @param $key
     * @return string
     */
    public static function getSourceNodeName($key): string
    {

        $data['AgriMerchSrc'] = 'Merchant';
        $data['AgriPosSrc'] = 'Agency';
        $data['AgriMPOSSrc'] = 'MPOS';
        $data['AgriTellSrc'] = 'Teller';

        return $data[$key];

    }


    /**
     * @param $key
     * @return string
     */
    public static function getTranTypeName($key): string
    {

        $item = Cache::rememberForever($key.'getTranTypeName', function () use ($key) {

            $item =  TransactionType::query()->where('code', $key )->first();

            if ($item)
            {
                return $item->description;
            }

            return null;

        });

        return $item ?: 'X';

    }

    /**
     * @param $key
     * @return string
     */
    public static function getResponseCodeName($key): string
    {

        $item = Cache::rememberForever($key.'getResponseCodeName',  function () use ($key) {

            $item =  ResponseCode::query()->where('code', $key )->first();

            if ($item)
            {
                return $item->description;
            }

            return null;

        });

        return $item ?: 'X';

    }

    /**
     * @param $key
     * @return string
     */
    public static function getBranchName($key): string
    {

        $item = Cache::rememberForever($key.'getBranchName',  function () use ($key) {

            $item = Branch::query()->where('branch_code', $key )->first();

            if ($item)
            {
                return $item->name;
            }

            return null;

        });

        return $item ?:'Un-known';

    }

    /**
     * @param $terminal
     * @return string
     */
    public static function getLastTransaction($terminal): string
    {
        $params = [
            'card_acceptor_id' => $terminal
        ];

        $tran = Cache::tags(['terminal-transaction'])->rememberForever($terminal.'getLastTransaction' , function () use ( $params , $terminal ) {

            $filters =  new TransactionFilters();
            $filters->apply(
                Transaction::search('*')->where('card_acceptor_id', $terminal )->orderBy('in_req', 'desc'),
                $params,
                $params,
                false
            );

            $extra = [
                'size' => 1,
                '_source' => 'in_req'
            ];

            $service  =  new TransactionsService(
                array_merge($filters->params() , $extra )
            );

            $filters = null;
            $response = $service->search();

            $date = collect($response['hits']['hits'])->map(function ($value) {
                return $value['_source']['in_req'];
            })->first();

            return $date;

        });

        return $tran ?: 'Un-known';

    }

    /**
     * @param $value
     * @return string
     */
    public static function format($value): string
    {

        return number_format( $value , 0, ',', ' ');

    }

}