<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 12/12/2018
 * Time: 9:47 AM
 */

namespace App\core\Filters;


use Illuminate\Database\Eloquent\Builder;

class SearchFilters
{
    public static function customerSearch(Builder $builder, $value): void
    {
        $value = preg_replace('/\s+/', ' ', $value);

        foreach (explode(' ', $value) as $searchV) {

            $builder->orWhere('name', 'like', "%{$searchV}%");
            $builder->orWhere('last_name', 'like', "%{$searchV}%");
            $builder->orWhere('phone', 'like', "%{$searchV}%");
            $builder->orWhere('address', 'like', "%{$searchV}%");

        }

        $builder->orWhere('name', 'like', "%{$value}%");
		$builder->orWhere('id', 'like', "%{$value}%");
        $builder->orWhere('last_name', 'like', "%{$value}%");
        $builder->orWhere('phone', 'like', "%{$value}%");
        $builder->orWhere('address', 'like', "%{$value}%");

    }


    public static function branchSearch(Builder $builder, $value): void
    {
        $value = preg_replace('/\s+/', ' ', $value);

        foreach (explode(' ', $value) as $searchV) {

            $builder->orWhere('branch_code', 'like', "%{$searchV}%");
            $builder->orWhere('name', 'like', "%{$searchV}%");
            $builder->orWhere('short_name', 'like', "%{$searchV}%");

        }

        $builder->orWhere('branch_code', 'like', "%{$value}%");
        $builder->orWhere('name', 'like', "%{$value}%");
        $builder->orWhere('short_name', 'like', "%{$value}%");

    }

    public static function accountSearch(Builder $builder, $value): void
    {
        $value = preg_replace('/\s+/', ' ', $value);

        foreach (explode(' ', $value) as $searchValue) {

            $builder->orWhere('account','like',"%{$searchValue}%");
            $builder->orWhere('branch_code','like',"%{$searchValue}%");
            $builder->orWhere('customer_id','like',"%{$searchValue}%");

        }

        $builder->orWhere('account','like',"%{$value}%");
        $builder->orWhere('branch_code','like',"%{$value}%");
        $builder->orWhere('customer_id','like',"%{$value}%");

    }

    public static function terminalSearch(Builder $builder, $value): void
    {

        $builder->orWhere('terminal_id','like',"%{$value}%");
        $builder->orWhere('account_id','like',"%{$value}%");
        $builder->orWhere('override_term_type','like',"%{$value}%");
        $builder->orWhere('model','like',"%{$value}%");
        $builder->orWhere('term_type','like',"%{$value}%");
        $builder->orWhere('system_serial_number','like',"%{$value}%");
        $builder->orWhere('serial_number','like',"%{$value}%");
        $builder->orWhere('trade_name','like',"%{$value}%");
        $builder->orWhere('location','like',"%{$value}%");

    }

    public static function requestSearch(Builder $builder, $value): void
    {
        $type = strtolower(str_slug($value));
        $builder->orWhere('requester_id','like',"%{$value}%");
        $builder->orWhere('branch_code','like',"%{$value}%");
        $builder->orWhere('role_assigned','like',"%{$value}%");
        $builder->orWhere('type','like',"%{$type}%");
        $builder->orWhere('reference','like',"%{$value}%");
        $builder->orWhere('suggestion','like',"%{$value}%");
        $builder->orWhere('resolution','like',"%{$value}%");
        $builder->orWhere('data','like',"%{$value}%");
        $builder->orWhere('state','like',"%{$value}%");
    }

    public static function posIssueSearch(Builder $builder, $value): void
    {
        $builder->orWhere('terminal','like',"%{$value}%");
        $builder->orWhere('serial_number','like',"%{$value}%");
        $builder->orWhere('branch','like',"%{$value}%");
    }

    public static function reportsSearch(Builder $builder, $value): void
    {
        $builder->orWhere('name','like',"%{$value}%");
        $builder->orWhere('description','like',"%{$value}%");
        $builder->orWhere('type','like',"%{$value}%");
        $builder->orWhere('section','like',"%{$value}%");
    }

    public static function howtoSearch(Builder $builder, $value): void
    {
        $builder->orWhere('name','like',"%{$value}%");
        $builder->orWhere('description','like',"%{$value}%");
        $builder->orWhere('type','like',"%{$value}%");
        $builder->orWhere('section','like',"%{$value}%");
    }

    public static function reportsRequestSearch(Builder $builder, $value): void
    {
        $builder->orWhere('requester_id','like',"%{$value}%");
        $builder->orWhere('report_path','like',"%{$value}%");
    }

    public static function posReturnSearch(Builder $builder, $value): void
    {
        $builder->orWhere('data','like',"%{$value}%");
        $builder->orWhere('suggestion','like',"%{$value}%");
        $builder->orWhere('resolution','like',"%{$value}%");
    }

    public static function userSearch(Builder $builder, $value): void
    {
        $builder->orWhere('name','like',"%{$value}%");
        $builder->orWhere('email','like',"%{$value}%");
        $builder->orWhere('branch','like',"%{$value}%");
    }

    public static function tellerSearch(Builder $builder, $value): void
    {
        $builder->orWhere('card_number','like',"%{$value}%");
        $builder->orWhere('linked_terminal','like',"%{$value}%");
        $builder->orWhere('name','like',"%{$value}%");
    }

    public static function posSearch(Builder $builder, $value): void
    {
        $builder->orWhere('asset_code','like',"%{$value}%");
        $builder->orWhere('model','like',"%{$value}%");
        $builder->orWhere('location','like',"%{$value}%");
        $builder->orWhere('working_state','like',"%{$value}%");
        $builder->orWhere('location','like',"%{$value}%");
        $builder->orWhere('serial_number','like',"%{$value}%");
    }

    public static function posHire(Builder $builder, $value): void
    {
        $builder->orWhere('terminal','like',"%{$value}%");
        $builder->orWhere('serial_number','like',"%{$value}%");
    }

    public static function posTransfer(Builder $builder, $value): void
    {
        $builder->orWhere('terminal','like',"%{$value}%");
        $builder->orWhere('asset_code','like',"%{$value}%");
        $builder->orWhere('batch_id','like',"%{$value}%");
    }

    public static function posLog(Builder $builder, $value): void
    {
        $builder->orWhere('serial_number','like',"%{$value}%");
        $builder->orWhere('log_id','like',"%{$value}%");
        $builder->orWhere('log','like',"%{$value}%");
        $builder->orWhere('suggestion','like',"%{$value}%");
        $builder->orWhere('level','like',"%{$value}%");
        $builder->orWhere('account','like',"%{$value}%");
    }

    public static function posBatch(Builder $builder, $value): void
    {
        $builder->orWhere('to','like',"%{$value}%");
        $builder->orWhere('to_branch','like',"%{$value}%");
        $builder->orWhere('transport','like',"%{$value}%");
    }
}