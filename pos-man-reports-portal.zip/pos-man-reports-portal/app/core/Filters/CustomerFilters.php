<?php

namespace App\core\Filters;

use App\User;
use Illuminate\Database\Eloquent\Builder;

class CustomerFilters extends Filters
{

    /**
     * Registered filters to operate upon.
     *
     * @var array
     */
    protected $filters = [
        'search','branch','account'
    ];

    protected function branch($value): Builder
    {
        return $this->builder->whereHas('transactions',function (Builder $builder) use ($value){
            $builder->where('branch_code' , $value);
        });
    }

    protected function account($value): Builder
    {
        return $this->builder->whereHas('transactions',function (Builder $builder) use ($value){
            $builder->where('account' , $value);
        });
    }

    /**
     * Filter the query by search of Customers
     *
     * @param $value
     * @return Builder
     */

    protected function search($value): Builder
    {
        return $this->builder->where(function (Builder $builder) use ($value){
            SearchFilters::customerSearch($builder, $value);
        });
    }


}
