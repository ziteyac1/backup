<?php

namespace App\core\Filters;

use App\User;
use Illuminate\Database\Eloquent\Builder;

class ReportRequestsFilters extends Filters
{

    /**
     * Registered filters to operate upon.
     *
     * @var array
     */
    protected $filters = [
        'search','user'
    ];

    protected function user($value): Builder
    {
        return $this->builder->where('requester_id', $value );
    }


    /**
     * Filter the query by search of Customers
     *
     * @param $value
     * @return Builder
     */
    protected function search($value): Builder
    {
        return $this->builder->where(function (Builder $builder) use ($value){

            SearchFilters::reportsRequestSearch($builder , $value);

            $builder->orWhereHas('report',function (Builder $builder) use ($value ){
                SearchFilters::reportsSearch($builder , $value);
            });

        });
    }


}
