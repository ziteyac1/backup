<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 11/21/2018
 * Time: 11:40 AM
 */

namespace App\core\Filters;


use phpDocumentor\Reflection\Types\Boolean;

trait HasFilter
{

    /**
     * @param $query
     * @param Filters $filters
     * @param array $extra
     * @param array $exclude
     * @param bool $considerRequest
     * @return \Illuminate\Database\Eloquent\Builder
     */

    public function scopeFilter($query, Filters $filters, array $extra = [], array $exclude = [] ,  bool $considerRequest = true ): \Illuminate\Database\Eloquent\Builder
    {
        return $filters->apply($query, $extra, $exclude , $considerRequest );
    }
}