<?php

namespace App\core\Filters;

use App\filters\core\ModelFilter;
use App\User;
use Illuminate\Database\Eloquent\Builder;

class TerminalFilters extends ModelFilter
{

    /**
     * Registered filters to operate upon.
     *
     * @var array
     */
    protected $filters = [
        'search'
    ];
    protected $search = [
        'terminal_id',
        'model',
        'override_term_type',
        'serial_number',
        'trade_name',
        'location',
    ];

    /*protected function search(Builder $builder,$value): Builder
    {
        return $this->builder->where(function ($builder) use ($value){

           SearchFilters::terminalSearch($builder , $value);

        });
    }

    protected function customer($value){

        return $this->builder->whereHas('account.customer' ,function (Builder $builder) use ($value){

            $builder->where('id', $value);

        });
    }

    protected function account_id($value){

        return $this->builder->whereHas('account' ,function (Builder $builder) use ($value){

            $builder->where('account_id', $value);

        });
    }

    protected function branch_code($value){

        return $this->builder->whereHas('account' ,function (Builder $builder) use ($value){

            $builder->where('branch_code', $value);

        });
    }


    protected function start_date($value): Builder
    {
        return $this->builder->where('terminals.created_at', '>=',$value.' 00:00:00.000');
    }

    protected function end_date($value): Builder
    {
        return $this->builder->where('terminals.created_at','<=', $value.' 23:59:59.000');
    }*/

}
