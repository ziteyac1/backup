<?php

namespace App\core\Filters;

use App\User;
use Illuminate\Database\Eloquent\Builder;

class RequestFilters extends Filters
{

    /**
     * Registered filters to operate upon.
     *
     * @var array
     */
    protected $filters = [
        'search','type','requester','mine',
        'state','id','start_date','end_date','branch_code'
    ];

    /**
     * Filter the query by ID  of Requests
     *
     * @param $value
     * @return Builder
     */
    protected function id($value): Builder
    {
        return $this->builder->where('id', $value );
    }

    /**
     * Filter the query by Type of Requests
     *
     * @param $value
     * @return Builder
     */
    protected function state($value): Builder
    {
        if ($value === 'closed')
        {
            return $this->builder->whereHas('state_name' , function (Builder $builder)
            {
                $builder->where('action', 'close');

            });


        } else {

            return $this->builder->whereHas('state_name' , function (Builder $builder)
            {
                $builder->where('action', '!=', 'close' );
            });

        }


    }

    /**
     * Filter the query by Type of Requests
     *
     * @param $value
     * @return Builder
     */
    protected function mine($value): Builder
    {
        return $this->builder->where(function (Builder $builder) use ($value){

            $user = auth()->user();

            /** @noinspection NullPointerExceptionInspection */
            /** @var User $user */
            $builder->orWhere('requester_id' , $user->id );

            /** @noinspection NullPointerExceptionInspection */
            /** @var User $user */
            if ( $user->role_name->name === 'branch-manager' || $user->role_name->name === 'branch' ){

                /** @noinspection NullPointerExceptionInspection */
                $builder->orWhere(function (Builder $builder) use ($user) {

                    /** @noinspection NullPointerExceptionInspection */
                    $builder->where('role_assigned' , $user->role_name->name );
                    /** @noinspection NullPointerExceptionInspection */
                    $builder->where('branch_code' , $user->branch );

                });


                return;

            }

            /** @noinspection NullPointerExceptionInspection */
            $builder->orWhere('role_assigned' , $user->role_name->name );

        });
    }


    /**
     * Filter the query by Type of Requests
     *
     * @param $value
     * @return Builder
     */
    protected function type($value): Builder
    {
        return $this->builder->where('type', $value );
    }


    protected function start_date($value): Builder
    {
        return $this->builder->where('requests.created_at', '>=',$value.' 00:00:00.000');
    }

    protected function end_date($value): Builder
    {
        return $this->builder->where('requests.created_at','<=', $value.' 23:59:59.000');
    }

    protected function branch_code($value): Builder
    {
        return $this->builder->where('branch_code',$value);
    }

    /**
     * Filter the query by Requester
     *
     * @param $value
     * @return Builder
     */
    protected function user($value): Builder
    {
        return $this->builder->where('requester_id', $value );
    }


    /**
     * Filter the query by search of Request
     *
     * @param $value
     * @return Builder
     */
    protected function search($value): Builder
    {
        return $this->builder->where(function (Builder $builder) use ($value){

            SearchFilters::requestSearch($builder , $value);

        });
    }


}
