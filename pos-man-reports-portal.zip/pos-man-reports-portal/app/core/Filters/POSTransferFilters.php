<?php

namespace App\core\Filters;

use App\User;
use Illuminate\Database\Eloquent\Builder;

class POSTransferFilters extends Filters
{

    /**
     * Registered filters to operate upon.
     *
     * @var array
     */
    protected $filters = [
        'search','mine','batch',
        'to','to_branch','transport','sender','receiver_id','sent','received','receiver'
    ];

    protected function to($value): Builder
    {
        return $this->builder->whereHas('batch' , function (Builder $builder) use ($value)
        {
            $builder->where('to' , $value );
        });
    }

    protected function to_branch($value): Builder
    {
        return $this->builder->whereHas('batch' , function (Builder $builder) use ($value)
        {
            $builder->where('to_branch' , $value );
        });
    }

    protected function transport($value): Builder
    {
        return $this->builder->whereHas('batch' , function (Builder $builder) use ($value)
        {
            $builder->where('transport' , $value );
        });
    }

    protected function sender($value): Builder
    {
        return $this->builder->whereHas('batch.sender' , function (Builder $builder) use ($value)
        {
            $builder->orWhere('email' , 'like' ,"%{$value}%");
            $builder->orWhere('name' , 'like' ,"%{$value}%");
        });
    }

    protected function receiver($value): Builder
    {
        return $this->builder->whereHas('batch.receiver' , function (Builder $builder) use ($value)
        {
            $builder->orWhere('email' , 'like' ,"%{$value}%");
            $builder->orWhere('name' , 'like' ,"%{$value}%");
        });
    }

    protected function received($value): Builder
    {
        return $this->builder->whereHas('batch' , function (Builder $builder) use ($value)
        {
            $builder->whereNotNull('received');
        });
    }

    protected function sent($value): Builder
    {
        return $this->builder->whereHas('batch' , function (Builder $builder) use ($value)
        {
            $builder->whereNotNull('sent');
        });
    }

    protected function batch($value): Builder
    {
        return $this->builder->where('batch_id' , $value );
    }

    /**
     * Filter the query by search of Customers
     *
     * @param $value
     * @return Builder
     */
    protected function search($value): Builder
    {
        return $this->builder->where(function (Builder $builder) use ($value){

           SearchFilters::posTransfer($builder , $value);

        });
    }

    /**
     * Filter by owner of the POSTransfer
     *
     * @param $value
     * @return Builder
     */
    protected function mine($value): Builder
    {
        return $this->builder->whereHas('batch' , function (Builder $builder) {

            $builder->where(function (Builder $builder){

                /** @var User $user */
                $user = auth()->user();

                $builder->orWhere('sender_id' , $user->id );

                $builder->orWhere(function (Builder $builder) use ($user) {

                    $builder->where('to_branch' , $user->branch );
                    $builder->where('to' , $user->role_name->name );

                });

                if ( $user->role_name->name === 'e-channels' ){

                    $builder->orWhere(function (Builder $builder){

                        $builder->where('to_branch' , 'eft' );
                        $builder->where('to' , 'eft' );

                    });
                }

            });

        });
    }


}
