<?php

namespace App;

use App\Core\DefaultModel;
use Illuminate\Database\Eloquent\Model;

class ResponseCode extends DefaultModel
{

    protected $guarded = [];
}
