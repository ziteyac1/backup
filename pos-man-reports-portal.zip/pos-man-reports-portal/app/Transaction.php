<?php

namespace App;
use App\Core\DefaultModel;
use App\elastic\TransactionsConfigurator;
use App\Terminal;
use Illuminate\Database\Eloquent\Model;
use ScoutElastic\Searchable;

/**
 * @property Terminal terminal
 * @property mixed tran_nr
 */
class Transaction extends DefaultModel
{
    use Searchable;

    protected $indexConfigurator = TransactionsConfigurator::class;

    protected $guarded = [];

    protected $mapping = [

        'properties' => [

            'tran_nr' => [
                'type' => 'long',
                'index' => true,
            ],
            'in_req' => [
                'type' => 'date',
                'index' => true,
                'format'=> 'yyyy-MM-dd HH:mm:ss.SSSSSS||yyyy-MM-dd||epoch_millis'
            ],
            'card_acceptor_id' => [
                'type' => 'keyword',
                'index' => true,
            ],
            'source_node' => [
                'type' => 'keyword',
                'index' => true,
            ],
            'sink_node' => [
                'type' => 'keyword',
                'index' => true,
            ],
            'account_id_1' => [
                'type' => 'keyword',
                'index' => true,
            ],
            'account_id_2' => [
                'type' => 'keyword',
                'index' => true,
            ],
            'sponsor_bank' => [
                'type' => 'keyword',
                'index' => true,
            ],
            'tran_type' => [
                'type' => 'keyword',
                'index' => true,
            ],
            'card_acceptor_name_loc' => [
                'type' => 'text',
                'index' => true,
                'fielddata' => true,
            ],
            'response_code' => [
                'type' => 'keyword',
                'index' => true,
            ],
            'structured_data' => [
                'type' => 'text',
                'index' => true,
                'fielddata' => true,
            ],
            'extended_data' => [
                'type' => 'text',
                'index' => true,
                'fielddata' => true,
            ],
            'trade_name' => [
                'type' => 'text',
                'index' => true,
                'fielddata' => true,
            ],
            'location' => [
                'type' => 'text',
                'index' => true,
                'fielddata' => true,
            ],
            'state' => [
                'type' => 'keyword',
                'index' => true,
            ],
            'amount' => [
                'type' => 'double',
                'index' => true,
            ],
            'pan' => [
                'type' => 'keyword',
                'index' => true,
            ],
            'expiry_date' => [
                'type' => 'keyword',
                'index' => true,
            ],
            'ret_ref_no' => [
                'type' => 'keyword',
                'index' => true,
            ],
            'account' => [
                'type' => 'keyword',
                'index' => true,
            ],
            'branch_code' => [
                'type' => 'keyword',
                'index' => true,
            ],
            'system_serial_number' => [
                'type' => 'keyword',
                'index' => true,
            ],
            'serial_number' => [
                'type' => 'keyword',
                'index' => true,
            ],
            'customer_id' => [
                'type' => 'long',
                'index' => true,
            ]
        ]
    ];

    public function terminal(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(Terminal::class ,'terminal_id','card_acceptor_id');
    }

    public function toSearchableArray(): array
    {
        $array = $this->toArray();

        $data = [];

        if ($this->terminal){

            $data3 = [
                'system_serial_number' => $this->terminal->system_serial_number,
                'serial_number' => $this->terminal->serial_number,
                'trade_name' => $this->terminal->trade_name,
                'location' => $this->terminal->location,
            ];

            $data = array_merge( $data , $data3 );

            if ($this->terminal->account){

                $data2 = [
                    'branch_code' => $this->terminal->account->branch_code,
                    'customer_id' => $this->terminal->account->customer_id,
                    'account' => $this->terminal->account->account,
                ];

                $data = array_merge( $data , $data2 );
            }
        }

        return array_merge( $array , $data );
    }
}
