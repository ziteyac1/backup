<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SelfRegistration extends Model
{
    protected $guarded = [];
}
