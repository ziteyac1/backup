<?php

namespace App;

use App\Core\DefaultModel;
use Illuminate\Database\Eloquent\Model;

class Report extends DefaultModel
{
    protected $guarded = [];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id','id');
    }
}
