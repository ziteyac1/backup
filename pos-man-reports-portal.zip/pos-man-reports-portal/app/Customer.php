<?php

namespace App;

use App\core\Filters\HasFilter;
use App\filters\core\HasModelFilter;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;

/**
 * @property mixed transactions
 * @property mixed name
 * @property mixed last_name
 * @property mixed updated_at
 * @property mixed created_at
 * @property mixed phone
 * @property mixed address
 * @property mixed email
 * @property mixed id
 * @property mixed full_name
 */
class Customer extends Model implements Auditable
{
    use HasModelFilter , \OwenIt\Auditing\Auditable ;

    protected /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $guarded = [];

    protected $connection = 'sqlsrv_pos';
    protected $table = 'customers';
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function accounts(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
       return $this->hasMany(Account::class ,'customer_id' ,'id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasManyThrough
     */
    public function terminals(): \Illuminate\Database\Eloquent\Relations\HasManyThrough
    {
        return $this->hasManyThrough(Terminal::class ,Account::class,'customer_id', 'account_id','id','account');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasManyThrough
     */
    public function terminals_limit(): \Illuminate\Database\Eloquent\Relations\HasManyThrough
    {
        return $this->terminals()->limit(20);
    }

    /**
     * @param $data
     * @return Model
     */
    public function addAccount($data): Model
    {
        return $this->accounts()->create($data);
    }

    /**
     * @return string
     */
    public function getFullNameAttribute(): string
    {
        return $this->name .' '. $this->last_name;
    }

}
