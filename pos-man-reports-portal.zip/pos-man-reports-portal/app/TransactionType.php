<?php

namespace App;

use App\Core\DefaultModel;

class TransactionType extends DefaultModel
{
    protected $guarded = [];
}
