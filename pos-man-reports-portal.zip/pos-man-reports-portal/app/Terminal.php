<?php

namespace App;

use App\Core\DefaultModel;


/**
 * @property mixed terminal_id
 * @property mixed trade_name
 * @property mixed account_id
 * @property Account account
 * @property mixed system_serial_number
 * @property mixed serial_number
 * @property mixed location
 * @property mixed|null term_model
 * @property null model
 * @property null override_term_type
 * @property mixed term_type
 * @property mixed active
 * @property mixed created_at
 */
class Terminal extends DefaultModel
{

    protected $connection = 'sqlsrv_pos';
    protected $table = 'terminals';


    public function account(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Account::class ,'account_id','account');
    }



}
