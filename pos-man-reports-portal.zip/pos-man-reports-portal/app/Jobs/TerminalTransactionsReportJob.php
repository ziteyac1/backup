<?php

namespace App\Jobs;

use App\ResponseCode;
use App\Report;
use App\TransactionType;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class TerminalTransactionsReportJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public $terminal;
    public $user_id;
    public $transactions;
    public function __construct($transactions,$user_id,$terminal)
    {
        $this->terminal = $terminal;
        $this->transactions = $transactions;
        $this->user_id = $user_id;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $terminal = $this->terminal;
        $user_id = $this->user_id;
        $name = $terminal . "-" . now()->format("Y-m-d") . ".csv";
        $path = public_path("/storage/reports/" . $name);
        $output = fopen($path, "w+");


        $response = $this->transactions;

        $line = "Transaction Number, Pan , Rrn , Terminal , Location , Amount , Tran Type , Response Code , Date" . PHP_EOL;
        fwrite($output, $line);

        foreach ($response['hits']['hits'] as $item) {

                $response_code = ResponseCode::query()->where('code',$item['_source']['response_code'])->first();
                $tran_type = TransactionType::query()->where('code',$item['_source']['tran_type'])->first();

                $date = Carbon::create($item['_source']['in_req']);

                $line = "{$item['_source']['tran_nr']}";
                $line .= ",{$item['_source']['pan']}";
                $line .= ",{$item['_source']['ret_ref_no']}";
                $line .= ",{$item['_source']['card_acceptor_id']}";
                $line .= ",{$item['_source']['card_acceptor_name_loc']}";
                $line .= ",{$item['_source']['amount']}";
                $line .= ",{$tran_type->description}";
                $line .= ",{$response_code->description}";
                $line .= ",{$date}";
                $line .= PHP_EOL;
                fwrite($output, $line);

            }

        fclose($output);

        Report::query()->create([
            'user_id' => $user_id,
            'name' => 'Test Report',
            'description' => 'Test Report',
            'path' => $path,
            'section' => 'Terminal Transactions',
        ]);
    }
}
