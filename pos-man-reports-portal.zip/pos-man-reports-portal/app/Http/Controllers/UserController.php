<?php

namespace App\Http\Controllers;

use App\Account;
use App\SelfRegistration;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function index()
    {

    }
    public function create(Request $request)
    {
        $request->validate([
            'email' => ['required', 'email' ,'unique:users' , 'unique:self_registrations'],
            'name' => ['required'],
            'last_name' => ['required'],
            'phone' => ['required' , 'starts_with:263'],
            'account' => ['required' , 'digits:12'],
        ]);

        /** @var SelfRegistration $registration */
        $registration = SelfRegistration::query()->create([
            'name' => $request->get('name'),
            'last_name' => $request->get('last_name'),
            'phone' => $request->get('phone'),
            'account' => $request->get('account'),
            'email' => $request->get('email'),
        ]);

        Account::query()->create([
            'account' => $registration->account,
            'customer_id' => $registration->id,
        ]);

        return api()->message("Your Registration was successful , registration ID is #{$registration->id} , email was sent to {$registration->email} , Verification takes 3 to 6 working days")->build();
    }

    public function activate(SelfRegistration $user)
    {
        $profile_activation = $user->update([
            'status' => true,
        ]);

        $new_user = User::query()->create([
            'name' => $user->name,
            'last_name' => $user->last_name,
            'phone' => $user->phone,
            'email' => $user->email,
            'password' => Hash::make('Password@1'),
        ]);

        return api()->message("User account with ID #{$new_user->id}, has been created");
    }
}
