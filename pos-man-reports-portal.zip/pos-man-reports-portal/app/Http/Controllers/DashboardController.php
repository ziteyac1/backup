<?php

namespace App\Http\Controllers;

use App\elastic\TransactionFilters;
use App\Account;
use App\Customer;
use App\Terminal;
use App\User;
use Elasticsearch\ClientBuilder;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;
use App\Transaction;

class DashboardController extends Controller
{
    public function index()
    {
        /** @var User $user */
        $user = auth()->user();
        $user->load(['accounts']);
        //$working = $user->is_corporate ? $user->corporate->working : $user->working;
        $user = $user->toArray();

        return view('home' , [
            'user' => $user
        ]);
    }
    public function users()
    {
        return api()->data('users',User::query()->get())->build();
    }
    public function details($id)
    {

        $account_id = Account::query()->where('id',$id)->first();

        $terminals = Terminal::query()->where('account_id',$account_id->account)->get();

        return api()->data('terminals',$terminals)->build();
    }

    public function term_transactions(TransactionFilters $filters)
    {
        $user = auth()->user();

        $accounts = Account::query()->where('customer_id',$user->id)->get();

        $terminals = [];
        foreach ($accounts as $account)
        {
            $terminals = Terminal::query()->where('account_id',$account->account)->with(['account.customer' ,'account.branch'])->paginate(30);
        }

        $transactions = [];
        foreach ($terminals as $terminal)
        {

            $transactions = Transaction::searchRaw([
                'query' => [
                    'bool' => [
                        'filter' => [
                            'term' => [
                                'card_acceptor_id' => $terminal->terminal_id
                            ],
                        ],
                    ]
                ],
                "sort" => [
                    "in_req" => [
                        "order" => "desc"
                    ]
                ],
                'size' => 300,
                'from' => 1,
            ]);
        }
        $transactions = $transactions['hits']['hits'];

        return api()->data('transactions',$transactions)->build();
    }

    public function getTrans($terminal)
    {
        $per_page = 50;
        $from = 1 * $per_page;
        $access = $this->getTransactions($per_page,$from,$terminal);

        $transactions = new LengthAwarePaginator(
            $access['hits'],
            $access['total'],
            $per_page,
            Paginator::resolveCurrentPage(),
            ['path' => Paginator::resolveCurrentPath()]);

        $response_codes['00'] = 'Approved and Successful';
        $response_codes['99'] = 'Aborted';

        foreach ($transactions as $transaction)
        {
            $transaction['_source']['response_code'] = $response_codes[$transaction->_source->response_code];
        }

        return $transactions;

    }
    public function getTransactions($per_page,$from,$terminal)
    {
        $client = ClientBuilder::create();
        //$client->setHosts(["192.168.0.124:9200"]);
        $client = $client->build();

        $start = "2020-04-21" . " 00:00:00.000";
        $end = "2020-05-19" . " 00:00:00.000";

        $params = [
            'index' => 'pos_transactions_index',
            'type' => 'transactions',
            'body' => [
                'query' => [
                    'bool' => [
                        'filter' => [
                            'term' => [
                                'card_acceptor_id' => $terminal
                            ],
                        ],
                    ]
                ],
                "sort" => [
                    "in_req" => [
                        "order" => "asc"
                    ]
                ],
                'size' => $per_page,
                'from' => $from,
            ]
        ];

        $response = $client->search($params);

        return $response['hits'];
    }

}
