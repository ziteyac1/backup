<?php

namespace App\Http\Controllers;

use App\Account;
use App\ResponseCode;
use App\Terminal;
use App\Transaction;
use App\TransactionType;
use Carbon\Carbon;
use Elasticsearch\ClientBuilder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;

class TransactionsReportController extends Controller
{
    public function index(Request $request)
    {
        $user = auth()->user();

        $accounts = Account::query()->where('customer_id',$user->id)->get();

        $terminals = [];
        foreach ($accounts as $account)
        {
            $terminals = Terminal::query()->where('account_id',$account->account)->with(['account.customer' ,'account.branch'])->paginate(30);
        }

        $transactions = [];
        $per_page = $request->size;
        foreach ($terminals as $terminal)
        {

            $transactions = Transaction::searchRaw([
                'query' => [
                    'bool' => [
                        'filter' => [
                            'term' => [
                                'card_acceptor_id' => $terminal->terminal_id
                            ],
                        ],
                    ]
                ],
                "sort" => [
                    "in_req" => [
                        "order" => "desc"
                    ]
                ],
                'size' => $per_page,
                'from' => 1,
            ]);
        }
        $access = $transactions['hits'];

        $transactions = new LengthAwarePaginator(
            $access['hits'],
            $access['total'],
            $per_page,
            Paginator::resolveCurrentPage(),
            ['path' => Paginator::resolveCurrentPath()]);

         return api()->data('transactions',$transactions)->build();

    }
    public function transaction($id)
    {
        $transactions = Transaction::searchRaw([
            'query' => [
                'bool' => [
                    'filter' => [
                        'term' => [
                            'tran_nr' => $id
                        ],
                    ],
                ]
            ],
        ]);

        $transaction = [];
        foreach ($transactions['hits']['hits'] as $transaction)
        {
            $response_code = ResponseCode::query()->where('code',$transaction['_source']['response_code'])->first();
            $tran_type = TransactionType::query()->where('code',$transaction['_source']['response_code'])->first();
            $transaction['_source']['response_code'] = $response_code->description;
            $transaction['_source']['tran_type'] = $tran_type->description;

            $transaction = [$transaction];
        }

        $transaction = $transaction[0]['_source'];

        return api()->data('terminal_transaction',$transaction)->build();
    }

    public function transactions_request(Request $request)
    {

        $start_to_time = strtotime($request->start);
        $end_to_time = strtotime($request->end);

        $start_to_date = date('Y-m-d',$start_to_time);
        $end_to_date = date('Y-m-d',$end_to_time);

        $start = $start_to_date . " 00:00:00.000";

        $end = $end_to_date . " 00:00:00.000";

        $per_page = 300;
        $transactions = Transaction::searchRaw([
            'query' => [
                'bool' => [
                    'filter' => [
                        'term' => [
                            'card_acceptor_id' => $request->search_term_id
                        ],
                    ],
                    'must' => [
                        'range' => [
                            'in_req' => [
                                "gte" => $start,
                                "lte" => $end,
                            ]
                        ]
                    ]
                ]
            ],
            "sort" => [
                "in_req" => [
                    "order" => "desc"
                ]
            ],
            'size' => $per_page,
            'from' => 1,
        ]);

        $access = $transactions['hits'];

        $transactions = new LengthAwarePaginator(
            $access['hits'],
            $access['total'],
            $per_page,
            Paginator::resolveCurrentPage(),
            ['path' => Paginator::resolveCurrentPath()]);

        return api()->data('requested_transactions',$transactions)->build();
    }

    public function getTransactions($per_page,$from,$request)
    {
        $client = ClientBuilder::create();
        $client->setHosts(["192.168.0.124:9200"]);
        $client = $client->build();

        $start = Carbon::now()->toDateTimeString();
        $end = Carbon::now()->toDateTimeString();


        $params = [
            'index' => 'pos_transactions_index',
            'type' => 'transactions',
            'body' => [
                'query' => [
                    'bool' => [
                        'filter' => [
                            'match_all' => (object)[],
                        ]
                    ]
                ],
                "sort" => [
                    "in_req" => [
                        "order" => "desc"
                    ]
                ],
                'size' => $per_page,
                'from' => $from,
            ]
        ];

        $response = $client->search($params);

        $access = $response['hits'];

        return $access;
    }
}
