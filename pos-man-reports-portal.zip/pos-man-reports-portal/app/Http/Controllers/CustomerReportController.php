<?php

namespace App\Http\Controllers;

use App\Customer;
use Illuminate\Http\Request;

class CustomerReportController extends Controller
{
    public function customers()
    {
        $customers = Customer::query()->orderBy('created_at','desc')->paginate(30);
        return api()->data('customers',$customers)->build();
    }
    public function show(Customer $customer)
    {
        $customer->load(['accounts.branch','accounts.terminals_limit']);
        return api()->data('customer',$customer)->build();
    }
    public function terms(Customer $customer)
    {
        $customer->load('terminals');
        return api()->data('customer',$customer)->build();
    }
}
