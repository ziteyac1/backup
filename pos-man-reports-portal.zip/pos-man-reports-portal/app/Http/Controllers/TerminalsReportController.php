<?php

namespace App\Http\Controllers;

use App\core\Filters\TerminalFilters;
use App\elastic\TransactionFilters;
use App\Account;
use App\ResponseCode;
use App\Terminal;
use App\Transaction;
use Carbon\Carbon;
use Elasticsearch\ClientBuilder;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;

class TerminalsReportController extends Controller
{
    public function index(TerminalFilters $filters)
    {
        $user = auth()->user();

        $accounts = Account::query()->where('customer_id',$user->id)->get();

        $terminals = [];
        foreach ($accounts as $account)
        {
            $terminals = Terminal::filter($filters,[])->where('account_id',$account->account)->with(['account.customer' ,'account.branch'])->paginate(\request('size') ?? 30);
        }
        //dd($terminals);

        return api()->data('terminals',$terminals)->build();
    }
    public function account_terminals(Account $account)
    {
        $terminals = Terminal::query()->where('account_id',$account->account)->paginate(30);
        return api()->data('terminals',$terminals)->build();
    }


    public function transactions($terminal,Request $request)
    {
        $per_page = 1000;
        $transactions = Transaction::searchRaw([
            'query' => [
                'bool' => [
                    'filter' => [
                        'term' => [
                            'card_acceptor_id' => $terminal
                        ],
                    ],
                ]
            ],
            "sort" => [
                "in_req" => [
                    "order" => "desc"
                ]
            ],
            'size' => $per_page,
            'from' => 1,
        ]);

        $access = $transactions['hits'];

        $transactions = new LengthAwarePaginator(
            $access['hits'],
            $access['total'],
            $per_page,
            Paginator::resolveCurrentPage(),
            ['path' => Paginator::resolveCurrentPath()]);

        foreach ($transactions as $transaction)
        {
            $response_code = ResponseCode::query()->where('code',$transaction['_source']['response_code'])->first();
            $transaction['_source']['response_code'] = $response_code->description;
        }

        return api()->data('transactions',$transactions)->build();
    }
    public function info($id)
    {
        $terminal = Terminal::query()->where('terminal_id',$id)->with('account')->first();
        return api()->data('terminal',$terminal)->build();
    }
    public function getTransactions($per_page,$from,$terminal,$request)
    {
        $client = ClientBuilder::create();
        $client->setHosts(["192.168.0.124:9200"]);
        $client = $client->build();

        $start = "2020-04-21" . " 00:00:00.000";
        $end = "2020-05-19" . " 00:00:00.000";

        $params = [
            'index' => 'pos_transactions_index',
            'type' => 'transactions',
            'body' => [
                'query' => [
                    'bool' => [
                        'filter' => [
                            'term' => [
                                'card_acceptor_id' => $terminal
                            ],
                        ],
                        'must' => [
                            'range' => [
                                'in_req' => [
                                    "gte" => $start,
                                    "lte" => $end,
                                ]
                            ]
                        ]
                    ]
                ],
                "sort" => [
                    "in_req" => [
                        "order" => "asc"
                    ]
                ],
                'size' => $per_page,
                'from' => $from,
            ]
        ];

        $response = $client->search($params);

        return $response['hits'];
    }
}
