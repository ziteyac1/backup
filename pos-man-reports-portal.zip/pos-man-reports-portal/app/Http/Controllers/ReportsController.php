<?php

namespace App\Http\Controllers;

use App\Jobs\TerminalTransactionsReportJob;
use App\Transaction;
use App\Report;
use Illuminate\Http\Request;

class ReportsController extends Controller
{
    public function index()
    {
        $reports = Report::query()->where('user_id',auth()->user()->id)->paginate(30);
        return api()->data('reports',$reports)->build();
    }
    public function report(Request $request)
    {
        $start_to_time = strtotime($request->start);
        $end_to_time = strtotime($request->end);

        $start_to_date = date('Y-m-d',$start_to_time);
        $end_to_date = date('Y-m-d',$end_to_time);

        $start = $start_to_date . " 00:00:00.000";

        $end = $end_to_date . " 00:00:00.000";

        $term_id = $request->search_term_id;
        $transactions = $this->transactions($term_id,$start,$end);
        $user_id = auth()->user()->id;

        $this->dispatch(new TerminalTransactionsReportJob($transactions,$user_id,$term_id));

        return api()->message("Please wait a few moments your report is being processed")->build();
    }

    public function download(Report $report)
    {
        return response()->download($report->path);
    }
    public function transactions($terminal,$start,$end)
    {
        return Transaction::searchRaw([
            'query' => [
                'bool' => [
                    'filter' => [
                        'term' => [
                            'card_acceptor_id' => $terminal
                        ],
                    ],
                    'must' => [
                        'range' => [
                            'in_req' => [
                                "gte" => $start,
                                "lte" => $end,
                            ]
                        ]
                    ]
                ]
            ],
            "sort" => [
                "in_req" => [
                    "order" => "desc"
                ]
            ],
            'size' => 1000,
        ]);
    }
}
