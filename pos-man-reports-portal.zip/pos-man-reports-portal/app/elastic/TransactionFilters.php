<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 2/12/2019
 * Time: 6:12 PM
 */

namespace App\elastic;
use App\models\ResponseCode;
use App\models\Transaction;
use App\models\TransactionType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use ScoutElastic\Builders\FilterBuilder;

class TransactionFilters
{

    /**
     * @var Request
     */
    protected $request;

    /**
     * @var FilterBuilder
     */
    protected $builder;

    /**
     * Registered filters to operate upon.
     *
     * @var array
     */
    protected  $filters = [
        'tran_nr','state','source_node',
        'amount','min_amount','max_amount',
        'sink_node','ret_ref_no','branch_code',
        'terminal','date','tran_type',
        'response_code','account','customer_id',
        'latest','oldest','end_date','start_date'
    ];


    /**
     * Create a new ThreadFilters instance.
     *
     * @param Request $request
     */
    public function __construct(Request $request = null )
    {
        if ($request)
        {
            $this->request = $request;
        }
    }

    /**
     * Apply the filters.
     *
     * @param FilterBuilder $builder
     * @param array $extra
     * @param array|null $exclude
     * @param bool $considerRequest
     * @return FilterBuilder
     */
    public function apply( FilterBuilder $builder , array $extra = [] , array $exclude = []  , bool $considerRequest = true )
    {

        $this->builder = $builder;

        $filters = array_filter($extra);

        if ($considerRequest)
        {
            $filters = $this->getFilters();
            $filters = array_diff_key( $filters , $exclude );
            $filters = array_merge( $extra , $filters);
        }

        foreach ($filters as $filter => $value)
        {
            if (method_exists($this, $filter))
            {
                $this->$filter($value);
            }
        }

        return $this->builder;
    }

    public function params()
    {
        return $this->builder->buildPayload()[0]['body'];
    }

    /**
     * Fetch all relevant filters from the request.
     *
     * @return array
     */
    public function getFilters(): array
    {
        return array_filter($this->request->only($this->filters));
    }

    public function latest()
    {
        return $this->builder->orderBy('in_req' , 'desc');
    }

    public function oldest()
    {
        return $this->builder->orderBy('in_req' , 'asc');
    }

    /**
     * Filter Transaction by Branch Code
     * @param $value
     * @return FilterBuilder
     */
    public function branch_code($value): FilterBuilder
    {
        return $this->builder->where('branch_code', $value);
    }

    /**
     * Filter Transaction by Customer ID
     * @param $value
     * @return FilterBuilder
     */
    public function customer_id($value): FilterBuilder
    {
        return $this->builder->where('customer_id', $value);
    }

    /**
     * Filter Transaction by Account
     * @param $value
     * @return FilterBuilder
     */
    public function account($value): FilterBuilder
    {
        return $this->builder->where('account', $value);
    }

    /**
     * Filter Transaction by Response Code
     * @param $value
     * @return FilterBuilder
     */
    public function response_code($value): FilterBuilder
    {

        if ($value === 'X'){

            $items = Cache::rememberForever('null-get-reponce-code-filter', function ()
            {
                return ResponseCode::query()->pluck('code')->toArray();
            });

            return $this->builder->whereNotIn('response_code', $items);

        }


        return $this->builder->where('response_code', $value);
    }

    /**
     * Filter Transaction by Transaction Type
     * @param $value
     * @return FilterBuilder
     */
    public function tran_type($value): FilterBuilder
    {
        if ($value === 'X'){

            $items = Cache::rememberForever('null-get-tran_type-filter', function ()
            {
                return TransactionType::query()->pluck('code')->toArray();
            });

            return $this->builder->whereNotIn('tran_type', $items);

        }

        return $this->builder->where('tran_type', $value);
    }

    /**
     * Filter Transaction by Terminal
     * @param $value
     * @return FilterBuilder
     */
    public function terminal($value): FilterBuilder
    {
        return $this->builder->where('card_acceptor_id', $value);
    }

    /**
     * Filter Transaction by Date
     * @param $value
     * @return FilterBuilder
     */
    public function date($value): FilterBuilder
    {
        return $this->builder->where('in_req', $value);
    }

    /**
     * Filter Transaction by Date
     * @param $value
     * @return FilterBuilder
     */
    public function start_date($value): FilterBuilder
    {
        return $this->builder->where('in_req','>=', $value);
    }

    /**
     * Filter Transaction by Date
     * @param $value
     * @return FilterBuilder
     */
    public function end_date($value): FilterBuilder
    {
        return $this->builder->where('in_req','<=', $value);
    }

    /**
     * Filter Transaction by Retrieval Reference Number
     * @param $value
     * @return FilterBuilder
     */
    public function ret_ref_no($value): FilterBuilder
    {
        return $this->builder->where('ret_ref_no', $value);
    }

    /**
     * Filter Transaction by Sink Node
     * @param $value
     * @return FilterBuilder
     */
    public function sink_node($value): FilterBuilder
    {
        return $this->builder->where('sink_node', $value);
    }

    /**
     * Filter Transaction by Amount
     * @param $value
     * @return FilterBuilder
     */
    public function amount($value): FilterBuilder
    {
        return $this->builder->where('amount', $value);
    }

    /**
     * Filter Transaction by Min Amount
     * @param $value
     * @return FilterBuilder
     */
    public function min_amount($value): FilterBuilder
    {
        return $this->builder->where('amount', '>=',$value);
    }

    /**
     * Filter Transaction by Max Amount
     * @param $value
     * @return FilterBuilder
     */
    public function max_amount($value): FilterBuilder
    {
        return $this->builder->where('amount', '<=',$value);
    }

    /**
     * Filter Transaction by Source Node
     * @param $value
     * @return FilterBuilder
     */
    public function source_node($value): FilterBuilder
    {
        return $this->builder->where('source_node', $value);
    }

    /**
     * Filter Transaction by State
     * @param $value
     * @return FilterBuilder
     */
    public function state($value): FilterBuilder
    {
        return $this->builder->where('state', $value);
    }

    /**
     * Filter Transaction by Transaction Number
     * @param $value
     * @return FilterBuilder
     */
    public function tran_nr($value): FilterBuilder
    {
        return $this->builder->where('tran_nr', $value);
    }


}