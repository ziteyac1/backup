<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 2/15/2019
 * Time: 11:00 AM
 */

namespace App\Reports\Core;


use App\core\Filters\Filters;
use App\Exports\TransactionsExport;
use App\Jobs\RunReportJob;
use App\models\ReportRequest;
use App\models\TransactionType;
use App\Notifications\ReportCompleted;
use App\Reports\Sections\Requests\Requests;
use App\Reports\Sections\Transactions\Transactions;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Facades\Excel;
use ScoutElastic\Builders\FilterBuilder;


class ReportsService
{


    /**
     * @param \App\models\Report $report
     * @param array $params
     * @param $user
     * @param null $receivers
     * @return \Illuminate\Database\Eloquent\Builder|\Illuminate\Database\Eloquent\Model
     */
    public function register(\App\models\Report $report  , array $params  , $user , $receivers = null )
    {
        $params = array_filter($params);

        $request = ReportRequest::query()->create([
            'requester_id' => $user ,
            'params' => $params,
            'report_id' => $report->id,
            'completed' => false,
            'state' => 'Requested',
            'progress' => '0.01',
        ]);

        RunReportJob::dispatch($request)->onConnection('redis');

        return $request;

    }

    /**
     * @param ReportRequest $request
     * @throws \Exception
     */
    public function run(ReportRequest $request): void
    {
        try {

            if ($request->canceled)
            {

                $request->update([
                    'progress' => '1',
                    'state' => 'Report Cancelled By User'
                ]);

                return;
            }

            $user = $request->user;

            $request->update([
                'progress' => '0.2',
            ]);

            $report =  $request->report;

            /**
             * Running Report
             */
            $request->update([
                'progress' => '0.25',
                'state' => 'Compiling Class'
            ]);

            $class = app()->make($report->class);

            $request->update([
                'progress' => '0.35',
                'state' => 'Building Summary'
            ]);

            /** @var \App\Reports\Core\Report|Transactions|Requests $class */
            $class->filters($request->params);

            if ( app()->make($report->filter) instanceof Filters )
            {
                $class->request($report);
            }

            $response = $class->getResponse();

            /** @var FilterBuilder|Builder $builder */

            $builder = $class->getBuilderCollection();

            /**
             * Update Summary
             */

            if (  $class instanceof PreExtracted ){

                $number = $class->getList()->count();

            } else {

                $number = $builder->count();
            }



            $request->update([
                'data' => $response ,
                'progress' => '0.5',
                'state' => 'Summary Completed',
                'number' => $number
            ]);

            if ($request->excel_disabled){

                $request->update([
                    'state' => 'Report Completed',
                    'completed' => true
                ]);

                $user->notify(new ReportCompleted($request));

                return;
            }

            if ( $number > 10000 && !$request->scheduled ){

                $request->update([
                    'scheduled' => true,
                    'state' => 'Scheduled For Midnight , Reason : Exceeds Limit - 10 000',
                ]);

                return;

            }

            // Generate Report

            if (  $class instanceof PreExtracted ){

                /** @var FromCollection|TransactionsExport $exportable  */
                $exportable  = app()->make($report->exportable ,[
                    'data' => $class->getList() ,
                ]);

            } else {

                /** @var FromCollection|TransactionsExport $exportable  */
                $exportable  = app()->make($report->exportable ,[
                    'builder' => $builder,
                    'params' => $request->params
                ]);

            }


            $request->update([
                'progress' => '0.8',
                'state' => 'Extracting Excel'
            ]);

            $path = strtolower(str_slug($report->name)).'-'.$request->user->email.'-'.$request->id.'.xlsx';
            Excel::store($exportable, $path,null,\Maatwebsite\Excel\Excel::XLSX);

            $size = File::size(storage_path('app\\'.$path)) / 1024 / 1000;

            $size = round($size ,2 );

            $request->update([
                'progress' => '1',
                'state' => 'Report Completed',
                'completed' => true,
                'size' => $size .'MB',
                'report_path' => $path
            ]);

            $user->notify(new ReportCompleted($request));

        } catch (\Exception $exception){

            echo $exception->getTraceAsString();

            $request->update([
                'progress' => '1',
                'state' => 'Error : '.$exception->getMessage(),
                'completed' => true,
                'canceled' => true,
            ]);

        }
    }
}