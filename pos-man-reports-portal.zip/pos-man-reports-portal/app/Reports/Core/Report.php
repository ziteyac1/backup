<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 2/14/2019
 * Time: 8:40 PM
 */

namespace App\Reports\Core;


interface Report
{
    public function filters(array $params) : void;
    public function getResponse();
    public function runResponse($response);
    public function getOverViewData();
    public function getBuilderCollection();
}