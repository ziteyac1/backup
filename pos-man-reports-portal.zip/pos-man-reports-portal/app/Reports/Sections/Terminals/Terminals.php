<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 2/14/2019
 * Time: 3:58 PM
 */

namespace App\Reports\Sections\Terminals;


use App\Reports\Core\Report;
use App\Reports\Core\ReportComponents;
use Illuminate\Support\Facades\DB;

class Terminals implements Report
{
    use ReportComponents;


    /**
     * @param $response
     * @throws \Exception
     */
    public function runResponse($response) : void
    {
        $response['chart_created_at'] = $this->makeChartData($response ,'chart_created_at' ,'term_type');
        $response['chart_updated_at'] = $this->makeChartData($response ,'chart_updated_at' ,'term_type');
        $this->overview = $response;
    }

    public function getResponse()
    {

        $response['total'] = $this->makeBuilder()->count();
        $response['active'] = $this->groupBy('active');
        $response['model'] = $this->groupBy('model');
        $response['term_type'] = $this->groupBy('term_type');

        $response['branch_code'] = $this->makeBuilder()->join('transactions', 'transactions.account','=','terminals.account_id')
            ->groupBy('transactions.branch_code')
            ->orderBy(DB::raw('count(*)') ,'desc')
            ->get([ 'branch_code', DB::raw('count(*) as branch_code_count') ])->toArray();

        $response['transactions'] = $this->makeBuilder()
            ->groupBy('account_id')
            ->orderBy(DB::raw('count(*)') ,'desc')
            ->limit(30)->get([ 'account_id', DB::raw('count(*) as account_id_count') ])->toArray();

        $response['chart_created_at'] = $this->groupByTypeChart('term_type', 'created_at');
        $response['chart_updated_at'] = $this->groupByTypeChart('term_type', 'updated_at');

        $this->builder = $this->makeBuilder()->with(['account']);
        return $response;

    }


}
