<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 2/14/2019
 * Time: 6:55 PM
 */

namespace App\Reports\Sections\Terminals;


class Commissions
{

}