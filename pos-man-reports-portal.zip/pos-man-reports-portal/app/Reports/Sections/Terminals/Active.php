<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 2/14/2019
 * Time: 6:52 PM
 */

namespace App\Reports\Sections\Terminals;


use App\core\Filters\Filters;
use App\core\Helper;
use App\elastic\TransactionFilters;
use App\elastic\TransactionsService;
use App\models\Account;
use App\models\Terminal;
use App\models\Transaction;
use App\Reports\Core\PreExtracted;
use App\Reports\Core\Report;
use App\Reports\Core\ReportComponents;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Active implements Report , PreExtracted
{
    use ReportComponents;

    public $list;

    /**
     * @var Collection $terminals
     */
    public $terminals;

    /**
     * @return array
     */
    public function getResponse() : array
    {
        $result = $this->fetchElastic();

        $terminals = collect($result['terminals']['buckets'])
            ->map(function ($value){
            return [
                'id' => $value['key'],
                'count' => Helper::format($value['doc_count'] ),
                'total_value' => '$ '. Helper::format( $value['total_value']['value'] )
            ];

        })->slice(0 , 100 )->toArray();

        $accounts = collect($result['transactions']['buckets'])->map(function ($value){
            return [
                'id' => $value['key'],
                'count' => Helper::format($value['doc_count'] ),
                'total_value' => '$ '. Helper::format( $value['total_value']['value'] )
            ];

        })->slice(0 , 100 )->toArray();

        $types = collect($result['source_nodes']['buckets'])->map(function ($value){

            return [
                'id' => Helper::getSourceNodeName($value['key']),
                'count' => Helper::format($value['doc_count'] ),
                'total_value' => '$ '. Helper::format( $value['total_value']['value'] )
            ];

        })->slice(0 , 100 )->toArray();

        $groups['Top Terminals'] = $terminals;
        $groups['Top Accounts'] = $accounts;
        $groups['Source Nodes'] = $types;
        $response['rankings'] = $groups;

        $list = $this->list;

        $this->terminals = $this->makeBuilder()->with('account')->get()->reject(function ($value) use ($list)
        {
            return !\in_array($value->terminal_id, $list, true);
        });

        $response['total'] = $this->terminals->count();

        $response['active'] = $this->terminals->groupBy(function ($value)
        {
            return $value->active;

        })->map(function ($value , $key )
        {
            return collect($value)->count();
        })->sort()->reverse()->toArray();


        $response['model'] = $this->terminals->groupBy(function ($value)
        {
            return $value->model;

        })->map(function ($value , $key )
        {
            return collect($value)->count();
        })->sort()->reverse()->toArray();

        $response['term_type'] = $this->terminals->groupBy(function ($value)
        {
            return $value->term_type;

        })->sort()->reverse()->map(function ($value , $key )
        {
            return collect($value)->count();
        })->toArray();


        $response['branch_code'] = $this->terminals->groupBy(function ($value)
        {
            return $value->account->branch_code;

        })->sort()->reverse()->map(function ($value , $key )
        {
            return collect($value)->count();
        })->toArray();



        $response['transactions'] = $this->terminals->groupBy(function ($value)
        {
            return $value->account_id;

        })->map(function ($value , $key ){
            return collect($value)->count();
        })->sort()->reverse()->toArray();


        return $response;

    }

    /**
     * @return Collection
     */
    public function getList()
    {
        return $this->terminals;
    }

    /**
     * @param $response
     * @throws \Exception
     */
    public function runResponse($response)
    {
        $this->overview = $response;
    }

    public function makeBuilder(): \Illuminate\Database\Eloquent\Builder
    {
        $list = $this->list;

        /** @var Filters $filter */
        $filter = app()->make($this->report->filter);

        /** @var Model $model */
        $model = app()->make($this->report->model);

        $remove = [
            'start_date' => '',
            'end_date' => '',
        ];

        $filters = $filter->apply(
            $model::query(),
            array_diff_key($this->params, $remove),
            array_diff_key($this->params, $remove),
            false
        );

        return $filters;
    }

    /**
     * @return array
     */
    public function fetchElastic(): array
    {
        $remove = [
            'branch_code' => ''
        ];

        $filters = new TransactionFilters();
        $this->builder = $filters->apply(
            Transaction::search('*'),
            array_diff_key($this->params, $remove),
            array_diff_key($this->params, $remove),
            false
        );

        $extra = [
            'size' => 0,
            'aggs' => [
                'terminals' => [
                    'terms' => [
                        'field' => 'card_acceptor_id',
                        'size' => Terminal::query()->count(),
                        'order' => [
                            '_count' => 'desc'
                        ]
                    ],
                    'aggs' => [
                        'total_value' => [
                            'sum' => [
                                'field' => 'amount',
                                'missing' => 0
                            ]
                        ]
                    ]
                ],
                'transactions' => [
                    'terms' => [
                        'field' => 'account',
                        'size' => Account::query()->count(),
                        'order' => [
                            '_count' => 'desc'
                        ]
                    ],
                    'aggs' => [
                        'total_value' => [
                            'sum' => [
                                'field' => 'amount',
                                'missing' => 0
                            ]
                        ]
                    ]
                ],
                'source_nodes' => [
                    'terms' => [
                        'field' => 'source_node',
                        'size' => 10,
                        'order' => [
                            '_count' => 'desc'
                        ]
                    ],
                    'aggs' => [
                        'total_value' => [
                            'sum' => [
                                'field' => 'amount',
                                'missing' => 0
                            ]
                        ]
                    ]
                ],
            ]
        ];

        $service = new TransactionsService(
            array_merge($filters->params(), $extra)
        );

        $filters = null;
        $response = $service->search();
        $this->list = collect($response['aggregations']['terminals']['buckets'])->map(function ($value) {
            return $value['key'];
        })->toArray();

        return $response['aggregations'];

    }
}
