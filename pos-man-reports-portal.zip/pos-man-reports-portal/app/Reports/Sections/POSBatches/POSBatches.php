<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 2/14/2019
 * Time: 4:23 PM
 */

namespace App\Reports\Sections\POSBatches;


use App\Reports\Core\Report;
use App\Reports\Core\ReportComponents;

class POSBatches implements  Report
{
    use ReportComponents;

    /**
     * @return  mixed
     */
    public function getResponse()
    {
        $response['total'] = $this->makeBuilder()->count();
        $response['chart_updated_at'] = $this->groupByChart('id', 'updated_at');
        $this->builder = $this->makeBuilder();
        return $response;
    }

    /**
     * @param $response
     * @throws \Exception
     */
    public function runResponse($response) : void
    {
        $response['chart_updated_at'] = $this->makeChart($response ,'chart_updated_at', 'id');
        $this->overview = $response;
    }


}