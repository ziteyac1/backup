<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 2/14/2019
 * Time: 4:17 PM
 */

namespace App\Reports\Sections\Customers;


class Customer
{

}