<?php

use App\models\TransactionType;
use Illuminate\Database\Seeder;

class TranTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
            $values = [
            [
                'code' => '00',
                'description' => 'Goods and services'
            ],
            [
                'code' => '01',
                'description' =>'Cash withdrawal'
            ],
            [
                'code'=> '02',
                'description' => 'Debit adjustment'
            ],
            [
                'code' => '03',
                'description' => 'Check cash/guarantee'
            ],
            [
                'code' => '04',
                'description' => 'Check verification'
            ],
            [
                'code' => '05',
                'description' => 'Eurocheque'
            ],
            [
                'code' => '06',
                'description' => 'Traveller check'
            ],
            [
                'code' => '07',
                'description' => 'Letter of credit'
            ],
            [
                'code' => '08',
                'description' => 'Giro (postal banking)'
            ],
            [
                'code' => '09',
                'description' => 'Goods and services with cash back'
            ],
            [
                'code' => '10',
                'description' => 'Non-cash e.g. wire transfer'
            ],
            [
                'code' => '11',
                'description' => 'Quasi-cash and scrip'
            ],
            [
                'code' => '12',
                'description' => 'General debit'
            ],
            [
                'code' => '19',
                'description' => 'Fee collection'
            ],
            [
                'code' => '20',
                'description' => 'Returns'
            ],
            [
                'code' => '21',
                'description' => 'Deposit'
            ],
            [
                'code' => '22',
                'description' => 'Credit adjustment'
            ],
            [
                'code' => '23',
                'description' => 'Check deposit guarantee'
            ],
            [
                'code' => '24',
                'description' => 'Check deposit'
            ],
            [
                'code' => '25',
                'description' => 'General credit'
            ],
            [
                'code' => '28',
                'description' => 'Merchandise dispatch'
            ],
            [
                'code' => '29',
                'description' => 'Funds disbursement'
            ],
            [
                'code' => '30',
                'description' => 'Available funds inquiry'
            ],
            [
                'code' => '31',
                'description' => 'Balance inquiry'
            ],
            [
                'code' => '32',
                'description' => 'General inquiry'
            ],
            [
                'code' => '35',
                'description' => 'Full-Statement inquiry'
            ],
            [
                'code' => '36',
                'description' => 'Merchandise inquiry'
            ],
            [
                'code' => '37',
                'description' => 'Card verification inquiry'
            ],
            [
                'code' => '38',
                'description' => 'Mini-statement inquiry'
            ],
            [
                'code' => '39',
                'description' => 'Linked account inquiry'
            ],
            [
                'code' => '40',
                'description' => 'Cardholder accounts transfer'
            ],
            [
                'code' => '42',
                'description' => 'General transfer'
            ],
            [
                'code' => '50',
                'description' => 'Payment from account'
            ],
            [
                'code' => '51',
                'description' => 'Payment by deposit'
            ],
            [
                'code' => '52',
                'description' => 'General payment'
            ],
            [
                'code' => '53',
                'description' => 'Payment to account'
            ],
            [
                'code' => '54',
                'description' => 'Payment from account to account'
            ],
            [
                'code' => '90',
                'description' => 'Place hold on card'
            ],
            [
                'code' => '91',
                'description' => 'General admin'
            ],
            [
                'code' => '92',
                'description' => 'Change PIN'
            ],
            [
                'code' => '93',
                'description' => 'Dead-end general admin'
            ],
        ];
        foreach ($values as $value)
        {
            TransactionType::query()->create([
                'code' => $value['code'],
                'description' => $value['description'],
            ]);
        }
    }
}
