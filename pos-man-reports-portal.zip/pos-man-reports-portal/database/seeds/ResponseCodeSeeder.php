<?php

use App\models\ResponseCode;
use Illuminate\Database\Seeder;

class ResponseCodeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $values = [
            [
                'code' => '00',
                'description' => 'Approved or completed successfully'
            ],
            [
                'code' => '01',
                'description' =>'Refer to card issuer'
            ],
            [
                'code'=> '02',
                'description' => 'Refer to card issuer, special condition'
            ],
            [
                'code' => '03',
                'description' => 'Invalid merchant'
            ],
            [
                'code' => '04',
                'description' => 'Pick-up card'
            ],
            [
                'code' => '05',
                'description' => 'Do not honor'
            ],
            [
                'code' => '06',
                'description' => 'Error'
            ],
            [
                'code' => '07',
                'description' => 'Pick-up card, special condition'
            ],
            [
                'code' => '08',
                'description' => 'Honor with identification'
            ],
            [
                'code' => '09',
                'description' => 'Request in progress'
            ],
            [
                'code' => '10',
                'description' => 'Approved, partial'
            ],
            [
                'code' => '11',
                'description' => 'Approved, VIP'
            ],
            [
                'code' => '12',
                'description' => 'Invalid transaction'
            ],
            [
                'code' => '13',
                'description' => 'Invalid amount'
            ],
            [
                'code' => '14',
                'description' => 'Invalid card number'
            ],
            [
                'code' => '15',
                'description' => 'No such issuer'
            ],
            [
                'code' => '16',
                'description' => 'Approved, update track 3'
            ],
            [
                'code' => '17',
                'description' => 'Customer cancellation'
            ],
            [
                'code' => '18',
                'description' => 'Customer dispute'
            ],
            [
                'code' => '19',
                'description' => 'Re-enter transaction'
            ],
            [
                'code' => '20',
                'description' => 'Invalid response'
            ],
            [
                'code' => '21',
                'description' => 'No action taken'
            ],
            [
                'code' => '22',
                'description' => 'Suspected malfunction'
            ],
            [
                'code' => '23',
                'description' => 'Unacceptable transaction fee'
            ],
            [
                'code' => '24',
                'description' => 'File update not supported'
            ],
            [
                'code' => '25',
                'description' => 'Unable to locate record'
            ],
            [
                'code' => '26',
                'description' => 'Duplicate record'
            ],
            [
                'code' => '27',
                'description' => 'File update field edit error'
            ],
            [
                'code' => '28',
                'description' => 'File update file locked'
            ],
            [
                'code' => '29',
                'description' => 'File update failed'
            ],
            [
                'code' => '30',
                'description' => 'Format error'
            ],
            [
                'code' => '31',
                'description' => 'Bank not supported'
            ],
            [
                'code' => '32',
                'description' => 'Completed partially'
            ],
            [
                'code' => '33',
                'description' => 'Expired card, pick-up'
            ],
            [
                'code' => '34',
                'description' => 'Suspected fraud, pick-up'
            ],
            [
                'code' => '35',
                'description' => 'Contact acquirer, pick-up'
            ],
            [
                'code' => '36',
                'description' => 'Restricted card, pick-up'
            ],
            [
                'code' => '37',
                'description' => 'Call acquirer security, pick-up'
            ],
            [
                'code' => '38',
                'description' => 'PIN tries exceeded, pick-up'
            ],
            [
                'code' => '39',
                'description' => 'No credit account'
            ],
            [
                'code' => '40',
                'description' => 'Function not supported'
            ],
            [
                'code' => '41',
                'description' => 'Lost card, pick-up'
            ],
            [
                'code' => '42',
                'description' => 'No universal account'
            ],
            [
                'code' => '43',
                'description' => 'Stolen card, pick-up'
            ],
            [
                'code' => '44',
                'description' => 'No investment account'
            ],
            [
                'code' => '45',
                'description' => 'Account closed'
            ],
            [
                'code' => '46',
                'description' => 'Identification required'
            ],
            [
                'code' => '47',
                'description' => 'Identification cross-check required'
            ],
            [
                'code' => '48',
                'description' => 'No customer record'
            ],
            [
                'code' => '49',
                'description' => 'Reserved for future Realtime use'
            ],
            [
                'code' => '50',
                'description' => 'Reserved for future Realtime use'
            ],
            [
                'code' => '51',
                'description' => 'Not sufficient funds'
            ],
            [
                'code' => '52',
                'description' => 'No check account'
            ],
            [
                'code' => '53',
                'description' => 'No savings account'
            ],
            [
                'code' => '54',
                'description' => 'Expired card'
            ],
            [
                'code' => '55',
                'description' => 'Incorrect PIN'
            ],
            [
                'code' => '56',
                'description' => 'No card record'
            ],
            [
                'code' => '57',
                'description' => 'Transaction not permitted to cardholder'
            ],
            [
                'code' => '58',
                'description' => 'Transaction not permitted on terminal'
            ],
            [
                'code' => '59',
                'description' => 'Suspected fraud'
            ],
            [
                'code' => '60',
                'description' => 'Contact acquirer'
            ],
            [
                'code' => '61',
                'description' => 'Exceeds withdrawal limit'
            ],
            [
                'code' => '62',
                'description' => 'Restricted card'
            ],
            [
                'code' => '63',
                'description' => 'Security violation'
            ],
            [
                'code' => '64',
                'description' => 'Original amount incorrect'
            ],
            [
                'code' => '65',
                'description' => 'Exceeds withdrawal frequency'
            ],
            [
                'code' => '66',
                'description' => 'Call acquirer security'
            ],
            [
                'code' => '67',
                'description' => 'Hard capture'
            ],
            [
                'code' => '68',
                'description' => 'Response received too late'
            ],
            [
                'code' => '69',
                'description' => 'Advice received too late'
            ],
            [
                'code' => '70',
                'description' => 'Reserved for future Realtime use'
            ],
            [
                'code' => '71',
                'description' => 'Reserved for future Realtime use'
            ],
            [
                'code' => '72',
                'description' => 'Reserved for future Realtime use'
            ],
            [
                'code' => '73',
                'description' => 'Reserved for future Realtime use'
            ],
            [
                'code' => '74',
                'description' => 'Reserved for future Realtime use'
            ],
            [
                'code' => '75',
                'description' => 'PIN tries exceeded'
            ],
            [
                'code' => '76',
                'description' => 'Reserved for future Realtime use'
            ],
            [
                'code' => '77',
                'description' => 'Intervene, bank approval required'
            ],
            [
                'code' => '78',
                'description' => 'Intervene, bank approval required for partial amount'
            ],
            [
                'code' => '79',
                'description' => 'Reserved for client-specific use (declined)'
            ],
            [
                'code' => '80',
                'description' => 'Reserved for client-specific use (declined)'
            ],
            [
                'code' => '81',
                'description' => 'Reserved for client-specific use (declined)'
            ],
            [
                'code' => '82',
                'description' => 'Reserved for client-specific use (declined)'
            ],
            [
                'code' => '83',
                'description' => 'Reserved for client-specific use (declined)'
            ],
            [
                'code' => '84',
                'description' => 'Reserved for client-specific use (declined)'
            ],
            [
                'code' => '85',
                'description' => 'Reserved for client-specific use (declined)'
            ],
            [
                'code' => '86',
                'description' => 'Reserved for client-specific use (declined)'
            ],
            [
                'code' => '87',
                'description' => 'Reserved for client-specific use (declined)'
            ],
            [
                'code' => '',
                'description' => 'Reserved for client-specific use (declined)'
            ],
            [
                'code' => '88',
                'description' => 'Reserved for client-specific use (declined)'
            ],
            [
                'code' => '89',
                'description' => 'Reserved for client-specific use (declined)'
            ],
            [
                'code' => '90',
                'description' => 'Cut-off in progress'
            ],
            [
                'code' => '91',
                'description' => 'Issuer or switch inoperative'
            ],
            [
                'code' => '92',
                'description' => 'Routing error'
            ],
            [
                'code' => '93',
                'description' => 'Violation of law'
            ],
            [
                'code' => '94',
                'description' => 'Duplicate transaction'
            ],
            [
                'code' => '95',
                'description' => 'Reconcile error'
            ],
            [
                'code' => '96',
                'description' => 'System malfunction'
            ],
            [
                'code' => '97',
                'description' => 'Reserved for future Realtime use'
            ],
            [
                'code' => '98',
                'description' => 'Exceeds cash limit'
            ],
            [
                'code' => '99',
                'description' => 'Reserved for future Realtime use'
            ],

        ];

        foreach ($values as $value)
        {
            ResponseCode::query()->create([
                'code' => $value['code'],
                'description' => $value['description'],
            ]);
        }
    }
}
