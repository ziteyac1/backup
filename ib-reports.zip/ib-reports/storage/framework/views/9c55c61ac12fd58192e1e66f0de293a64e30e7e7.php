<?php $__env->startSection('content'); ?>
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">Transactions Activity Report</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="col-lg-12 mb-2">
                <div class="card rounded-0">
                    <div class="card-body">
                        <span>Showing cumulative figures for all transactions</span>
                        <br>
                        <br>
                        <span>Total Transactions by Volume: <b><?php echo e($transactions_by_volume); ?></b></span>
                        <br>
                        <br>
                        <span>Total Transactions by Value: <b>ZWL <?php echo e(number_format($transactions_by_value->total_value,2)); ?></b></span>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 mb-3">
                <div class="card rounded-0">
                    <div class="card-header text-center">
                        <h6><?php echo e($status_message); ?></h6>
                    </div>
                    <div class="card-body">
                        <form method="get" class="row col-12">
                            <div class="col-4">
                                <label for="">Start Date</label>
                                <input type="date" name="start_date" id="start_date" class="form-control <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> rounded-0" value="<?php echo e(request('start_date')); ?>">
                                <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-4">
                                <label for="">End Date</label>
                                <input type="date" name="end_date" id="end_date" class="form-control <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> rounded-0" value="<?php echo e(request('end_date')); ?>">
                                <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-2">
                                <label style="visibility: hidden;display: block"> Extract</label>
                                <button type="submit"class="form-control btn btn-outline-primary rounded-0"><i data-feather="filter"></i> Filter</button>
                            </div>
                            <div class="col-2">
                                <label style="visibility: hidden;display: block"> Extract</label>
                                <button type="submit" name="run" id="run" class="form-control btn btn-outline-primary rounded-0"><i data-feather="download"></i> Download</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="card rounded-0">
                    <div class="card-body">
                        <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                            <thead>
                            <tr>
                                <th>Transaction ID</th>
                                <th>Name</th>
                                <th>Surname</th>
                                <th>Account Number</th>
                                <th>Amount Transacted</th>
                                <th>Transaction State</th>
                                <th>Reason for Exception</th>
                                <th>Date Transacted</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if($transactions->isEmpty()): ?>
                                <tr>
                                    <td colspan="7" class="text-center"><h7>Nothing to show...</h7></td>
                                </tr>
                            <?php endif; ?>
                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div><span><?php echo e($transaction->transaction_id); ?></span></div>
                                    </td>
                                    <td>
                                        <div><span><?php echo e($transaction->user->name); ?></span></div>
                                    </td>
                                    <td>
                                        <div><span><?php echo e($transaction->user->last_name); ?></span></div>
                                    </td>
                                    <td>
                                        <div><span><?php echo e($transaction->account->account); ?></span></div>
                                    </td>
                                    <td>
                                        <div><span><?php echo e($transaction->amount); ?></span></div>
                                    </td>
                                    <td>
                                        <div><span><?php echo e($transaction->status->description); ?></span></div>
                                    </td>
                                    <td>
                                        <div><span><?php echo e($transaction->error); ?></span></div>
                                    </td>
                                    <td>
                                        <div><span><?php echo e($transaction->created_at); ?></span></div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                            <div class="justify-content-center align-items-center">
                                <div class="row col-lg-12">
                                    <div class="col-lg-4">
                                        <span>Showing <?php echo e($transactions->firstItem()); ?> to <?php echo e($transactions->lastItem()); ?> of <?php echo e($transactions->total()); ?> Records </span>
                                    </div>
                                    <div class="col-lg-4"><?php echo e($transactions->render()); ?></div>
                                </div>
                            </div>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zuvarashe\PhpstormProjects\ib-reports-portal\resources\views/report_views/transactions.blade.php ENDPATH**/ ?>