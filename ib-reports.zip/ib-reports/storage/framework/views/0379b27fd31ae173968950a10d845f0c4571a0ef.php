<?php $__env->startSection('content'); ?>
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">IB Registrations Report</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="col-lg-12 mb-3">
                <div class="card rounded-0">
                    <div class="card-header text-center">
                        <h6><?php echo e($status_message); ?></h6>
                    </div>
                    <div class="card-body">
                        <form action="" method="get">
                            <div class="row col-lg-12">
                                <div class="col-lg-3">
                                    <label for="">Start Date</label>
                                    <input type="date" name="start_date" id="start_date" class="form-control <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> rounded-0" value="<?php echo e(request('start_date')); ?>">
                                    <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-3">
                                    <label for="">End Date</label>
                                    <input type="date" name="end_date" id="end_date" class="form-control <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> rounded-0" value="<?php echo e(request('end_date')); ?>">
                                    <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-2">
                                    <label for="">User Type</label>
                                    <select name="user_type" id="user_type" class="form-control <?php $__errorArgs = ['user_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> rounded-0" value="<?php echo e(request('user_type')); ?>">
                                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(request('user_type') == $type->short_name ? 'selected' : ''); ?> value="<?php echo e($type->short_name); ?>"><?php echo e($type->long_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['user_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-2">
                                    <label style="visibility: hidden;display: block"> Extract</label>
                                    <button type="submit" class="form-control btn btn-outline-primary rounded-0"><i data-feather="filter"></i> Filter</button>
                                </div>
                                <div class="col-2">
                                    <label style="visibility: hidden;display: block"> Extract</label>
                                    <button name="run" type="submit" class="form-control btn btn-outline-primary rounded-0"><i data-feather="download"></i> Extract</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="card rounded-0">
                    <div class="card-body">
                        <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Surname</th>
                                <th>Customer Type</th>
                                <th>Date Created</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if($customers->isEmpty()): ?>
                                <tr>
                                    <td colspan="5" class="text-center"><h7>Nothing to show...</h7></td>
                                </tr>
                            <?php endif; ?>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div><?php echo e($customer->id); ?></div>
                                    </td>
                                    <td>
                                        <div><?php echo e($customer->name); ?></div>
                                    </td>
                                    <td>
                                        <div><?php echo e($customer->last_name); ?></div>
                                    </td>
                                    <td>
                                        <div><?php echo e($customer->type); ?></div>
                                    </td>
                                    <td>
                                        <div><?php echo e($customer->created_at); ?></div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                            <div class="justify-content-center align-items-center">
                                <div class="row col-lg-12">
                                    <div class="col-lg-4">
                                        <span>Showing <?php echo e($customers->firstItem()); ?> to <?php echo e($customers->lastItem()); ?> of <?php echo e($customers->total()); ?> Records </span>
                                    </div>
                                    <div class="col-lg-4"><?php echo e($customers->render()); ?></div>
                                </div>
                            </div>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard' , [
    'bread' => [
        [ 'name' => 'Home' , 'link' => url('/home') ],
        [ 'name' => 'Dashboard' , 'link' => url('/home') ],
    ]
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zuvarashe\PhpstormProjects\ib-reports-portal\resources\views/report_views/users.blade.php ENDPATH**/ ?>