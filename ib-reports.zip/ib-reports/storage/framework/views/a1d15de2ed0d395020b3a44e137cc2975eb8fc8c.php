<?php $__env->startSection('main'); ?>
    <div class="content content-fixed content-auth">
        <div class="container">
            <div class="media align-items-stretch justify-content-center ht-100p pos-relative">
                <?php echo $__env->yieldContent('content'); ?>
            </div><!-- media -->
        </div><!-- container -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zuvarashe\PhpstormProjects\ib-reports-portal\resources\views/layouts/auth.blade.php ENDPATH**/ ?>