<?php $__env->startSection('main'); ?>
    <div class="filemgr-wrapper">
        <?php echo $__env->make('includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="filemgr-content" style="overflow-y: scroll" >
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zuvarashe\PhpstormProjects\ib-reports-portal\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>