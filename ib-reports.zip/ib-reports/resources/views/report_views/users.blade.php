@extends('layouts.dashboard' , [
    'bread' => [
        [ 'name' => 'Home' , 'link' => url('/home') ],
        [ 'name' => 'Dashboard' , 'link' => url('/home') ],
    ]
])
@section('content')
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">IB Registrations Report</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="col-lg-12 mb-3">
                <div class="card rounded-0">
                    <div class="card-header text-center">
                        <h6>{{$status_message}}</h6>
                    </div>
                    <div class="card-body">
                        <form action="" method="get">
                            <div class="row col-lg-12">
                                <div class="col-lg-3">
                                    <label for="">Start Date</label>
                                    <input type="date" name="start_date" id="start_date" class="form-control @error('start_date') is-invalid @enderror rounded-0" value="{{ request('start_date') }}">
                                    @error('start_date')
                                        <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                                <div class="col-lg-3">
                                    <label for="">End Date</label>
                                    <input type="date" name="end_date" id="end_date" class="form-control @error('end_date') is-invalid @enderror rounded-0" value="{{ request('end_date') }}">
                                    @error('end_date')
                                        <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                                <div class="col-lg-2">
                                    <label for="">User Type</label>
                                    <select name="user_type" id="user_type" class="form-control @error('user_type') is-invalid @enderror rounded-0" value="{{ request('user_type') }}">
                                        @foreach($types as $type)
                                            <option {{ request('user_type') == $type->short_name ? 'selected' : '' }} value="{{$type->short_name}}">{{$type->long_name}}</option>
                                        @endforeach
                                    </select>
                                    @error('user_type')
                                    <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                                <div class="col-lg-2">
                                    <label style="visibility: hidden;display: block"> Extract</label>
                                    <button type="submit" class="form-control btn btn-outline-primary rounded-0"><i data-feather="filter"></i> Filter</button>
                                </div>
                                <div class="col-2">
                                    <label style="visibility: hidden;display: block"> Extract</label>
                                    <button name="run" type="submit" class="form-control btn btn-outline-primary rounded-0"><i data-feather="download"></i> Extract</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="card rounded-0">
                    <div class="card-body">
                        <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Surname</th>
                                <th>Customer Type</th>
                                <th>Date Created</th>
                            </tr>
                            </thead>
                            <tbody>
                            @if($customers->isEmpty())
                                <tr>
                                    <td colspan="5" class="text-center"><h7>Nothing to show...</h7></td>
                                </tr>
                            @endif
                            @foreach($customers as $customer)
                                <tr>
                                    <td>
                                        <div>{{$customer->id}}</div>
                                    </td>
                                    <td>
                                        <div>{{$customer->name}}</div>
                                    </td>
                                    <td>
                                        <div>{{$customer->last_name}}</div>
                                    </td>
                                    <td>
                                        <div>{{$customer->type}}</div>
                                    </td>
                                    <td>
                                        <div>{{$customer->created_at}}</div>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                            <tfoot>
                            <div class="justify-content-center align-items-center">
                                <div class="row col-lg-12">
                                    <div class="col-lg-4">
                                        <span>Showing {{$customers->firstItem()}} to {{$customers->lastItem()}} of {{$customers->total()}} Records </span>
                                    </div>
                                    <div class="col-lg-4">{{ $customers->render() }}</div>
                                </div>
                            </div>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
