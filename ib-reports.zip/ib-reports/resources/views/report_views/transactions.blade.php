@extends('layouts.dashboard')
@section('content')
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">Transactions Activity Report</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="col-lg-12 mb-2">
                <div class="card rounded-0">
                    <div class="card-body">
                        <span>Showing cumulative figures for all transactions</span>
                        <br>
                        <br>
                        <span>Total Transactions by Volume: <b>{{$transactions_by_volume}}</b></span>
                        <br>
                        <br>
                        <span>Total Transactions by Value: <b>ZWL {{number_format($transactions_by_value->total_value,2)}}</b></span>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 mb-3">
                <div class="card rounded-0">
                    <div class="card-header text-center">
                        <h6>{{$status_message}}</h6>
                    </div>
                    <div class="card-body">
                        <form method="get" class="row col-12">
                            <div class="col-4">
                                <label for="">Start Date</label>
                                <input type="date" name="start_date" id="start_date" class="form-control @error('start_date') is-invalid @enderror rounded-0" value="{{ request('start_date') }}">
                                @error('start_date')
                                <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="col-4">
                                <label for="">End Date</label>
                                <input type="date" name="end_date" id="end_date" class="form-control @error('end_date') is-invalid @enderror rounded-0" value="{{ request('end_date') }}">
                                @error('end_date')
                                <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="col-2">
                                <label style="visibility: hidden;display: block"> Extract</label>
                                <button type="submit"class="form-control btn btn-outline-primary rounded-0"><i data-feather="filter"></i> Filter</button>
                            </div>
                            <div class="col-2">
                                <label style="visibility: hidden;display: block"> Extract</label>
                                <button type="submit" name="run" id="run" class="form-control btn btn-outline-primary rounded-0"><i data-feather="download"></i> Download</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="card rounded-0">
                    <div class="card-body">
                        <table class="table card-table table-dashboard mg-b-0 table-vcenter">
                            <thead>
                            <tr>
                                <th>Transaction ID</th>
                                <th>Name</th>
                                <th>Surname</th>
                                <th>Account Number</th>
                                <th>Amount Transacted</th>
                                <th>Transaction State</th>
                                <th>Reason for Exception</th>
                                <th>Date Transacted</th>
                            </tr>
                            </thead>
                            <tbody>
                            @if($transactions->isEmpty())
                                <tr>
                                    <td colspan="7" class="text-center"><h7>Nothing to show...</h7></td>
                                </tr>
                            @endif
                            @foreach($transactions as $transaction)
                                <tr>
                                    <td>
                                        <div><span>{{$transaction->transaction_id}}</span></div>
                                    </td>
                                    <td>
                                        <div><span>{{$transaction->user->name}}</span></div>
                                    </td>
                                    <td>
                                        <div><span>{{$transaction->user->last_name}}</span></div>
                                    </td>
                                    <td>
                                        <div><span>{{$transaction->account->account}}</span></div>
                                    </td>
                                    <td>
                                        <div><span>{{$transaction->amount}}</span></div>
                                    </td>
                                    <td>
                                        <div><span>{{$transaction->status->description}}</span></div>
                                    </td>
                                    <td>
                                        <div><span>{{$transaction->error}}</span></div>
                                    </td>
                                    <td>
                                        <div><span>{{$transaction->created_at}}</span></div>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                            <tfoot>
                            <div class="justify-content-center align-items-center">
                                <div class="row col-lg-12">
                                    <div class="col-lg-4">
                                        <span>Showing {{$transactions->firstItem()}} to {{$transactions->lastItem()}} of {{$transactions->total()}} Records </span>
                                    </div>
                                    <div class="col-lg-4">{{ $transactions->render() }}</div>
                                </div>
                            </div>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
