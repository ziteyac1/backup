
<div class="filemgr-sidebar">
    <div class="filemgr-sidebar-body">
        <div class="pd-t-20 pd-b-10 pd-x-10">
            <label class="tx-sans tx-uppercase tx-medium tx-10 tx-spacing-1 tx-color-03 pd-l-10">Transactions</label>
            <nav class="nav nav-sidebar tx-13">
                <ul class="nav nav-aside">
                    <li class="nav-item">
                        <a href="/home" class="nav-link"><i data-feather="user-plus"></i> User Registrations Report</a>
                    </li>
                    <br>
                    <li class="nav-item">
                        <a href="/transactions/report" class="nav-link"><i data-feather="activity"></i> Transactions Activity Report</a>
                    </li>
                    <br>
                    <li class="nav-item">
                        <a href="/users_activity/report" class="nav-link"><i data-feather="user-x"></i> Active and Inactive Users Report</a>
                    </li>
                    <br>
                    <li class="nav-item">
                        <a href="/reports/all" class="nav-link"><i data-feather="database"></i> Generated Reports</a>
                    </li>
                    <br>
                    @can('monitor system')
                        <li class="nav-item"><a target="_blank" href="{{ url('/horizon') }}" class="nav-link"><i data-feather="archive"></i> Monitor </a></li>
                    @endcan
                </ul>
            </nav>
        </div>
    </div>
</div>

