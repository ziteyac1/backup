@extends('layouts.dashboard' , [
    'bread' => [
        [ 'name' => 'Home' , 'link' => url('/home') ],
        [ 'name' => 'View' , 'link' => url('/home') ],
    ]
])

@section('content')
    <div class="filemgr-content-body">
        <div class="container-fluid">
            <div class="d-flex  mb-5 align-items-center mt-3">
                <h4 class="mr-auto mb-0">Request {{$document->id}} Details</h4>
                <div class="border-bottom ml-3 flex-fill"></div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-3">
                    <div class="card">
                        <div class="card-header">
                            @if(session()->has('success'))
                                <div class="alert alert-success rounded-0 text-center">
                                    {{ session()->get('success') }}
                                </div>
                            @endif
                            <span>Upload Files</span>
                        </div>
                        <div class="card-body">
                            <form action="/files/{{$document->id}}/response" method="post" enctype="multipart/form-data">
                                @csrf
                                <div class="row mb-3">
                                    <label for="">Message</label>
                                    <input type="text" name="upload_message" id="upload_message" class="form-control @error('upload_message') is-invalid @enderror">
                                    @error('upload_message')
                                    <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                                <div class="row mb-3">
                                    <label>Upload File</label>
                                    <input type="file" name="upload_file" id="upload_file" class="form-control @error('upload_file') is-invalid @enderror">
                                    @error('upload_file')
                                    <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                                <div class="row mb-3">
                                    <input type="submit" value="Submit Request" class="form-control btn-outline-primary">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="card">
                        <div class="card-header text-center">
                            <span>Individual Request Details</span>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="row mb-5">
                                        <div class="col-lg-12">
                                            <h6>Requester Name: <span class="text-muted">{{$document->user->full_name}}</span></h6>
                                        </div>
                                    </div>
                                    <div class="row mb-5">
                                        <div class="col-lg-12">
                                            <h6>Action Required: <span class="text-muted">{{$document->requester_message}}</span></h6>
                                        </div>
                                    </div>
                                    <div class="row mb-5">
                                        <div class="col-lg-12">
                                            <h6>Message: <span class="text-muted">{{$document->requester_message}}</span></h6>
                                        </div>
                                    </div>
                                    <div class="row mb-5">
                                        <div class="col-lg-12">
                                            <h6>File Uploaded: <a target="_blank" href="/files/{{ $document->id }}/download">{{\Illuminate\Support\Str::limit($document->file_to_process_name , 50 , '...' )  }}</a></h6>
                                        </div>
                                    </div>
                                    <div class="row mb-5">
                                        <div class="col-lg-12">
                                            <h6>Date File Uploaded: <span class="text-muted">{{$document->created_at}}</span></h6>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-5">
                                        <div class="col-lg-12">
                                            <h6>File Processed By: <span class="text-muted">{{$document->processor_id}}</span></h6>
                                        </div>
                                    </div>
                                    <div class="row mb-5">
                                        <div class="col-lg-12">
                                            <h6>Process Response: <span class="text-muted">{{$document->response_message}}</span></h6>
                                        </div>
                                    </div>
                                    <div class="row mb-5">
                                        <div class="col-lg-12">
                                            <h6>Message: <span class="text-muted">{{$document->response_message}}</span></h6>
                                        </div>
                                    </div>
                                    <div class="row mb-5">
                                        <div class="col-lg-12">
                                            <h6>Response File: <a target="_blank" href="/files/{{ $document->id }}/download">{{\Illuminate\Support\Str::limit($document->response_file_name , 50 , '...' )  }}</a></h6>
                                        </div>
                                    </div>
                                    <div class="row mb-5">
                                        <div class="col-lg-12">
                                            <h6>Response Date: <span class="text-muted">{{$document->updated_at}}</span></h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
