@extends('layouts.app')
@section('main')
    <div class="filemgr-wrapper">
        @include('includes.nav')
        <div class="filemgr-content" style="overflow-y: scroll" >
            @yield('content')
        </div>
    </div>
@endsection
