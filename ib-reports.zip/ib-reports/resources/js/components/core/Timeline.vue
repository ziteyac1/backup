<template>
    <div  class="filemgr-content-body">
        <div style="" :class="['dimmer' , data.loading ? '' : '' ]">
            <div class="loader"></div>
            <div class="dimmer-content">
                <div style="position: relative">
                    <div :class="['timeline-filters' , filterPanel ? 'timeline-filters-open' : '']">
                        <div style="font-size: 18px;height: 55px;padding: 0 20px" class="d-flex justify-content-between align-items-center border-bottom">
                            <span>Filters</span>
                            <x-icon @click="closeFilterPanel"/>
                        </div>
                        <div class="filemgr-content-filters-content">
                            <div class="card-body">
                                <div  class="form-row">
                                    <div  class="form-group col-md-8">
                                        <label for="order-by-filter-field" class="col-form-label">Order By</label>
                                        <select v-model="data.sort.field" id="order-by-filter-field" class="form-control">
                                            <option :value="item" :key="`sort-value-key-${item.field}`" v-for="item in data.sortFields">{{ item.read }}</option>
                                        </select>
                                    </div>
                                    <div  class="form-group col-md-4">
                                        <label for="order-by-filter-direction" class="col-form-label">Direction</label>
                                        <select v-model="data.sort.value" id="order-by-filter-direction" class="form-control">
                                            <option  value="Asc">ASC</option>
                                            <option  value="Desc">DESC</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group" :key="`key-filter-fields-${item.field}`" v-for="item in data.filterFields">
                                    <label for="inputState" class="col-form-label">{{ item.read }}</label>
                                    <select v-model="data.filterForm.filters[item.field]" id="inputState" class="form-control">
                                        <option :key="`key-filter-fields-value-${i.value}-${item.field}`" :value="i" v-for="i in item.filter">{{ i.read }}</option>
                                    </select>
                                </div>
                                <div class="form-group" :key="`key-range-fields-${item.field}`" v-for="item in data.rangeFields">
                                    <label>{{ item.read }} </label>
                                    <div class="d-flex">
                                        <!--suppress HtmlFormInputWithoutLabel -->
                                        <input v-model="data.filterForm.ranges.min[item.field]" :type="[item.date ? 'date' : 'text']" placeholder="Min" class="form-control d-inline-block ">
                                        <span class="d-inline-block text-center text-muted mx-2"><i class="mdi mdi-window-minimize"/></span>
                                        <!--suppress HtmlFormInputWithoutLabel -->
                                        <input v-model="data.filterForm.ranges.max[item.field]" :type="[item.date ? 'date' : 'text']" placeholder="Max" class="form-control d-inline-block ">
                                    </div>
                                </div>
                            </div>
                            <div class="border-top text-center card-body">
                                <button @click="runFilters" class="btn btn-sm pd-x-15 btn-white btn-uppercase mr-3"><i class="fa fa-filter wd-10 mg-r-5"/> Filter </button>
                            </div>
                        </div>
                    </div>
                    <div style="height: 55px;padding: 0 20px;" class="border-bottom d-flex align-items-center">
                        <h6 class="mb-0 tx-uppercase mr-3">{{ name }}</h6>
                        <div class="search-form mr-auto d-flex align-items-center border-left border-right mr-3 px-3">
                            <search-icon class="" size="16"/>
                            <!--suppress HtmlFormInputWithoutLabel -->
                            <input v-model="data.search" type="text" class="form-control border-0" placeholder="Search..">
                        </div>
                        <div  class="d-flex align-items-center mr-2 tx-12">
                            <span class="mr-3"> Showing {{ data.content.data.length }} of {{ data.content.total }} Records </span>
                            <span class="border border-secondary py-1 px-2 rounded mr-auto">Sorted By  : <strong> {{ data.sort.field.read }} </strong> , {{ data.sort.value }} </span>
                        </div>
                        <button @click="data.fetch()"  :class="['tx-uppercase btn btn-white btn-sm mr-2' , data.loading ? 'btn-loading' :'']">
                            <refresh-ccw-icon class="mr-1"/> Refresh
                        </button>
                        <button @click="openFilterPanel"  :class="['tx-uppercase btn btn-white btn-sm' , data.loading ? 'btn-loading' :'']">
                            <filter-icon class="mr-1"/> Filter
                        </button>
                    </div>
                    <div v-if="data.filters.length > 0 || data.ranges.length > 0 " class="px-2 py-2 filters-container tx-12 border-bottom">
                        <span class="ml-2" :key="`filters-${index}`" v-for="(item, index) in data.filters" >
                            <span class="border border-secondary py-2 px-2 rounded-left">{{ item.field.read }} : <strong > {{ item.value.read }} </strong></span>
                            <span @click="data.removeFilter(index)" class="border-top border-bottom border-right border-secondary text-muted  py-2 px-2 rounded-right" style="cursor: pointer;"><x-icon size="15"/></span>
                        </span>
                            <span :key="`ranges-${index}`" class="ml-2" v-for="(item, index) in data.ranges">
                            <span class="border border-secondary py-2 px-2 rounded-left"> {{ item.field.read }} : <strong> {{ item.min }} - {{ item.max }} </strong></span>
                            <span @click="data.removeRange(item)" class="border-top border-bottom border-right border-secondary text-muted  py-2 px-2 rounded-right" style="cursor: pointer;"><x-icon size="15"/></span>
                        </span>
                    </div>
                    <div class="content">
                        <div class="container">
                            <div class="media d-block d-lg-flex">
                                <div class="media-body">
                                    <div class="timeline-group tx-13">
                                        <div class="timeline-label py-5"></div>
                                        <div :key="item.id" v-for="item in data.content.data" class="timeline-item">
                                            <div class="timeline-time">
                                                <strong>{{ item.created_at }} <br> {{ item.last_update }}</strong>
                                            </div>
                                            <div class="timeline-body">
                                                <h6 class="mg-b-0">{{ item.event }} : {{ item.user.full_name }} - {{ item.user.email }} - <span class="text-primary">#{{ item.user.id }}</span></h6>
                                                <h6 class="mg-b-0"><span class="text-primary">#{{ item.auditable_id }}</span> {{ item.auditable_type }}</h6>
                                                <p class="mb-3">
                                                    <span class="text-muted">IP : </span> {{ item.ip_address }}<br>
                                                    <span class="text-muted">User Agent : </span> {{ item.user_agent }}<br>
                                                    <span class="text-muted">Url : </span> <span class="text-primary"> {{ item.url }} </span> <br>
                                                </p>
                                                <table v-if="Object.entries(item.old_values).length > 0 || Object.entries(item.new_values).length > 0 " class="table border-bottom border-right border-left">
                                                    <thead>
                                                    <tr>
                                                        <th v-if="Object.entries(item.old_values).length > 0" class="w-50">Old</th>
                                                        <th v-if="Object.entries(item.new_values).length > 0 " class="w-50">New</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <tr>
                                                        <td  v-if="Object.entries(item.old_values).length > 0"  class="">
                                                            <div :key="`${i}-${k}-${item.id}-old-values`" v-for="(i , k ) in item.old_values"><span class="text-muted">{{ k.replace('_',' ') }} : </span>{{ i }}</div>
                                                        </td>

                                                        <td v-if="Object.entries(item.new_values).length > 0 "  class="">
                                                            <div :key="`${i}-${k}-${item.id}-new-values`" v-for="(i , k ) in item.new_values"><span class="text-muted">{{ k.replace('_',' ') }} : </span>{{ i }}</div>
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="timeline-label pb-4 pt-4">
                                            <button @click="data.append()" v-if="data.content.total !== data.content.to && data.content.data.length > 0" :class="['btn btn-white btn-sm' , data.loading ? 'btn-loading' :'']">
                                                <arrow-down-icon class="mr-1"/> Load More
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { FilterIcon , XIcon , ArrowDownIcon , RefreshCcwIcon , SearchIcon } from 'vue-feather-icons'
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    import DataHandler from "../../core/data/DataHandler";
    export default {
        props : ['url' , 'name'],
        mounted : function (){
            new PerfectScrollbar('.filemgr-content-filters-content', {
                suppressScrollX: true,
            });
            this.data.fetch();
        },
        name: "timeline",
        components : {
            FilterIcon , XIcon , ArrowDownIcon , RefreshCcwIcon , SearchIcon
        },
        data :  function () {
            return {
                data : new DataHandler({
                    url : this.url,
                    prefix : 'audits',
                }),
                // Filter Panel with filter form
                filterPanel : false,
            }
        },
        methods : {
            openFilterPanel : function () {
                this.filterPanel = true
            },
            closeFilterPanel : function () {
                this.filterPanel = false
            },
            runFilters : function (){

                // Add to filters
                this.data.runFilters();
                this.closeFilterPanel();

            },
        }
    }
</script>

<style scoped>

</style>
