<?php

namespace App\Http\Controllers;

use App\Application;
use App\Entities\core\Audit;
use App\Entities\core\Permission;
use App\Entities\core\Role;
use App\filters\AuditFilter;
use App\filters\PermissionFilter;
use App\filters\RoleFilter;
use App\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ApplicationController extends Controller
{
    public function index(){

        $applications = Application::query()->paginate(30);
        return api()
                 ->data('applications' , $applications)
                 ->data('filters' , [])
             ->build();
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function store(Request $request) : JsonResponse {

        $request->validate([
           'name' => ['required'],
           'link' => ['required'],
        ]);

        Application::query()->create([
           'name' => $request->get('name'),
           'link' => $request->get('link'),
        ]);

        return api()->message('Application was successfully created')->build();

    }

    public function users(Application $application)
    {
        $users = $application->users()->paginate(20);
        return api()
                ->data('application' , $application)
                ->data('users' , $users)
            ->build();
    }

    public function roles(RoleFilter $filter , Application $application)
    {
        $roles = Role::filter($filter , [
            'application_id' => $application->id
        ])->with('application')->paginate(\request('size') ?? 30);

        return api()
                ->data('application' , $application)
                ->data('roles' , $roles)
            ->build();
    }

    public function permissions(PermissionFilter $filter , Application $application)
    {
        $permissions = Permission::filter($filter , [
            'application_id' => $application->id
        ])->paginate(\request('size') ?? 30 );

        return api()
            ->data('application' , $application)
            ->data('permissions' , $permissions)
            ->build();
    }

    public function view(Application $application)
    {
        return api()->data('application' , $application)->build();
    }

    public function timeline(Application $application , AuditFilter $filter) : JsonResponse
    {
        $audits = Audit::filter($filter , [
            'auditable_type' => Application::class,
            'auditable_id' => $application->id,
        ])->with('user')->paginate(\request('size') ?? 30 );
        return api()
            ->data('audits',$audits)
            ->data('filters' , $filter->documentation)
            ->build();
    }

    /**
     * @param Request $request
     * @param Application $application
     * @return JsonResponse
     */
    public function update(Request $request , Application $application) : JsonResponse {

        $request->validate([
            'name' => ['required'],
            'link' => ['required'],
        ]);

        $application->update([
            'name' => $request->get('name'),
            'link' => $request->get('link'),
        ]);

        return api()->message('Application was successfully updated')->build();

    }


}
