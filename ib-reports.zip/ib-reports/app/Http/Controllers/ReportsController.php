<?php

namespace App\Http\Controllers;

use App\Report;
use Illuminate\Http\Request;

class ReportsController extends Controller
{
    public function home()
    {
        $reports = Report::query()->where('user_id',auth()->user()->id)->orderByDesc('created_at')->paginate(25);

        return view('report_views.all',['reports'=>$reports]);
    }

    public function download($id)
    {
        $file = Report::find($id);

        return response()->download($file->file_path);
    }

}
