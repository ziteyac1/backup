<?php

namespace App\Http\Controllers;

use App\core\api\response\Response;
use App\Entities\core\Audit;
use App\filters\AuditFilter;
use App\filters\PermissionFilter;
use App\filters\RoleFilter;
use App\filters\UserFilter;
use App\Notifications\UserUpdate;
use App\User;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\View\View;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class UserController extends Controller
{

    /**
     * @param UserFilter $filter
     * @return JsonResponse
     */
    public function index(UserFilter $filter) : JsonResponse
    {
        $overrides = [];
        $users =  User::filter($filter , $overrides)->paginate(\request('size') ?? 30 );
        return api()
            ->data('users' , $users)
            ->data('filters' , $filter->documentation)
            ->build();
    }

    /**
     * @return JsonResponse
     */
    public function create() : JsonResponse
    {
       return api()
              ->data('roles' , Role::all())
              ->data('permissions' , Permission::all())
           ->build();
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function store(Request $request) : JsonResponse
    {

        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8'],
        ]);

        /**
         * @var User $user
         * @noinspection VirtualTypeCheckInspection
         */

        $user = User::query()->create([
            'name' => $request->get('name'),
            'last_name' => $request->get('last_name'),
            'email' => $request->get('email'),
            'password' => Hash::make($request->get('password')),
        ]);

        $roles = Role::query()->whereIn('id' , $request->get('roles'))->get();
        $permissions = Permission::query()->whereIn('id' , $request->get('permissions'))->get();

        $user->assignRole($roles);
        if (count($permissions))
            $user->givePermissionTo($permissions);

        return api()->message('User was created successfully')->build();
    }

    /**
     * @param User $user
     * @return JsonResponse
     */
    public function view(User $user) : JsonResponse
    {
        $user->load('roles' , 'permissions');
        return api()->data('user',$user)->build();
    }

    /**
     * @param User $user
     * @return JsonResponse
     */
    public function edit(User $user) : JsonResponse
    {
        $user->load(['roles' , 'permissions' , 'applications']);

        return api()
            ->data('roles' , Role::all())
            ->data('permissions' , Permission::all())
            ->data('user',$user)
            ->build();
    }

    /**
     * @param Request $request
     * @param User $user
     * @return JsonResponse
     */
    public function update(Request $request , User $user) : JsonResponse
    {

        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'unique:users,email,' . $user->id ],
        ]);

        /**
         * @var User $user
         * @noinspection VirtualTypeCheckInspection
         */

        $user->update([
            'name' => $request->get('name'),
            'last_name' => $request->get('last_name'),
            'email' => $request->get('email'),
        ]);

        $roles = Role::query()->whereIn('id' , $request->get('roles'))->get();
        $permissions = Permission::query()->whereIn('id' , $request->get('permissions'))->get();

        $user->syncRoles($roles);
        if (count($permissions)){
            $user->syncPermissions($permissions);
        }

        $user->applications()->sync($request->get('applications'));

        return api()->message('User was updated successfully')->build();

    }

    /**
     * @param User $user
     * @param AuditFilter $filter
     * @return JsonResponse
     */
    public function activity(User $user , AuditFilter $filter) : JsonResponse
    {
        $audits = Audit::filter($filter , [
            'user_id' => $user->id,
        ])->with('user')->paginate(\request('size') ?? 30 );
        return api()
            ->data('audits',$audits)
            ->data('filters' , $filter->documentation)
            ->build();
    }

    /**
     * @param User $user
     * @param RoleFilter $filter
     * @return JsonResponse
     */
    public function roles(User $user , RoleFilter $filter)
    {
        $roles  = \App\Entities\core\Role::filter($filter , [
            'users.id' => $user->id,
        ])->paginate(\request('size') ?? 30);

        return api()
            ->data('roles',$roles)
            ->data('filters' , $filter->documentation)
            ->build();
    }

    /**
     * @param User $user
     * @param PermissionFilter $filter
     * @return JsonResponse
     */
    public function permissions(User $user , PermissionFilter $filter) : JsonResponse
    {

        $permissions = \App\Entities\core\Permission::filter($filter , [
            'users.id' => $user->id,
        ])->paginate(\request('size') ?? 30 );

        return api()
            ->data('permissions',$permissions)
            ->data('filters' , $filter->documentation)
            ->build();
    }
    /**
     * @param User $user
     * @return JsonResponse
     */
    public function applications(User $user) : JsonResponse
    {

       $applications =  $user->applications()->paginate(\request('size') ?? 30 );

        return api()
            ->data('applications',$applications)
            ->data('filters' , [] )
            ->build();
    }

    /**
     * @param User $user
     * @param AuditFilter $filter
     * @return JsonResponse
     */
    public function timeline(User $user , AuditFilter $filter) : JsonResponse
    {
        $audits = Audit::filter($filter , [
            'auditable_type' => User::class,
            'auditable_id' => $user->id,
        ])->with('user')->paginate(\request('size') ?? 30 );
        return api()
                ->data('audits',$audits)
                ->data('filters' , $filter->documentation)
            ->build();
    }

    /**
     * @param User $user
     * @return JsonResponse
     */
    public function activate(User $user) : JsonResponse
    {
        $user->update([
            'status' => true
        ]);
        $user->load('roles' , 'permissions');
        return api()
            ->message('User was activated successfully')
            ->data('user',$user)
            ->build();
    }
    /**
     * @param User $user
     * @return JsonResponse
     */
    public function deactivate(User $user) : JsonResponse
    {
        $user->update([
            'status' => false
        ]);
        $user->load('roles' , 'permissions');
        return api()
            ->message('User was deactivated successfully')
            ->data('user',$user)
            ->build();
    }
}
