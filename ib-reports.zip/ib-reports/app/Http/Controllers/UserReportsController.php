<?php

namespace App\Http\Controllers;

use App\Jobs\RegistrationsReportJob;
use App\Jobs\UsersReportJob;
use App\Report;
use App\TransactionsIB;
use App\UsersIB;
use App\UserType;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class UserReportsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\View\View|\Symfony\Component\HttpFoundation\BinaryFileResponse
     * @throws \Illuminate\Validation\ValidationException
     */
    public function home(Request $request)
    {

        $now = Carbon::now()->toDateString();

        //dd(Carbon::now()->subDays(10)->toDateString());

        $types = UserType::all();

        $customers = $this->getBuilder($request)->orderByDesc('created_at')->paginate(25);
        $status_message = "Select start and end dates to view previous records";

        $start = $now;
        $end = $now;

        if ($request->start_date && $request->end_date)
        {
            $status_message = "Showing records for period ".$request->start_date." to ".$request->end_date;
            $customers = $this->getBuilder($request)->orderByDesc('created_at')->paginate(25);
            $start = $request->start_date;
            $end = $request->end_date;

        }

        if (\request()->has('run'))
        {
            $customers = $this->getBuilder($request)->get();
            $user = auth()->user()->id;
            $this->dispatch(new RegistrationsReportJob($start,$end,$customers,$user));

            return redirect('/reports/all')->with('success',"Please wait a moment while your report is being processed");//response()->download(public_path($name));
        }

        return view('report_views.users',['customers'=>$customers,'status_message'=>$status_message,'types'=>$types]);
    }

    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\View\View|\Symfony\Component\HttpFoundation\BinaryFileResponse
     * @throws \Illuminate\Validation\ValidationException
     */
    public function user_activity(Request $request)
    {
        $customers = UsersIB::query()
            ->select()
            ->orderByDesc('updated_at')
            ->paginate(25);

        if ($request->days_more_than)
        {
            $customers = UsersIB::query()
                ->select()
                ->where('updated_at','<=',Carbon::now()->subDays($request->days_more_than)->toDateString())
                ->orderByDesc('updated_at')
                ->paginate(25);
        }

        if (\request()->has('run'))
        {
            $this->validate($request, [
                'days_more_than' => ['required','numeric']
            ]);
            $customers_report = UsersIB::query()
                ->select()
                ->where('updated_at','<=',Carbon::now()->subDays($request->days_more_than)->toDateString())
                ->orderByDesc('updated_at')
                ->get();

            $user_id = auth()->user()->id;

            $start = now()->toDateString();
            $end = now()->toDateString();
            $this->dispatch(new UsersReportJob($start,$end,$customers_report,$user_id));

            return redirect('/reports/all')->with('success',"Please wait a moment while your report is being processed");
        }

        return view('report_views.user_activity',['customers'=>$customers,]);
    }

    public function carbon($date)
    {
        if ($date === '' || empty($date)) {
            return null;
        }
        $date = explode("-", $date);
        return count($date) === 3 ? Carbon::createMidnightDate($date[0], $date[1], $date[2]) : now();

    }

    public function getBuilder($request){

        $customers = UsersIB::query();

        if ($request->start_date && $request->end_date)
        {
            $customers = $customers
                ->where('created_at', '>=', $request->start_date.' 00:00:00.000')
                ->where('created_at', '<=', $request->end_date.' 23:59:59.000');
        }
        if ($request->user_type && $request->start_date && $request->end_date)
        {
            $customers = $customers
                ->where('type','=',$request->user_type)
                ->where('created_at', '>=', $request->start_date.' 00:00:00.000')
                ->where('created_at', '<=', $request->end_date.' 23:59:59.000');
        }
        if ($request->user_type)
        {
            $customers = $customers->where('type','=',$request->user_type);
        }
        return $customers;
    }
}
