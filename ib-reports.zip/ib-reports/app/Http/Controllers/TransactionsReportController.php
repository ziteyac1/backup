<?php

namespace App\Http\Controllers;

use App\Jobs\TransactionsReportJob;
use App\Report;
use App\TransactionsIB;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use NumberFormatter;

class TransactionsReportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @throws \Illuminate\Validation\ValidationException
     */
    public function home(Request $request)
    {

        $now = Carbon::now()->toDateString();
        $start_week = Carbon::now()->startOfWeek();
        $end_week = Carbon::now()->endOfWeek();
        $start = $now;
        $end = $now;

        $period = $start_week." to ".$end_week;

        $transactions = $this->getBuilder($request)
            ->where('state','!=',99)
            ->orderByDesc('created_at')
            ->paginate(25);


        $transactions_by_value = $this->getBuilder($request)->select(DB::raw('sum(amount) as total_value'))->first();

        $transactions_by_volume = $this->getBuilder($request)->count();

        $status_message = "Select start and end dates to view previous records";

        if ($request->start_date && $request->end_date)
        {
            $status_message = "Showing records for period: ".$request->start_date." to ".$request->end_date;

            $period = $request->start_date." to ".$request->end_date;

            $start = $request->start_date;
            $end = $request->end_date;

            $transactions = $this->getBuilder($request)
                ->where('state','!=',99)
                ->orderByDesc('created_at')
                ->paginate(25);

            $transactions_by_value = $this->getBuilder($request)->select(DB::raw('sum(amount) as total_value'))->first();

            $transactions_by_volume = $this->getBuilder($request)->count();
        }

        if (\request()->has('run'))
        {
            $transactions_report = $this->getBuilder($request)->where('state','!=',99)->get();

            $user_id = auth()->user()->id;

            $this->dispatch(new TransactionsReportJob($start,$end,$transactions_report,$user_id));


            return redirect('/reports/all')->with('success',"Please wait a moment while your report is being processed");
        }

        return view('report_views.transactions',
            [
                'transactions'=>$transactions,
                'status_message'=>$status_message,
                'transactions_by_value' => $transactions_by_value,
                'transactions_by_volume' => $transactions_by_volume,
                'period' => $period,
            ]);
    }

    public function getBuilder($request){

        $transactions = TransactionsIB::query();


        if ($request->start_date || $request->end_date)
        {
            $transactions = $transactions
                ->where('created_at', '>=', $request->start_date.' 00:00:00.000')
                ->where('created_at', '<=', $request->end_date.' 23:59:59.000');
        }
        return $transactions;
    }
}
