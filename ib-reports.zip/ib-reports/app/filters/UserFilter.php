<?php
/** @noinspection MethodShouldBeFinalInspection */
/** @noinspection MissingParameterTypeDeclarationInspection */
namespace App\filters;


use App\filters\core\ModelFilter;

class UserFilter extends ModelFilter
{
    protected  $filters = [
        'search'
    ];
    protected  $equal = [
        'id'
    ];
    protected  $dates = [];
    protected  $range = [];
    protected  $sort = [
        'id',
        'created_at'
    ];

    protected $search = [
      'name',
      'email',
      'status',
    ];

    public $documentation = [
        [
            "field"  => "id",
            "read"  => "ID",
            "range"  => false,
            "date"  => false,
            "filter" => [],
            "sort" => true,
        ],
        [
            "field"  => "created_at",
            "read"  => "Date Created",
            "range"  => true,
            "filter" => [],
            "sort" => true,
            "date"  => true,
        ]
    ];

}
