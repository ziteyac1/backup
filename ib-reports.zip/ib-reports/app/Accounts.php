<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Accounts extends Model
{
    protected $keyType = 'string';
    public $timestamps = false;
    protected $connection = 'ib_connection';
    protected $table = 'accounts';
    protected $primaryKey  = 'id';
}
