<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TranStatus extends Model
{
    protected $keyType = 'string';
    public $timestamps = false;
    protected $connection = 'ib_connection';
    protected $table = 'transaction_states';
    protected $primaryKey  = 'id';
}
