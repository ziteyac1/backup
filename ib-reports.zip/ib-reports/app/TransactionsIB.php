<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TransactionsIB extends Model
{
    protected $keyType = 'string';
    protected $connection = 'ib_connection';
    protected $table = 'transactions';
    protected $primaryKey  = 'id';


    public function user()
    {
        return $this->belongsTo(UsersIB::class,'user_id','id');
    }

    public function account()
    {
        return $this->belongsTo(Accounts::class,'account_id','id');
    }
    public function status()
    {
        return $this->belongsTo(TranStatus::class,'state','id');
    }
}
