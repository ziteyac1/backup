<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UsersIB extends Model
{
    protected $keyType = 'string';
    public $timestamps = false;
    protected $connection = 'ib_connection';
    protected $table = 'users';
    protected $primaryKey  = 'id';
}
