<?php

namespace App\Jobs;

use App\Report;
use App\UsersIB;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;

class RegistrationsReportJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public $start;
    public $end;
    public $customers;
    public $user;

    public function __construct($start,$end,$customers,$user)
    {
        $this->start = $start;
        $this->end = $end;
        $this->customers = $customers;
        $this->user = $user;
    }

    /**
     * Execute the job.
     *
     * @return void
     * @throws \Exception
     */
    public function handle()
    {
        $start = $this->start;
        $end = $this->end;
        $user = $this->user;

        $Name = "IB Registrations Report";
        $report_name = "New IB Registrations". '-' . now()->format('Y-m-d-H-i-s') . '-' . random_int( 10 , 99 )  . '.csv';
        $name =    "reports/".$report_name;
        $output = fopen(public_path($name) , 'w+');

        fwrite($output , "First Name, Last Name, Date Registered, Type of Customer".PHP_EOL);

        foreach ($this->customers as $customer)
        {
            fwrite($output , "{$customer->name},{$customer->last_name},{$customer->created_at},{$customer->type}".PHP_EOL);
        }

        fclose($output);

        Report::query()->create([
            'name' => $Name,
            'user_id' => $user,
            'file_name' => $report_name,
            'file_path' => $name,
            'period_start' => $start,
            'period_end' => $end,
        ]);
    }
}
