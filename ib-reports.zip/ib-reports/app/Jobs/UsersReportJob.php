<?php

namespace App\Jobs;

use App\Report;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class UsersReportJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public $start;
    public $end;
    public $customers_report;
    public $user_id;

    public function __construct($start,$end,$customers_report,$user_id)
    {
        $this->start = $start;
        $this->end = $end;
        $this->user_id = $user_id;
        $this->customers_report = $customers_report;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $start = $this->start;
        $end = $this->end;
        $user_id = $this->user_id;

        $Name = "IB User Activity Report";
        $report_name = "Users Activity Report". '-' . now()->format('Y-m-d-H-i-s') . '-' . random_int( 10 , 99 )  . '.csv';
        $name =    "reports/".$report_name;
        $output = fopen(public_path($name) , 'w+');

        fwrite($output , "Customer Name, Date Registered, Type of Customer, Date Last Transacted, Days since last Transaction".PHP_EOL);

        foreach ($this->customers_report as $customer)
        {
            $days = Carbon::createFromFormat('Y-m-d H:i:s', $customer->updated_at)->diffInDays(Carbon::now()->toDateString());
            fwrite($output , "{$customer->name} {$customer->last_name},{$customer->created_at},{$customer->type},{$customer->updated_at},{$days}".PHP_EOL);
        }

        fclose($output);

        Report::query()->create([
            'name' => $Name,
            'user_id' => $user_id,
            'file_name' => $report_name,
            'file_path' => $name,
            'period_start' => $start,
            'period_end' => $end,
        ]);
    }
}
