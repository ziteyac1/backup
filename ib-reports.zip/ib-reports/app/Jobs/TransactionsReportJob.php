<?php

namespace App\Jobs;

use App\Report;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class TransactionsReportJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public $start;
    public $end;
    public $transactions_report;
    public $user_id;

    public function __construct($start,$end,$transactions_report,$user_id)
    {
        $this->start = $start;
        $this->end = $end;
        $this->transactions_report = $transactions_report;
        $this->user_id = $user_id;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $start = $this->start;
        $end = $this->end;
        $Name = "Exceptions Report";
        $report_name = $Name. '-' . now()->format('Y-m-d-H-i-s') . '-' . random_int( 10 , 99 )  . '.csv';
        $name =    "reports/".$report_name;
        $output = fopen(public_path($name) , 'w+');

        fwrite($output , "Customer Name, Account Number, Amount,Error Description, Reason of Exception".PHP_EOL);

        foreach ($this->transactions_report as $transaction)
        {
            fwrite($output , "{$transaction->user->name} {$transaction->user->last_name},{$transaction->account->account},{$transaction->amount},{$transaction->status->description},{$transaction->error}".PHP_EOL);
        }

        fclose($output);

        Report::query()->create([
            'name' => $Name,
            'user_id' => $this->user_id,
            'file_name' => $report_name,
            'file_path' => $name,
            'period_start' => $start,
            'period_end' => $end,
        ]);
    }
}
