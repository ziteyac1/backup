<?php

use App\Building;
use App\Owner;
use App\Room;
use App\RoomTypes;
use App\Tenant;
use App\Unit;
use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
         // Create Base User
        // Remove Guards

        echo "Starting Database Seeding".PHP_EOL;

        Model::unguard();

        \SSO\Module\models\Permission::query()->where('application_id' , env('APP_ID'))->delete();
        \SSO\Module\models\Role::query()->where('application_id' , env('APP_ID'))->delete();

        \SSO\Module\models\Permission::query()->create([
            'name' => 'monitor system',
            'application_id' => 12
        ]);

        $this->call(UserTypeSeeder::class);

    }
}
