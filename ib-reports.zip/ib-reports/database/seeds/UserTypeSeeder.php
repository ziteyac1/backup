<?php

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Seeder;

class UserTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $values = [
            [
                'short_name'=>'admin',
                'long_name' => 'Administrator',
            ],
            [
                'short_name' => 'corporate',
                'long_name' => 'Corporate'
            ],
            [
                'short_name' => 'individual',
                'long_name' => 'Individual',
            ],
        ];
        Model::unguard();

        foreach($values as $value)
        {
            \App\UserType::query()->create([
                'short_name' => $value['short_name'],
                'long_name' => $value['long_name'],
            ]);
        }
    }
}
