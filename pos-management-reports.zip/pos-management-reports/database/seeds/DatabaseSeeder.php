<?php


use App\Accounts;
use App\Report;
use App\Reports\TerminalReport;
use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Seeder;

use Illuminate\Support\Facades\Hash;
use Spatie\Permission\PermissionRegistrar;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
         // Create Base User
        // Remove Guards

        echo "Starting Database Seeding".PHP_EOL;

        Model::unguard();

        factory(User::class)->create([
           'email' =>  'root@system',
           'password' => Hash::make('password')
        ]);

        // Reports
        // Terminal Reports

        Report::query()->create([
            'name' => 'Terminal Report',
            'description' => 'Terminal Transaction Report for a given period of time',
            'class' => TerminalReport::class,
                         // Field | Field type | Input Type | UI Show | Required
            'filters' => 'date|date|range|1|1,account|text|static|1|0,terminal|text|static|1|0,type|text|static|0|0,source|text|static|0|0,sync|text|static|0|0,serial|text|static|0|0,response|text|static|0|0,state|text|static|0|0,amount|text|range|0|0'
        ]);

        Accounts::query()->create([
            'account_id' => '044000049098',
            'emails' => 'pgurajena@agribank.co.zw,cziteya@agribank.co.zw'
        ]);


    }
}
