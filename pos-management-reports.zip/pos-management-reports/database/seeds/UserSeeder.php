<?php

use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\User::query()->create([
            'name'=> 'Cephas Munyaradzi',
            'last_name' => 'Ziteya',
            'email' => 'cziteya@agribank.co.zw',
            'email_verified_at' => Carbon::now(),
            'password'=>Hash::make('mz0754cz'),
            'remember_token' => Str::random(10),
        ]);
    }
}
