<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Mail\Message;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;

class SendTerminalReports implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $account;
    private $files;

    /**
     * Create a new job instance.
     *
     * @param $account
     * @param $files
     */
    public function __construct($account  , $files)
    {
        $this->account = $account;
        $this->files = $files;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $account = $this->account;
        $files = $this->files;

        $emails  = explode(',' , $account->emails);

        Mail::send('welcome' , [] , function($message) use ($account ,$emails , $files) {

            $message->from('echannels@agribank.co.zw', $name = 'Agribank POS Management');

            foreach ($emails as $email)
            {
                $message->to( $email );
            }

            $message->subject("Terminal reports for account " . $account->account_id);

            foreach ($files as $file)
            {
                $message->attach($file);
            }

        });

    }
}
