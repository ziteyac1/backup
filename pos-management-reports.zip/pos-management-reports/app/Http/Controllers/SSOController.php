<?php

namespace App\Http\Controllers;

use App\sso\models\Role;
use App\sso\models\User;
use App\sso\services\RoleService;
use App\sso\services\UserService;
use Illuminate\Http\Request;

class SSOController extends Controller
{
    public function auth(){

        $domain = parse_url(request()->server('HTTP_REFERER'), PHP_URL_HOST) . ':' . parse_url(request()->server('HTTP_REFERER'), PHP_URL_PORT);
        $checkDomain = parse_url(env('APP_SSO_LINk'), PHP_URL_HOST) . ':' . parse_url(request()->server('HTTP_REFERER'), PHP_URL_PORT);
        if ($domain == $checkDomain )
        {
            $email = decrypt(request()->get('access'));
            $user   = \App\User::query()->where('email' , '=' , $email)->first();
            if ($user)
            {
                \auth()->loginUsingId($user->id);
                return redirect('/');
            }
        }

        return redirect(env('APP_SSO_LINk'));

    }

    public function syncUser($id){

        $user = User::query()->find($id);
        if ($user)
        {
            (new UserService())->syncUser($user);
        }

        return api()->message('User was successfully synced')->build();

    }

    public function syncRole($id)
    {
        $role = Role::query()->find($id);
        if ($role)
        {
            (new RoleService())->syncRole($role);
        }

        return api()->message('Role was successfully synced')->build();
    }
}
