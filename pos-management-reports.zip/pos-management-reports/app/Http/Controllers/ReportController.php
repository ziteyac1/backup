<?php

namespace App\Http\Controllers;

use App\Report;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function index()
    {
        return api()->data('reports' , Report::query()->latest()->paginate(20))->build();
    }

    public function view(Report $model){
        return api()->data('report' , $model)->build();
    }
}
