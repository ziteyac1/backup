<?php

namespace App\Console\Commands;

use App\Services\TerminalsService;
use Elasticsearch\ClientBuilder;
use Illuminate\Console\Command;

class TerminalReport extends Command
{
    use TerminalsService;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'report:terminal';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Terminal Reports';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $terminal = "80010983";
        $start = "2020-03-17 00:00:00.000";
        $end = "2020-03-17 23:59:59.999";

        [$response, $client] = $this->build($terminal, $start, $end);
        [$path, $statics] = $this->generate($response, $client, $terminal);


        $response = $this->last($terminal);

        if (isset($response['hits']['hits']) && count($response['hits']['hits']) > 0) {
            $record = $response['hits']['hits'][0]['_source'];
        }

        return;
    }


}
