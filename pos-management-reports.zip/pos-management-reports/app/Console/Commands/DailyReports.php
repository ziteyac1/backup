<?php

namespace App\Console\Commands;

use App\Accounts;
use App\Jobs\SendTerminalReports;
use App\Services\TerminalsService;
use App\Terminal;
use Illuminate\Console\Command;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Mail\Message;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Support\Facades\Mail;

class DailyReports extends Command
{
    use TerminalsService , DispatchesJobs;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'daily:terminal';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        echo  "Start >>> ". now() .PHP_EOL;

        // Get Accounts

        $accounts = Accounts::query()->get();

        foreach ($accounts as $account)
        {

            $files  = [];
            echo  "Account >>> $account->account_id ".PHP_EOL;

            // Get Terminals
            $terminals = Terminal::query()->where('account_id' , '=' , $account->account_id)->where('active' , '=' , 1 )->get();

            // Generate Report For Terminals

            foreach ($terminals as $terminal)
            {
                $start = now()->subDays(2)->format('Y-m-d') . " 00:00:00.000";
                $end = now()->subDays(1)->format('Y-m-d') . " 00:00:00.000";

                echo  "Terminal >>> $terminal->terminal_id " . $start . " - " .$end . PHP_EOL;

                [$response, $client] = $this->build($terminal->terminal_id, $start, $end);
                [$path, $statics] = $this->generate($response, $client, $terminal->terminal_id);

                echo  "Report >>> $path ".PHP_EOL;
                $files[] = $path;

            }

            // Send Email

            echo  "Email >>> $account->emails ".PHP_EOL;
            $this->dispatch(new SendTerminalReports($account , $files));

        }

    }
}
