<?php


namespace App\Services;


use App\Console\Commands\TerminalReport;
use Elasticsearch\ClientBuilder;

trait TerminalsService
{

    public function build($terminal, $start, $end)
    {

        $client = ClientBuilder::create();
        $client->setHosts(["192.168.0.124:9200"]);
        $client = $client->build();

        $params = [
            'index' => 'pos_transactions_index',
            'type' => 'transactions',
            "scroll" => "30s",
            'body' => [
                'query' => [
                    'bool' => [
                        'filter' => [
                            'term' => [
                                'card_acceptor_id' => $terminal
                            ],
                        ],
                        'must' => [
                            'range' => [
                                'in_req' => [
                                    "gte" => $start,
                                    "lte" => $end,
                                ]
                            ]
                        ]
                    ]
                ],
                "sort" => [
                    "in_req" => [
                        "order" => "asc"
                    ]
                ],
                'size' => 1000,
            ]
        ];

        return [$client->search($params), $client];
    }



    protected function generate($response, $client, $terminal)
    {
        $name = $terminal . "-" . now()->format("Y-m-d") . ".csv";
        $path = public_path("/storage/reports/" . $name);
        $output = fopen($path, "w+");

        $statics = [];

        $statics['total'] = $response['hits']['total'];
        $statics['sumSuccess'] = 0;
        $statics['countSuccess'] = 0;

        $statics['sumError'] = 0;
        $statics['countError'] = 0;

        $line = "Transaction Number, Trade Name , Account , Serial Number  ,Terminal , Location , Pan , RRN , Response Code , Transaction Type , Amount , Date" . PHP_EOL;
        fwrite($output, $line);

        while (isset($response['hits']['hits']) && count($response['hits']['hits']) > 0) {
            foreach ($response['hits']['hits'] as $item) {
                $success = $item['_source']['response_code'] === "00";

                if ($success) {
                    $statics['sumSuccess'] = $statics['sumSuccess'] + $item['_source']['amount'];
                    $statics['countSuccess']++;
                }

                if (!$success) {
                    $statics['sumError'] = $statics['sumError'] + $item['_source']['amount'];
                    $statics['countError']++;
                }

                $line = "{$item['_source']['tran_nr']}";
                $line .= ",{$item['_source']['trade_name']}";
                $line .= ",{$item['_source']['account']}";
                $line .= ",{$item['_source']['system_serial_number']}";
                $line .= ",{$item['_source']['card_acceptor_id']}";
                $line .= ",{$item['_source']['card_acceptor_name_loc']}";
                $line .= ",{$item['_source']['pan']}";
                $line .= ",{$item['_source']['ret_ref_no']}";
                $line .= ",{$item['_source']['response_code']}";
                $line .= ",{$item['_source']['tran_type']}";
                $line .= ",{$item['_source']['amount']}";
                $line .= ",{$item['_source']['in_req']}";
                $line .= PHP_EOL;
                fwrite($output, $line);

            }

            $scroll_id = $response['_scroll_id'];
            /** @noinspection PhpUndefinedMethodInspection */
            $response = $client->scroll(["scroll_id" => $scroll_id, "scroll" => "30s"]);

        }

        fclose($output);

        return [$path, $statics];
    }

    protected function last($terminal)
    {
        $client = ClientBuilder::create();
        $client->setHosts(["192.168.0.124:9200"]);
        $client = $client->build();

        $params = [
            'index' => 'pos_transactions_index',
            'type' => 'transactions',
            'body' => [
                'query' => [
                    'bool' => [
                        'filter' => [
                            'term' => [
                                'card_acceptor_id' => $terminal
                            ],
                        ]
                    ]
                ],
                "sort" => [
                    "in_req" => [
                        "order" => "desc"
                    ]
                ],
                'size' => 1,
            ]
        ];

        return $client->search($params);

    }
}
