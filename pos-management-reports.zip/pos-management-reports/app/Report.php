<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property mixed filters
 */
class Report extends Model
{
    protected $guarded = [];

    protected $appends = ['documentation'];

    public function getDocumentationAttribute()
    {

        $transaction  = [
            'date' => 'in_req',
            'state' => 'state',
            'account' => 'account',
            'terminal' => 'card_acceptor_id',
            'type' => 'tran_type',
            'source' => 'source_node',
            'sync' => 'sink_node',
            'serial' => 'serial_number',
            'amount' => 'amount',
            'response' => 'response_code',
        ];

        $string = $this->filters;
        $output = [];

        foreach (explode( ',', $string) as $item ){

            $item = explode('|' , $item);

            $temp['field'] = $item[0];
            $temp['type'] = $item[1];
            $temp['value'] = $item[2];
            $temp['actual'] = $transaction[$temp['field']];
            $temp['required'] = (bool)$item[3];
            $temp['ui'] = (bool)$item[4];


            $output[]  = $temp;

        }

        return $output;

    }

}
