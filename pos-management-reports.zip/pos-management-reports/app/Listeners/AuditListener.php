<?php /** @noinspection VirtualTypeCheckInspection */

namespace App\Listeners;

use App\Entities\core\Audit;
use App\User;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use OwenIt\Auditing\Events\Audited;

class AuditListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param Audited $event
     * @return void
     */
    public function handle(Audited $event)
    {
        /** @var Audit $model */

        $model = $event->audit;

        if (!$model->user_id)
        {
            $model->update([
                'user_type' => User::class,
                'user_id' => 1,
            ]);
        }
    }
}
