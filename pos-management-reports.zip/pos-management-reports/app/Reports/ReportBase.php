<?php


namespace App\Reports;


abstract  class ReportBase
{

}
