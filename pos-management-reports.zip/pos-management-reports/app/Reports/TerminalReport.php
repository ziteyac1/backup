<?php


namespace App\Reports;


class TerminalReport extends ReportBase
{
    public function prepare(){

    }

    public function run(){

    }
}
