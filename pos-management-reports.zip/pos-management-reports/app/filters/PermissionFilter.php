<?php
/** @noinspection MethodShouldBeFinalInspection */
/** @noinspection MissingParameterTypeDeclarationInspection */
namespace App\filters;


use App\Entities\core\Role;
use App\filters\core\ModelFilter;
use App\User;

class PermissionFilter extends ModelFilter
{
    protected  $filters = [];
    protected  $equal = [
        'users.id',
        'roles.id',
        'application_id'
    ];
    protected  $dates = [];
    protected  $range = [];
    protected  $sort = [
        'id',
        'created_at'
    ];

    protected $morphs = [
      User::class,
      Role::class
    ];

    protected $search = [];

    public $documentation = [
        [
            "field"  => "created_at",
            "read"  => "Date Created",
            "range"  => true,
            "filter" => [],
            "sort" => true,
            "date"  => true,
        ]
    ];

}
