<?php
/** @noinspection MethodShouldBeFinalInspection */
/** @noinspection MissingParameterTypeDeclarationInspection */
namespace App\filters;


use App\filters\core\ModelFilter;
use App\User;

class RoleFilter extends ModelFilter
{
    protected  $filters = [];
    protected  $equal = [
        'users.id',
        'application_id'
    ];
    protected  $dates = [];
    protected  $range = [];
    protected  $sort = [
        'id',
        'created_at'
    ];

    protected $morphs = [
        User::class
    ];

    protected $search = [];

    public $documentation = [
        [
            "field"  => "created_at",
            "read"  => "Date Created",
            "range"  => true,
            "filter" => [],
            "sort" => true,
            "date"  => true,
        ]
    ];

}
