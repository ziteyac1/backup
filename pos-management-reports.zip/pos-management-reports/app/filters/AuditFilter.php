<?php
/** @noinspection MethodShouldBeFinalInspection */
/** @noinspection MissingParameterTypeDeclarationInspection */
namespace App\filters;


use App\filters\core\ModelFilter;
use App\User;

class AuditFilter extends ModelFilter
{
    protected  $filters = [
        'search'
    ];
    protected  $equal = [
        'auditable_type',
        'auditable_id',
        'user_id'
    ];
    protected  $dates = [];
    protected  $range = [];
    protected  $sort = [
        'id',
        'created_at'
    ];

    protected $search = [
        'old_values',
        'new_values',
        'user.name',
        'user.email',
        'user.last_name',
    ];

    protected $morphs  = [
        User::class
    ];

    public $documentation = [
        [
            "field"  => "created_at",
            "read"  => "Date Created",
            "range"  => true,
            "filter" => [],
            "sort" => true,
            "date"  => true,
        ]
    ];

}
