@extends('layouts.app')
@section('css')
    <link rel="stylesheet" href="{{ asset('assets/css/dashforge.filemgr.css') }}">
@endsection
@section('main')
    <div class="filemgr-wrapper">
        <div style="z-index:5" class="filemgr-sidebar">
            <div class="filemgr-sidebar-body">
                <div class="pd-t-20 pd-b-10 pd-x-10">
                    <label class="tx-sans tx-uppercase tx-medium tx-10 tx-spacing-1 tx-color-03 pd-l-10">Reports</label>
                    <nav class="nav nav-sidebar tx-13">
                        <router-link class="nav-link" active-class="active" to="/reports"> <folder-icon size="24"></folder-icon> Reports </router-link>
                        <router-link class="nav-link" active-class="active" to="/requests" exact> <zap-icon size="24"></zap-icon> Requests </router-link>
                    </nav>
                </div>
            </div>
        </div>
        <transition name="slide-in-left">
            <router-view></router-view>
        </transition>
    </div>
@endsection

