<template>
    <div class="data-container">
        <div @click="open" v-if="!selected" class="start">
            Click to select {{ name }}
        </div>
        <div v-if="selected" class="result">
            <div>
                Selected : <strong><span class="text-primary">#</span> {{ selected }} - {{ selectedName }} </strong>
            </div>
            <button @click="open" class="btn btn-white btn-sm btn-icon">
                <edit-icon/>
            </button>
        </div>
        <div v-if="dialog" class="select-container">
            <div class="container">
                <div class="row justify-content-center">
                    <div v-if="selected" style="padding: 15px 20px" class="bg-white col-lg-12 text-center">
                        Selected : <strong><span class="text-primary">#</span> {{ selected }}- {{ selectedName }} </strong>
                    </div>
                    <div :class="['dimmer col-lg-12 bg-white pb-5 px-0' , data.loading ? 'active' : '']">
                        <div class="loader"></div>
                        <div class="dimmer-content border-bottom border-top">
                            <div style="height:60vh;position: relative" class="">
                                <div class="select-header border-bottom d-flex align-items-center">
                                    <h6 class="tx-uppercase mb-0 mr-3"> {{ name }}</h6>
                                    <div class="search-form mr-auto d-flex align-items-center border-left border-right mr-3 px-3">
                                        <search-icon class="" size="16"/>
                                        <input v-model="data.search" type="text" class="form-control border-0" placeholder="Search..">
                                    </div>
                                    <div class="d-flex align-items-center mr-2 tx-12">
                                        <span class="mr-3"> Showing {{ data.content.data.length }} of {{ data.content.total }} Records </span>
                                        <span class="border border-secondary py-1 px-2 rounded mr-auto">Sorted By  : <strong> {{ data.sort.field.read }} </strong> , {{ data.sort.value }} </span>
                                    </div>
                                    <button @click="data.fetch()" :class="['tx-uppercase btn btn-white btn-sm mr-2' , data.loading ? 'btn-loading' :'']">
                                        <refresh-ccw-icon class="mr-1"/> Refresh
                                    </button>
                                    <button @click="close"  :class="['ml-2 tx-uppercase btn btn-white btn-sm btn-icon' , data.loading ? 'btn-loading' :'']">
                                        <x-icon/>
                                    </button>
                                </div>
                                <div class="select-content">
                                    <div v-if="data.filters.length > 0 || data.ranges.length > 0 " class="px-2 py-2 filters-container tx-12 border-bottom">
                        <span class="ml-2" :key="`filters-${index}`" v-for="(item, index) in data.filters" >
                            <span class="border border-secondary py-2 px-2 rounded-left">{{ item.field.read }} : <strong > {{ item.value.read }} </strong></span>
                            <span @click="data.removeFilter(index)" class="border-top border-bottom border-right border-secondary text-muted  py-2 px-2 rounded-right" style="cursor: pointer;"><x-icon size="15"/></span>
                        </span>
                                        <span :key="`ranges-${index}`" class="ml-2" v-for="(item, index) in data.ranges">
                            <span class="border border-secondary py-2 px-2 rounded-left"> {{ item.field.read }} : <strong> {{ item.min }} - {{ item.max }} </strong></span>
                            <span @click="data.removeRange(item)" class="border-top border-bottom border-right border-secondary text-muted  py-2 px-2 rounded-right" style="cursor: pointer;"><x-icon size="15"/></span>
                        </span>
                                    </div>
                                    <div v-if="data.content.total > 0" class="table-responsive tx-13">
                                        <table class="table border-bottom table-hover table-vcenter">
                                            <thead>
                                            <tr class="bg-light">
                                                <!--suppress HtmlDeprecatedAttribute -->
                                                <th width="10"/>
                                                <slot name="table-header"/>
                                                <!--suppress HtmlDeprecatedAttribute -->
                                                <th/>
                                                <th width="10"/>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <template v-for="row in data.content.data">
                                                <tr :key="row.id">
                                                    <td/>
                                                        <slot :row="row" name="table-row"/>
                                                    <td>
                                                        <button @click="add(row)" v-if="row.id !== selected" class="btn btn-white btn-icon btn-sm">
                                                            <check-circle-icon size="24"/>
                                                        </button>
                                                        <button @click="remove(row)" v-if="row.id === selected" class="btn btn-icon btn-danger btn-sm">
                                                            <x-icon size="24"/>
                                                        </button>
                                                    </td>
                                                    <td/>
                                                </tr>
                                            </template>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div v-if="data.content.total !== data.content.to && data.content.data.length > 0" :class="['px-2 py-3 text-center dimmer' , data.loading ? 'active' : '']">
                                        <div class="loader"></div>
                                        <div class="dimmer-content">
                                            <a @click.prevent="data.append" href="" class="link-03"> Load More <i class="icon ion-md-arrow-down mg-l-5"/></a>
                                        </div>
                                    </div>
                                    <div v-if="data.content.data.length < 1" :class="['px-2 py-5 text-center border-bottom  dimmer' , data.loading ? 'active' : '']">
                                        <div class="loader"></div>
                                        <div class="dimmer-content">
                                            No records found
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>

<script>
    import DataHandler from "../../core/data/DataHandler";
    import {FilterIcon, RefreshCcwIcon, SearchIcon , XIcon , CheckCircleIcon , EditIcon} from 'vue-feather-icons';
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    export default {
        components : {
            RefreshCcwIcon , SearchIcon , FilterIcon , XIcon  , CheckCircleIcon  , EditIcon
        },
        name: "data-select",
        props: ['value' , 'name' , 'url' , 'prefix' ,'start' , 'global'],
        mounted : function()
        {
            this.data.fetch();
        },
        data : function(){
            return {
                data : new DataHandler({
                    url : this.url,
                    prefix : this.prefix,
                }),
                selected : '',
                selectedName :  '',
                dialog : false,
            };
        },
        watch : {
            start : function( n , o) {
                this.selectedName = n[ this.select ? this.select : 'select_name' ] ;
                this.selected = n.id;
            },
            global : function( n , o) {
                this.data.setGlobal(n);
                this.data.fetch();
            }
        },
        methods : {
            add : function (row){
                this.selected = row.id;
                this.selectedName = row.select_name;
                this.close();
                this.update();
            },

            close : function(){
                this.dialog = false;
            },

            open : function(){
                this.dialog = true;
                // new PerfectScrollbar('.select-content', {
                //     suppressScrollX: true,
                // });
            },

            remove : function (row)
            {
                this.selected = "";
                this.selectedName = "";
                this.update();
            },
            update : function () {
                this.$emit('input', this.selected);
            }
        }

    }
</script>

<style scoped>
    .start {
        border: 1px solid #c0ccda;
        border-radius: 0.25rem;
        font-weight: 400;
        color: #596882;
        background-color: #fff;
        background-clip: padding-box;
        padding: 0.46875rem 0.625rem;
    }

    .result {
        border: 1px solid #c0ccda;
        border-radius: 0.25rem;
        font-weight: 400;
        background-color: #fff;
        background-clip: padding-box;
        padding: 0.46875rem 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .data-container {
        width: 100%;
    }

    .select-container {
        position: fixed;
        z-index: 9999;
        top: 60px;
        right: 0;
        left: 0;
        bottom: 0;
        background-color: rgba( 0 , 0 , 0 , 0.6 );
        display: flex;
        justify-content: center;
        align-content: center;
        align-items: center;
    }

    .select-header {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 55px;
        padding: 0 20px;
    }

    .select-content {
        position: absolute;
        top: 55px;
        left: 0;
        right: 0;
        bottom: 0;
        overflow-y:scroll;
    }
</style>
