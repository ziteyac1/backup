<template>
    <data-table url="/requests" filter="false" prefix="requests">
        <template slot="table-header">
            <th/>
            <th>Name</th>
            <th>User</th>
            <th>Info</th>
            <th>Date</th>
            <th/>
        </template>
        <!--suppress JSUnusedLocalSymbols -->
        <template slot="table-row" slot-scope="data">
            <td class="text-primary">#{{ data.row.id }}</td>
            <td class="">{{ data.row.report.name }}</td>
            <td class="">
                <div>Name : {{ data.row.user.name }}</div>
                <div>Email : {{ data.row.user.email }}</div>
            </td>
            <td class="">
                <div>State : {{ data.row.state }}</div>
                <div>Progress : {{ data.row.progress }}</div>
            </td>
            <td class="">{{ data.row.created_at }}</td>
            <td class="text-center">
                <a v-if="data.row.complete === 1" target="_blank" :href="`/requests/${data.row.id}/download`" class="btn btn-sm pd-x-15 btn-white">
                    Download
                </a>
            </td>
        </template>
    </data-table>
</template>

<script>
    import DataTable from "../core/DataTable";
    import {PlusIcon , EyeIcon} from "vue-feather-icons";
    export default {
        name: "requests",
        components: {DataTable , PlusIcon , EyeIcon }
    }
</script>
