<template>
   <div>
       <div class="filemgr-content-header px-5">
           <div class="d-flex align-items-center">
               <div class="avatar">
                   <span class="avatar-initial rounded-circle bg-gray-600">{{ $route.params.id }}</span>
               </div>
           </div>

           <button class="btn btn-white rounded-0 ml-auto btn-sm px-5">Refresh</button>
       </div>
       <div style="overflow-x: scroll" class="filemgr-content-body p-5">
           <div :class="['dimmer' , false ? 'active' : '' ]">
               <div class="loader"></div>
               <div class="dimmer-content">
                   <div class="container">
                       <div class="row">
                           <div class="col-4">
                               <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                                   Name
                               </label>
                               <p class="mg-b-0">
                                   {{ report.name }}
                               </p>
                           </div>
                           <div class="col-6">
                               <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                                   Description
                               </label>
                               <p class="mg-b-0">
                                   {{ report.description  }}
                               </p>
                           </div>
                       </div>
                   </div>
               </div>
           </div>

       </div>
   </div>
</template>

<script>
    import DataTable from "../core/DataTable";
    import {PlusIcon , EyeIcon} from "vue-feather-icons";
    export default {
        name: "index",
        components: {DataTable , PlusIcon , EyeIcon },
        mounted() {
            this.init();
        },
        data(){
           return {
               initLoading : true,
               report : {
                   documentation : []
               }
           }
        },
        methods : {
            init()
            {
                this.initLoading = true;
                window.axios.get(`${window.location.origin}/reports/${this.$route.params.id}/view`).then((response) => {
                    this.report = response.data.body.report;
                }).finally(() => {
                    this.initLoading = false;
                });
            }
        }
    }
</script>
