<template>
    <data-table url="/reports" filter="false" prefix="reports">
        <template slot="table-header">
            <th/>
            <th>Name</th>
            <th>Description</th>
            <th>Date</th>
            <th/>
        </template>
        <template slot="table-row" slot-scope="data">
            <td class="text-primary py-3">#{{ data.row.id }}</td>
            <td class="">{{ data.row.name }}</td>
            <td class="">{{ data.row.description }}</td>
            <td class="">{{ data.row.created_at }}</td>
            <td class="text-center">
                <router-link :to="`/reports/${data.row.id}/view`" class="btn btn-sm btn-white">View</router-link>
            </td>
        </template>
    </data-table>
</template>

<script>
    import DataTable from "../core/DataTable";
    import {PlusIcon , EyeIcon} from "vue-feather-icons";
    export default {
        name: "index",
        components: {DataTable , PlusIcon , EyeIcon },
        methods : {

        }
    }
</script>
