import Errors from "./errors";

class Form {

    constructor(data , storage = {})
    {
        this.storage = storage;
        this.original =  data;
        this.loading = false;
        for ( let  field in data )
        {
            // noinspection JSUnfilteredForInLoop
            this[field] = data[field];
        }

        this.errors = new Errors();
    }

    data()
    {
        let data = {};
        for ( let  field in this.original ) {
            data[field] = this[field];
        }

        return data;
    }

    reset()
    {
        for ( let  field in this.original )
        {
            // noinspection JSUnfilteredForInLoop
            this[field] = '';
        }
    }

    submit(url)
    {
        this.loading = true;
        this.errors.clear();
        return new Promise((resolve , reject) => {
            window.axios['post'](`${window.location.origin}${url}` , this.data())
                .then((e) => {
                   this.loading = false;
                   this.onSuccess(e);
                   resolve(e);
                }).catch((e) => {
                    this.loading = false;
                    this.onFail(e);
                    reject(e);
                });

        });

    }

    onSuccess(e){

    }

    onFail(e) {
        this.errors.record(e.response.data.errors);
    }
}

export default Form;
