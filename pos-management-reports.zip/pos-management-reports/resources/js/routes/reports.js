// Buildings

import Index from "../components/reports/index";
import View from "../components/reports/view";
import Requests from "../components/reports/requests";

const routes = [

    {
        path : '/reports',
        component : Index
    },
    {
        path : '/reports/:id/view',
        component : View
    },
    {
        path : '/requests',
        component : Requests
    },
];

export default routes;
