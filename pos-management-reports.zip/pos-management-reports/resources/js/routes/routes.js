// Router
import VueRouter from "vue-router";
import Vue from "vue";
Vue.use(VueRouter);

let routes = [];

import reports from "./reports";
routes = routes.concat(reports);

const router = new VueRouter({
    routes :  routes,
    activeClass : 'active',
});



let apps = [
    {
        path : "/apps/reports",
        to : "/reports"
    },
];

router.beforeEach((to, from, next) => {

    if (to.path === "/") {
        apps.forEach((value) => {
            if ( window.location.pathname === value.path){
                next(value.to)
            }
        });
    }
    next();
});

export default router;
