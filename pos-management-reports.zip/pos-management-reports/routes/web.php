<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Http\Controllers\AccountController;
use App\Http\Controllers\AppController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\RequestController;
use App\Http\Controllers\SSOController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

// Authentication Routes

Auth::routes([
    'register' => false,
    'verify' => false,
    "reset" => false,
]);

// Landing Page

Route::get('/', [HomeController::class , 'landing']);

// Auth Guard

Route::middleware('auth')->group(function (){

    Route::get('/home', [HomeController::class , 'home']);

    Route::prefix('/apps')->group( function (){
        Route::get('/reports' , [AppController::class , 'reports'])->name('apps.reports');
    });

    Route::prefix('/reports')->group( function (){
        Route::get('/' , [ReportController::class , 'index']);
        Route::get('/{model}/view' , [ReportController::class , 'view']);
    });

    Route::prefix('/requests')->group( function (){
        Route::get('/' , [RequestController::class , 'index']);
    });

    Route::prefix('/requests')->group( function (){
        Route::get('/' , [AccountController::class , 'index']);
    });

});

