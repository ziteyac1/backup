<?php

namespace App;

use App\Core\DefaultModel;
use Illuminate\Database\Eloquent\Model;

/**
 * @property mixed primary
 * @property mixed name
 */
class Currency extends DefaultModel
{
    //
}
