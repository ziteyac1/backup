<?php


namespace App\TransactionManager\Core;


use Illuminate\Pipeline\Pipeline;

class TM
{
    public function pipe($context , $pipes = [])
    {
        /** @var Pipeline $pipeline */
        $pipeline = app(Pipeline::class);
        return $pipeline->send($context)->through($pipes)->thenReturn();
    }
}
