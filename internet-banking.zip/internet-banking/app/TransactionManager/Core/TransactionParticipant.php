<?php


namespace App\TransactionManager\Core;
use Closure;

abstract class TransactionParticipant
{
    public function handle($context, Closure $next){
        $context = $this->commit($context);
        return $next($context);
    }
    public abstract function abort($context);
    public abstract function commit($context);
}
