<?php


namespace App\TransactionManager\InternalTransfer;


use App\TransactionManager\Core\TransactionParticipant;
use Closure;
use Illuminate\Http\Request;

class Create extends TransactionParticipant
{
    public function abort($context)
    {
        return $context;
    }

    public function commit($context)
    {
        return $context;
    }
}
