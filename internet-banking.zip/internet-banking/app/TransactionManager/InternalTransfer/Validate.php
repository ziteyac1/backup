<?php


namespace App\TransactionManager\InternalTransfer;


use App\TransactionManager\Core\TransactionParticipant;
use Closure;
use Illuminate\Http\Request;

class Validate extends TransactionParticipant
{
    public function abort($context)
    {
        return $context;
    }

    public function commit($context)
    {
        /** @var Request $request */
        $request = $context['request'];
        $request->validate([
            'name' => ['required'],
            'last_name' => ['required'],
        ]);
        return $context;
    }
}
