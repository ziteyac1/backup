<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Queue\SerializesModels;

class UserUpdatedEmail extends Mailable
{
    use Queueable, SerializesModels;

    private $user;

    public function __construct($user)
    {
        $this->user = $user;
    }

    /**
     * Build the message.
     *
     * @return $this
     */

    public function build()
    {
        $message = "Your Internet Banking account was successfully updated";
        $mail = (new MailMessage)
            ->greeting('Good Day!')
            ->line($message)
            ->line('For enquires , immediately contact us  on +263 8677202202 or +263 242 772103-4 or write to us at contactcentre@agribank.co.zw')
            ->line('Thank you for using our application!');
        return  $this->subject('Agribank Internet banking : Account Update')
            ->markdown('vendor.notifications.email' , $mail->data());
    }
}
