<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Queue\SerializesModels;

class OTPMail extends Mailable
{
    use Queueable, SerializesModels;

    private $otp;

    /**
     * Create a new message instance.
     *
     * @param $otp
     */
    public function __construct($otp)
    {
        $this->otp = $otp;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $message = "Your Internet Banking login OTP is {$this->otp} , OTP will expire in 20 minutes. For security reasons, please do not share the OTP with anyone.";
        $mail = (new MailMessage)
            ->greeting('Good Day!')
            ->line($message)
            ->line('Should you receive any message requesting your details, immediately contact us  on +263 8677202202 or +263 242 772103-4 or write to us at contactcentre@agribank.co.zw')
            ->line('Thank you for using our application!');
        return  $this->subject('Agribank Internet Banking OTP')
            ->markdown('vendor.notifications.email' , $mail->data());

    }
}
