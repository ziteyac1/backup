<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Queue\SerializesModels;

class RegistrationCreatedAdminEmail extends Mailable
{
    use Queueable, SerializesModels;

    private $reg;

    /**
     * Create a new message instance.
     * @param $reg
     */
    public function __construct($reg)
    {
        $this->reg = $reg;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $message = "There is a new self registration on Internet Banking with id #{$this->reg->id} , name " . $this->reg->full_name;
        $mail = (new MailMessage)
            ->greeting('Good Day!')
            ->line($message)
            ->line('Thank you for using our application!');
        return  $this->subject('Agribank Internet banking : Self registration')
            ->markdown('vendor.notifications.email' , $mail->data());
    }
}
