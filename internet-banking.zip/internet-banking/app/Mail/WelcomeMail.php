<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Queue\SerializesModels;

class WelcomeMail extends Mailable
{
    use Queueable, SerializesModels;

    private $email;
    private $password;
    private $full_name;


    /**
     * Create a new message instance.
     *
     * @param $email
     * @param $full_name
     * @param $password
     */
    public function __construct($email , $full_name , $password)
    {
        $this->email = $email;
        $this->full_name = $full_name;
        $this->password = $password;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
         $mail = (new MailMessage)
            ->greeting('Dear '. ucwords($this->full_name))
            ->line('Greetings from Agribank')
            ->line('Welcome to Agribank Green 365 banking, we are happy to announce that you have been successfully registered. Follow the link below to login, your login one-time password will be sent to your mobile and you will be asked to change password after first login.')
            ->line('Your Login details are as follows :')
            ->line('Email : ' . $this->email)
            ->line('Password : ' . $this->password)
            ->action('Login' , config('system.url'))
            ->line('Thank you for using Agribank Green 365 Banking!')
            ->line('Security Information')
            ->line('Never provide your User ID or password to any one on phone or in response to an email')
            ->line('Change your Login Password periodically')
            ->line('Should you receive any message requesting your details, immediately contact us  on +263 8677202202 or +263 242 772103-4 or write to us at contactcentre@agribank.co.zw')
            ->line('Do not enter login or other sensitive information in any pop up window');
        return  $this->subject('Welcome to Agribank Internet Banking')
            ->markdown('vendor.notifications.email' , $mail->data());

    }
}
