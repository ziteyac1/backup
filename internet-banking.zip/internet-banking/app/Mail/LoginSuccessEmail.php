<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Queue\SerializesModels;

class LoginSuccessEmail extends Mailable
{
    use Queueable, SerializesModels;

    private $email;

    /**
     * Create a new message instance.
     * @param $email
     */
    public function __construct($email)
    {
        $this->email = $email;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $message = "There was a login on your account [ {$this->email} ] on " . now()->toString();
        $mail = (new MailMessage)
            ->greeting('Good Day!')
            ->line($message)
            ->line('Thank you for using our application!');
        return  $this->subject('Agribank Internet banking : Login Success')
            ->markdown('vendor.notifications.email' , $mail->data());
    }
}
