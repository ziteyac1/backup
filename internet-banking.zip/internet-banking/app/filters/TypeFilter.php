<?php
/** @noinspection MethodShouldBeFinalInspection */
/** @noinspection MissingParameterTypeDeclarationInspection */
namespace App\filters;


use App\filters\core\ModelFilter;

class TypeFilter extends ModelFilter
{
    protected  $filters = [
        'search'
    ];

    protected  $equal = [
        'id'
    ];

    protected $search = [
      'name',
      'rtgs',
      'internal',
    ];

}
