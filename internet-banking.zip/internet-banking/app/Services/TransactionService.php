<?php


namespace App\Services;


use App\Authorisation;
use App\Core\HasTransactionServiceFunctions;
use App\FundLiquidition;
use App\InternalTransfer;
use App\RTGSTransfer;
use App\TobaccoInternalPayment;
use App\Transaction;
use App\Transactions\Core\TransactionContract;
use App\User;
use Illuminate\Contracts\Container\BindingResolutionException;
use Ramsey\Uuid\Uuid;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class TransactionService
{
    use HasTransactionServiceFunctions;

    /**
     * @param Transaction $transaction
     * @return Transaction
     * @throws BindingResolutionException
     */
    public function run($transaction)
    {
        [ $code , $path ] = $this->generateTransactionQr($transaction);

        $transaction->update([
            'state' => 1,
            'qr' => $path,
            'code'=> $code
        ]);


        /** @var User $auth */
        $auth = auth()->user();

        $needAuth = [
            InternalTransfer::class,
            TobaccoInternalPayment::class,
            RTGSTransfer::class,
            FundLiquidition::class,
        ];

        if ($auth->is_corporate && in_array($transaction->transaction_type , $needAuth))
        {
            // Initiate Authorisation Leg for Corporates

            $transaction->update([
                'state' => 2
            ]);

            $transaction->authorisation()->create([
                'corporate_id' => $auth->corporate_id,
//                'user_id' => $auth->id
            ]);

            $transaction->load('authorisation');

            return  $transaction;

        }

        // Complete Transaction

        $transaction->update([
            'start' => now(),
        ]);



        $transaction = $this->instantiateService($transaction)->complete($transaction);

        return $transaction;
    }

    /**
     * @param $transaction
     * @return Transaction
     * @throws BindingResolutionException
     */
    public function complete($transaction)
    {
        return $this->instantiateService($transaction)->complete($transaction);
    }

    /**
     * @param Transaction $model
     * @return Transaction
     * @throws BindingResolutionException
     */
    public function retry(Transaction $model)
    {
        return $this->instantiateService($model)->complete($model);
    }
}
