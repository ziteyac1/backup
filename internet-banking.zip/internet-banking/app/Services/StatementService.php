<?php


namespace App\Services;


use App\Corporate;
use App\Transaction;
use App\User;

class StatementService
{
    public function summary($st , $transaction)
    {
        $statement = [];
        $statement['transactions'] = [];
        $statement['start'] = 0;
        $statement['end'] = 0;
        $statement['debits'] = 0;
        $statement['debits_count'] = 0;
        $statement['credits'] = 0;
        $statement['change'] = 0;
        $statement['credits_count'] = 0;
        $statement['transactions'] = 0;
        $statement['total'] = 0;
        $statement['qr'] = '';
        $statement['state'] = $transaction->state;
        $statement['pdf'] = $st->pdf;
        $statement['csv'] = $st->csv;
        $statement['code'] = '';
        $statement['date_start'] = $st->start->format('Y-m-d');
        $statement['date_end'] = $st->end->format('Y-m-d');
        $statement['date'] = $st->created_at->format('Y-m-d H:i:s');
        $statement['account'] = $transaction->account;

        $statement['running_balance_values'] = [];
        $statement['running_balance_dates'] = [];
        $statement['transaction_types'] = [];
        $statement['min'] = 0;
        $statement['max'] = 0;
        $statement['average'] = 0;
        $statement['tran_id'] = $transaction->id;

        $temp = [];
        $tempTypes = [];

        $name = "";

        /** @var Transaction $transaction */
        if ($transaction->account->parent instanceof  User)
        {
            $name = $transaction->account->parent->full_name;
        }

        /** @var Transaction $transaction */
        if ($transaction->account->parent instanceof  Corporate)
        {
            $name = $transaction->account->parent->name;
        }

        $statement['name'] = $name;
        $statement['reference'] = $transaction->reference;

        if ( $st->statement)
        {
            $transactions = $st->statement['transactions'];
            $debits = 0;
            $debitsCount = 0;
            $credits = 0;
            $creditsCount = 0;
            $total = 0;
            foreach ($transactions as $item)
            {

                $tranValue = 0;

                $temp[$item['valueDate']][] = floatval(str_replace(',' , '' , $item['balance']));

                $total++;

                $value =  floatval(
                    str_replace(',' , '' ,
                        str_replace('$' , '' , $item['debit'])
                    )
                );

                $debits += $value;

                if ($value > 0 )
                {
                    $debitsCount++;
                    $tranValue = $value;
                }

                $value = floatval(
                    str_replace(',' , '' ,
                        str_replace('$' , '' , $item['credit'])
                    )
                );

                $credits += $value;

                if ($value > 0 )
                {
                    $creditsCount++;
                    $tranValue = $value;
                }

                // Min and max and average

                $tranValue = floatval($tranValue);

                if ( $statement['min'] === 0 )
                {
                    $statement['min'] = $tranValue;
                }

                $statement['min'] = $statement['min'] >= $tranValue ? $tranValue : $statement['min'];
                $statement['max'] = $statement['max'] < $tranValue ? $tranValue : $statement['max'];

                if (isset($tempTypes[$item['reference']])) {

                    $tempTypes[$item['reference']]['count']++;
                    $tempTypes[$item['reference']]['sum']
                        = round( $tempTypes[$item['reference']]['sum'] +  $tranValue , 2 );

                } else {
                    $tempTypes[$item['reference']]['count'] = 1;
                    $tempTypes[$item['reference']]['sum'] = $tranValue;
                }



            }

            // Process Running Balances

            foreach ($temp as $key => $item)
            {
                $statement['running_balance_values'][] = $temp[$key][count($temp[$key]) - 1 ];
                $statement['running_balance_dates'][] = $key;
            }

            // Types Running Balances

            foreach ($tempTypes as $key => $item )
            {
                $statement['transaction_types'][] = [
                    'name' => $key,
                    'count' => $item['count'],
                    'sum' => $item['sum'],
                ];
            }

//            $statement['change'] = round((( $st->statement['end'] - $st->statement['start']  ) / ($st->statement['start'] == 0 ? 1 : $st->statement['start'])  ) / 100 );
            $statement['change'] = $this->getPercentageChange($st->statement['start'] ,  $st->statement['end'] );

            $statement['start'] = '$'. ( $st->statement['start'] / 100 );
            $statement['end'] = '$'. ( $st->statement['end'] / 100 );
            $statement['debits'] = round($debits , 2 );
            $statement['debits_count'] = $debitsCount;
            $statement['credits'] = round($credits , 2 );
            $statement['credits_count'] = $creditsCount;
            $statement['transactions'] = $transactions;
            $statement['average'] = round( ( $statement['debits'] + $statement['credits'] )  / ( $total == 0 ? 1 : $total ));
            $statement['total'] = $total;
            $statement['qr'] = $transaction->qr;
            $statement['code'] = $transaction->code;

            // Running Balances Trimmer
            /*
             *  $statement['running_balance_values'] = [];
             *   $statement['running_balance_dates'] = [];
             */

            $limit = 30;

            if (count($statement['running_balance_values']) > $limit )
            {
                $statement['running_balance_values'] = $this->trimArray($statement['running_balance_values'] , $limit);
                $statement['running_balance_dates'] = $this->trimArray($statement['running_balance_dates'] , $limit);
            }

        }

        return $statement;
    }

    private function getPercentageChange($oldNumber, $newNumber)
    {
        $decreaseValue = $oldNumber - $newNumber;
        if ((int)$oldNumber == 0)
        {
            $oldNumber = 1;
        }
        return round(($decreaseValue / $oldNumber) * 100 * -1);
    }


    private function trimArray( $array , $limit)
    {
        $out = $array;
        do {
            $out = $this->remove($out , $limit);
        } while ( count($out) > $limit);

        return $out;
    }

    private  function remove($array , $limit)
    {
        $remove = true;
        $out = [];
        $original = $array;
        $copy = $array;

        foreach ($array as $key => $item)
        {
            if ($key == 0 || $key == count($original) - 1 || count($copy) <= $limit)
            {
                $out[] = $item;
                continue;
            }
            if ($remove)
            {
                unset($array[$key]);
                unset($copy[$key]);
                $remove = !$remove;
                continue;
            }
            $out[] = $remove;
            $remove = !$remove;
        }

        return array_values($array);
    }
}
