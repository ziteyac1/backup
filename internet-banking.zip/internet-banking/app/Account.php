<?php

namespace App;

use App\Core\DefaultModel;
use Illuminate\Database\Eloquent\Model;

/**
 * @property mixed id
 * @property mixed parent
 * @property mixed account_type
 * @property mixed account
 * @property Currency currency
 */
class Account extends DefaultModel
{

    protected $with = ['currency' , 'types'];

    protected $casts = [
        'created_at' => 'datetime:Y-m-d H:i:s',
        'updated_at' => 'datetime:Y-m-d H:i:s',
        'data'=> 'array'
    ];

    protected $appends = ['type' , 'route'];

    public function getTypeAttribute()
    {
        $helper = [];
        $helper[User::class] = 'user';
        $helper[Corporate::class] = 'corporate';
        return $helper[$this->account_type];
    }

    public function getRouteAttribute()
    {
        $helper = [];
        $helper[User::class] = 'users';
        $helper[Corporate::class] = 'corporates';
        return $helper[$this->account_type];
    }

    public function currency()
    {
        return $this->hasOne(Currency::class , 'id' , 'currency_id');
    }

    public function parent()
    {
        return $this->morphTo('account');
    }


    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function types()
    {
        return $this->belongsToMany(TransactionType::class ,
            'account_transaction_types' ,
            'type_id' ,
            'account_id'
        )->using(AccountTransactionType::class)->withPivot([
            'created_at',
            'updated_at',
        ])->withTimestamps();
    }


}
