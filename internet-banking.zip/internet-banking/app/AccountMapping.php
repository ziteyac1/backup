<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AccountMapping extends Model
{
    protected $guarded = [];
}
