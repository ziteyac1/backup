<?php

namespace App\Policies;

use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class StatementPolicy
{
    use HandlesAuthorization;

    public function run(User $user)
    {
        if ($user->is_corporate)
        {
            return $user->hasPermissionTo('run-statement');
        }

        return true;
    }
}
