<?php

namespace App\Policies;

use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class UsersPolicy
{
    use HandlesAuthorization;

    public function list(User $user)
    {
        if ($user->is_corporate)
        {
            return $user->hasPermissionTo('manage-users');
        }
        return $user->is_admin;
    }

    public function update(User $user , User $model)
    {
        if ($user->is_admin)
        {
            return true;
        }

        if ($user->is_corporate)
        {
            return $user->corporate_id === $model->corporate_id && $user->hasPermissionTo('manage-users');
        }

        return false;
    }

    public function activate(User $user , User $model)
    {

        if ($user->is_admin)
        {
            return true;
        }

        return false;
    }

    public function deactivate(User $user , User $model)
    {
        if ($user->is_corporate)
        {
            return $user->corporate_id === $model->corporate_id && $user->hasPermissionTo('manage-users');
        }

        if ($user->is_admin)
        {
            return true;
        }

        return false;
    }

    public function admin(User $user)
    {
        if ($user->is_admin)
        {
            return true;
        }

        return false;
    }

    public function root(User $user)
    {
        if ($user->is_root)
        {
            return true;
        }

        return false;
    }

    public function documents(User $user)
    {
        if ( $user->is_admin || $user->hasPermissionTo('manage-users'))
        {
            return true;
        }

        return false;
    }

    public function corporateAdmin(User $user)
    {
        if ($user->is_corporate)
        {
            return $user->hasPermissionTo('manage-users');
        }

        return false;
    }


}
