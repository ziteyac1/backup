<?php

namespace App\Policies;

use App\Batch;
use App\User;

class BatchTransferPolicy
{
    public function view(User $user , Batch $model)
    {
        $accounts = $user->is_corporate ? $user->corporate->working : $user->working;

        if (count($accounts))
        {
            $accounts = $accounts->map(function ($value) {
                return $value->id;
            })->values()->toArray();
        }

        return in_array($model->account_id , $accounts);
    }

    public function authorise(User $user , Batch $model)
    {
        if (!in_array($model->status , [3]))
        {
            return false;
        }

        $accounts = $user->is_corporate ? $user->corporate->working : $user->working;

        if (count($accounts))
        {
            $accounts = $accounts->map(function ($value) {
                return $value->id;
            })->values()->toArray();
        }

        return in_array($model->account_id , $accounts) && $user->is_corporate && $user->hasPermissionTo('authorise-transaction');
    }

    public function cancel(User $user , Batch $model)
    {
        if (!in_array($model->status , [3,4]))
        {
            return false;
        }

        return  $user->id === $model->user_id;

    }
}
