<?php

namespace App\Policies;

use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class AuthorisationsPolicy
{
    use HandlesAuthorization;

    public function list(User $user)
    {
        if ($user->is_corporate)
        {
            return $user->hasPermissionTo('authorise-transaction');
        }

        return false;
    }
}
