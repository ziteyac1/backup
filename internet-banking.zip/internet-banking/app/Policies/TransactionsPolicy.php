<?php

namespace App\Policies;

use App\Transaction;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class TransactionsPolicy
{
    use HandlesAuthorization;

    public function initiate(User $user)
    {
        if ($user->is_corporate)
        {
            return $user->hasPermissionTo('input-transactions');
        }

        return true;
    }
    public function tobacco(User $user)
    {
        if ($user->is_corporate && $user->corporate->is_tobacco_client === 1)
        {
            return $user->hasPermissionTo('input-transactions');
        }

        return false;
    }

    public function authorise(User $user , Transaction $model)
    {
        $accounts = $user->is_corporate ? $user->corporate->working : $user->working;

        if (count($accounts))
        {
            $accounts = $accounts->map(function ($value) {
                return $value->id;
            })->values()->toArray();
        }

        return in_array($model->account_id , $accounts) && $user->is_corporate && $user->hasPermissionTo('authorise-transaction');
    }

    public function initiateTransaction(User $user)
    {
        return $user->is_admin || $user->is_individual || ( $user->is_corporate && $user->hasPermissionTo('input-transactions'));
    }

    public function runStatement(User $user)
    {

        return $user->is_admin || $user->is_individual || ( $user->is_corporate && $user->hasPermissionTo('run-statement'));
    }

    public function view(User $user , Transaction $model)
    {
        $accounts = $user->is_corporate ?
                    $user->corporate->working :
                    $user->working;

        if (count($accounts)) {
            $accounts = $accounts->map(function ($value) {
                return $value->id;
            })->values()->toArray();
        } else {
            $accounts = [];
        }

        return in_array($model->account_id , $accounts);
    }
}
