<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Http;

class ReverseBulkFTs extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'reverse:ft';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Reverse Fts';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $file = file('data/-tobacco-ft.csv');


        foreach ($file as $line)
        {
            $line = trim($line);
            echo  $line.PHP_EOL;

            $data = explode(",", $line);
            $ft = $data[1];
            $id = $data[0];

            $result = Http::post('192.168.0.27:4321/transaction/reverse', [
                'id' => $id,
                'ft' => $ft,
                'application' => 'tobacco-api'
            ]);

            print_r($result->json());

        }

    }
}
