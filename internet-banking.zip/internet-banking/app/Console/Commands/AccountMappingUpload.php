<?php

namespace App\Console\Commands;

use App\AccountMapping;
use Illuminate\Console\Command;

class AccountMappingUpload extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'accounts:load';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Load all old accounts';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $file = file("data/accounts.log" , FILE_SKIP_EMPTY_LINES | FILE_IGNORE_NEW_LINES );
        foreach ( $file as $line)
        {
            $line = trim($line);
            $line = preg_replace('/\s+/', ' ', $line);
            $line = explode(' ' , $line);
            if (count($line) == 2 )
            {
                echo 'Created : ' . $line[0] . ' : ' . $line[1] .PHP_EOL;
                AccountMapping::query()->create([
                    'old' => $line[0],
                    'new' => $line[1],
                ]);
            }
        }
    }
}
