<?php

namespace App\Console\Commands;

use App\InternalTransfer;
use App\RTGSTransfer;
use App\TransactionManager\Groups\Internal\CreateInternalTransaction;
use App\TransactionManager\Groups\Internal\CreateRTGSTransaction;
use App\TransactionManager\Groups\SwitchTransactionType;
use App\TransactionManager\PrepareInternalTransfer;
use App\TransactionManager\SwitchByType;
use App\TransactionManager\ValidateInternalTransfer;
use App\TransactionManager\ValidateRTGSTransfer;
use Illuminate\Console\Command;

class SimulateTM extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'simulate:tm';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

    }
}
