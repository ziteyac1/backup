<?php

namespace App\Listeners;

use App\Events\LoginSuccessEvent;
use App\Mail\LoginAttemptEmail;
use App\Mail\LoginSuccessEmail;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Mail;

class LoginSuccessNotification implements ShouldQueue
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param LoginSuccessEvent $event
     * @return void
     */

    public function handle(LoginSuccessEvent $event)
    {
        Mail::to($event->user->email)->send(new LoginSuccessEmail($event->user->email));
    }
}
