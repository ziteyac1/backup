<?php

namespace App\Listeners;

use App\Events\RegistrationCreatedEvent;
use App\Events\UserActivatedEvent;
use App\Events\UserDeactivatedEvent;
use App\Mail\RegistrationAcceptedCustomerEmail;
use App\Mail\RegistrationCreatedAdminEmail;
use App\Mail\RegistrationCreatedCustomerEmail;
use App\Mail\UserActivatedEmail;
use App\Mail\UserDeactivatedEmail;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Mail;

class UserDeactivatedNotification implements ShouldQueue
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param UserDeactivatedEvent $event
     * @return void
     */
    public function handle(UserDeactivatedEvent $event)
    {
        Mail::to($event->model->email)->send(new UserDeactivatedEmail($event->model));
    }
}
