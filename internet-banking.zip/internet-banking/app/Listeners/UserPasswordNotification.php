<?php

namespace App\Listeners;

use App\Events\PasswordUpdatedEvent;
use App\Mail\UserPasswordEmail;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Mail;

class UserPasswordNotification implements ShouldQueue
{
    public function handle(PasswordUpdatedEvent $event)
    {
        Mail::to($event->user->email)->send(new UserPasswordEmail($event->user));
    }
}
