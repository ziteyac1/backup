<?php

namespace App\Listeners;

use App\Events\RegistrationAcceptedEvent;
use App\Mail\RegistrationAcceptedCustomerEmail;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Mail;

class RegistrationAcceptedCustomerNotification implements ShouldQueue
{
    /**
     * Handle the event.
     *
     * @param RegistrationAcceptedEvent $event
     * @return void
     */
    public function handle(RegistrationAcceptedEvent $event)
    {
        Mail::to($event->user->email)->send(new RegistrationAcceptedCustomerEmail($event->user));
    }
}
