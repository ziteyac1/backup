<?php

namespace App\Listeners;

use App\Events\RegistrationCreatedEvent;
use App\Events\RegistrationDeclineEvent;
use App\Mail\RegistrationAcceptedCustomerEmail;
use App\Mail\RegistrationCreatedAdminEmail;
use App\Mail\RegistrationCreatedCustomerEmail;
use App\Mail\RegistrationDeclinedCustomerEmail;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Mail;

class RegistrationDeclinedCustomerNotification implements ShouldQueue
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param RegistrationDeclineEvent $event
     * @return void
     */
    public function handle(RegistrationDeclineEvent $event)
    {
        Mail::to($event->model->email)->send(new RegistrationDeclinedCustomerEmail($event->model));
    }
}
