<?php

namespace App\Listeners;

use App\Events\RegistrationCreatedEvent;
use App\Events\UserActivatedEvent;
use App\Events\UserCreatedEvent;
use App\Events\UserUpdatedEvent;
use App\Mail\RegistrationAcceptedCustomerEmail;
use App\Mail\RegistrationCreatedAdminEmail;
use App\Mail\RegistrationCreatedCustomerEmail;
use App\Mail\UserActivatedEmail;
use App\Mail\UserCreatedEmail;
use App\Mail\UserUpdatedEmail;
use App\User;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Mail;

class UserUpdatedNotification implements ShouldQueue
{
    /**
     * Handle the event.
     *
     * @param UserUpdatedEvent $event
     * @return void
     */
    public function handle(UserUpdatedEvent $event)
    {
        Mail::to($event->model->email)->send(new UserUpdatedEmail($event->model));
    }
}
