<?php

namespace App\Listeners;
use App\Events\UserResetEvent;
use App\Mail\ResetMail;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Mail;

class UserResetNotification implements ShouldQueue
{
    /**
     * Handle the event.
     *
     * @param UserResetEvent $event
     * @return void
     */
    public function handle(UserResetEvent $event)
    {
        Mail::to($event->model->email)->send(new ResetMail($event->model , $event->phrase));
    }
}
