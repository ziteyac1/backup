<?php

namespace App\Listeners;

use App\Events\RegistrationCreatedEvent;
use App\Mail\LoginSuccessEmail;
use App\Mail\RegistrationCreatedAdminEmail;
use App\User;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Mail;

class RegistrationCreatedAdminNotification implements ShouldQueue
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param RegistrationCreatedEvent $event
     * @return void
     */

    public function handle(RegistrationCreatedEvent $event)
    {
        foreach (User::query()->where('type', '=', 'admin')->get() as $user)
        {
            Mail::to($user->email)->send(new RegistrationCreatedAdminEmail($event->registration));
        }
    }
}
