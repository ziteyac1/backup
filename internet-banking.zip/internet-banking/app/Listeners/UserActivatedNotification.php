<?php

namespace App\Listeners;

use App\Events\RegistrationCreatedEvent;
use App\Events\UserActivatedEvent;
use App\Mail\RegistrationAcceptedCustomerEmail;
use App\Mail\RegistrationCreatedAdminEmail;
use App\Mail\RegistrationCreatedCustomerEmail;
use App\Mail\UserActivatedEmail;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Mail;

class UserActivatedNotification implements ShouldQueue
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserActivatedEvent  $event
     * @return void
     */
    public function handle(UserActivatedEvent $event)
    {
        Mail::to($event->model->email)->send(new UserActivatedEmail($event->model));
    }
}
