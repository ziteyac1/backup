<?php

namespace App\Listeners;

use App\Events\LoginAttemptEvent;
use App\Mail\LoginAttemptEmail;
use App\Mail\OTPMail;
use App\User;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Mail;

class LoginAttemptWarning implements ShouldQueue
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param LoginAttemptEvent $event
     * @return void
     */
    public function handle(LoginAttemptEvent $event)
    {
        // Check email if its in database

        /** @var User $user */
        $user  = User::query()->where('email' , $event->email)->first();

        // Send email to the user

        if ($user)
        {
            Mail::to($user->email)->send(new LoginAttemptEmail($user->email));
        }

    }
}
