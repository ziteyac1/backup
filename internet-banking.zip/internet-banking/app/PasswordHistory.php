<?php

namespace App;

use App\Core\DefaultModel;
use Illuminate\Database\Eloquent\Model;

class PasswordHistory extends DefaultModel
{
    //
}
