<?php

namespace App\Providers;

use App\Account;
use App\Authorisation;
use App\Batch;
use App\Corporate;
use App\InternalTransfer;
use App\Policies\AccountsPolicy;
use App\Policies\AuthorisationsPolicy;
use App\Policies\BatchTransferPolicy;
use App\Policies\CorporatePolicy;
use App\Policies\RTGSTransferPolicy;
use App\Policies\SettingsPolicy;
use App\Policies\StatementPolicy;
use App\Policies\TransactionsPolicy;
use App\Policies\UsersPolicy;
use App\RTGSTransfer;
use App\Settings;
use App\StatementEnquiry;
use App\Transaction;
use App\User;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
         Account::class =>  AccountsPolicy::class,
         Authorisation::class =>  AuthorisationsPolicy::class,
         Batch::class =>  BatchTransferPolicy::class,
         Corporate::class =>  CorporatePolicy::class,
         InternalTransfer::class =>  InternalTransfer::class,
         RTGSTransfer::class =>  RTGSTransferPolicy::class,
         Settings::class =>  SettingsPolicy::class,
         StatementEnquiry::class =>  StatementPolicy::class,
         TransactionsPolicy::class =>  TransactionsPolicy::class,
         User::class =>  UsersPolicy::class,
         Transaction::class =>  TransactionsPolicy::class,
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();

        Gate::define('viewWebTinker', function ($user = null) {
            /** @var User $user */
            if ($user)
            {
                return $user->is_root;
            }
            return false;
        });

    }
}
