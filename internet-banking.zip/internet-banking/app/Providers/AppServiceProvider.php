<?php

namespace App\Providers;

use App\Batch;
use App\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Str;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {

    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);

        Validator::extendImplicit('current_password', function ($attribute, $value, $parameters, $validator) {
            return Hash::check($value, auth()->user()->password);
        });

        Validator::extendImplicit('password_history', function ($attribute, $value, $parameters, $validator) {

            /** @var User $user */
            $user = auth()->user();
            $history = $user->passwords;
            foreach ($history as $item)
            {
                if (Hash::check($value, $item->password))
                {
                    return false;
                }
            }
            return !Hash::check($value, $user->password);

        } , 'You cannot use a password you have used before');

        Validator::extendImplicit('password_history_id', function ($attribute, $value, $parameters, $validator) {

            /** @var User $user */
            $user = User::query()->where('id' ,'=' , $parameters)->first();
            $history = $user->passwords;
            foreach ($history as $item)
            {
                if (Hash::check($value, $item->password))
                {
                    return false;
                }
            }
            return !Hash::check($value, $user->password);

        } , 'You have used this password before');

        Validator::extendImplicit('agribank_account', function ($attribute, $value, $parameters, $validator) {
            return Str::length($value) === 12 || Str::length($value) === 16;
        }, 'Account must be 12 or 16 digits');

        Validator::extendImplicit('unique_batch', function ($attribute, $value, $parameters, $validator) {
            return !Batch::query()->where('account_id' , '=' , $parameters[0])
                ->where('reference' , '=' , $value)->exists();
        }, 'Duplicate batch , check batch reference');

    }
}
