<?php

namespace App\Providers;

use App\Events\LoginAttemptEvent;
use App\Events\LoginSuccessEvent;
use App\Events\PasswordUpdatedEvent;
use App\Events\RegistrationAcceptedEvent;
use App\Events\RegistrationCreatedEvent;
use App\Events\RegistrationDeclineEvent;
use App\Events\UserActivatedEvent;
use App\Events\UserCreatedEvent;
use App\Events\UserDeactivatedEvent;
use App\Events\UserResetEvent;
use App\Events\UserUpdatedEvent;
use App\Listeners\LoginAttemptWarning;
use App\Listeners\LoginSuccessNotification;
use App\Listeners\RegistrationAcceptedCustomerNotification;
use App\Listeners\RegistrationCreatedAdminNotification;
use App\Listeners\RegistrationCreatedCustomerNotification;
use App\Listeners\RegistrationDeclinedCustomerNotification;
use App\Listeners\UserActivatedNotification;
use App\Listeners\UserCreatedNotification;
use App\Listeners\UserDeactivatedNotification;
use App\Listeners\UserPasswordNotification;
use App\Listeners\UserResetNotification;
use App\Listeners\UserUpdatedNotification;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event listener mappings for the application.
     *
     * @var array
     */
    protected $listen = [
        LoginAttemptEvent::class => [
            LoginAttemptWarning::class
        ],
        LoginSuccessEvent::class => [
            LoginSuccessNotification::class
        ],
        RegistrationCreatedEvent::class => [
            RegistrationCreatedAdminNotification::class,
            RegistrationCreatedCustomerNotification::class,
        ],
        RegistrationAcceptedEvent::class => [
            RegistrationAcceptedCustomerNotification::class,
        ],
        RegistrationDeclineEvent::class => [
            RegistrationDeclinedCustomerNotification::class
        ],
        UserActivatedEvent::class => [
            UserActivatedNotification::class
        ],
        UserCreatedEvent::class => [
            UserCreatedNotification::class
        ],
        UserDeactivatedEvent::class => [
            UserDeactivatedNotification::class
        ],
        UserResetEvent::class => [
            UserResetNotification::class
        ],
        UserUpdatedEvent::class => [
            UserUpdatedNotification::class
        ],
        PasswordUpdatedEvent::class =>  [
            UserPasswordNotification::class
        ],
    ];

    /**
     * Register any events for your application.
     *
     * @return void
     */
    public function boot()
    {
        parent::boot();

        //
    }
}
