<?php

namespace App;

use App\Core\DefaultModel;
use Carbon\Carbon;

/**
 * @property Carbon end
 * @property Carbon start
 * @property array statement
 * @property Carbon created_at
 * @property Transaction transaction
 */
class StatementEnquiry extends DefaultModel
{
    protected $auditExclude = [
        'statement'
    ];

    protected $casts = [
        'statement' => 'array'
    ];

    protected $dates = [
         'start' , 'end'
    ];

    public function transaction()
    {
        return $this->morphOne(Transaction::class , 'transaction');
    }
}
