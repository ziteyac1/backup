<?php

namespace App;

use App\Core\DefaultModel;
use Illuminate\Database\Eloquent\Model;

class TobaccoRTGSPayment extends DefaultModel
{
    public function transaction()
    {
        return $this->morphOne(Transaction::class , 'transaction');
    }
}
