<?php

namespace App;

use App\Core\DefaultModel;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * @property mixed authorisation_type
 * @property Carbon updated_at
 * @property array users
 * @property mixed number
 * @property Carbon completed
 */
class Authorisation extends DefaultModel
{
    protected $appends = ['type' , 'read_updated'];

    protected $with = ['authorisation'];

    protected $casts = [
        'created_at' => 'datetime:Y-m-d H:i:s',
        'users' => 'array'
    ];

    public function getReadUpdatedAttribute()
    {
        return $this->updated_at->diffForHumans();
    }

    public function getTypeAttribute()
    {
        $helper = [
            Transaction::class => 'transaction',
            Batch::class => 'batch',
        ];

        return $helper[$this->authorisation_type];
    }

    public function authorisation()
    {
        return  $this->morphTo('authorisation');
    }
}
