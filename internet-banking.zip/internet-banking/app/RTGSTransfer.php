<?php

namespace App;

use App\Core\DefaultModel;
use Illuminate\Database\Eloquent\Model;

/**
 * @property mixed amount
 * @property Bank bank
 * @property mixed reason
 * @property mixed receive
 * @property mixed name
 * @property mixed receive_bank_id
 * @property mixed account_id
 */
class RTGSTransfer extends DefaultModel
{
    protected $with = ['bank'];

    public function bank()
    {
        return $this->hasOne(Bank::class , 'id' , 'receive_bank_id');
    }


    public function transaction()
    {
        return $this->morphOne(Transaction::class , 'transaction');
    }
}
