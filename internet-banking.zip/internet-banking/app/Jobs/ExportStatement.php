<?php

namespace App\Jobs;

use App\Services\StatementService;
use App\StatementEnquiry;
use App\Transaction;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Ramsey\Uuid\Uuid;
use Barryvdh\Snappy\Facades\SnappyPdf as PDF;

class ExportStatement implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $statement;


    /**
     * Create a new job instance.
     *
     * @param $statement
     */
    public function __construct($statement)
    {
        $this->statement = $statement;
    }

    /**
     * Execute the job.
     *
     * @param StatementService $service
     * @return void
     */
    public function handle(StatementService $service)
    {
        /** @var StatementEnquiry $statement */
        $statement = $this->statement;
        $transaction = $statement->transaction;
        $summary = $service->summary($statement, $transaction);

        // CSV

        $name = '/storage/statements/' . $transaction->account->account . '-' . $transaction->id .'-'. Uuid::uuid1() . '.csv';
        $write = fopen(public_path($name), 'w+');

        fwrite($write, 'Value Date , Booking Date , Reference , Description , Location , Debit , Credit , Balance'.PHP_EOL);

        foreach ($summary['transactions'] as $item){
            fwrite($write, "'{$item['valueDate']}','{$item['bookingDate']}','{$item['ft']}','{$item['reference']}','{$item['location']}','{$item['debit']}','{$item['credit']}','{$item['balance']}'" . PHP_EOL);
        }

        fclose($write);

        $statement->update([
            'csv' => $name
        ]);

        $name = '/storage/statements/' . $transaction->account->account . '-'. $transaction->id .'-'. Uuid::uuid1() . '.pdf';

        // PDF

        $statement->update([
            'pdf' => $name
        ]);

        $pdf = PDF::loadView('exports.statement', [
            'statement' => $summary
            ])->setOption('margin-bottom', 15)->setOption('margin-left', 10)
            ->setOption('margin-right', 10)
            ->setOption('margin-top', 15)->save(public_path($name));

    }

    public function tags()
    {
        return ['export'];
    }
}
