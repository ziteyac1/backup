<?php

namespace App\Jobs;

use App\Batch;
use App\Core\HasTransactionServiceFunctions;
use App\Transaction;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Container\BindingResolutionException;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class ProcessBatchTransaction implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels , HasTransactionServiceFunctions;

    private $transaction;
    /**
     * Create a new job instance.
     *
     * @param $transaction
     */
    public function __construct($transaction)
    {
        $this->transaction = $transaction;
    }

    /**
     * Execute the job.
     *
     * @return void
     * @throws BindingResolutionException
     */
    public function handle()
    {
        $transaction = $this->transaction;
        /** @var Transaction $transaction */

//        $transaction->update([
//            'state' => 97
//        ]);
//
//        $transaction = $this->instantiateService($transaction)->complete($transaction);
//
//        // Update Batch information
//        $batch = $transaction->batch;
//
//        if ($batch)
//        {
//            if ($batch->retry()->count() > 0 )
//            {
//                $batch->update([
//                    'status' => 5
//                ]);
//            }
//
//            if ($batch->proceed()->count() === $batch->upload_success )
//            {
//                $batch->update([
//                    'status' => 99
//                ]);
//
//                ExportBatchReport::dispatch($batch);
//
//            }
//        }

    }

    public function tags()
    {
        return ['transaction'];
    }
}
