<?php

namespace App\Jobs;

use App\Authorisation;
use App\Bank;
use App\Batch;
use App\Core\HasTransactionServiceFunctions;
use App\InternalTransfer;
use App\RTGSTransfer;
use App\TobaccoInternalPayment;
use App\TobaccoRTGSPayment;
use App\Transaction;
use App\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Validator;
use Ramsey\Uuid\Uuid;
use SebastianBergmann\CodeCoverage\Report\PHP;

class ImportTobaccoPaymentsBatch implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels , HasTransactionServiceFunctions;

    /**
     * @var Batch $batch
     */
    private $batch;
    /**
     * @var User $user
     */
    private $user;
    /**
     * @var int $type
     */
    private $type;

    /**
     * Create a new job instance.
     *
     * @param Batch $batch
     * @param User $user
     * @param int $type
     */
    public function __construct($batch , $user , $type)
    {
        $this->batch = $batch;
        $this->user = $user;
        $this->type = $type;
    }

    /**
     * Execute the job.
     *
     * @return array
     */

    private function retrieveBankCodes()
    {
        $banks = Bank::all();
        $ids = [];
        $codes = [];
        $host = null;

        foreach ($banks as $bank)
        {
            $codes[] = $bank->code;
            $ids[$bank->code] = $bank->id;
            if ($bank->host)
            {
                $host = $bank->code;
            }
        }

        return [ $ids , $codes , $host ];
    }

    public function validation($codes)
    {
        return [
            0 => [
                'column' => 'bank_code',
                'rules' => ['required', 'in:' . implode(',' , $codes)],
            ],
            1 => [
                'column' => 'account',
                'rules' => ['required' , 'numeric']
            ],
            2 => [
                'column' => 'name',
                'rules' => ['required']
            ],
            3 => [
                'column' => 'reason',
                'rules' => ['required']
            ],
            4 => [
                'column' => 'amount',
                'rules' => ['required' , 'numeric' , 'min:10' , 'max:500000']
            ],
        ];
    }

    public function handle()
    {
        // Get All Bank Codes

        [$ids , $codes , $host ] = $this->retrieveBankCodes();
        $batch = $this->batch;

        $batch->update([
           'status' => 2
        ]);

        $successCount = 0;
        $errorCount = 0;
        $failure = false;

        $validation = $this->validation($codes);
        $correctionsPath = '/storage/corrections/'. $batch->account->account . now()->format('Y-m-d').'-'. Uuid::uuid1() . '.csv';
        $corrections = fopen(public_path($correctionsPath) , 'w+');
        $file = file(public_path($batch->file) , FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);


        $account = $batch->account;
        $type = $account->types()->where('type_id' , $this->type)->exists() ? $this->type : 1;



        foreach ($file as $key => $line )
        {
            $write = trim($line);

            if ($key == 0 )
            {
                continue;
            }

            $data = explode(',' , $line);

            $rules = [];
            $columns = [];

            foreach ($data as $k => $item)
            {
                if (isset($validation[$k]))
                {
                    $columns[$validation[$k]['column']] = trim($item);
                }
            }

            foreach ($validation as $k => $valid)
            {
                $rules[$validation[$k]['column']] = $validation[$k]['rules'];
            }

            $validator = Validator::make($columns , $rules);

            if ($validator->fails())
            {
                $failure = true;
                $errors =  $validator->errors()->toArray();
                $errors = implode(' and ' , collect($errors)->map(function ($value){
                    return $value[0];
                })->toArray());
                $write .= ',Error = ' . str_replace("." , "" , $errors);
                $errorCount++;

            } else {

                $write .= ' , Correct';
                $successCount++;

                [$code , $account , $name , $reason , $amount ] = explode(',' , $line);

                $code = trim($code);
                $account = trim($account);
                $reason = trim($reason);
                $name = trim($name);
                $amount = trim($amount);

                /** @var TobaccoInternalPayment|TobaccoRTGSPayment $route */
                $route = $this->routeTransaction($code, $host, $batch, $account, $amount, $reason, $name, $ids);

                /** @var Transaction $transaction */
                $transaction = $route->transaction()->create([
                    'account_id' => $batch->account_id,
                    'state' => 4 ,
                    'user_id' => $batch->user_id,
                    'batch_id' => $batch->id,
                    'amount' => $amount,
                    'type_id' => $type
                ]);

                [ $code , $path ] = $this->generateTransactionQr($transaction);

                $transaction->update([
                    'qr' => $path,
                    'code'=> $code
                ]);

            }

            $write = $write.PHP_EOL;
            fwrite($corrections , $write);
        }

        fclose($corrections);

        $batch->update([
            'upload_success' => $successCount,
            'upload_error' => $errorCount,
            'corrections' => $correctionsPath,
            'errors' => $failure,
            'imported' => now()
        ]);

        if ($this->user->is_corporate)
        {
            $batch->authorisation()->create([
                'corporate_id' => $this->user->corporate_id
            ]);

            $batch->update([
                'status' =>  3
            ]);

        } else {

            $batch->update([
                'status' =>  4
            ]);
        }

        if ($batch->transactions()->count() === 0 )
        {
            // Abort Batch

            $batch->update([
               'status' => 94
            ]);

        }
    }

    /**
     * @param string $code
     * @param $host
     * @param Batch $batch
     * @param string $account
     * @param string $amount
     * @param string $reason
     * @param string $name
     * @param $ids
     * @return mixed
     */

    public function routeTransaction(string $code, $host, Batch $batch, string $account, string $amount, string $reason, string $name, $ids)
    {
        $route = null;

        // check if is internal transfer
        if ($code === $host) {
            /** @var TobaccoInternalPayment $route */
            $route = TobaccoInternalPayment::query()->create([
                'account_id' => $batch->account_id,
                'receive' => $account,
                'amount' => $amount,
                'reference' => $reason,
            ]);

        } else {

            /** @var TobaccoRTGSPayment $route */
            $route = TobaccoRTGSPayment::query()->create([
                'account_id' => $batch->account_id,
                'receive' => $account,
                'amount' => $amount,
                'name' => $name,
                'reason' => $reason,
                'receive_bank_id' => $ids[$code],
            ]);
        }

        return $route;
    }

    public function tags()
    {
        return ['batch'];
    }

}
