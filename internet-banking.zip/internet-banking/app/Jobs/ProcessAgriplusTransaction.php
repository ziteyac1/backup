<?php

namespace App\Jobs;

use App\AgriplusManualTransaction;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Http;

class ProcessAgriplusTransaction implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    public $line;


    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($line)
    {
        //
        $this->line = $line;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $line = $this->line;
        $line = trim($line);
        $data = explode(",", $line);
        $pan = $data[0];
        $amount = $data[1];

        $transaction = AgriplusManualTransaction::query()->create([
            'amount' => $amount,
            'pan' => $pan
        ]);

        $amount = bcmul($amount ,  100 );

        $send = [
            'id' => '1',
            'amount' => $amount,
            'pan' => $pan,
            'application' => 'manual-agiplus'
        ];



        print_r($send);

        $result = Http::post('192.168.0.27:3321/transfer/agriplus', $send);
        $result = $result->json();

        print_r($result);

        $transaction->update([
            'tran_nr' => $result['body']['result']['tranNr'],
            'adapter' => $result['body']['reference'],
            'rsp' => $result['success'],
            'post' => $result['body']['result']['success'],
        ]);

    }
}
