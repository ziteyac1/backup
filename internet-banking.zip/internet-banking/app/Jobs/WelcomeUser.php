<?php

namespace App\Jobs;

use App\Mail\WelcomeMail;
use App\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;

class WelcomeUser implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * @var User $model
     */
    private $model;
    private $password;

    /**
     * Create a new job instance.
     *
     * @param $model
     * @param $password
     */
    public function __construct($model , $password)
    {
        $this->model = $model;
        $this->password = $password;
    }

    /**
     * Execute the job.
     *
     * @return void
     */

    public function handle()
    {
        Mail::to($this->model->email)->send(new WelcomeMail($this->model->email , $this->model->full_name , $this->password));
    }

    public function tags()
    {
        return ['notification'];
    }
}
