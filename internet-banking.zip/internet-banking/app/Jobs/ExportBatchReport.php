<?php

namespace App\Jobs;

use App\Batch;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Ramsey\Uuid\Uuid;
use Barryvdh\Snappy\Facades\SnappyPdf as PDF;

class ExportBatchReport implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * @var Batch $batch
     */

    private $batch;

    /**
     * Create a new job instance.
     *
     * @param $batch
     */
    public function __construct($batch)
    {
        $this->batch = $batch;
    }

    /**E
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $batch = $this->batch;
        $name = '/storage/batch/' . $batch->account->account . '-'. $batch->id .'-'. Uuid::uuid1() . '.pdf';

        $batch->update([
           'pdf' => $name
        ]);

        $pdf = PDF::loadView('exports.batch', [
            'batch' => $batch
        ])->setOption('margin-bottom', 15)->setOption('margin-left', 10)
            ->setOption('margin-right', 10)
            ->setOption('margin-top', 15)->save(public_path($name));

    }

    public function tags()
    {
        return ['export'];
    }
}
