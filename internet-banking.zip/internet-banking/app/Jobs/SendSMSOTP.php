<?php

namespace App\Jobs;

use GuzzleHttp\Client;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SendSMSOTP implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $phone;
    private $otp;

    /**
     * Create a new job instance.
     *
     * @param $phone
     * @param $otp
     */

    public function __construct($phone , $otp)
    {
        $this->phone = $phone;
        $this->otp = $otp;
    }

    /**
     * Execute the job.
     *
     * @return void
     */

    public function handle()
    {
        $message = "Dear customer, Your Internet Banking login OTP is {$this->otp} OTP will expire in 20 minutes. For security reasons, please do not share the OTP with anyone.";
        if (config('mail.driver') !== "log")
        {
            $link = "https://secure.zss.co.zw/vportal/cnm/vsms/plain?user=Agribank012&password=agri13&sender=Agribank&SMSText={$message}&GSM={$this->phone}";
            $client = new Client();
            $result  = $client->request('GET', $link);
            $result->getBody();
        } else {
            Log::info("SMS : " . $message );
        }
    }

    public function tags()
    {
        return ['notification'];
    }
}
