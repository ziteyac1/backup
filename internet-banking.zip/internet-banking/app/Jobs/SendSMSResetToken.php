<?php

namespace App\Jobs;

use GuzzleHttp\Client;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendSMSResetToken implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $phone;
    private $otp;

    /**
     * Create a new job instance.
     *
     * @param $phone
     * @param $otp
     */

    public function __construct($phone , $otp)
    {
        $this->phone = $phone;
        $this->otp = $otp;
    }

    /**
     * Execute the job.
     *
     * @return void
     */

    public function handle()
    {
        $message = "Dear customer, Your Internet Banking Reset Token is {$this->otp} Token will expire in 60 minutes";
        $link = "https://secure.zss.co.zw/vportal/cnm/vsms/plain?user=Agribank012&password=agri13&sender=Agribank&SMSText={$message}&GSM={$this->phone}";
        $client = new Client();
        $result  = $client->request('GET', $link);
        $result->getBody();
    }

    public function tags()
    {
        return ['notification'];
    }
}
