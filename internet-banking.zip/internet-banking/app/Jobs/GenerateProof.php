<?php

namespace App\Jobs;

use App\Core\HasTransactionServiceFunctions;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Container\BindingResolutionException;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class GenerateProof implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels , HasTransactionServiceFunctions;

    private $transaction;


    /**
     * Create a new job instance.
     *
     * @param $transaction
     */
    public function __construct($transaction)
    {
        $this->transaction = $transaction;
    }

    /**
     * Execute the job.
     *
     * @return void
     * @throws BindingResolutionException
     */
    public function handle()
    {
        $transaction = $this->transaction;
        $this->instantiateService($transaction)->generate($transaction);
    }

    public function tags()
    {
        return ['export'];
    }
}
