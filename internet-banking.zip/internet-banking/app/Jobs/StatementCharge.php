<?php

namespace App\Jobs;

use App\Transaction;
use Exception;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Http;

class StatementCharge implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * @var Transaction $transaction
     */
    private $transaction;

    /**
     * Create a new job instance.
     *
     * @param $transaction
     */
    public function __construct($transaction)
    {
        $this->transaction = $transaction;
    }

    /**
     * Execute the job.
     *
     * @return void
     * @throws Exception
     */
    public function handle()
    {
        // todo : update transaction amount after charging

//        $result = Http::post(config('system.R18-Adapter-host') . '/transaction/statement/charge', [
//            'id' => $this->transaction->id,
//            'charge' => 3.10,
//            'application' => config('system.adapter-name')
//        ]);
//
//        $result = $result->json();
//
//        if (!$result['success'])
//        {
//            throw new Exception("Statement Charge Failed");
//        }

        // implement charge

    }

    public function tags()
    {
        return ['transaction'];
    }

}
