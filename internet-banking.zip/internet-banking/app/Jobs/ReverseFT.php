<?php

namespace App\Jobs;

use Exception;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Http;

class ReverseFT implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $ft;
    private $id;

    /**
     * Create a new job instance.
     *
     * @param $id
     * @param $ft
     */
    public function __construct($id , $ft)
    {
        $this->ft = $ft;
        $this->id = $id;
    }

    /**
     * Execute the job.
     *
     * @return void
     * @throws Exception
     */
    public function handle()
    {
       $result = Http::post(config('system.R18-Adapter-host') . '/transaction/reverse', [
            'id' => $this->id,
            'ft' => $this->ft,
           'application' => config('system.adapter-name')
        ]);

       $result = $result->json();

       if (!$result['success'])
       {
            throw new Exception("FT Reversal Failed");
       }

    }

    public function tags()
    {
        return ['transaction'];
    }

}
