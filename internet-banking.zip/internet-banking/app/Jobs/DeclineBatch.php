<?php

namespace App\Jobs;

use App\Batch;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class DeclineBatch implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $batch;

    /**
     * Create a new job instance.
     *
     * @param Batch $model
     */

    public function __construct(Batch $model)
    {
        $this->batch = $model;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $this->batch->transactions()->update([
            'state' => 95
        ]);
    }

    public function tags()
    {
        return ['batch'];
    }
}
