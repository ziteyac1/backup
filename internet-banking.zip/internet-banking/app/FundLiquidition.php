<?php

namespace App;

use App\Core\DefaultModel;
use Illuminate\Database\Eloquent\Model;

class FundLiquidition extends DefaultModel
{
    /**
     * @property mixed receive
     * @property mixed amount
     * @property mixed reference
     * @property mixed name
     */
    public function transaction()
    {
        return $this->morphOne(Transaction::class , 'transaction');
    }

    public function account()
    {
        return $this->belongsTo(Account::class,'receive','account');
    }

}
