<?php

namespace App;

use App\Core\DefaultModel;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * @property mixed file
 * @property mixed account_id
 * @property Authorisation authorisation
 * @property mixed id
 * @property mixed user_id
 * @property mixed processed
 * @property mixed upload_success
 * @property mixed failed
 * @property Carbon updated_at
 * @property mixed corrections
 * @property Account account
 * @property mixed pdf
 * @property mixed status
 */
class Batch extends DefaultModel
{
    protected $with = ['state'];

    protected $casts = [
        'created_at' => 'datetime:Y-m-d H:i:s',
    ];

    protected $appends = ['read_updated'];

    public function getTotalAttribute()
    {
        return '$ ' . number_format( floatval($this->transactions()->sum('amount')));
    }

    public function getTotalDebitedAttribute()
    {
        return '$ ' . number_format( floatval($this->debited()->sum('amount')));
    }

    public function getReadUpdatedAttribute()
    {
        return $this->updated_at->diffForHumans();
    }

    public function user()
    {
        return $this->hasOne(User::class , 'id' , 'user_id');
    }

    public function state()
    {
        return $this->hasOne(BatchState::class , 'id' , 'status');
    }

    public function account()
    {
        return $this->hasOne(Account::class , 'id' , 'account_id');
    }

    public function transactions()
    {
        return $this->hasMany(
            Transaction::class ,
            'batch_id',
            'id'
        );
    }

    protected $withCount = ['proceed' , 'pending' , 'failed' , 'retry'];

    public function proceed()
    {
        return $this->hasMany(
            Transaction::class ,
            'batch_id',
            'id'
        )->whereIn('state' , [99 ,98 ,96 ,95]);
    }

    public function debited()
    {
        return $this->hasMany(
            Transaction::class ,
            'batch_id',
            'id'
        )->whereIn('state' , [99]);
    }

    public function pending()
    {
        return $this->hasMany(
            Transaction::class ,
            'batch_id',
            'id'
        )->whereIn('state' , [ 1 , 2 , 3 , 4 ,  97 ]);
    }

    public function retry()
    {
        return $this->hasMany(
            Transaction::class ,
            'batch_id',
            'id'
        )->whereIn('state' , [3]);
    }

    public function failed()
    {
        return $this->hasMany(
            Transaction::class ,
            'batch_id',
            'id'
        )->whereIn('state' , [ 96 , 95 ]);
    }

    public function authorisation()
    {
        return  $this->morphOne(Authorisation::class , 'authorisation');
    }
}
