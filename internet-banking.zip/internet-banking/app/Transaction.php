<?php

namespace App;

use App\Core\DefaultModel;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * @property mixed data
 * @property mixed id
 * @property mixed transaction_type
 * @property InternalTransfer|RTGSTransfer|FundLiquidition parent
 * @property mixed state
 * @property Carbon updated_at
 * @property Account account
 * @property InternalTransfer|RTGSTransfer|FundLiquidition transaction
 * @property mixed qr
 * @property mixed error
 * @property mixed retry
 * @property Authorisation authorisation
 * @property mixed retry_count
 * @property mixed pdf
 * @property Batch batch
 * @property mixed account_id
 * @property mixed reference
 * @property mixed code
 * @property mixed amount
 */
class Transaction extends DefaultModel
{

    protected $with = ['status' , 'type_n'];

    protected $appends = ['type' , 'read_updated' , 'component'];

    protected $casts = [
        'created_at' => 'datetime:Y-m-d H:i:s',
        'adapter_reference' => 'array'
    ];

    public function getReadUpdatedAttribute()
    {
        return $this->updated_at->diffForHumans();
    }

    public function getTypeAttribute()
    {
        $helper = [
           InternalTransfer::class => 'internal-transfer',
           RTGSTransfer::class => 'rtgs-transfer',
           StatementEnquiry::class => 'statement-enq',
           FundLiquidition::class => 'nostro-liquidation',
           TobaccoInternalPayment::class => 'tobacco-internal-payment',
           TobaccoRTGSPayment::class => 'tobacco-rtgs-payment',
        ];

        return $helper[$this->transaction_type];
    }

    public function getComponentAttribute()
    {
        $helper = [
           InternalTransfer::class => 'internal',
           RTGSTransfer::class => 'rtgs',
           StatementEnquiry::class => 'statement',
           FundLiquidition::class => 'liquidate',
           TobaccoInternalPayment::class => 'tobacco',
           TobaccoRTGSPayment::class => 'tobacco-rtgs',
        ];

        return $helper[$this->transaction_type];
    }

    public function authorisation()
    {
        return  $this->morphOne(Authorisation::class , 'authorisation');
    }

    public function account()
    {
        return $this->hasOne(Account::class , 'id' , 'account_id');
    }

    public function status()
    {
        return $this->hasOne(TransactionState::class , 'id' , 'state');
    }

    public function type()
    {
        return $this->hasOne(TransactionType::class,'id','type_id');
    }

    public function transaction()
    {
        return $this->morphTo('transaction');
    }

    public function batch()
    {
        return $this->hasOne(
            Batch::class ,
            'id',
            'batch_id'
        );
    }


    public function type_n()
    {
        return $this->hasOne(
            TransactionType::class ,
            'id',
            'type_id'
        );
    }

}
