<?php

namespace App;

use App\Core\DefaultModel;
use Illuminate\Database\Eloquent\Model;

/**
 * @property mixed receive
 * @property mixed amount
 * @property mixed reference
 * @property mixed name
 */
class InternalTransfer extends DefaultModel
{
    public function transaction()
    {
        return $this->morphOne(Transaction::class , 'transaction');
    }

}
