<?php

namespace App;

use App\Core\DefaultModel;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Corporate
 * @package App
 * @property Carbon created_at
 * @property Carbon updated_at
 * @property mixed email
 * @property mixed name
 * @property mixed accounts
 * @property array settings
 * @property mixed working
 */
class Corporate extends DefaultModel
{
    protected $appends = ['read_updated_at' , 'read_created_at' , 'select_name'];

    protected $casts = [
        'created_at' => 'datetime:Y-m-d H:i:s',
        'updated_at' => 'datetime:Y-m-d H:i:s',
        'settings' => 'array'
    ];

    public function getSelectNameAttribute()
    {
        return $this->name . " " . $this->email;
    }

    public function getReadCreatedAtAttribute()
    {
        return $this->created_at->format('Y-m-d H:i:s');
    }

    public function getReadUpdatedAtAttribute()
    {
        return $this->updated_at->format('Y-m-d H:i:s');
    }

    public function accounts()
    {
        return $this->morphMany(Account::class , 'account');
    }


    public function working()
    {
        return $this->morphMany(Account::class , 'account')->where('status' , '=' , true);
    }
}
