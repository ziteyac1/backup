<?php

namespace App;
use App\Core\DefaultModel;

/**
 * @property mixed id
 * @property mixed name
 * @property mixed email
 * @property mixed last_name
 * @property mixed created_at
 * @property mixed updated_at
 */
class SelfRegistration extends DefaultModel
{
    protected $appends = [
        'full_name' , 'avatar_name' ,'read_updated_at' ,
        'read_created_at'
    ];

    protected $casts = [
        'postilion' => 'array',
        'core_banking' => 'array',
        'mobile_banking' => 'array',
    ];

    public function getAvatarNameAttribute()
    {
        return substr($this->name , 0 , 1 ) . '' . substr($this->last_name , 0 , 1 );
    }

    public function getFullNameAttribute()
    {
        return $this->name . ' ' . $this->last_name;
    }

    public function getReadCreatedAtAttribute()
    {
        return $this->created_at->format('Y-m-d H:i:s');
    }

    public function getReadUpdatedAtAttribute()
    {
        return $this->updated_at->format('Y-m-d H:i:s');
    }

}
