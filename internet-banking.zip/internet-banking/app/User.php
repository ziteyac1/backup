<?php

namespace App;

use App\filters\core\HasModelFilter;
use Carbon\Carbon;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use OwenIt\Auditing\Contracts\Auditable;
use phpDocumentor\Reflection\Types\Boolean;
use Spatie\Permission\Traits\HasRoles;

/**
 * @property mixed last_name
 * @property mixed name
 * @property mixed full_name
 * @property mixed avatar_name
 * @property mixed type
 * @property Corporate $corporate
 * @property Carbon created_at
 * @property Carbon updated_at
 * @property mixed id
 * @property mixed accounts
 * @property mixed active_accounts
 * @property mixed corporate_id
 * @property mixed is_admin
 * @property mixed is_corporate
 * @property mixed is_individual
 * @property mixed working
 * @property mixed password
 * @property mixed email
 * @property mixed phone
 * @property mixed otp
 * @property Carbon otp_expiry
 * @property Carbon password_reset_expiry
 * @property mixed password_reset_token
 * @property Carbon password_reset_token_expiry
 * @property Boolean status
 * @property mixed passwords
 * @property mixed is_root
 */
class User extends Authenticatable implements Auditable
{
    use Notifiable , HasModelFilter , HasRoles , \OwenIt\Auditing\Auditable;

    protected $appends = [
        'full_name' , 'avatar_name' , 'read_updated_at' ,
        'read_created_at' , 'is_admin' , 'is_corporate' , 'is_individual'
    ];

    protected $dates = ['otp_expiry'];

    public function getIsAdminAttribute()
    {
        return $this->type === 'admin';
    }

//    public function getWorkingAttribute()
//    {
//        if ($this->is_corporate)
//        {
//            return $this->corporate->working;
//        }
//
//        return $this->active_accounts;
//    }

    public function getIsCorporateAttribute()
    {
        return $this->type === 'corporate';
    }

    public function getIsIndividualAttribute()
    {
        return $this->type === 'individual';
    }

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    protected $fillable = [
        'name' , 'last_name', 'email' , 'phone', 'password', 'attempts' , 'type', 'status' , 'corporate_id' , 'password_reset_token_expiry' ,
        'otp' , 'password_expiry'  , 'otp_expiry' , 'ip' , 'last_login' , 'password_reset' ,'password_reset_token' , 'is_root'
    ];

    public function getAvatarNameAttribute()
    {
        return substr($this->name , 0 , 1 ) . '' . substr($this->last_name , 0 , 1 );
    }

    public function getFullNameAttribute()
    {
        return $this->name . ' ' . $this->last_name;
    }

    public function getReadCreatedAtAttribute()
    {
        return $this->created_at->format('Y-m-d H:i:s');
    }

    public function getReadUpdatedAtAttribute()
    {
        return $this->updated_at->format('Y-m-d H:i:s');
    }

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token', 'otp' , 'email_verified_at' , 'attempts', 'password_reset_token' , 'password_reset_token_expiry',
        'ip', 'last_login' , 'otp' , 'password_expiry' , 'otp_expiry' , 'password_reset'
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function corporate()
    {
        return $this->hasOne(Corporate::class , 'id' , 'corporate_id');
    }

    public function accounts()
    {
        return $this->morphMany(Account::class , 'account');
    }


    public function active_accounts()
    {
        return $this->morphMany(Account::class , 'account')->where('status' , '=' , true);
    }

    public function working()
    {
        return $this->morphMany(Account::class , 'account')->where('status' , '=' , true);
    }

    public function passwords()
    {
        return $this->hasMany(PasswordHistory::class , 'user_id' , 'id');
    }

}
