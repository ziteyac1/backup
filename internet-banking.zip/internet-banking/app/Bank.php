<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property mixed sub
 * @property mixed code
 */
class Bank extends Model
{
    //
}
