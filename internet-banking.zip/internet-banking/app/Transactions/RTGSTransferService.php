<?php


namespace App\Transactions;


use App\RTGSTransfer;
use App\TobaccoRTGSPayment;
use App\Transaction;
use App\Transactions\Core\TransactionContract;
use App\TransactionType;
use App\User;
use Barryvdh\Snappy\Facades\SnappyPdf as PDF;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Ramsey\Uuid\Uuid;

class RTGSTransferService extends TransactionContract
{

    /**
     * @param Transaction $transaction
     * @return Transaction
     */
    public function complete($transaction)
    {

        $number = $transaction->retry_count;
        $number++;
        $transaction->update([
            'retry_count' => $number,
            'state' => 97
        ]);

        /** @var RTGSTransfer $rtgs */
        $rtgs = $transaction->transaction;

        // Throttle

//        $fields = [
//            'name',
//            'reason',
//            'amount',
//            'receive_bank_id',
//            'receive',
//            'account_id'
//        ];
//
//        $similar = RTGSTransfer::query()
//            ->whereHas('transaction' , function ($builder) use ($transaction){
//                /** @var Builder $builder */
//                $builder->whereIn('state' , [ 99 , 97]);
//                $builder->where('id' , '!=' , $transaction->id);
//            })->where('created_at' , '>=' , now()->subHours(24));
//
//        foreach ($fields as $field)
//        {
//            $similar = $similar->where($field , $rtgs->$field);
//        }
//
//        $duplicate = $similar->exists();
//
//        if ($duplicate)
//        {
//            $transaction->update([
//                'state' => 3,
//                'end' => now(),
//                'error' => 'Duplicate Transaction , Retry Later after 24 hours',
//                'retry' => true
//            ]);
//
//            return  $transaction;
//        }

        // Disable USD to RTGS

        if ($transaction->account->currency->primary !== "ZWL")
        {
            $transaction->update([
                'state' => 96,
                'end' => now(),
                'error' => 'Not Supported',
                'retry' => false,
            ]);

            return $transaction;
        }

        // Checking  Limits
        $start = now()->subSeconds(now()->secondsSinceMidnight());
        $end = now()->addSeconds(now()->secondsUntilEndOfDay());

        $sum = Transaction::query()
            ->whereIn('transaction_type' , [ TobaccoRTGSPayment::class, RTGSTransfer::class] )
            ->where('created_at' , '>=', $start)
            ->where('created_at' , '<=', $end)
            ->where('account_id' , '=', $transaction->account_id)
            ->whereIn('state' , [ 99 , 97])->sum('amount');

        $limit = $transaction->account->account_type == User::class ? 500000 : 2000000;

        if ( ( $sum + $transaction->amount ) > $limit )
        {
            $transaction->update([
                'state' => 3,
                'end' => now(),
                'error' => 'Exceeded Daily Limit of '. $limit .' , Total is ' . $sum,
                'retry' => true,
            ]);

            return $transaction;
        }

        try {

            $response = Http::post(config('system.R18-Adapter-host').'/transaction/rtgs', [
                'id' => $transaction->id,
                'application' => config('system.adapter-name'),
                'debit' => $transaction->account->account,
                'version' => 'RTGS.IB',
                'amount' => $rtgs->amount,
                'currency' => $transaction->account->currency->primary,
                'bankId' => $rtgs->bank->sub,
                'name' => $rtgs->name,
                'receive' => $rtgs->receive,
                'bankCode' => $rtgs->bank->code,
                'reason' => $rtgs->reason,
                'details' => [
                    [
                        "field" => "DEBIT.THEIR.REF",
                        "value" => Str::limit('' . $rtgs->name, 15, ''),
                    ],
                    [
                        "field" => "CREDIT.THEIR.REF",
                        "value" => Str::limit('' . $rtgs->name, 15, ''),
                    ],
                ]
            ]);

            return $this->handleTransferResponse($transaction, $response);

        } catch (\Exception $exception) {

            $transaction->update([
                'state' => 3,
                'end' => now(),
                'error' => 'Internet Banking Offline',
                'retry' => true,
                'reference' => "",
            ]);

            return  $transaction;
        }

    }

    /**
     * @param Transaction $transaction
     */
    public function generate($transaction)
    {
        $transaction->load(['account' ,'transaction' ,'batch' , 'authorisation']);

        $name = '/storage/pop/' . $transaction->account->account . '-'. $transaction->id .'-'. Uuid::uuid1() . '.pdf';

        // PDF

        $transaction->update([
            'pdf' => $name
        ]);

        $pdf = PDF::loadView('exports.rtgs', [
            'transaction' => $transaction
        ])->setOption('margin-bottom', 15)->setOption('margin-left', 10)->setOption('margin-right', 10)
            ->setOption('margin-top', 15)->save(public_path($name));

    }

}
