<?php


namespace App\Transactions;


use App\Jobs\ExportStatement;
use App\RTGSTransfer;
use App\StatementEnquiry;
use App\Transaction;
use App\Transactions\Core\TransactionContract;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Http;

class StatementEnquiryService extends TransactionContract
{

    /**
     * @param Transaction $transaction
     * @return Transaction
     */
    public function complete($transaction)
    {
        try {


            /** @var StatementEnquiry $statement */
            $statement = $transaction->transaction;
            $response = Http::post(config('system.R18-Adapter-host').'/enquiry/statement', [
                'id' => $transaction->id,
                'application' => config('system.adapter-name'),
                'account' => $transaction->account->account,
                'version' => 'STMT.ENT.BOOK',
                'parameters' => [
                    [
                        'field' => 'BOOKING.DATE',
                        'sign' => 'RG',
                        'value' => $statement->start->format('Ymd') .' ' . $statement->end->format('Ymd')
                    ],
                ]
            ]);

            $result = $response->json();

            if ($result['success'])
            {
                $statement->update([
                    'statement' => $result['body']['result']
                ]);

                $transaction->update([
                    'state' => 99,
                    'end' => now(),
                    'reference' => "STMT-" .  $result['body']['reference'],
                    'adapter_reference' => $result['body']['reference'],
                ]);

                ExportStatement::dispatch($statement);

                return $transaction;
            }

            // T24 Offline

            $transaction->update([
                'state' => 96,
                'end' => now(),
                'error' => 'Internet Banking Offline',
                'retry' => true,
                'reference' => "",
                'adapter_reference' => $result['body']['reference'],
            ]);

            return $transaction;

        } catch (\Exception $exception){

            $transaction->update([
                'state' => 3,
                'end' => now(),
                'error' => 'Internet Banking Offline',
                'retry' => true,
                'reference' => "",
            ]);

            return  $transaction;

        }

    }

    public function generate($transaction)
    {

    }
}
