<?php


namespace App\Transactions\Core;


use App\Transaction;
use Illuminate\Http\Client\Response;

abstract class TransactionContract
{
    /**
     * @param $transaction
     * @return Transaction
     */
    public abstract function complete($transaction);

    public abstract function generate($transaction);

    /**
     * @param Transaction $transaction
     * @param Response $response
     * @return mixed
     */
    public function handleTransferResponse($transaction, Response $response)
    {
        $result = $response->json();
        $adapter_reference = $transaction->adapter_reference ?? [];
        $adapter_reference[] = $result['body']['reference'];

        if ($result['success'])
        {
            if (isset($result['body']['result']))
            {
                if ($result['body']['result']['success'])
                {
                    $transaction->update([
                        'state' => 99,
                        'end' => now(),
                        'retry' => false,
                        'error' => null,
                        'reference' => $result['body']['result']['ft'],
                        'adapter_reference' => $adapter_reference,
                    ]);

                    return $transaction;
                }
            }

            $transaction->update([
                'state' => $result['body']['result']['retry'] ? 3 : 96,
                'end' => now(),
                'error' => $result['body']['result']['error'],
                'retry' => $result['body']['result']['retry'],
                'reference' => $result['body']['result']['ft'],
                'adapter_reference' => $adapter_reference,
            ]);

            return $transaction;
        }

        // T24 Offline

        $transaction->update([
            'state' => 3,
            'end' => now(),
            'error' => 'Internet Banking Offline',
            'retry' => true,
            'reference' => "",
            'adapter_reference' => $adapter_reference,
        ]);

        return $transaction;
    }
}
