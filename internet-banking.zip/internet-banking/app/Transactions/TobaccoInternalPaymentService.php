<?php /** @noinspection DuplicatedCode */


namespace App\Transactions;
use App\TobaccoInternalPayment;
use App\Jobs\ReverseFT;
use App\Jobs\UpdateAgriPayTransactionBalance;
use App\RTGSTransfer;
use App\Transaction;
use App\Transactions\Core\TransactionContract;
use App\TransactionType;
use App\User;
use Barryvdh\Snappy\Facades\SnappyPdf as PDF;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Ramsey\Uuid\Uuid;

class TobaccoInternalPaymentService extends TransactionContract
{
    /**
     * @param Transaction $transaction
     * @return Transaction
     */

    public function complete($transaction)
    {
        // throttle transaction

        // Disable other currency

        if ($transaction->account->currency->primary !== "ZWL")
        {
            $transaction->update([
                'state' => 96,
                'end' => now(),
                'error' => 'Not Supported',
                'retry' => false,
            ]);

            return $transaction;
        }

        /** @var TobaccoInternalPayment $internal */
        $internal = $transaction->transaction;

        $number = $transaction->retry_count;
        $number++;
        $transaction->update([
            'retry_count' => $number,
            'state' => 97
        ]);

        try {

            if (Str::startsWith($internal->receive, "5048759")) {

                return $this->completeAgriPlus($transaction, $internal);

            } else {

                return $this->completeAgriCash($transaction, $internal);

            }


        } catch (\Exception $exception) {

              $transaction->update([
                'state' => 3,
                'end' => now(),
                'error' => 'Internet Banking Offline',
                'retry' => true,
                'reference' => "",
            ]);

            return  $transaction;
        }

    }

    /**
     * @param Transaction $transaction
     */
    public function generate($transaction)
    {
        $transaction->load(['account' ,'transaction' ,'batch' , 'authorisation']);

        $name = '/storage/pop/' . $transaction->account->account . '-'. $transaction->id .'-'. Uuid::uuid1() . '.pdf';

        // PDF

        $transaction->update([
            'pdf' => $name
        ]);

        $pdf = PDF::loadView('exports.tobacco', [
            'transaction' => $transaction
        ])->setOption('margin-bottom', 15)->setOption('margin-left', 10)->setOption('margin-right', 10)
            ->setOption('margin-top', 15)->save(public_path($name));

    }

    /**
     * @param Transaction $transaction
     * @param TobaccoInternalPayment $internal
     * @return Transaction|mixed
     */
    public function completeAgriCash(Transaction $transaction, TobaccoInternalPayment $internal)
    {

        $data = [
            'id' => $transaction->id,
            'application' => config('system.adapter-name'),
            'debit' => $transaction->account->account,
            'credit' => $internal->receive,
            'amount' => $internal->amount,
            'currency' => $transaction->account->currency->primary,
            'reference' => 'Tobacco Payment',
            'version' => 'INT.TOB',
            'auth' => 0,
            'details' => $this->TobaccoPaymentData($transaction, $internal)
        ];

        $response = Http::post(config('system.R18-Adapter-host') . '/transaction/transfer', $data);
        return $this->handleTransferResponse($transaction, $response);
    }
    /**
     * @param Transaction $transaction
     * @param TobaccoInternalPayment $internal
     * @return Transaction|mixed
     */
    public function completeAgriPlus(Transaction $transaction, TobaccoInternalPayment $internal)
    {

        // Disable USD to Agriplus

        if ($transaction->account->currency->primary === "USD")
        {
            $transaction->update([
                'state' => 96,
                'end' => now(),
                'error' => 'Not Supported',
                'retry' => false,
            ]);

            return $transaction;
        }

        // Initiate Transaction for T24 for debiting customer

        $data = $this->getAgriplusT24LegData($transaction, $internal);

        $response = Http::post(config('system.R18-Adapter-host') . '/transaction/transfer', $data);

        // Check if transaction was successful

        $result = $response->json();
        $adapter_reference = $transaction->adapter_reference ?? [];
        $adapter_reference[] = $result['body']['reference'];

        if ($result['success'])
        {
            if (isset($result['body']['result']))
            {
                if ($result['body']['result']['success'])
                {
                     return $this->completeAgriplusPostilionLeg($internal, $transaction, $result['body'], $adapter_reference);
                }

                $transaction->update([
                    'state' => $result['body']['result']['retry'] ? 3 : 96,
                    'end' => now(),
                    'error' => $result['body']['result']['error'],
                    'retry' => $result['body']['result']['retry'],
                    'reference' => $result['body']['result']['ft'],
                    'adapter_reference' => $adapter_reference,
                ]);

                return $transaction;
            }
        }

        // T24 Offline

        $transaction->update([
            'state' => 3,
            'end' => now(),
            'error' => 'Internet Banking Offline',
            'retry' => true,
            'reference' => "",
            'adapter_reference' => $adapter_reference,
        ]);

        return  $transaction;

    }

    /**
     * @param Transaction $transaction
     * @param TobaccoInternalPayment $internal
     * @return array
     */
    public function getAgriplusT24LegData(Transaction $transaction, TobaccoInternalPayment $internal): array
    {

        return [
            'id' => $transaction->id,
            'application' => config('system.adapter-name'),
            'debit' => $transaction->account->account,
            'credit' => '101000006638', // Agripay Account
            'amount' => $internal->amount,
            'currency' => $transaction->account->currency->primary,
            'reference' => 'Tobacco Payment',
            'version' => 'INT.TOB',
            'auth' => 0,
            'details' => $this->TobaccoPaymentData($transaction, $internal)
        ];
    }

    /**
     * @param TobaccoInternalPayment $internal
     * @param Transaction $transaction
     * @param $body
     * @param array $adapter_reference
     */

    public function completeAgriplusPostilionLeg(TobaccoInternalPayment $internal, Transaction $transaction, $body, array $adapter_reference)
    {

        // Initiate Agriplus Transaction  to Postilion

        $postilion = Http::post(config('system.Postilion-Adapter-host') . '/transfer/agriplus', [
            'id' => $transaction->id,
            'pan' => $internal->receive,
            'amount' => bcmul($internal->amount , 100),
            'application' => config('system.adapter-name')
        ]);


        $postilionResult = $postilion->json();

        // Check Agriplus is successful

        if ($postilionResult['success'])
        {
            if (isset($postilionResult['body']['result'])) {

                if ($postilionResult['body']['result']['success']) {

                    $transaction->update([
                        'state' => 99,
                        'end' => now(),
                        'retry' => false,
                        'error' => null,
                        'reference' => $body['result']['ft'] . ':' . $postilionResult['body']['result']['tranNr'],
                        'adapter_reference' => $adapter_reference,
                    ]);

                    return $transaction;

                } else {

                    $transaction->update([
                        'state' => $postilionResult['body']['result']['retry'] ? 3 : 96,
                        'end' => now(),
                        'error' => $postilionResult['body']['result']['error'],
                        'retry' => $postilionResult['body']['result']['retry'],
                        'reference' => "",
                        'adapter_reference' => $adapter_reference,
                    ]);

                    // Reverse Transaction at T24 using JOB

                    ReverseFT::dispatch($transaction->id, $body['result']['ft']);

                    return  $transaction;

                }
            }

        } else {

            // Reverse Transaction at T24 using JOB

            $transaction->update([
                'state' => 3,
                'end' => now(),
                'error' => 'System Error , Retry Transaction',
                'retry' => true,
                'reference' => $body['result']['ft'],
                'adapter_reference' => $adapter_reference,
            ]);

            ReverseFT::dispatch($transaction->id, $body['result']['ft']);
        }

        return $transaction;
    }

    /**
     * @param Transaction $transaction
     * @param TobaccoInternalPayment $internal
     * @return array[]
     */
    public function TobaccoPaymentData(Transaction $transaction, TobaccoInternalPayment $internal): array
    {
        return [
            [
                "field" => "PAYMENT.DETAILS:2",
                "value" => $transaction->id,
            ],
            [
                "field" => "CREDIT.CURRENCY",
                "value" => $transaction->account->currency->primary,
            ],
            [
                "field" => "DEBIT.THEIR.REF",
                "value" => Str::limit('' . $internal->reference . ' ' . $internal->name, 15, ''),
            ],
            [
                "field" => "DebitNarr::",
                "value" => Str::limit('' . $internal->reference . ' ' . $internal->name, 15, ''),
            ],
            [
                "field" => "CREDIT.THEIR.REF",
                "value" => Str::limit('' . $internal->reference, 15, ''),
            ],
            [
                "field" => "CreditNarr::",
                "value" => Str::limit('' . $internal->reference, 15, ''),
            ],
        ];
    }
}
