<?php /** @noinspection DuplicatedCode */


namespace App\Transactions;
use App\FundLiquidition;
use App\Transaction;
use App\Transactions\Core\TransactionContract;
use Barryvdh\Snappy\Facades\SnappyPdf as PDF;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Ramsey\Uuid\Uuid;

class FundsLiquidationService extends TransactionContract
{
    /**
     * @param Transaction $transaction
     * @return Transaction
     */

    public function complete($transaction)
    {
        // throttle transaction

        // Disable other currency
        if ($transaction->account->currency->primary !== "USD")
        {
            $transaction->update([
                'state' => 96,
                'end' => now(),
                'error' => 'Not Supported',
                'retry' => false,
            ]);

            return $transaction;
        }

        /** @var FundLiquidition $internal */
        $internal = $transaction->transaction;
        if ($internal->account->currency->primary === "USD")
        {
            $transaction->update([
                'state' => 96,
                'end' => now(),
                'error' => 'USD to USD liquidation not supported',
                'retry' => false,
            ]);
            return $transaction;
        }

        $number = $transaction->retry_count;
        $number++;
        $transaction->update([
            'retry_count' => $number,
            'state' => 97
        ]);

        try {

            return $this->completeAgriCash($transaction, $internal);

        } catch (\Exception $exception) {

              $transaction->update([
                'state' => 3,
                'end' => now(),
                'error' => 'Internet Banking Offline',
                'retry' => true,
                'reference' => "",
            ]);

            return  $transaction;
        }

    }

    /**
     * @param Transaction $transaction
     */
    public function generate($transaction)
    {
        $transaction->load(['account' ,'transaction' ,'batch' , 'authorisation']);

        $name = '/storage/pop/' . $transaction->account->account . '-'. $transaction->id .'-'. Uuid::uuid1() . '.pdf';

        // PDF

        $transaction->update([
            'pdf' => $name
        ]);

        $pdf = PDF::loadView('exports.internal', [
            'transaction' => $transaction
        ])->setOption('margin-bottom', 15)->setOption('margin-left', 10)->setOption('margin-right', 10)
            ->setOption('margin-top', 15)->save(public_path($name));

    }

    /**
     * @param Transaction $transaction
     * @param FundLiquidition $internal
     * @return Transaction|mixed
     */
    public function completeAgriCash(Transaction $transaction, FundLiquidition $internal)
    {
        $data = [
            'id' => $transaction->id,
            'application' => config('system.adapter-name'),
            'debit' => $transaction->account->account,
            'credit' => $internal->receive,
            'amount' => $internal->amount,
            'currency' => $transaction->account->currency->primary,
            'reference' => 'Nostro Funds Liquidation',
            'version' => 'LIQ',
            'auth' => 0,
            'details' => $this->internalTransferData($transaction, $internal)
        ];

        $response = Http::post(config('system.R18-Adapter-host') . '/transaction/transfer', $data);

        return $this->handleTransferResponse($transaction, $response);
    }

    /**
     * @param Transaction $transaction
     * @param FundLiquidition $internal
     * @return array[]
     */
    public function internalTransferData(Transaction $transaction, FundLiquidition $internal): array
    {
        return [
            [
                "field" => "PAYMENT.DETAILS:2",
                "value" => $transaction->id,
            ],
            [
                "field" => "CREDIT.CURRENCY",
                "value" => "ZWL",
            ],
            [
                "field" => "DEBIT.THEIR.REF",
                "value" => Str::limit('' . $internal->reference . ' ' . $internal->name, 15, ''),
            ],
            [
                "field" => "DebitNarr::",
                "value" => Str::limit('' . $internal->reference . ' ' . $internal->name, 15, ''),
            ],
            [
                "field" => "CREDIT.THEIR.REF",
                "value" => Str::limit('' . $internal->reference, 15, ''),
            ],
            [
                "field" => "CreditNarr::",
                "value" => Str::limit('' . $internal->reference, 15, ''),
            ],
        ];
    }
}
