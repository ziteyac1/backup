<?php

namespace App;

use App\Core\DefaultModel;
use Carbon\Carbon;

/**
 * @property Carbon created_at
 */
class BalanceEnquiry extends DefaultModel
{
    protected $casts = [
        'updated_at' => 'datetime:Y-m-d H:i:s',
    ];

    protected $appends = ['read_created' , 'read_ago'];

    public function getReadCreatedAttribute()
    {
        return $this->created_at->format('Y-m-d H:i:s');
    }

    public function getReadAgoAttribute()
    {
        return $this->created_at->diffForHumans();
    }
}
