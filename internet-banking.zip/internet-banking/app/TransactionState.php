<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TransactionState extends Model
{
    protected $guarded = [];
}
