<?php

namespace App\Http\Controllers;

use App\Corporate;
use App\filters\CorporateFilter;
use Illuminate\Http\Request;

class CorporateController extends Controller
{
    public function index(CorporateFilter $filter)
    {
        return api()->data('corporates', Corporate::filter($filter , [

        ])->paginate(\request('size') ?? 30 ))->build();
    }

    public function create(Request $request)
    {
        $request->validate([
           'name' => ['required'],
           'email' => ['required' , 'email'],
           'phone' => ['required' , 'starts_with:263'],
           'address' => ['required'],
           'contact' => ['required'],
        ]);

        $model = Corporate::query()->create([
           'name' => $request->get('name'),
           'email' => $request->get('email'),
           'phone' => $request->get('phone'),
           'address' => $request->get('address'),
           'contact' => $request->get('contact'),
            'settings' => [
                'number_of_auth' => $request->get('auth')
            ]
        ]);

        return api()->data('model', $model)->build('Corporate was successfully created');
    }

    public function update(Request $request , Corporate $model)
    {
        $request->validate([
           'name' => ['required'],
           'email' => ['required' , 'email'],
           'phone' => ['required' , 'starts_with:263'],
           'address' => ['required'],
           'contact' => ['required'],
        ]);

        $model->update([
           'name' => $request->get('name'),
           'email' => $request->get('email'),
           'phone' => $request->get('phone'),
           'address' => $request->get('address'),
           'contact' => $request->get('contact'),
           'settings' => [
               'number_of_auth' => $request->get('auth')
           ]
        ]);

        return api()->data('model', $model)->build('Corporate was successfully updated');
    }

    public function view(Corporate $model)
    {
        $model->load('accounts');
        return api()->data('model' , $model)->build();
    }

    public function activate(Corporate $model)
    {
        $model->update([
            'status' =>  true
        ]);
        return api()->data('model' , $model)->build("Corporate was successfully activated");
    }
    public function add_tobacco(Corporate $model)
    {
        $model->update([
            'is_tobacco_client' =>  true
        ]);
        return api()->data('model' , $model)->build("Corporate was successfully added as tobacco client");
    }
    public function remove_tobacco(Corporate $model)
    {
        $model->update([
            'is_tobacco_client' =>  false
        ]);
        return api()->data('model' , $model)->build("Corporate was successfully removed as tobacco client");
    }

    public function deactivate(Corporate $model)
    {
        $model->update([
            'status' =>  false
        ]);
        return api()->data('model' , $model)->build("Corporate was successfully deactivated");
    }

    public function settings()
    {
        return api()->data('settings' , auth()->user()->corporate->settings)->build();
    }

    public function settingsUpdate(Request $request)
    {
        $request->validate([
            'number_of_auth' => ['required' , 'integer' , 'min:1']
        ]);

        /** @var Corporate $corporate */
        $corporate = auth()->user()->corporate;
        $corporate->update([
           'settings' =>  [
               'number_of_auth' => $request->get('number_of_auth')
           ]
        ]);

        return api()->build('Settings Updated');
    }
}
