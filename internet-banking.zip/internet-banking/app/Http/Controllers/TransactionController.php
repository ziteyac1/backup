<?php

namespace App\Http\Controllers;

use App\Account;
use App\Bank;
use App\Batch;
use App\filters\TransactionFilter;
use App\FundLiquidition;
use App\InternalTransfer;
use App\Jobs\GenerateProof;
use App\Jobs\ImportBatch;
use App\Jobs\ImportTobaccoPaymentsBatch;
use App\Jobs\StatementCharge;
use App\RTGSTransfer;
use App\Services\StatementService;
use App\Services\TransactionService;
use App\StatementEnquiry;
use App\TobaccoInternalPayment;
use App\TobaccoRTGSPayment;
use App\Transaction;
use App\User;
use Illuminate\Contracts\Container\BindingResolutionException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;

class TransactionController extends Controller{

    public function index(TransactionFilter $filter)
    {
        $accounts = $this->fetchAccounts()->map(function ($value) {
            return $value->id;
        })->values()->toArray();

        if (count($accounts) === 0)
        {
            $accounts = ['no-exits'];
        }

        return api()->data('transactions' , Transaction::filter($filter ,[
            'account_id' => $accounts
        ])->with(['account','batch'])->paginate(\request('size') ?? 30 ))->build();
    }

    public function view(Transaction $model)
    {

        $model->load(['account' ,'transaction' ,'batch' , 'authorisation']);
        return api()->data('transaction', $model)->build();
    }


    public function statementView(Transaction $model, StatementService $service)
    {
        $model->load(['account' ,'transaction' ,'batch' , 'authorisation']);

        /** @var StatementEnquiry $st */
        $enquiry = $model->transaction()->first();
        $statement = $service->summary($enquiry , $model);

        return api()
            ->data('statement', $statement)
            ->data('id', $model->id)
            ->build();
    }

    public function statementDownload(Transaction $model)
    {
        /** @var StatementEnquiry $st */
        $enquiry = $model->transaction()->first();
        if ($enquiry)
        {
            $type = \request('type');
            $path = public_path($enquiry->$type);
            if (File::exists($path))
            {
                return response()->download($path);
            }
        }

        return 'File Not Found';
    }

    public function accounts()
    {
        /** @var User $auth */
        $accounts = $this->fetchAccounts();
        return api()->data('accounts' , $accounts)->build();
    }

    public function upload(Request $request)
    {
        $request->validate([
            'sending_account' => [ 'required' , 'in:'. $this->getAccountsString()],
            'reference' => ['required' , 'unique_batch:'.$request->get('sending_account') ],
            'file' => ['required', 'mimes:csv,txt'],
        ]);

        /** @var Batch $batch */
        $batch = Batch::query()->create([
            'account_id' => $request->get('sending_account'),
            'file' => '/storage/' .$request->file('file')->store('batch-uploads'  ,'public'),
            'name' => $request->file('file')->getClientOriginalName(),
            'reference' => $request->get('reference'),
            'status' => 1,
            'user_id' => auth()->id()
        ]);

        /** @var User $user */
        $user =  auth()->user();

        $this->dispatch(new ImportBatch($batch , $user  , $request->get('type')));

        return api()->data('batch' , $batch)->build('Batch sent to queue for processing');

    }


    public function tobacco_upload(Request $request)
    {
        $request->validate([
            'sending_account' => [ 'required' , 'in:'. $this->getAccountsString()],
            'reference' => ['required' , 'unique_batch:'.$request->get('sending_account') ],
            'file' => ['required', 'mimes:csv,txt'],
        ]);

        /** @var Batch $batch */
        $batch = Batch::query()->create([
            'account_id' => $request->get('sending_account'),
            'file' => '/storage/' .$request->file('file')->store('batch-uploads'  ,'public'),
            'name' => $request->file('file')->getClientOriginalName(),
            'reference' => $request->get('reference'),
            'status' => 1,
            'user_id' => auth()->id()
        ]);

        /** @var User $user */
        $user =  auth()->user();

        $this->dispatch(new ImportTobaccoPaymentsBatch($batch , $user  , $request->get('type')));

        return api()->data('batch' , $batch)->build('Batch sent to queue for processing');

    }

    /**
     * @param Request $request
     * @param TransactionService $service
     * @return JsonResponse
     * @throws BindingResolutionException
     */
    public function internal(Request $request , TransactionService $service)
    {
        $request->validate([
           'sending_account' => [ 'required' , 'in:'. $this->getAccountsString()],
           'receiving_account' => ['required' , 'agribank_account' , 'confirmed'],
           'amount' => ['required', 'numeric' , 'min:10' , 'max:500000'], // Remove Hard Code
           'reference' => [ 'nullable'] ,
           'name' => [ 'nullable'] ,
        ]);



        /** @var InternalTransfer $internal */
        $internal = InternalTransfer::query()->create([
            'account_id' => $request->get('sending_account'),
            'receive' => $request->get('receiving_account'),
            'amount' => $request->get('amount'),
            'reference' => $request->get('reference'),
            'name' => $request->get('name'),
        ]);



        /** @var Transaction $transaction */
        $transaction = $internal->transaction()->create([
            'account_id' => $request->get('sending_account'),
            'user_id' => auth()->id(),
            'amount' => $request->get('amount'),
        ]);

        // check transaction type

        if ($request->get('type'))
        {
            $type = $request->get('type');
            $account = $transaction->account;

            $transaction->update([
               'type_id' => $account->types()->where('type_id' , $type)->exists() ? $type : 1
            ]);
        }


        $transaction = $service->run($transaction);

        return $this->transactionResponse($transaction);

    }

    public function tobacco_internal(Request $request , TransactionService $service)
    {
        $request->validate([
           'sending_account' => [ 'required' , 'in:'. $this->getAccountsString()],
           'receiving_account' => ['required' , 'agribank_account' , 'confirmed'],
           'amount' => ['required', 'numeric' , 'min:10' , 'max:500000'], // Remove Hard Code
           'reference' => [ 'nullable'] ,
           'name' => [ 'nullable'] ,
        ]);



        /** @var TobaccoInternalPayment $internal */
        $internal = TobaccoInternalPayment::query()->create([
            'account_id' => $request->get('sending_account'),
            'receive' => $request->get('receiving_account'),
            'amount' => $request->get('amount'),
            'reference' => $request->get('reference'),
            'name' => $request->get('name'),
        ]);



        /** @var Transaction $transaction */
        $transaction = $internal->transaction()->create([
            'account_id' => $request->get('sending_account'),
            'user_id' => auth()->id(),
            'amount' => $request->get('amount'),
        ]);

        // check transaction type

        if ($request->get('type'))
        {
            $type = $request->get('type');
            $account = $transaction->account;
            $transaction->update([
               'type_id' => $account->types()->where('type_id' , $type)->exists() ? $type : 1
            ]);
        }


        $transaction = $service->run($transaction);

        return $this->transactionResponse($transaction);

    }


    /**
     * @param Request $request
     * @param TransactionService $service
     * @return JsonResponse
     * @throws BindingResolutionException
     */
    public function fundsLiquidation(Request $request , TransactionService $service)
    {
        $request->validate([
            'sending_account' => [ 'required'],
            'receiving_account' => ['required' , 'agribank_account' , 'confirmed'],
            'amount' => ['required', 'numeric' , 'min:1' , 'max:1000'], // Remove Hard Code
            'reference' => [ 'nullable'] ,
            'name' => [ 'nullable'] ,
        ]);

        $account = Account::query()->where('account',$request->get('sending_account'))->first();

        /** @var FundLiquidition $fundLiquidation */
        $fundLiquidation = FundLiquidition::query()->create([
            'account_id' => $account->id,
            'receive' => $request->get('receiving_account'),
            'amount' => $request->get('amount'),
            'reference' => $request->get('reference'),
            'name' => $request->get('name'),
        ]);

        /** @var Transaction $transaction */
        $transaction = $fundLiquidation->transaction()->create([
            'account_id' => $account->id,
            'user_id' => auth()->id(),
            'amount' => $request->get('amount'),
        ]);


        $transaction = $service->run($transaction);


        return $this->transactionResponse($transaction);
    }

    public function buildMessage($transaction)
    {
        $states = [];
        $states[1] = 'Transaction waiting authorisation';
        $states[2] = 'Transaction is processing';
        $states[3] = 'Transaction is processing';
        $states[99] = 'Transaction was successful';
        $states[97] = 'Transaction is processing';
        $states[4] = 'Error Occurred';
        $states[96] = 'Error occurred , with your transaction , check your transaction details';
        $states[6] = 'Transaction was cancelled';

        if (isset($states[$transaction->state]))
        {
            return $states[$transaction->state];
        }

        return  "Error occurred , with your transaction , check your transaction details";

    }

    public function rtgsBanks()
    {
        $banks = Bank::query()
            ->whereNotNull('code')
            ->whereNotNull('sub')
            ->where('status' , '=' , true)
            ->where('host' , '=' , false)
            ->get();

        return api()->data('banks', $banks)->build();
    }

    /**
     * @param Request $request
     * @param TransactionService $service
     * @param StatementService $statementService
     * @return JsonResponse
     * @throws BindingResolutionException
     */
    public function statement(Request $request , TransactionService $service , StatementService $statementService)
    {
        $request->validate([
            'account' => [ 'required' , 'in:'. $this->getAccountsString()],
            'start' => ['required','date', 'date_format:Y-m-d' , 'before_or_equal:end'],
            'end' => ['required' , 'date' , 'date_format:Y-m-d' ,   'after_or_equal:start']
        ]);

        /** @var StatementEnquiry $statement */
        $statement = StatementEnquiry::query()->create([
            'start' => carbon($request->get('start')),
            'end' => carbon($request->get('end')),
            'account_id' => $request->get('account'),
            'amount' => 0
        ]);

        /** @var Transaction $transaction */
        $transaction = $statement->transaction()->create([
            'account_id' => $request->get('account'),
            'user_id' => auth()->id(),
            'amount' => 0
        ]);

        $transaction = $service->run($transaction);

        /** @var StatementEnquiry $st */
        $st = $transaction->transaction()->first();
        $statement = $statementService->summary($st , $transaction);

        if ($transaction->error === null)
        {
            $this->dispatch(new StatementCharge($transaction));
        }

        return api()
            ->success($transaction->error === null)
            ->data('statement' , $statement)
            ->data('id' , $transaction->id)
            ->build($this->buildResponse($transaction));
    }


    /**
     * @param Request $request
     * @param TransactionService $service
     * @return JsonResponse
     * @throws BindingResolutionException
     */
    public function rtgs(Request $request , TransactionService $service)
    {
        $request->validate([
            'sending_account' => [ 'required' , 'in:'. $this->getAccountsString()],
            'receiving_account' => ['required' , 'confirmed'],
            'amount' => ['required', 'numeric' , 'min:10' , 'max:500000'], // TODO : Remove Hard Code
            'bank' => ['required' , 'exists:banks,id'],
            'name' => ['required'],
            'reason' => ['required'],
        ]);

        /** @var RTGSTransfer $internal */
        $internal = RTGSTransfer::query()->create([
            'account_id' => $request->get('sending_account'),
            'receive' => $request->get('receiving_account'),
            'amount' => $request->get('amount'),
            'reason' => $request->get('reason'),
            'name' => $request->get('name'),
            'receive_bank_id' => $request->get('bank'),
        ]);

        /** @var Transaction $transaction */
        $transaction = $internal->transaction()->create([
            'account_id' => $request->get('sending_account'),
            'user_id' => auth()->id(),
            'amount' => $request->get('amount'),
        ]);

        // check transaction type

        if ($request->get('type'))
        {
            $type = $request->get('type');
            $account = $transaction->account;
            $transaction->update([
                'type' => $account->types()->where('id' , $type)->exists() ? $type : 1
            ]);
        }


        $transaction = $service->run($transaction);
        return $this->transactionResponse($transaction);
    }/**
     * @param Request $request
     * @param TransactionService $service
     * @return JsonResponse
     * @throws BindingResolutionException
     */
    public function tobacco_rtgs(Request $request , TransactionService $service)
    {
        $request->validate([
            'sending_account' => [ 'required' , 'in:'. $this->getAccountsString()],
            'receiving_account' => ['required' , 'confirmed'],
            'amount' => ['required', 'numeric' , 'min:10' , 'max:500000'], // TODO : Remove Hard Code
            'bank' => ['required' , 'exists:banks,id'],
            'name' => ['required'],
            'reason' => ['required'],
        ]);

        /** @var TobaccoRTGSPayment $rtgs */
        $rtgs = TobaccoRTGSPayment::query()->create([
            'account_id' => $request->get('sending_account'),
            'receive' => $request->get('receiving_account'),
            'amount' => $request->get('amount'),
            'reason' => $request->get('reason'),
            'name' => $request->get('name'),
            'receive_bank_id' => $request->get('bank'),
        ]);

        /** @var Transaction $transaction */
        $transaction = $rtgs->transaction()->create([
            'account_id' => $request->get('sending_account'),
            'user_id' => auth()->id(),
            'amount' => $request->get('amount'),
        ]);

        // check transaction type

        if ($request->get('type'))
        {
            $type = $request->get('type');
            $account = $transaction->account;
            $transaction->update([
                'type' => $account->types()->where('id' , $type)->exists() ? $type : 1
            ]);
        }


        $transaction = $service->run($transaction);
        return $this->transactionResponse($transaction);
    }

    /**
     * @return Collection
     */
    public function fetchAccounts()
    {
        /** @var User $auth */
        $auth = auth()->user();
        return $auth->type === 'corporate' ? $auth->corporate->working : $auth->working;
    }

    /**
     * @return string
     */
    public function getAccountsString(): string
    {
        return implode(',', $this->fetchAccounts()->map(function ($value) {
            return $value->id;
        })->values()->toArray());
    }

    /**
     * @param Transaction $transaction
     * @return mixed|string
     */
    public function buildResponse(Transaction $transaction)
    {
        if ($transaction->authorisation)
        {
            if (!$transaction->authorisation->completed)
            {
                return 'Transaction was successfully captured';
            }
        }

        if ($transaction->error === null)
        {
            return $this->buildMessage($transaction);
        }

        return $transaction->retry  ? $transaction->error . ' , Please try again later'
            :  $transaction->error;
    }

    /**
     * @param Transaction $model
     * @param TransactionService $service
     * @return JsonResponse
     * @throws BindingResolutionException
     */
    public function authorise(Transaction $model , TransactionService $service)
    {
        $model->load(['account' ,'transaction' ,'batch' , 'authorisation']);

        /** @var User $auth */
        $auth = auth()->user();
        $authorisation = $model->authorisation;
        $users = $authorisation->users;
        if (in_array($auth->id , $users ?? []))
        {
            // Already Authorised
            return api()->success(false)->data('transaction' , $model)->build('You have already authorised this transaction');
        }

        $users[] = $auth->id;
        $number = $authorisation->number + 1;
        $authorisation->update([
            'users' => $users,
            'number' => $number
        ]);

        $corporateConfig = $auth->corporate->settings['number_of_auth'];
        if ($corporateConfig <= $number)
        {
            $model->authorisation->update([
                'completed' => now()
            ]);

            // Authorise Transaction and process

            $model = $service->complete($model);
            return api()->success($model->error === null)
                         ->data('transaction' , $model)
                         ->build($this->buildResponse($model));
        }


        return api()->data('transaction' , $model)->build('Transaction was successfully authorised');
    }

    /**
     * @param Transaction $model
     * @return JsonResponse
     */
    public function decline(Transaction $model)
    {
        $model->load(['account' ,'transaction' ,'batch' , 'authorisation']);

        $model->authorisation->update([
           'completed' => now()
        ]);

        $model->update([
            'state' => 95
        ]);

        return api()->data('transaction' , $model)->build('Transaction was successfully cancelled');
    }

    /**
     * @param Transaction $model
     * @param TransactionService $service
     * @return JsonResponse
     * @throws BindingResolutionException
     */
    public function retry(Transaction $model , TransactionService $service)
    {
        $model->load(['account' ,'transaction' ,'batch' , 'authorisation']);
        $model = $service->retry($model);
        return $this->transactionResponse($model);
    }

    public function generate(Transaction $model)
    {
        $model->load(['account' ,'transaction' ,'batch' , 'authorisation']);

        $this->dispatch( new GenerateProof($model));

        return api()->data('transaction' , $model)->build('Generating Proof , Refresh After a few minutes');
    }

    public function download(Transaction $model)
    {
        return response()->download(public_path($model->pdf));
    }

    /**
     * @param Transaction $transaction
     * @return JsonResponse
     */
    public function transactionResponse(Transaction $transaction): JsonResponse
    {
        return api()
            ->success($transaction->error === null)
            ->data('transaction', $transaction)
            ->build($this->buildResponse($transaction));
    }

    public function verify(Request $request){

        /** @var Transaction $transaction */
        $transaction = Transaction::query()->where('code' , '=' , $request->get('code'))->first();

        if ($transaction)
        {
            if($transaction->transaction instanceof InternalTransfer )
            {
                $transaction->load(['account' ,'transaction' ,'batch' , 'authorisation']);
                return view('exports.extenal.internal' , [
                    'transaction' => $transaction
                ]);
            }

            if ($transaction->transaction instanceof RTGSTransfer )
            {
                $transaction->load(['account' ,'transaction' ,'batch' , 'authorisation']);
                return view('exports.extenal.rtgs' , [
                    'transaction' => $transaction
                ]);
            }

            if ($transaction->transaction instanceof StatementEnquiry)
            {
                $service = new StatementService();
                $summary = $service->summary($transaction->transaction, $transaction);

                return view('exports.extenal.statement' , [
                    'statement' => $summary
                ]);
            }
        }

        return view('errors.401');

    }

}
