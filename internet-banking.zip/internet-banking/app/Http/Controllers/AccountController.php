<?php

namespace App\Http\Controllers;

use App\Account;
use App\Corporate;
use App\filters\AccountFilter;
use App\filters\TypeFilter;
use App\TransactionType;
use App\User;
use Illuminate\Http\Request;

class AccountController extends Controller
{
    protected  $helper = [
        'corporates' => Corporate::class,
        'users' => User::class,
    ];

    public function types(TypeFilter $filter)
    {
        return api()
                ->data('types' , TransactionType::filter($filter)->paginate(\request('size') ?? 30 ))
            ->build();
    }

    public function index(AccountFilter $filter)
    {
        return api()->data('accounts' , Account::filter($filter , [

        ])->paginate(\request('size') ?? 30 ))->build();
    }

    public function create(Request $request , $id , $type)
    {
        $request->validate([
            'account' => [ 'required','unique:accounts,account'],
            'currency_id' => [ 'required' , 'exists:currencies,id' ],
        ]);

        /** @var Account $model */
        $model = Account::query()->create([
            'account' => $request->get('account'),
            'currency_id' => $request->get('currency_id'),
            'account_type' => $this->helper[$type],
            'account_id' => $id,
        ]);

        $model->types()->sync($request->get('types'));

        return api()->data('model' , $model)->build('Account was successfully created');

    }

    public function update(Request $request , Account $model)
    {
        $request->validate([
            'account' => [ 'required','unique:accounts,account,'. $model->id],
            'currency_id' => ['required','exists:currencies,id'],
        ]);

        $model->update([
            'account' => $request->get('account'),
            'currency_id' => $request->get('currency_id'),
        ]);

        $model->types()->sync($request->get('types'));

        return api()->data('model' , $model)->build('Account was successfully updated');

    }

    public function view(Account $model)
    {
        return api()->data('model' , $model)->build();
    }


    public function activate(Account $model)
    {
        $model->update([
            'status' =>  true
        ]);

        return api()->data('model' , $model)->build("Account was successfully activated");
    }

    public function deactivate(Account $model)
    {
        $model->update([
            'status' =>  false
        ]);

        return api()->data('model' , $model)->build("Account was successfully deactivated");
    }
}
