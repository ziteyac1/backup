<?php

namespace App\Http\Controllers;

use App\Account;
use App\AccountMapping;
use App\BalanceEnquiry;
use App\Services\StatementService;
use App\StatementEnquiry;
use App\Transaction;
use App\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Inspiring;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

class DashboardController extends Controller
{
    public function quote()
    {
        return Inspiring::quote();
    }

    public function dashboard()
    {
        /** @var User $user */
        $user = auth()->user();
        $user->load(['permissions' , 'accounts' , 'working']);
        $working = $user->is_corporate ? $user->corporate->working : $user->working;
        $user = $user->toArray();
        $user['working'] = $working;

        return view('home' , [
            'user' => $user
        ]);
    }

    public function transactions()
    {
        $accounts = $this->getAccounts();

        if (count($accounts) === 0) {
            $accounts = ['no-exits'];
        }

        return api()->data('transactions',
            Transaction::query()
                ->whereIn('account_id', $accounts)
                ->latest()
                ->with('account')
                ->limit(20)
                ->get()
        )->build();
    }

    public function card_transactions(Request $request)
    {
        $request->validate([
            'pan' => ['required']
        ]);

        $stats = [];
        $groups  = [];

        $pan = decrypt($request->get('pan'));
        $query = "select TOP 30 pan , retrieval_ref_nr , tran_local_datetime  , tran_amount , card_acceptor_name_location , tran_type , extended_tran_type from pc_statement_deltas WITH (NOLOCK) where pan =  '{$pan}' order by tran_local_datetime desc";

        $transactions = DB::connection('sqlsrv_post_card')
            ->select($query);
        $output = [];

        foreach ($transactions as $transaction)
        {
            $type = '';
            $aggregate = $transaction->tran_type . '-' .$transaction->extended_tran_type;

            $types = [
                '50-9900' => 'Bank to Wallet',
                '00-6400' => 'Air Time Top Up',
                '50-9027' => 'Zipit Send',
                '27-' => 'Wallet to Bank',
                '00-' => 'Pos Purchase',
                '27-9027' => 'Zipit Receive',
                '01-' => 'Withdraw',
                '40-6001' => 'Mobile Transfer',
            ];

            if (isset($types[$aggregate]))
            {
                $type = $types[$aggregate];
            }

            $output[] = [
                'pan' => $this->ccMasking($transaction->pan),
                'ref' => $transaction->retrieval_ref_nr,
                'date' => $transaction->tran_local_datetime,
                'amount' => $transaction->tran_amount / 100,
                'type' => $type,
                'location' => $transaction->card_acceptor_name_location,
            ];
        }

        return api()->data('transactions', $output)->data('stats' , $stats)->data('groups' , $groups)->build();

    }

    public function statement(StatementService $service)
    {
        $accounts = $this->getAccounts();

        if (count($accounts) === 0) {
            $accounts = ['no-exits'];
        }

        /** @var StatementEnquiry $model */
        $model = Transaction::query()
            ->where('transaction_type', StatementEnquiry::class)
            ->whereIn('account_id', $accounts)
            ->whereNull('error')
            ->latest()
            ->first();

        $statement = null;

        if ($model) {
            $model->load(['account', 'transaction', 'batch', 'authorisation']);
            /** @var StatementEnquiry $st */
            $enquiry = $model->transaction()->first();
            $statement = $service->summary($enquiry, $model);
            $statement['transactions'] = null;
        }

        return api()
            ->data('statement', $statement)
            ->build();
    }

    public function home(Account $model)
    {
        $accounts = $this->getAccounts();

        if (in_array($model->id, $accounts))
        {
            list($account, $enquiry) = $this->getBalance($model);

            // Get Cards From Postilion

            $output = [];

            if ($enquiry)
            {
                try {

                    $acc = $account->account;
                    $t = AccountMapping::query()->where('new' , $acc)->first();
                    if ($t)
                    {
                        $acc  = $t->old;
                    }

                    $cards = DB::connection('sqlsrv_post_card')
                        ->select("select TOP 2 pc_cards_1_A.pan , expiry_date , account_id  from pc_card_accounts_1_A WITH (NOLOCK) inner join pc_cards_1_A on pc_cards_1_A.pan = pc_card_accounts_1_A.pan where account_id = '{$acc}'");

                    if ($cards) {
                        foreach ($cards as $card) {
                            $output[] = [
                                'card' => $this->ccMasking($card->pan),
                                'expiry' => $this->changeExpiry($card->expiry_date),
                            ];
                        }
                    }

                } catch (\Exception $exception) {
                }

                $enquiry = $enquiry->toArray();
                $enquiry['cards'] = $output;

            }

            return api()->data('details', $enquiry)->build();

        }

        return api()
            ->data('details', null)
            ->build();

    }


    public function cards(Account $model)
    {
        $output = [];
        $accounts = $this->getAccounts();

        if (in_array($model->id, $accounts)) {
            $account = $model;
            try {

                $acc = $account->account;
                $t = AccountMapping::query()->where('new' , $acc)->first();
                if ($t)
                {
                    $acc  = $t->old;
                }

                $cards = DB::connection('sqlsrv_post_card')
                    ->select("select pc_cards_1_A.pan , expiry_date , account_id  from pc_card_accounts_1_A WITH (NOLOCK) inner join pc_cards_1_A on pc_cards_1_A.pan = pc_card_accounts_1_A.pan where account_id = '{$acc}'");

                if ($cards) {
                    foreach ($cards as $card) {
                        $output[] = [
                            'card' => $this->ccMasking($card->pan),
                            'expiry' => $this->changeExpiry($card->expiry_date),
                            'pan' => encrypt($card->pan)
                        ];
                    }
                }

            } catch (\Exception $exception) {
            }

        }

        return api()
            ->data('cards', $output)
            ->build();

    }

    public function account_details(Account $model)
    {
        $accounts = $this->getAccounts();

        if (in_array($model->id, $accounts)) {
            list($account, $enquiry) = $this->getBalance($model);
            return api()->data('details', $enquiry)->build();
        }

        return api()
            ->data('details', null)
            ->build();

    }

    public function ccMasking($number, $maskingCharacter = '*')
    {
        return substr($number, 0, 4) . str_repeat($maskingCharacter, strlen($number) - 8) . substr($number, -4);
    }

    public function changeExpiry($number)
    {
        return substr($number, 0, 2) . "/" . substr($number, 2, 2);
    }

    /**
     * @param Account $account
     * @return Builder|Model|array|null
     */
    public function runBalanceEnq(Account $account)
    {
        $enquiry = null;

        try {

            $response = Http::post(config('system.R18-Adapter-host') . '/enquiry/details', [
                'account' => $account->account,
                'application' => config('system.adapter-name')
            ]);

            $result = $response->json();

            if ($result['success'])
            {
                if ($result['body']['result']['account'] == "" || empty($result['body']['result']['account'])){
                    $enquiry = $this->runMicroFinance($account);
                } else {
                    $enquiry = $this->createBalanceRequest($result['body'], $account);
                }
            }

            return $enquiry;

        } catch (\Exception $exception) {
            return null;
        }

    }

    public function runMicroFinance($account)
    {
        $enquiry = null;

        try {

            $response = Http::post(config('system.R18-Adapter-host') . '/enquiry/details/micro', [
                'account' => $account->account,
                'application' => config('system.adapter-name')
            ]);

            $result = $response->json();

            if ($result['success'])
            {
                $enquiry = $this->createBalanceRequest($result['body'], $account);
            }

            return $enquiry;

        } catch (\Exception $exception){
            return $enquiry;
        }
    }

    /**
     * @return mixed
     */
    public function getAccounts()
    {
        /** @var User $user */
        $user = auth()->user();
        $accounts = $user->is_corporate ? $user->corporate->working : $user->working;

        $accounts = $accounts->map(function ($value) {
            return $value->id;
        })->values()->toArray();
        return $accounts;
    }

    /**
     * @param $body
     * @param $account
     * @return Builder|Model
     */
    public function createBalanceRequest($body, $account)
    {
        return BalanceEnquiry::query()->create([
            'reference' => $body['reference'],
            'balance' => '$ ' . number_format((floatval($body['result']['balance'])), 2, '.', ' '),
            'branch' => $body['result']['branch'],
            'currency' => $body['result']['currency'],
            'type' => ucwords(strtolower($body['result']['type'])),
            'name' => ucwords(strtolower($body['result']['name'])),
            'account' => $body['result']['account'],
            'account_id' => $account->id,
        ]);
    }

    /**
     * @param Account $model
     * @return array
     */
    public function getBalance(Account $model): array
    {
        $account = $model;

        /** @var BalanceEnquiry $enquiry */
        $enquiry = BalanceEnquiry::query()->where('account_id', $account->id)->latest()->first();
        if (!$enquiry)
        {
            $enquiry = $this->runBalanceEnq($account);
        } else {
            if ($enquiry->created_at->diffInMinutes(now()) >= 2 ){
                $enquiry = $this->runBalanceEnq($account) ?? $enquiry;
            }
        }

        return array($account, $enquiry);
    }
}
