<?php

namespace App\Http\Controllers;

use App\Authorisation;
use App\filters\AuthorisationFilter;
use App\User;
use Illuminate\Http\Request;

class AuthorisationController extends Controller
{
    public function index(AuthorisationFilter $filter)
    {
        /** @var User $user */
        $user = auth()->user();
        $id  = $user->corporate_id;
        return api()
            ->data('authorisations' , Authorisation::filter($filter , [
                'corporate_id' => $id
            ])->paginate(\request('size') ?? 30 ))->build();
    }
}
