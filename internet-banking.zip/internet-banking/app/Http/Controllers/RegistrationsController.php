<?php

namespace App\Http\Controllers;

use App\Events\RegistrationAcceptedEvent;
use App\Events\RegistrationDeclineEvent;
use App\Events\UserCreatedEvent;
use App\filters\RegistrationsFilter;
use App\Jobs\WelcomeUser;
use App\SelfRegistration;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class RegistrationsController extends Controller
{
    public function index(RegistrationsFilter $filter)
    {
        return api()->data('users' ,
            SelfRegistration::filter($filter)->paginate(\request('size') ?? 30 )
        )->build();
    }

    public function view(SelfRegistration $model)
    {
        return api()->data('model' , $model)->build();
    }

    public function update(Request $request , SelfRegistration $model)
    {
        $request->validate([
            'email' => ['required', 'email' ,'unique:users'],
            'name' => ['required'],
            'last_name' => ['required'],
            'currency_id' => [ 'required' , 'exists:currencies,id' ],
            'phone' => ['required' , 'starts_with:263'],
            'account' => ['required' , 'unique:accounts,account' , 'digits:12'],
            'card' => ['required' , 'digits:4'],
        ]);

        $phrase = Str::random(8);
        $password = Hash::make($phrase);

        /** @var User $user */
        $user = User::query()->create([
            'name' => $request->get('name'),
            'last_name' => $request->get('last_name'),
            'email' => $request->get('email'),
            'phone' => $request->get('phone'),
            'password' => $password,
            'password_reset' => now(),
            'status' => true,
            'type' => 'individual',
        ]);

        $model->update([
            'name' => $request->get('name'),
            'last_name' => $request->get('last_name'),
            'email' => $request->get('email'),
            'phone' => $request->get('phone'),
            'account' => $request->get('account'),
            'card' => $request->get('card'),
        ]);

        $user->accounts()->create([
            'account' => $request->get('account'),
            'currency_id' => $request->get('currency_id')
        ]);

        $model->update([
            'state' => 'completed'
        ]);

        event(new RegistrationAcceptedEvent($user));
        event(new UserCreatedEvent($user));
        $this->dispatch(new WelcomeUser($model , $phrase));

        return api()->data('model' , $user)->build("Registration Accepted");

    }

    public function decline(Request $request , SelfRegistration $model)
    {
        $request->validate([
            'reason' => ['required']
        ]);

        $model->update([
            'reason' => $request->get('reason'),
            'state' => 'declined'
        ]);

        event(new RegistrationDeclineEvent($model));

        return api()->data('model' , $model)->build("Registration declined");
    }
}
