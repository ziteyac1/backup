<?php

namespace App\Http\Controllers;

use App\Batch;
use App\filters\BatchFilter;
use App\filters\TransactionFilter;
use App\Jobs\DeclineBatch;
use App\Jobs\ExportBatchReport;
use App\Jobs\ProcessBatch;
use App\Jobs\RetryBatch;
use App\Transaction;
use App\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;

class BatchController extends Controller
{
    public function sample()
    {
        return response()->download(public_path('/sample/sample-batch.csv'), 'sample-batch.csv');
    }

    public function codes()
    {
        return response()->download(public_path('/sample/codes.csv'), 'bank-codes.csv');
    }

    /**
     * @return Collection
     */
    public function fetchAccounts()
    {
        /** @var User $auth */
        $auth = auth()->user();
        return $auth->type === 'corporate' ? $auth->corporate->working : $auth->working;
    }


    public function index(BatchFilter $filter)
    {
        $accounts = $this->fetchAccounts()->map(function ($value) {
            return $value->id;
        })->values()->toArray();

        if (count($accounts) === 0)
        {
            $accounts = ['no-exits'];
        }

        return api()->data('batches' , Batch::filter($filter , [
            'account_id' => $accounts
        ])->with(['user' , 'account'])->paginate(\request('size') ?? 30 ))->build();
    }

    public function view(Batch $model)
    {
        $model->load(['authorisation' , 'account' , 'user']);

        $result = $model->toArray();

        $result['total'] = '$ ' . number_format( floatval($model->transactions()->sum('amount')));
        $result['total_debited'] = '$ ' . number_format( floatval($model->debited()->sum('amount')));

        return api()->data('model' , $result)->build();
    }

    public function transactions(Batch $model , TransactionFilter $filter)
    {
        return api()->data('transactions' , Transaction::filter($filter ,[
            'batch_id' => $model->id
        ])->with(['account','batch'])->paginate(\request('size') ?? 30 ))->build();
    }

    public function decline(Batch $model)
    {
        $model->load(['authorisation' , 'account' , 'user']);

        $model->authorisation->update([
            'completed' => now()
        ]);

        $model->update([
            'status' => 95
        ]);

        $this->dispatch(new DeclineBatch($model));

        return api()->data('model' , $model)->build('Batch was successfully cancelled');
    }

    public function cancel(Batch $model)
    {
        $model->load(['authorisation' , 'account' , 'user']);

        if ($model->authorisation)
        {
            $model->authorisation->update([
                'completed' => now()
            ]);
        }

        $model->update([
            'status' => 95
        ]);

        $this->dispatch(new DeclineBatch($model));

        return api()->data('model' , $model)->build('Batch was successfully cancelled');
    }

    public function process(Batch $model)
    {
        $model->load(['authorisation' , 'account' , 'user']);
        $model->update([
            'status' => 97
        ]);
        $this->dispatch(new ProcessBatch($model));
        return api()->data('model' , $model)->build('Batch was sent to queue for Processing');
    }

    public function retry(Batch $model)
    {
        $model->load(['authorisation' , 'account' , 'user']);
        $model->update([
            'status' => 97,
        ]);
        $this->dispatch(new RetryBatch($model));
        return api()->data('model' , $model)->build('Batch was sent to queue for Processing');
    }

    public function authorise(Batch $model)
    {
        $model->load(['authorisation' , 'account' , 'user']);

        /** @var User $auth */
        $auth = auth()->user();
        $authorisation = $model->authorisation;
        $users = $authorisation->users;
        if (in_array($auth->id , $users ?? []))
        {
            return api()->success(false)->data('model' , $model)->build('You have already authorised this Batch');
        }

        $users[] = $auth->id;
        $number = $authorisation->number + 1;
        $authorisation->update([
            'users' => $users,
            'number' => $number
        ]);

        $corporateConfig = $auth->corporate->settings['number_of_auth'];
        if ($corporateConfig <= $number)
        {
            $model->update([
               'status' => 4
            ]);
            return api()->data('model' , $model)->build('Batch ready for processing');
        }

        return api()->data('model' , $model)->build('Batch was successfully authorised');
    }

    public function corrections(Batch $model)
    {
        $path = public_path($model->corrections);

        if (File::exists($path))
        {
            return response()->download($path);
        }

        return 'File Not Found';
    }

    public function report(Batch $model)
    {
        $path = public_path($model->pdf);

        if (File::exists($path))
        {
            return response()->download($path);
        }

        return 'File Not Found';
    }

    public function generate_report(Batch $model){

        $model->load(['authorisation' , 'account' , 'user']);
        ExportBatchReport::dispatch($model);

        $result = $model->toArray();
        $result['total'] = '$ ' . number_format( floatval($model->transactions()->sum('amount')));
        $result['total_debited'] = '$ ' . number_format( floatval($model->debited()->sum('amount')));

        return api()->data('model' , $result)->build('Generating , Kindly Refresh after few minutes');

    }

}
