<?php

namespace App\Http\Controllers;

use App\filters\PermissionsFilter;
use App\Permission;
use Illuminate\Http\Request;

class PermissionController extends Controller
{
    public function index(PermissionsFilter $filter)
    {
        return api()->data('permissions' , Permission::filter($filter , [

        ])->paginate(\request('size') ?? 30 ))->build();
    }
}
