<?php

namespace App\Http\Controllers;

use App\Events\PasswordUpdatedEvent;
use App\Events\UserActivatedEvent;
use App\Events\UserCreatedEvent;
use App\Events\UserDeactivatedEvent;
use App\Events\UserResetEvent;
use App\Events\UserUpdatedEvent;
use App\filters\UserFilter;
use App\Jobs\WelcomeUser;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class UserController extends Controller
{
    public function index(UserFilter $filter)
    {
        /** @var User $user */
        $user = auth()->user();
        return api()->data('users' ,
              User::filter($filter , [
                'corporate_id' => $user->is_admin ? null : $user->corporate_id
              ])->paginate(\request('size') ?? 30 )
            )->build();
    }

    public function create(Request $request)
    {
        $request->validate([
           'name' => ['required'],
           'last_name' => ['required'],
           'phone' => ['required' , 'starts_with:263'],
           'email' => ['required' , 'email' ,  'unique:users'],
           'password' => ['required']
        ]);

        /** @var User $auth */
        $auth = auth()->user();

        // Check if User is admin

        if ($auth->type === 'admin')
        {
            $request->validate([
                'type' => ['required'],
                'corporate_id'=> ['required_if:type,corporate' , 'nullable'  ,'exists:corporates,id']
            ]);
        }

        /** @var User $model */
        $model = User::query()->create([
           'name' => $request->get('name'),
           'last_name' => $request->get('last_name'),
           'email' => $request->get('email'),
           'phone' => $request->get('phone'),
           'password' => Hash::make($request->get('password')),
           'password_reset' => now(),
           'status' => false,
           'type' => $auth->type === 'corporate' ? 'corporate' : $request->get('type'),
           'corporate_id' => $auth->type === 'corporate' ? $auth->corporate_id : $request->get('corporate_id')
        ]);

        $model->permissions()->sync($request->get('permissions'));

        // Send Email to the user

        $this->dispatch(new WelcomeUser($model , $request->get('password')));
        event(new UserCreatedEvent($model));

        return api()->data('model', $model)->build('User was created successfully');

    }

    public function update(Request $request , User $model)
    {
        $request->validate([
           'name' => ['required'],
           'last_name' => ['required'],
           'phone' => ['required' , 'starts_with:263'],
           'email' => ['required' , 'email'  ,  'unique:users,email,'.$model->id],
        ]);

        /** @var User $auth */
        $auth = auth()->user();

        // Check if User is admin

        if ($auth->type === 'admin')
        {
            $request->validate([
                'type' => ['required'],
                'corporate_id'=> ['required_if:type,corporate' , 'nullable'  ,'exists:corporates,id']
            ]);
        }

        $corporate = $auth->type === 'corporate' ? $auth->corporate_id : $request->get('corporate_id');

        if (( $request->get('type') === 'individual' || $request->get('type') === 'admin' )  && $auth->type === 'admin')
        {
            $corporate =  null;
        }

        $model->update([
           'name' => $request->get('name'),
           'last_name' => $request->get('last_name'),
           'email' => $request->get('email'),
           'phone' => $request->get('phone'),
           'type' => $auth->type === 'corporate' ? 'corporate' : $request->get('type'),
           'corporate_id' => $corporate
        ]);

        $model->permissions()->sync($request->get('permissions'));
        event(new UserUpdatedEvent($model));
        return api()->data('model', $model)->build('User was updated successfully');

    }

    public function view(User $model)
    {
        $model->load(['corporate'  , 'permissions' , 'accounts']);
        return api()->data('model' , $model)->build();
    }

    public function activate(User $model)
    {
        $model->update([
            'status' =>  true
        ]);
        $model->load(['corporate'  , 'permissions' , 'accounts']);
        event(new UserActivatedEvent($model));
        return api()->data('model' , $model)->build("User was successfully activated");
    }

    public function password(Request $request)
    {
        $request->validate([
            'old_password' => ['required','current_password'],
            'password' => ['required', 'string', 'min:8', 'max:20' ,  'confirmed' , 'regex:/[a-z]/','regex:/[A-Z]/','regex:/[0-9]/','regex:/[@$!%*#?&]/' ,'password_history'],
        ],[
            'old_password.current_password' => 'Your old password is wrong'
        ]);

        /** @var User $user */
        $user = auth()->user();

        $user->update([
            'password_reset' => null,
            'password' => Hash::make($request->get('password'))
        ]);

        $user->passwords()->create([
            'password' => Hash::make($request->get('password'))
        ]);

        event(new PasswordUpdatedEvent($user));

        return api()->message('Password Updated')->build();

    }

    public function deactivate(User $model)
    {
        $model->update([
            'status' =>  false
        ]);
        $model->load(['corporate'  , 'permissions' , 'accounts']);

        event( new UserDeactivatedEvent($model));

        return api()->data('model' , $model)->build("User was successfully deactivated");
    }

    public function reset(User $model)
    {

        $phrase = Str::random(8);
        $password = Hash::make($phrase);

        $model->update([
            'password_reset' => now(),
            'password' => $password
        ]);

        $model->load(['corporate'  , 'permissions' , 'accounts']);

        event(new UserResetEvent($model , $phrase));

        return api()->data('model' , $model)->build("Reset was successful");
    }

    public function root(User $model)
    {
        $model->update([
            'is_root' =>  true
        ]);
        $model->load(['corporate'  , 'permissions' , 'accounts']);
        return api()->data('model' , $model)->build("User was successfully added as root");
    }

    public function remove(User $model)
    {
        $model->update([
            'is_root' =>  false
        ]);
        $model->load(['corporate'  , 'permissions' , 'accounts']);
        return api()->data('model' , $model)->build("User was successfully removed as root");
    }
}
