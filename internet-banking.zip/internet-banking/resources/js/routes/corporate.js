import loading from "../components/async/loading";
import error from "../components/async/error";

const Index =  () => ({
    component : import(/* webpackChunkName: "corporates" */"../components/corporates/index"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});
const Create =  () => ({
    component : import(/* webpackChunkName: "corporates" */"../components/corporates/create"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});
const Edit =  () => ({
    component : import(/* webpackChunkName: "corporates" */"../components/corporates/edit"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});
const View =  () => ({
    component : import(/* webpackChunkName: "corporates" */"../components/corporates/view"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});
const Open =  () => ({
    component : import(/* webpackChunkName: "corporates" */"../components/corporates/open"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

import Documents from "../components/corporates/documents";

const routes = [
    {
        path : '/corporates/create',
        component : Create
    },
    {
        path : '/corporates',
        component : Index,
    },
    {
        path : '/corporates/:id/view',
        component : Open,
        children : [
            {
                path : '/corporates/:id/view',
                component : View,
            },
            {
                path : '/corporates/:id/edit',
                component : Edit,
            },
            {
                path : '/corporates/:id/documents',
                component : Documents,
            },
        ]
    },
];


export default routes;
