import loading from "../components/async/loading";
import error from "../components/async/error";

const Index =  () => ({
    component : import(/* webpackChunkName: "users" */"../components/registrations/index"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const Edit = () => ({
    component : import(/* webpackChunkName: "users" */ "../components/registrations/edit"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const View = () => ({
    component : import(/* webpackChunkName: "users" */ "../components/registrations/view"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});
const Decline = () => ({
    component : import(/* webpackChunkName: "users" */ "../components/registrations/decline"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const Open = () => ({
    component : import(/* webpackChunkName: "users" */"../components/registrations/open"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const routes = [

    {
        path : '/registrations',
        component : Index,
    },
    {
        path : '/registrations/:id/view',
        component : Open,
        children : [
            {
                path : '/registrations/:id/view',
                component : View,
            },
            {
                path : '/registrations/:id/edit',
                component : Edit,
            },
            {
                path : '/registrations/:id/decline',
                component : Decline,
            },
        ]
    },
];

export default routes;
