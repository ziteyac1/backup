import loading from "../components/async/loading";
import error from "../components/async/error";

const Internal = () => ({
    component : import(/* webpackChunkName: "tobacco" */ "../components/tobacco/internal"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});
const RTGS = () => ({
    component : import(/* webpackChunkName: "tobacco" */ "../components/tobacco/rtgs"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});
const Batch = () => ({
    component : import(/* webpackChunkName: "tobacco" */ "../components/tobacco/tobacco_batch_upload"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const Open = () => ({
    component : import(/* webpackChunkName: "tobacco" */"../components/tobacco/open"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const routes = [
    {
        path : '/tobacco/batch',
        component : Open,
        children : [
            {
                path : '/tobacco/batch',
                component : Batch,
            },
            {
                path : '/tobacco/internal',
                component : Internal,
            },
            {
                path : '/tobacco/rtgs',
                component : RTGS,
            },
        ]
    },
]

export default routes;
