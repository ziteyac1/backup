import Internal from "../components/transactions/internal";
import Liquidation from "../components/transactions/liquidate";
import RTGS from "../components/transactions/rtgs";
import Index from "../components/transactions/index";
import Statement from "../components/statement/index";

import InternalView from "../components/transactions/view/internal";
import TobaccoInternalView from "../components/transactions/view/tobacco";
import LiquidationView from "../components/transactions/view/liquidate";
import RTGSView from "../components/transactions/view/rtgs";
import TobaccoRTGSView from "../components/transactions/view/tobacco-rtgs";
import StatementView from "../components/transactions/view/statement";
import BalanceView from "../components/transactions/view/balanace";


const routes = [
    {
        path : '/transactions/internal',
        component : Internal
    },
    {
        path : '/transactions/rtgs',
        component : RTGS
    },
    {
        path : '/statement',
        component : Statement
    },
    {
        path : '/transactions',
        component : Index
    },
    {
        path : '/transactions/internal/:id/view',
        component : InternalView
    },
    {
        path : '/transactions/tobacco/:id/view',
        component : TobaccoInternalView
    },
    {
        path : '/transactions/liquidate/:id/funds',
        component : Liquidation
    },
    {
        path : '/transactions/liquidate/:id/view',
        component : LiquidationView
    },
    {
        path : '/transactions/rtgs/:id/view',
        component : RTGSView
    },
    {
        path : '/transactions/tobacco-rtgs/:id/view',
        component : TobaccoRTGSView
    },
    {
        path : '/transactions/statement/:id/view',
        component : StatementView
    },
    {
        path : '/transactions/balance/:id/view',
        component : BalanceView
    }
];


export default routes;
