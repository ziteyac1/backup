import loading from "../components/async/loading";
import error from "../components/async/error";

const Index =  () => ({
    component : import(/* webpackChunkName: "users" */"../components/users/index"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const Create = () => ({
    component : import(/* webpackChunkName: "users" */ "../components/users/create"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const Edit = () => ({
    component : import(/* webpackChunkName: "users" */ "../components/users/edit"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const View = () => ({
    component : import(/* webpackChunkName: "users" */ "../components/users/view"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const Open = () => ({
    component : import(/* webpackChunkName: "users" */"../components/users/open"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const SettingsOpen = () => ({
    component : import(/* webpackChunkName: "settings" */ "../components/settings/open"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const Corporate = () => ({
    component : import(/* webpackChunkName: "settings" */"../components/settings/corporate"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const Password = () => ({
    component : import(/* webpackChunkName : "settings" */ "../components/settings/password"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const Profile = () => ({
    component : import(/* webpackChunkName : "settings" */ "../components/settings/profile"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const Documents =  () => ({
    component : import(/* webpackChunkName: "users" */"../components/users/documents"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

import Dashboard  from  "../components/dashboard/index";
import MyAccounts  from  "../components/dashboard/accounts";

const routes = [
    {
        path : '/',
        component : Dashboard
    },
    {
        path : '/dashboard/accounts',
        component : MyAccounts
    },
    {
        path : '/settings',
        component : SettingsOpen,
        children : [
            {
                path : '/settings',
                component : Profile,
            },
            {
                path : '/password',
                component : Password,
            },
            {
                path : '/corporate',
                component : Corporate,
            },
        ]
    },
    {
        path : '/users/create',
        component : Create
    },
    {
        path : '/users',
        component : Index,
    },
    {
        path : '/users/:id/view',
        component : Open,
        children : [
            {
                path : '/users/:id/view',
                component : View,
            },
            {
                path : '/users/:id/edit',
                component : Edit,
            },
            {
                path : '/users/:id/documents',
                component : Documents,
            },
        ]
    },
];


export default routes;
