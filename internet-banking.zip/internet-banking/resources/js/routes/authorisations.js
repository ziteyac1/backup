import Index from "../components/authorisations/index";


const routes = [
    {
        path : '/authorisations',
        component : Index
    },
];


export default routes;
