import loading from "../components/async/loading";
import error from "../components/async/error";

const Create = () => ({
    component : import(/* webpackChunkName : "accounts" */ "../components/accounts/create"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const Edit = () => ({
    component : import(/* webpackChunkName: "accounts" */ "../components/accounts/edit"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const Index = () => ({
    component : import(/* webpackChunkName: "accounts" */ "../components/accounts/index"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const Open = () => ({
    component : import(/* webpackChunkName: "accounts" */ "../components/accounts/open"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const View = () => ({
    component : import(/* webpackChunkName: "accounts" */ "../components/accounts/view"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const routes = [
    {
      path : '/accounts',
      component : Index
    },
    {
        path : '/accounts/create',
        component : Create
    },
    {
        path : '/accounts/:id/edit',
        component : Edit,
    },
    {
        path : '/accounts/:id/view',
        component : Open,
        children : [
            {
                path : '/accounts/:id/view',
                component : View,
            },
            {
                path : '/accounts/:id/update',
                component : Edit,
            },
        ]
    },
];
export default routes;
