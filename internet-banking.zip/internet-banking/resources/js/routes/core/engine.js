import VueRouter from "vue-router";
import Vue from "vue";

Vue.use(VueRouter);

let routes = [];

import transactions from "../transactions";
routes = routes.concat(transactions);

import tobacco from "../tobacco";
routes = routes.concat(tobacco);

import batch from "../batch";
routes = routes.concat(batch);

import users from "../users";
routes = routes.concat(users);

import registrations from "../registations";
routes = routes.concat(registrations);

import corporates from "../corporate";
routes = routes.concat(corporates);

import accounts from "../accounts";
routes = routes.concat(accounts);

import authorisations from "../authorisations";
routes = routes.concat(authorisations);

const router = new VueRouter({
    routes :  routes
});

router.beforeEach((to, from, next) => {
    window.scrollTo( 0 , 0 );
    next();
});

export default router;
