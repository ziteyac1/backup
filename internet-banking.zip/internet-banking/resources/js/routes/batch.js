import Batch from "../components/batch/index";
import Upload from "../components/batch/upload";
import TobaccoUpload from "../components/tobacco/tobacco_batch_upload";
import View from "../components/batch/view";
const routes = [
    {
        path : '/batch',
        component : Batch
    },
    {
        path : '/batch/upload',
        component : Upload
    },
    {
        path : '/batch/tobacco_upload',
        component : TobaccoUpload
    },
    {
        path : '/batch/:id/view',
        component : View
    }
];

export default routes;
