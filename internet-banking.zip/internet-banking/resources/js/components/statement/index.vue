<script>
    import Form from "../../core/forms/form";

    export default {
        name: "index",
        data(){
            return {
                loading : false,
                form : new Form({
                    start : new Date().toISOString().slice(0,10),
                    end : new Date().toISOString().slice(0,10),
                    account : '',
                }),
                accounts : [],
                header : true,
                id : null,
                statement : {
                    transactions : [],
                    account : {
                        currency : {}
                    }
                }
            }
        },
        mounted() {
            this.init();
        },
        methods : {
            reset(){
                this.header = true;
                this.statement = {
                    transactions : [],
                    account : {
                        currency : {}
                    }
                };
                this.init();
            },
            init()
            {
                this.loading = true;
                window.axios.get(`${window.location.origin}/transactions/accounts`).then((response) => {
                    this.accounts = response.data.body.accounts;
                    if (this.accounts.length === 0)
                    {
                        window.Swal.fire({
                            icon: 'error',
                            text: 'You don\'t have any account linked on your Account , Contact the Bank',
                            showConfirmButton: true,
                            confirmButtonColor: '#1c4b27',
                            padding: '20px',
                        }).then((e) => {});
                    }

                    if (this.accounts.length === 1)
                    {
                        let account = this.accounts[0];
                        this.form.account = account.id;
                    }

                }).finally(() => {
                    this.loading = false;
                });
            },
            request(){
                window.Swal.fire({
                    title: 'Are you sure ?',
                    text: `Request statement from ${this.form.start} to ${this.form.end}`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#1c4b27',
                    cancelButtonColor: '#d33',
                    confirmButtonText: `Yes, Request!`
                }).then((result) => {
                    if (result.value) {
                        this.form.submit('/transactions/statement').then((response) => {
                            if (response.data.success === true){
                                this.statement  = response.data.body.statement;
                                this.id =  response.data.body.id;
                                this.header = false;
                            } else {
                                window.alerts.error(response).then((response) => {
                                });
                            }
                        }).catch((error) => {
                        });
                    }
                });
            }
        }
    }
</script>
<template>
    <div class="row pt-3">
        <div :class="['dimmer w-100 min-h-70' ,  loading || form.loading ? 'active':'']">
            <div class="loader"></div>
            <div class="dimmer-content w-100">
                <div v-if="header" class="col-lg-12">
                    <div class="card">
                        <div class="card-body d-flex align-items-start">
                            <div class="form-group mb-0 m-2">
                                <select  name="gender" v-model="form.account" :disabled="this.accounts.length < 2" :class="[ 'custom-select' , form.errors.get('account') ? 'is-invalid' : '' ]">
                                    <option value="">Choose Account</option>
                                    <option v-for="account in accounts" :value="account.id">{{ account.account }} - {{ account.currency.name }}</option>
                                </select>
                                <div v-text="form.errors.get('account')" class="text-danger"/>
                            </div>
                            <div class="app-search m-2 flex-fill">
                                <form>
                                    <div class="input-group"><input type="date" v-model="form.start" class="form-control bg-white border">
                                        <span class="mdi mdi mdi-calendar-arrow-right"></span>
                                        <div class="input-group-append">
                                            <button type="submit" disabled class="btn btn-primary shadow-none">Start Date</button>
                                        </div>
                                    </div>
                                    <div v-text="form.errors.get('start')" class="text-danger"/>
                                </form>
                            </div>
                            <div class="app-search m-2 flex-fill">
                                <form>
                                    <div class="input-group">
                                        <input type="date" v-model="form.end" class="form-control bg-white border">
                                        <span class="mdi mdi mdi-calendar-arrow-left"></span>
                                        <div class="input-group-append">
                                            <button type="submit" disabled class="btn btn-primary shadow-none">End Date</button>
                                        </div>
                                    </div>
                                    <div v-text="form.errors.get('end')" class="text-danger"/>
                                </form>
                            </div>
                            <div class="m-2">
                                <button @click="request" class="btn btn-primary">Run Statement</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div v-if="statement.transactions.length > 0 " class="col-lg-12">
                    <div class="card">
                        <div class="card-body px-5 border-bottom d-flex justify-content-end">
                            <button @click.prevent="reset" class="btn btn-light px-3 mr-2">Select Another Period</button>
                            <router-link :to="`/transactions/statement/${id}/view`" class="btn btn-light"><i class="mdi mdi-eye mr-1"/>View More</router-link>
                        </div>
                        <div class="card-body px-5 d-flex align-items-center border-bottom">
                            <div>
                                <img src="/images/logo-full.png" height="100" alt="">
                            </div>
                            <div class="text-center mx-auto">
                                Agricultural Bank of Zimbabwe <br>
                                Hurudza House, 14-16 Nelson Mandela Harare , Zimbabwe <br>
                                Tel: (+263)(242) 774400-19
                            </div>
                            <div>
                                <img :src="statement.qr" height="100" alt="">
                            </div>
                        </div>
                        <div class="card-body px-5 border-bottom">
                            <h3 class="text-center">Account Statement</h3>
                            <h6 class="text-center"> {{ statement.date }} </h6>
                        </div>
                        <div class="card-body px-5">
                            <div class="row">
                                <div class="col-lg-6 text-left">
                                    <div class="col-lg-6 text-left">
                                        Name : <strong>{{ statement.name}}</strong> <br>
                                        Reference : <strong>{{ statement.reference }} </strong> <br>
                                    </div>
                                </div>
                                <div class="col-lg-6 text-right">
                                    Start Date : <strong>{{ statement.date_start }}</strong> <br>
                                    End Date : <strong>{{ statement.date_end }} </strong> <br>
                                    Account : <strong>{{ statement.account.account }} </strong> <br>
                                    Currency : <strong>{{ statement.account.currency.name }} </strong> <br>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive font-12">
                            <table class="table table-centered">
                                <thead class="thead-light">
                                    <tr>
                                        <th/>
                                            <th>Value Date</th>
                                            <th>Booking Date</th>
                                            <th>Reference</th>
                                            <th>Description</th>
                                            <th>Location</th>
                                            <th>Debit</th>
                                            <th>Credit</th>
                                            <th>Balance</th>
                                        <th/>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="transaction in statement.transactions">
                                        <td/>
                                        <td class="text-primary">{{ transaction.valueDate }}</td>
                                        <td class="text-muted">{{ transaction.bookingDate }}</td>
                                        <td><strong>{{ transaction.ft }}</strong></td>
                                        <td>{{ transaction.reference }}</td>
                                        <td>{{ transaction.location }}</td>
                                        <td>{{ transaction.debit }}</td>
                                        <td>{{ transaction.credit }}</td>
                                        <td><strong>{{ transaction.balance }}</strong></td>
                                        <td/>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-centered table-nowrap mb-0 table-borderless border-top">
                                <tbody>
                                <tr class="text-center">
                                    <td/>
                                    <td>
                                        <h5 class="font-14 my-1"> [ {{ statement.total }} ] </h5>
                                        <span class="text-muted font-13">Total</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1">{{ statement.start }}</h5>
                                        <span class="text-muted font-13">Start Balance</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1">[ {{ statement.debits_count }} ] {{ statement.debits }}</h5>
                                        <span class="text-muted font-13">Debits</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1">[ {{ statement.credits_count }} ] {{ statement.credits }}</h5>
                                        <span class="text-muted font-13">Credits</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1">{{ statement.end }}</h5>
                                        <span class="text-muted font-13">End Balance</span>
                                    </td>
                                    <td/>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="card-body">
                            <h6 class="text-center"> {{ statement.code }} </h6>
                        </div>
                    </div>
                </div>
                <div v-else class="col-lg-12">
                    <div class="card">
                        <div class="card-body p-5 text-center">
                            <h2 v-if="header" class="text-center mb-3">Select your statement Period</h2>
                            <h2 v-if="!header" class="text-center mb-3">No Entries Found or Period Too Large</h2>
                            <h5  v-if="!header" class="mb-3">{{ form.start }} - {{ form.end }} </h5>
                            <button v-if="!header" @click.prevent="reset" class="btn btn-primary px-3">Try Another Period</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</template>
