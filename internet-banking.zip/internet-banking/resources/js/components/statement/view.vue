<script>
    import Form from "../../core/forms/form";

    export default {
        name: "index",
        data(){
            return {
                loading : false,
                form : new Form({
                    start : window.moment().format('YYYY-MM-DD'),
                    end : window.moment().format('YYYY-MM-DD'),
                    account : '',
                }),
                accounts : [],
                statement : {
                    transactions : [],
                    account : {
                        currency : {}
                    }
                }
            }
        },
        mounted() {
            this.init();
        },
        methods : {
            init()
            {
                this.loading = true;
                window.axios.get(`${window.location.origin}/transactions/accounts`).then((response) => {
                    this.accounts = response.data.body.accounts;
                    if (this.accounts.length === 0)
                    {
                        window.Swal.fire({
                            icon: 'error',
                            text: 'You don\'t have any account linked on your Account , Contact the Bank',
                            showConfirmButton: true,
                            confirmButtonColor: '#1c4b27',
                            padding: '20px',
                        }).then((e) => {});
                    }

                    if (this.accounts.length === 1)
                    {
                        let account = this.accounts[0];
                        this.form.account = account.id;
                    }

                }).finally(() => {
                    this.loading = false;
                });
            },
            request(){
                window.Swal.fire({
                    title: 'Are you sure ?',
                    text: `Request statement from ${this.form.start} to ${this.form.end}`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#1c4b27',
                    cancelButtonColor: '#d33',
                    confirmButtonText: `Yes, Request!`
                }).then((result) => {
                    if (result.value) {
                        this.form.submit('/transactions/statement').then((response) => {
                            if (response.data.success === true){

                            } else {
                                window.alerts.error(response).then((response) => {
                                    this.$router.push(`/transactions/${response.data.body.transaction.component}/${response.data.body.transaction.id}/view`);
                                });
                            }
                        }).catch((error) => {
                        });
                    }
                });
            }
        }
    }
</script>
<template>
    <div class="row pt-3">
        <div :class="['dimmer w-100 min-h-70' ,  loading || form.loading ? 'active':'']">
            <div class="loader"></div>
            <div class="dimmer-content w-100">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body d-flex align-items-center">
                            <div class="form-group mb-0 m-2">
                                <select  name="gender" v-model="form.account" :disabled="this.accounts.length < 2" :class="[ 'custom-select' , form.errors.get('account') ? 'is-invalid' : '' ]">
                                    <option value="">Choose Account</option>
                                    <option v-for="account in accounts" :value="account.id">{{ account.account }} - {{ account.currency.name }}</option>
                                </select>
                                <div v-text="form.errors.get('account')" class="text-danger"/>
                            </div>
                            <div class="app-search m-2 flex-fill">
                                <form>
                                    <div class="input-group"><input type="date" v-model="form.start" class="form-control bg-white border">
                                        <span class="mdi mdi mdi-calendar-arrow-right"></span>
                                        <div class="input-group-append">
                                            <button type="submit" disabled class="btn btn-primary shadow-none">Start Date</button>
                                        </div>
                                    </div>
                                    <div v-text="form.errors.get('start')" class="text-danger"/>
                                </form>
                            </div>
                            <div class="app-search m-2 flex-fill">
                                <form>
                                    <div class="input-group">
                                        <input type="date" v-model="form.end" class="form-control bg-white border">
                                        <span class="mdi mdi mdi-calendar-arrow-left"></span>
                                        <div class="input-group-append">
                                            <button type="submit" disabled class="btn btn-primary shadow-none">End Date</button>
                                        </div>
                                    </div>
                                    <div v-text="form.errors.get('end')" class="text-danger"/>
                                </form>
                            </div>
                            <div class="m-2">
                                <button @click="request" class="btn btn-primary">Run Statement</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div v-if="statement.transactions.length > 0 " class="col-lg-12">
                    <div class="card">
                        <div class="card-body px-5 border-bottom d-flex justify-content-end">
                            <a href="" class="btn btn-light mr-2">Generate PDF</a>
                            <button class="btn btn-light">Generate CSV</button>
                        </div>
                        <div class="card-body px-5 d-flex align-items-center border-bottom">
                            <div>
                                <img src="/images/logo-full.png" height="100" alt="">
                            </div>
                            <div class="text-center mx-auto">
                                Agricultural Bank of Zimbabwe <br>
                                Hurudza House, 14-16 Nelson Mandela Harare , Zimbabwe <br>
                                Tel: (+263)(242) 774400-19
                            </div>
                            <div>
                                <img :src="statement.qr" height="100" alt="">
                            </div>
                        </div>
                        <div class="card-body px-5 border-bottom">
                            <h3 class="text-center">Account Statement</h3>
                            <h6 class="text-center"> {{ statement.date }} </h6>
                            <h6 class="text-center"> {{ statement.code }} </h6>
                        </div>
                        <div class="card-body px-5">
                            <div class="row">
                                <div class="col-lg-6 text-left">
                                    Name : <strong>{{ statement.account.data.name }}</strong> <br>
                                    Address : <strong>{{ statement.account.data.address }} </strong> <br>
                                    Phone : <strong>{{ statement.account.data.phone }}</strong> <br>
                                    Email : <strong>{{ statement.account.data.email }}</strong>
                                </div>
                                <div class="col-lg-6 text-right">
                                    Start Date : <strong>{{ statement.date_start }}</strong> <br>
                                    End Date : <strong>{{ statement.date_end }} </strong> <br>
                                    Account : <strong>{{ statement.account.account }} </strong> <br>
                                    Currency : <strong>{{ statement.account.currency.name }} </strong> <br>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-centered">
                                <thead class="thead-light">
                                    <tr>
                                        <th/>
                                            <th>Value Date</th>
                                            <th>Booking Date</th>
                                            <th>Reference</th>
                                            <th>Description</th>
                                            <th>Location</th>
                                            <th>Debit</th>
                                            <th>Credit</th>
                                            <th>Balance</th>
                                        <th/>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="transaction in statement.transactions">
                                        <td/>
                                        <td class="text-primary">{{ transaction.valueDate }}</td>
                                        <td class="text-muted">{{ transaction.bookingDate }}</td>
                                        <td><strong>{{ transaction.ft }}</strong></td>
                                        <td>{{ transaction.reference }}</td>
                                        <td>{{ transaction.location }}</td>
                                        <td>{{ transaction.debit }}</td>
                                        <td>{{ transaction.credit }}</td>
                                        <td><strong>{{ transaction.balance }}</strong></td>
                                        <td/>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-centered table-nowrap mb-0 table-borderless border-top">
                                <tbody>
                                <tr class="text-center">
                                    <td/>
                                    <td>
                                        <h5 class="font-14 my-1"> [ {{ statement.total }} ] </h5>
                                        <span class="text-muted font-13">Total</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1">{{ statement.start }}</h5>
                                        <span class="text-muted font-13">Start Balance</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1">[ {{ statement.debits_count }} ] {{ statement.debits }}</h5>
                                        <span class="text-muted font-13">Debits</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1">[ {{ statement.credits_count }} ] {{ statement.credits }}</h5>
                                        <span class="text-muted font-13">Credits</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1">{{ statement.end }}</h5>
                                        <span class="text-muted font-13">End Balance</span>
                                    </td>
                                    <td/>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div v-else class="col-lg-12">
                    <div class="card">
                        <div class="card-body p-5">
                            <h2 class="text-center">No Entries Found</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</template>
