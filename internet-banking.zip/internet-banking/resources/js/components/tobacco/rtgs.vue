<script>
    import AccountsService  from "../../servicies/AccountsService";
    import Form from "../../core/forms/form";
    export default {
        name: "rtgs",
        mounted() {
            this.init();
        },
        data()
        {
            return {
                count : 0,
                loading : true,
                accounts : [],
                banks : [],
                types : [],
                form : new Form({
                    sending_account : '',
                    receiving_account_confirmation : '',
                    receiving_account : '',
                    amount : '',
                    name : '',
                    reason : '',
                    bank : '',
                    type : '',
                })
            }
        },

        watch : {
            accounts  : function (n , o) {
                this.accountChange();
            }
        },

        methods : {
            accountChange(){

                console.log("Account Types mapping");
                this.form.type = '';
                console.log(this.accounts);
                console.log(this.form.sending_account);

                let t = this.accounts.find(e => e.id === this.form.sending_account);
                if (t){
                    this.types = t.types;
                    if (t.types.length  === 1 )
                    {
                        this.form.type = t.types[0].id;
                    }
                }

            },

            getAccounts(){
                this.loading = true;
                window.axios.get(`${window.location.origin}/transactions/accounts`).then((response) => {
                    AccountsService.load(this , response);
                }).finally(() => {
                    this.count++;
                    if (this.count === 2 ){
                        this.loading = false;
                    }
                });
            },

            getBanks(){
                this.loading = true;
                window.axios.get(`${window.location.origin}/transactions/rtgs/banks`).then((response) => {
                    this.banks = response.data.body.banks;
                }).finally(() => {
                    this.count++;
                    if (this.count === 2 ){
                        this.loading = false;
                    }
                });
            },
            init (){
                this.getAccounts();
                this.getBanks();
            },
            submit(){
                let bank = this.banks.find((e) => e.id === this.form.bank);
                if (!bank){
                    bank = {
                        name : ''
                    }
                }
                window.Swal.fire({
                    title: 'Are you sure ?',
                    text: `Transfer of \$${this.form.amount} Account : ${this.form.receiving_account}  Bank : ${bank.name}`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#1c4b27',
                    cancelButtonColor: '#d33',
                    confirmButtonText: `Yes, Transfer!`
                }).then((result) => {
                    if (result.value) {
                        this.form.submit('/transactions/tobacco_rtgs').then((response) => {
                            if (response.data.success === true){
                                window.alerts.success(response).then((response) => {
                                    this.$router.push(`/transactions/${response.data.body.transaction.component}/${response.data.body.transaction.id}/view`);
                                });
                            } else {
                                window.alerts.error(response).then((response) => {
                                    this.$router.push(`/transactions/${response.data.body.transaction.component}/${response.data.body.transaction.id}/view`);
                                });
                            }
                        }).catch((error) => {
                        });
                    }
                });
            }
        }
    }
</script>
<template>
    <div class="row justify-content-center pt-4">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div :class="['dimmer' , loading || form.loading ? 'active' : '']">
                        <div class="loader"></div>
                        <div class="dimmer-content">
                            <div class="form-group mb-0 justify-content-end row">
                                <div class="col-lg-9">
                                    <h4 class="header-title mb-2">RTGS [ Real Time Gross Settlement ]</h4>
                                </div>
                            </div>
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label"> From Account</label>
                                <div class="col-lg-9">
                                    <div class="help-block text-right mw-400"><small> [ Debit ] </small></div>
                                    <select  name="gender" @change="accountChange" v-model="form.sending_account" :disabled="this.accounts.length < 2" :class="[ 'form-control mw-400 ' , form.errors.get('sending_account') ? 'is-invalid' : '' ]">
                                        <option value="">Choose Account</option>
                                        <option v-for="account in accounts" :value="account.id">{{ account.account }} - {{ account.currency.name }}</option>
                                    </select>
                                    <div v-text="form.errors.get('sending_account')" class="invalid-feedback"/>
                                </div>
                            </div>

                            <!--<div v-if="types.length > 0" class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label"> Transaction Type</label>
                                <div class="col-lg-9">
                                    <div class="help-block text-right mw-400"></div>
                                    <select  name="type" v-model="form.type" :disabled="this.types.length < 2" :class="[ 'form-control mw-400 ' , form.errors.get('type') ? 'is-invalid' : '' ]">
                                        <option value="">Choose Transaction Type</option>
                                        <option v-for="type in types" :value="type.id">{{ type.name }}</option>
                                    </select>
                                    <div v-text="form.errors.get('type')" class="invalid-feedback"/>
                                </div>
                            </div>-->

                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label">To Account</label>
                                <div class="col-lg-9">
                                    <div class="help-block text-right mw-400"><small> [ Credit ] </small></div>
                                    <input type="text" v-model="form.receiving_account" :class="[ 'form-control mw-400' , form.errors.get('receiving_account') ? 'is-invalid' : '' ]" placeholder="To Account">
                                    <div v-text="form.errors.get('receiving_account')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label">Confirm Account</label>
                                <div class="col-lg-9">
                                    <div class="help-block text-right mw-400"><small> [ Credit ] </small></div>
                                    <input type="text" v-model="form.receiving_account_confirmation" :class="[ 'form-control mw-400' , form.errors.get('receiving_account_confirmation') ? 'is-invalid' : '' ]" placeholder="Confirm Account">
                                    <div v-text="form.errors.get('receiving_account_confirmation')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label"> To Bank </label>
                                <div class="col-lg-9">
                                    <select  name="bank" v-model="form.bank" :class="[ 'form-control mw-400 ' , form.errors.get('bank') ? 'is-invalid' : '' ]">
                                        <option value="">Choose Bank</option>
                                        <option v-for="bank in banks" :value="bank.id">{{ bank.name }}</option>
                                    </select>
                                    <div v-text="form.errors.get('bank')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label">Amount</label>
                                <div class="col-lg-9">
                                    <input type="number" name="amount" v-model="form.amount" :class="[ 'form-control mw-400' , form.errors.get('amount') ? 'is-invalid' : '' ]" placeholder="Amount">
                                    <div v-text="form.errors.get('amount')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label">Account Name </label>
                                <div class="col-lg-9">
                                    <input type="text" name="amount" v-model="form.name" :class="[ 'form-control mw-400' , form.errors.get('name') ? 'is-invalid' : '' ]" placeholder="name">
                                    <div v-text="form.errors.get('name')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label">Reason / Reference </label>
                                <div class="col-lg-9">
                                    <input type="text" name="reason" v-model="form.reason" :class="[ 'form-control mw-400' , form.errors.get('reason') ? 'is-invalid' : '' ]" placeholder="reason">
                                    <div v-text="form.errors.get('reason')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="form-group mb-0 justify-content-end row">
                                <div class="col-lg-9">
                                    <button type="submit" @click.prevent="submit" :class="['btn btn-primary' , form.loading ? 'btn-loading' : '']">Transfer</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

