<script>
    import PageOpen from "../core/page-open";
    export default {
        name: "user-open",
        components: {PageOpen},
        data() {
            return {
                win : window
            }
        }
    }
</script>
<template>
    <page-open>
        <template slot="links">
            <li class="nav-item">
                <router-link exact :to="`/tobacco/batch`" active-class="active" data-toggle="tab" aria-expanded="false" class="nav-link rounded-0">
                    <i class="mdi mdi-eye font-18 "></i>
                    <span class="d-none d-lg-block">Tobacco Payments Batch Upload</span>
                </router-link>
            </li>
            <li class="nav-item">
                <router-link exact  :to="`/tobacco/internal`" active-class="active" data-toggle="tab" aria-expanded="false" class="nav-link rounded-0">
                    <i class="mdi mdi-circle-edit-outline font-18 "></i>
                    <span class="d-none d-lg-block">Tobacco Single Internal Payment</span>
                </router-link>
            </li>
            <li class="nav-item">
                <router-link exact  :to="`/tobacco/rtgs`" active-class="active" data-toggle="tab" aria-expanded="false" class="nav-link rounded-0">
                    <i class="mdi mdi-file-document font-18 "></i>
                    <span class="d-none d-lg-block">Tobacco Single RTGS Payment</span>
                </router-link>
            </li>
        </template>
    </page-open>
</template>
