<script>
    import Form from "../../core/forms/form";
    import AccountsService from "../../servicies/AccountsService";
    export default {
        name: "internal-transfer-initiate",
        mounted() {
            this.init();
        },
        data()
        {
            return {
                loading : true,
                accounts : [],
                types : [],
                form : new Form({
                    sending_account : '',
                    receiving_account : '',
                    receiving_account_confirmation : '',
                    amount : '',
                    reference : '',
                    name : '',
                    type : '',
                })
            }
        },
        watch : {
            accounts  : function (n , o) {
                this.accountChange();
            }
        },
        methods : {
            accountChange(){
                this.form.type = '';
                let t = this.accounts.find(e => e.id === this.form.sending_account);
                if (t){
                    this.types = t.types;
                    if (t.types.length  === 1 )
                    {
                        this.form.type = t.types[0].id;
                    }
                }

            },
            init ()
            {
                AccountsService.loadAccounts(this);
            },
            submit()
            {
                window.Swal.fire({
                    title: 'Are you sure ?',
                    text: `You want to transfer \$${this.form.amount} to ${this.form.receiving_account} with minimum charge of 2%`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#1c4b27',
                    cancelButtonColor: '#d33',
                    confirmButtonText: `Yes, Transfer!`
                }).then((result) => {
                    if (result.value) {
                        this.form.submit('/transactions/tobacco_internal').then((response) => {

                            window.alerts[response.data.success === true ? 'success' : 'error'](response).then((response) => {
                                this.$router.push(`/transactions/${response.data.body.transaction.component}/${response.data.body.transaction.id}/view`);
                            });

                        }).catch((error) => {
                        });
                    }
                });
            }
        }
    }
</script>
<template>
    <div class="row justify-content-center pt-4">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div :class="['dimmer' , loading || form.loading ? 'active' : '']">
                        <div class="loader"></div>
                        <div class="dimmer-content">
                            <div class="form-group mb-0 justify-content-end row">
                                <div class="col-lg-9">
                                    <h4 class="header-title mb-2">Tobacco Internal Transfer</h4>
                                </div>
                            </div>
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label"> From Account</label>
                                <div class="col-lg-9">
                                    <div class="help-block text-right mw-400"><small> [ Debit ] </small></div>
                                    <select  name="gender" @change="accountChange" v-model="form.sending_account" :disabled="this.accounts.length < 2" :class="[ 'form-control mw-400 ' , form.errors.get('sending_account') ? 'is-invalid' : '' ]">
                                        <option value="">Choose Account</option>
                                        <option v-for="account in accounts" :value="account.id">{{ account.account }} - {{ account.currency.name }}</option>
                                    </select>
                                    <div v-text="form.errors.get('sending_account')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <!--<div v-if="types.length > 0" class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label"> Transaction Type</label>
                                <div class="col-lg-9">
                                    <div class="help-block text-right mw-400"></div>
                                    <select  name="type" v-model="form.type" :disabled="this.types.length < 2" :class="[ 'form-control mw-400 ' , form.errors.get('type') ? 'is-invalid' : '' ]">
                                        <option value="">Choose Transaction Type</option>
                                        <option v-for="type in types" :value="type.id">{{ type.name }}</option>
                                    </select>
                                    <div v-text="form.errors.get('type')" class="invalid-feedback"/>
                                </div>
                            </div>-->
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label">To Account</label>
                                <div class="col-lg-9">
                                    <div class="help-block text-right mw-400"><small> [ Credit ] </small></div>
                                    <input type="text" name="phone" v-model="form.receiving_account" :class="[ 'form-control mw-400' , form.errors.get('receiving_account') ? 'is-invalid' : '' ]" placeholder="To Account">
                                    <div v-text="form.errors.get('receiving_account')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label">Confirm Account</label>
                                <div class="col-lg-9">
                                    <div class="help-block text-right mw-400"><small> [ Credit ] </small></div>
                                    <input type="text" name="phone" v-model="form.receiving_account_confirmation" :class="[ 'form-control mw-400' , form.errors.get('receiving_account_confirmation') ? 'is-invalid' : '' ]" placeholder="Confirm Account">
                                    <div v-text="form.errors.get('receiving_account_confirmation')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label">Amount</label>
                                <div class="col-lg-9">
                                    <input type="number" name="amount" v-model="form.amount" :class="[ 'form-control mw-400' , form.errors.get('amount') ? 'is-invalid' : '' ]" placeholder="Amount">
                                    <div v-text="form.errors.get('amount')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label">Reference </label>
                                <div class="col-lg-9">
                                    <div class="help-block text-right mw-400"><small> [ Optional ] </small></div>
                                    <input type="text" name="amount" v-model="form.reference" :class="[ 'form-control mw-400' , form.errors.get('reference') ? 'is-invalid' : '' ]" placeholder="Reference">
                                    <div v-text="form.errors.get('reference')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label">Name </label>
                                <div class="col-lg-9">
                                    <div class="help-block text-right mw-400"><small> [ Optional ] </small></div>
                                    <input type="text" name="name" v-model="form.name" :class="[ 'form-control mw-400' , form.errors.get('name') ? 'is-invalid' : '' ]" placeholder="Name">
                                    <div v-text="form.errors.get('name')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="form-group mb-0 justify-content-end row">
                                <div class="col-lg-9">
                                    <button type="submit" @click.prevent="submit" :class="['btn btn-primary' , form.loading ? 'btn-loading' : '']">Transfer</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

