<script>
    import Form from "../../core/forms/form";
    export default {
        name: "upload",
        mounted() {
            this.init();
        },
        data()
        {
            return {
                loading : true,
                accounts : [],
                types : [],
                form : new Form({
                    sending_account : '',
                    amount : 0,
                    reference : '',
                    file : '',
                    type : '',
                })
            }
        },
        watch : {
            accounts  : function (n , o) {
                this.accountChange();
            }
        },
        methods : {
            accountChange(){
                this.form.type = '';
                let t = this.accounts.find(e => e.id === this.form.sending_account);
                if (t){
                    this.types = t.types;
                    if (t.types.length  === 1 )
                    {
                        this.form.type = t.types[0].id;
                    }
                }

            },
            fileChange : function ()
            {
                this.form.file = this.$refs.file.files[0];
            },
            init (){
                this.loading = true;
                window.axios.get(`${window.location.origin}/transactions/accounts`).then((response) => {
                    this.accounts = response.data.body.accounts;
                    if (this.accounts.length === 0)
                    {
                        window.Swal.fire({
                            icon: 'error',
                            text: 'You don\'t have any account linked on your Account , Contact the Bank',
                            showConfirmButton: true,
                            confirmButtonColor: '#1c4b27',
                            padding: '20px',
                        }).then((e) => {});
                    }

                    if (this.accounts.length === 1)
                    {
                        let account = this.accounts[0];
                        this.form.sending_account = account.id;
                    }

                }).finally(() => {
                    this.loading = false;
                });
            },
            submit(){
                window.Swal.fire({
                    title: 'Are you sure ?',
                    text: `Upload Batch for ${this.form.reference}`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#1c4b27',
                    cancelButtonColor: '#d33',
                    confirmButtonText: `Yes, Upload!`
                }).then((result) => {
                    if (result.value) {
                        this.form.upload('/batch/tobacco_upload').then((response) => {
                            this.$router.push(`/batch/${response.data.body.batch.id}/view`);
                        }).catch((error) => {
                        });
                    }
                });
            }
        }
    }
</script>
<template>
    <div class="row justify-content-center pt-4">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div :class="['dimmer' , loading || form.loading ? 'active' : '']">
                        <div class="loader"></div>
                        <div class="dimmer-content">
                            <div class="form-group mb-0 justify-content-end row">
                                <div class="col-lg-9">
                                    <h4 class="header-title mb-2">Upload Batch</h4>
                                </div>
                            </div>
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label"> From Account</label>
                                <div class="col-lg-9">
                                    <div class="help-block text-right mw-400"><small> [ Debit ] </small></div>
                                    <select @change="accountChange"  name="gender" v-model="form.sending_account" :disabled="this.accounts.length < 2" :class="[ 'form-control mw-400 ' , form.errors.get('sending_account') ? 'is-invalid' : '' ]">
                                        <option value="">Choose Account</option>
                                        <option v-for="account in accounts" :value="account.id">{{ account.account }} - {{ account.currency.name }}</option>
                                    </select>
                                    <div v-text="form.errors.get('sending_account')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <!--<div v-if="types.length > 0" class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label"> Transaction Type</label>
                                <div class="col-lg-9">
                                    <div class="help-block text-right mw-400"></div>
                                    <select  name="type" v-model="form.type" :disabled="this.types.length < 2" :class="[ 'form-control mw-400 ' , form.errors.get('type') ? 'is-invalid' : '' ]">
                                        <option value="">Choose Transaction Type</option>
                                        <option v-for="type in types" :value="type.id">{{ type.name }}</option>
                                    </select>
                                    <div v-text="form.errors.get('type')" class="invalid-feedback"/>
                                </div>
                            </div>-->
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label">Reference</label>
                                <div class="col-lg-9">
                                    <div class="help-block text-right mw-400"><small></small></div>
                                    <input type="text" name="amount" v-model="form.reference" :class="[ 'form-control mw-400' , form.errors.get('reference') ? 'is-invalid' : '' ]" placeholder="Reference">
                                    <div v-text="form.errors.get('reference')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="form-group row d-flex mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label">File</label>
                                <div class="col-lg-9">
                                    <input type="file" id="file" @change="fileChange"  ref="file" :class="[ 'form-control-file border p-1 rounded mw-400' , form.errors.get('file') ? 'is-invalid' : '' ]">
                                    <div v-text="form.errors.get('file')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="form-group mb-0 justify-content-end row">
                                <div class="col-lg-9">
                                    <button type="submit" @click.prevent="submit" :class="['btn btn-primary' , form.loading ? 'btn-loading' : '']">Upload</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

