<template>
    <page-index name="Users" url="/users" prefix="users">
        <template slot="actions">
            <router-link :to="`/users/create?scope=${win.user.type}`" class="btn btn-primary ml-2 my-1">
                <i class="mdi mdi-plus mr-1"></i>Create User
            </router-link>
        </template>
        <template slot="table-header">
            <th></th>
            <th></th>
            <th>Info</th>
            <th>Contact</th>
            <th >Type</th>
            <th>Date</th>
            <th class="text-center"></th>
        </template>
        <template slot="table-row" slot-scope="data">
            <td>
                <span class="text-primary">#{{ data.row.id }}</span>
            </td>
            <td>
               <div class="avatar-sm">
                    <span class="avatar-title bg-light text-dark font-15 rounded-circle">
                        {{ data.row.avatar_name }}
                    </span>
                </div>
            </td>
            <td>name : {{ data.row.name }} <br> surname : {{ data.row.last_name }} </td>
            <td>email : {{ data.row.email }} <br> phone : {{ data.row.phone }}</td>
            <td><span :class="['badge badge-light p-2 font-12 ' , 'text-primary'  ]">{{ data.row.type }}</span></td>
            <td> created : {{ data.row.read_created_at }} <br> updated : {{ data.row.read_updated_at }} </td>
            <td>
                <router-link :to="`/users/${data.row.id}/view`" class="action-icon text-primary">
                    <i class="mdi mdi-eye mdi-24px"/>
                </router-link>
            </td>
        </template>
    </page-index>
</template>

<script>
    import PageIndex from "../core/page-index";
    export default {
        name: "index",
        components: {PageIndex},
        data(){
            return {
                win : window
            }
        }
    }
</script>
