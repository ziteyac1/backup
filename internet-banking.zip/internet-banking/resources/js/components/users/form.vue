<script>

    import Form from "../../core/forms/form";

    import DataSelect from "../core/DataSelect";
    import MultiDataSelect from "../core/MultiDataSelect";

    import RolesSelect from "../roles/select";
    import CorporateSelect from "../corporates/select";

    export default {
        name: "user-form",
        components: {CorporateSelect, RolesSelect, MultiDataSelect, DataSelect},
        props: [ 'edit' , 'id' ],
        data(){
            return {
                form : new Form({
                    name : '',
                    last_name : '',
                    phone : '',
                    email : '',
                    password : '',
                    type : 'admin',
                    corporate_id : '',
                    permissions : []
                }, {
                    corporate : {},
                    permissions : []
                }),
            };
        },
        mounted() {

            // Scope logic


            if (this.edit)
            {
                this.init();
            }
        },
        methods: {
            init()
            {
                this.form.loading = true;
                window.axios.get(`/users/${this.id}/view`).then((response) => {
                    this.form.extract(response.data.body.model);
                    this.form.store('permissions' , response.data.body.model);
                    this.form.store('corporate' , response.data.body.model);
                    this.form.loading = false;
                });
            },
            create()
            {
                this.form.submit(this.edit ? `/users/${this.id}/update`  : '/users/create').then((response) => {
                    window.alerts.success(response).then((response) => {
                        if (!this.edit)
                        this.$router.push(`/users/${response.data.body.model.id}/view`);
                    });
                }).catch((error) => {
                }).finally(() => {
                });
            }
        }
    }
</script>
<template>
    <div class="row pt-3">
        <div class="col-lg-12">
            <div :class="['dimmer' , form.loading ? 'active' : '']">
                <div class="loader"></div>
                <div class="dimmer-content">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="mb-3"> {{ this.edit ? 'Edit' : 'Create' }}  User</h4>
                            <div class="form-horizontal">
                                <div class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">First Name</label>
                                    <div class="col-lg-9">
                                        <input type="text" name="name" v-model="form.name" :class="[ 'form-control mw-400' , form.errors.get('name') ? 'is-invalid' : '' ]" placeholder="First Name">
                                        <div v-text="form.errors.get('name')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Last Name</label>
                                    <div class="col-lg-9">
                                        <input type="text" name="last_name" v-model="form.last_name" :class="[ 'form-control mw-400' , form.errors.get('last_name') ? 'is-invalid' : '' ]" placeholder="Last Name">
                                        <div v-text="form.errors.get('last_name')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Phone</label>
                                    <div class="col-lg-9">
                                        <input type="text" name="phone" v-model="form.phone" :class="[ 'form-control mw-400' , form.errors.get('phone') ? 'is-invalid' : '' ]" placeholder="Phone">
                                        <div v-text="form.errors.get('phone')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Email</label>
                                    <div class="col-lg-9">
                                        <input type="email" name="email" v-model="form.email" :class="[ 'form-control mw-400' , form.errors.get('email') ? 'is-invalid' : '' ]" placeholder="Email">
                                        <div v-text="form.errors.get('email')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div v-if="!edit" class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Password</label>
                                    <div class="col-lg-9">
                                        <input type="password" name="password" v-model="form.password" :class="[ 'form-control mw-400' , form.errors.get('password') ? 'is-invalid' : '' ]" placeholder="Password">
                                        <div v-text="form.errors.get('password')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div v-if="$route.query.scope === 'admin'" class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Type</label>
                                    <div class="col-lg-9">
                                        <select type="email" name="type" v-model="form.type" :class="[ 'form-control mw-400' , form.errors.get('type') ? 'is-invalid' : '' ]">
                                            <option value="admin">Admin</option>
                                            <option value="corporate">Corporate</option>
                                            <option value="individual">Individual</option>
                                        </select>
                                        <div v-text="form.errors.get('type')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div v-if="form.type === 'corporate' && $route.query.scope === 'admin'" class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Corporate</label>
                                    <div class="col-lg-9">
                                        <data-select select="name" :start="form.storage.corporate"  v-model="form.corporate_id" name="Corporate" url="/corporates" prefix="corporates">
                                            <template slot="select" slot-scope="data">
                                                <corporate-select :data="data"/>
                                            </template>
                                        </data-select>
                                        <div v-text="form.errors.get('corporate_id')" class="text-danger font-12"/>
                                    </div>
                                </div>
                                <div v-if="form.type === 'corporate'" class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Permissions</label>
                                    <div class="col-lg-9">
                                        <multi-data-select select="name" :start="form.storage.permissions"  v-model="form.permissions" name="Permissions" url="/permissions" prefix="permissions">
                                            <template slot="select" slot-scope="data">
                                                <roles-select :data="data"/>
                                            </template>
                                        </multi-data-select>
                                        <div v-text="form.errors.get('permissions')" class="text-danger font-12"/>
                                    </div>
                                </div>
                                <div class="form-group mb-0 justify-content-end row">
                                    <div class="col-lg-9">
                                        <button type="submit" @click.prevent="create" :class="['btn btn-primary' , form.loading ? 'btn-loading' : '']">{{ this.edit ? 'Edit' : 'Create' }} User</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>
