<script>
    import UserForm from "./form";
    export default {
        components: {UserForm}
    }
</script>
<template>
    <user-form :edit="false"/>
</template>
