<script>
    export default {
        data() {
            return {
                user: {
                    corporate : {},
                    permissions : [],
                    accounts : []
                },
                loading: true,
                auth : window.user,
            };
        },
        methods : {
            act(action  , id)
            {
                window.action(action , 'Account' , `${window.location.origin}/accounts/${id}/${action}`).then((response) => {
                    this.init();
                });
            },
            action(action){
                window.action(action , 'User' , `${window.location.origin}/users/${this.$route.params.id}/${action}`).then((response) => {
                    this.user = response.data.body.model;
                });
            },
            init(){
                this.loading = true;
                window.axios.get(`${window.location.origin}/users/${this.$route.params.id}/view`).then((response) => {
                    this.user = response.data.body.model;
                }).finally(() => {
                    this.loading = false;
                });
            }
        },
        mounted() {
            this.init();
        }
    }
</script>
<template>
    <div :class="['dimmer' , loading ? 'active' : '']">
        <div class="loader"></div>
        <div class="dimmer-content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-3 flex-wrap">
                                <h4 class="header-title m-0 flex-fill">Personal Information</h4>
                                <div class="">
                                    <button v-if="!user.status && auth.is_admin" @click="action('activate')" type="button" class="btn btn-light m-1">
                                        <i class="mdi mdi-lightbulb-outline mr-1"></i> Activate
                                    </button>
                                    <button v-if="" @click="action('reset')"  type="button" class="btn btn-light m-1">
                                        <i class="mdi mdi-lightbulb-outline mr-1"></i> Reset
                                    </button>
                                    <button v-if="user.status" @click="action('deactivate')"  type="button" class="btn btn-light m-1">
                                        <i class="mdi mdi-lightbulb-off-outline mr-1"></i> De-Activate
                                    </button>
                                    <button v-if="!user.is_root && auth.is_root" @click="action('root')" type="button" class="btn btn-light m-1">
                                        <i class="mdi mdi-lightbulb-outline mr-1"></i> Root
                                    </button>
                                    <button v-if="user.is_root && auth.is_root" @click="action('remove')"  type="button" class="btn btn-light m-1">
                                        <i class="mdi mdi-lightbulb-off-outline mr-1"></i> Remove
                                    </button>
                                </div>
                            </div>
                            <div class="text-left">
                                <p>
                                    <strong class="mr-2">First Name :</strong>
                                    <span>{{ user.name }}</span>
                                </p>
                                <p>
                                    <strong class="mr-2">Last Name : </strong>
                                    <span>{{ user.last_name }}</span>
                                </p>
                                <p>
                                    <strong class="mr-2"> Email :</strong>
                                    <span>{{ user.email }}</span>
                                </p>
                                <p>
                                    <strong class="mr-2"> Phone :</strong>
                                    <span>{{ user.phone }}</span>
                                </p>
                                <p>
                                    <strong class="mr-2"> Type :</strong>
                                    <span class="badge badge-light p-2 m-1 font-12">{{ user.type }}</span>
                                </p>
                                <p  v-if="user.type === 'corporate' && auth.is_admin">
                                    <strong class="mr-2"> Corporate :</strong>
                                    <router-link :to="`/corporates/${user.corporate_id}/view`" class="badge badge-light p-2 m-1 font-12 text-primary">{{ user.corporate.select_name }}</router-link>
                                </p>
                                <p>
                                    <strong class="mr-2">Created :</strong>
                                    <span>{{ user.read_created_at }}</span>
                                </p>
                                <p>
                                    <strong class="mr-2">Status :</strong>
                                    <span> <span class="badge badge-light p-2 font-12">{{ user.status ? 'activated' : 'de-activated' }}</span></span>
                                </p>
                                <p v-if="user.permissions.length > 0">
                                    <strong class="mr-2">Permissions :</strong>
                                    <span> <span v-for="row in user.permissions" class="badge badge-light p-2 m-1 font-12">{{ row.name }}</span></span>
                                </p>
                            </div>
                        </div>
                        <div v-if="user.type !== 'corporate'" class="card-body border-top">
                            <div class="d-flex align-items-center flex-wrap">
                                <h4 class="header-title m-0 flex-fill">Accounts</h4>
                                <div class="">
                                    <router-link :to="`/accounts/create?parent=${user.id}&type=users`" type="button" class="btn btn-light m-1">
                                        <i class="mdi mdi-plus mr-1"></i> Create Account
                                    </router-link>
                                </div>
                            </div>
                        </div>
                        <div v-if="user.type !== 'corporate'" class="table-responsive">
                            <table class="table table-centered table-nowrap mb-0">
                                <tbody>
                                <tr :key="`account-${account.id}`" v-for="account in user.accounts">
                                    <td/>
                                        <td class="text-primary">
                                            #{{ account.id }}
                                        </td>
                                        <td>
                                            <h5 class="font-14 my-1 font-weight-normal">{{ account.created_at }}</h5>
                                            <span class="text-muted font-13">Date Created</span>
                                        </td>
                                        <td>
                                            <h5 class="font-14 my-1 font-weight-normal">{{ account.updated_at }}</h5>
                                            <span class="text-muted font-13">Last Update</span>
                                        </td>
                                        <td>
                                            <h5 class="font-14 my-1 font-weight-normal">{{ account.account }}</h5>
                                            <span class="text-muted font-13">Account</span>
                                        </td>
                                        <td>
                                            <h5 class="font-14 my-1 font-weight-normal">{{ account.currency.name }}</h5>
                                            <span class="text-muted font-13">Currency</span>
                                        </td>
                                        <td>
                                            <router-link :to="`/accounts/${account.id}/edit?parent=${user.id}&type=users`" class="btn btn-light">Edit Account</router-link>
                                        </td>
                                        <td>
                                            <button v-if="!account.status" @click.prevent="act('activate' , account.id)" class="btn btn-light">Activate Account</button>
                                            <button v-if="account.status" @click.prevent="act('deactivate' , account.id)" class="btn btn-light">De-Activate Account</button>
                                        </td>
                                    <td/>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</template>
