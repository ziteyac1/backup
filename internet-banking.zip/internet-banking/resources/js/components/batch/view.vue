<script>
    import PageIndex from "../core/page-index";
    import Can from "../core/can";
    export default {
        name: "index",
        components: {Can, PageIndex},
        data(){
            return {
                loading : false,
                auth : window.user,
                batch : {
                    state : {},
                    authorisation : {},
                    account : {},
                    user : {}
                }
            }
        },
        mounted() {
            this.init();
        },
        methods : {
            action(action)
            {
                window.action(action , 'Batch' , `${window.location.origin}/batch/${this.$route.params.id}/${action}`).then((response) => {
                    this.batch = response.data.body.model;
                });
            },
            init(){
                this.loading = true;
                window.axios.get(`${window.location.origin}/batch/${this.$route.params.id}/view`).then((response) => {
                    this.batch = response.data.body.model;
                }).finally(() => {
                    this.loading = false;
                });
            }
        }
    }
</script>
<template>
    <div :class="['dimmer' , loading ? 'active' : '']">
        <div class="loader"></div>
        <div class="dimmer-content">
            <div class="">
                <div class="row mt-4">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex align-items-center mb-3 flex-wrap">
                                    <h4 class="header-title m-0 flex-fill">Batch Information</h4>
                                    <div class="">
                                        <a v-if="batch.imported" :href="`/batch/${batch.id}/corrections`" target="_blank" class="btn btn-light m-1" >Download Validated File</a>
                                        <a v-if="batch.pdf" :href="`/batch/${batch.id}/report`" target="_blank" class="btn btn-light m-1" >PDF Report</a>
                                        <button v-if="" @click="init" type="button" :class="['btn btn-light m-1' ,  loading ? 'btn-loading' : '']">
                                            <i class="mdi mdi-refresh mr-1"></i> Refresh
                                        </button>
                                        <button v-if="batch.status === 4" @click="action('process')" type="button" class="btn btn-light m-1">
                                            <i class="mdi mdi-lightbulb-outline mr-1"></i> Process
                                        </button>
                                        <button @click="action('generate-report')" type="button" class="btn btn-light m-1">
                                            <i class="mdi mdi-lightbulb-outline mr-1"></i> Generate Report
                                        </button>
                                        <button v-if="(batch.status === 3 || batch.status === 4  ) && batch.user.id === auth.id" @click="action('cancel')" type="button" class="btn btn-light m-1">
                                            <i class="mdi mdi-lightbulb-outline mr-1"></i> Cancel
                                        </button>
                                        <button v-if="batch.retry_count > 0"
                                                @click="action('retry')" type="button" class="btn btn-light m-1">
                                                <i class="mdi mdi-lightbulb-outline mr-1"></i> Retry Failed
                                        </button>
                                        <can permission="authorise-transaction">
                                            <button v-if="batch.authorisation" @click="action('authorise')" type="button" class="btn btn-light m-1">
                                                <i class="mdi mdi-lightbulb-outline mr-1"></i> Authorise
                                            </button>
                                            <button v-if="batch.authorisation" @click="action('decline')"  type="button" class="btn btn-light m-1">
                                                <i class="mdi mdi-lightbulb-off-outline mr-1"></i> Decline
                                            </button>
                                        </can>
                                        <button v-if="" @click="$router.back()" class="ml-3 btn btn-light" type="button">
                                            <i class="mdi mdi-close mr-1"></i> Close
                                        </button>
                                    </div>
                                </div>
                                <div class="text-left">
                                    <p>
                                        <strong class="mr-2">Reference :</strong>
                                        <span>{{ batch.reference }}</span>
                                    </p>
                                    <p>
                                        <strong class="mr-2">Status :</strong>
                                        <span>{{ batch.state.description }}</span>
                                    </p>
                                    <p>
                                        <strong class="mr-2"> File :</strong>
                                        <span>{{ batch.name }}</span>
                                    </p>
                                    <p>
                                        <strong class="mr-2"> Uploaded :</strong>
                                        <span>{{ batch.user.full_name }} - {{ batch.user.email }}</span>
                                    </p>
                                    <p>
                                        <strong class="mr-2"> Created :</strong>
                                        <span>{{ batch.created_at }}</span>
                                    </p>
                                    <p>
                                        <strong class="mr-2"> Last Update :</strong>
                                        <span>{{ batch.read_updated }}</span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-4">
                        <div class="card tilebox-one">
                            <div class="card-body">
                                <i class=" mdi mdi-shield-check float-right text-success"></i>
                                <h6 class="text-uppercase mt-0">Processed Records</h6>
                                <h2 class="my-2">{{ batch.proceed_count }}</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card tilebox-one">
                            <div class="card-body">
                                <i class="mdi mdi-source-fork float-right text-warning"></i>
                                <h6 class="text-uppercase mt-0">Retry Records</h6>
                                <h2 class="my-2">{{ batch.retry_count }}</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card tilebox-one">
                            <div class="card-body">
                                <i class="mdi mdi-source-merge float-right text-warning"></i>
                                <h6 class="text-uppercase mt-0">Pending Records</h6>
                                <h2 class="my-2">{{ batch.pending_count }}</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card tilebox-one">
                            <div class="card-body">
                                <i class="mdi mdi-alert-circle float-right text-danger"></i>
                                <h6 class="text-uppercase mt-0">Failed Records</h6>
                                <h2 class="my-2">{{ batch.failed_count }}</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card tilebox-one">
                            <div class="card-body">
                                <i class="mdi mdi-check float-right text-success"></i>
                                <h6 class="text-uppercase mt-0"> Upload Success</h6>
                                <h2 class="my-2">{{ batch.upload_success }}</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card tilebox-one">
                            <div class="card-body">
                                <i class="mdi mdi-close float-right text-danger"></i>
                                <h6 class="text-uppercase mt-0"> Upload Errors</h6>
                                <h2 class="my-2">{{ batch.upload_error }}</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card tilebox-one">
                            <div class="card-body">
                                <i class="mdi mdi-cash float-right text-primary"></i>
                                <h6 class="text-uppercase mt-0"> Batch Total</h6>
                                <h2 class="my-2">{{ batch.total }}</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card tilebox-one">
                            <div class="card-body">
                                <i class="mdi mdi-cash float-right text-success"></i>
                                <h6 class="text-uppercase mt-0"> Batch Debited</h6>
                                <h2 class="my-2">{{ batch.total_debited }}</h2>
                            </div>
                        </div>
                    </div>
                </div>
                <page-index name="Transactions" :url="`/batch/${$route.params.id}/transactions`" prefix="transactions">
                    <template slot="table-header">
                        <th>ID</th>
                        <th>Account</th>
                        <th>Amount</th>
                        <th>Reference</th>
                        <th>Type</th>
                        <th>Mode</th>
                        <th>Date</th>
                        <th class="text-center"></th>
                    </template>
                    <template slot="table-row" slot-scope="data">
                        <td>
                            <span class="text-primary">#{{ data.row.id }}</span>
                        </td>
                        <td>
                            account : <strong>{{ data.row.account.account  }} </strong> <br>
                            currency : <strong>{{ data.row.account.currency.name  }} </strong>
                        </td>
                        <td> <span class="text-primary font-weight-bolder">${{ data.row.amount }}</span> </td>
                        <td>
                            reference : {{ data.row.reference ? data.row.reference  : 'Not Available' }} <br>
                            state : <span class="font-weight-bolder"> {{ data.row.status.description}} </span> <br>
                            <span v-if="data.row.state === 96 || data.row.state === 3">
                                error : <span class="font-weight-bolder"> {{ data.row.error }} </span>
                            </span>

                        </td>
                        <td>
                            <span class="badge badge-light p-2">{{ data.row.type }}</span> <br>
                        </td>
                        <td>
                            <span class="badge badge-light p-2"> {{ data.row.batch ? 'batch' : 'single' }} </span>
                        </td>

                        <td> created : {{ data.row.created_at }} <br>  updated : {{ data.row.read_updated }} </td>
                        <td>
                            <router-link :to="`/transactions/${data.row.component}/${data.row.id}/view`" class="action-icon text-primary">
                                <i class="mdi mdi-eye mdi-24px"/>
                            </router-link>
                        </td>
                    </template>
                </page-index>
            </div>
        </div>
    </div>

</template>
