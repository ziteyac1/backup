<template>
    <page-index name="Batch Transfers" url="/batch" prefix="batches">
        <template slot="actions">
            <a target="_blank" href="/batch/codes" class="btn btn-primary ml-2 my-1">
                <i class="mdi mdi-download mr-1"></i>Bank Codes
            </a>
            <a target="_blank" href="/batch/sample" class="btn btn-primary ml-2 my-1">
                <i class="mdi mdi-download mr-1"></i>Download Sample
            </a>
            <router-link to="/batch/upload" class="btn btn-primary ml-2 my-1">
                <i class="mdi mdi-upload mr-1"></i>Upload Batch
            </router-link>
        </template>

        <template slot="table-header">
            <th></th>
            <th>Info</th>
            <th>Batch</th>
            <th>Status</th>
            <th>Dates</th>
            <th class="text-center"></th>
        </template>
        <template slot="table-row" slot-scope="data">
            <td>
                <span class="text-primary">#{{ data.row.id }}</span>
            </td>
            <td>
                Account : {{ data.row.account.account }}  - {{ data.row.account.currency.name }} <br>
                User : {{ data.row.user.full_name  }}
            </td>
            <td>
               File :  {{ data.row.name | string_limit }} <br>
               Reference : {{ data.row.reference }}
            </td>
            <td>
                <span class="badge badge-light p-2">{{ data.row.state.description }}</span>
            </td>
            <td>
                created : {{ data.row.created_at }} <br> updated : {{ data.row.updated_at }}
            </td>

            <td>
                <router-link :to="`/batch/${data.row.id}/view`" class="action-icon text-primary">
                    <i class="mdi mdi-eye mdi-24px"/>
                </router-link>
            </td>
        </template>

    </page-index>
</template>

<script>
    import PageIndex from "../core/page-index";
    export default {
        name: "index",
        components: {PageIndex}
    }
</script>

