<script>
    import Form from "../../core/forms/form";
    import DataSelect from "../core/DataSelect";
    import MultiDataSelect from "../core/MultiDataSelect";
    import RolesSelect from "../roles/select";
    export default {
        name: "institutions-form",
        components: {RolesSelect, MultiDataSelect, DataSelect},
        props: [ 'edit' , 'id' ],
        data(){
            return {
                currencies : [],
                form : new Form({
                    account : '',
                    currency_id : '',
                    types : []

                  } , {
                    types : []
                }),
            };
        },
        mounted() {
            if (this.edit)
            {
                this.init();
            }
            this.load();
        },
        methods: {
            load()
            {
                this.form.loading = true;
                window.axios.get(`/currencies`).then((response) => {
                    this.currencies = response.data.body.currencies;
                }).finally(() => {
                    this.form.loading = false;
                });
            },
            init()
            {
                this.form.loading = true;
                window.axios.get(`/accounts/${this.id}/view`).then((response) => {
                    this.form.extract(response.data.body.model);
                    this.form.store('types',response.data.body.model);
                }).finally(() => {
                    this.form.loading = false;
                });
            },
            create()
            {
                this.form.submit(this.edit ? `/accounts/${this.id}/update`  : `/accounts/${this.$route.query.parent}/${this.$route.query.type}/create`).then((response) => {
                    window.alerts.success(response).then((response) => {
                        if (this.$route.query.type && this.$route.query.parent)
                        this.$router.push(`/${this.$route.query.type}/${this.$route.query.parent}/view`);
                    });
                }).catch((error) => {
                }).finally(() => {
                });
            }
        }
    }
</script>
<template>
    <div class="row pt-3">
        <div class="col-lg-12">
            <div :class="['dimmer' , form.loading ? 'active' : '']">
                <div class="loader"></div>
                <div class="dimmer-content">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="mb-3"> {{ this.edit ? 'Edit' : 'Create' }}  Account</h4>
                            <div class="form-horizontal">
                                <div class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Account</label>
                                    <div class="col-lg-9">
                                        <input type="text" name="account" v-model="form.account" :class="[ 'form-control mw-400' , form.errors.get('account') ? 'is-invalid' : '' ]" placeholder="Account"/>
                                        <div v-text="form.errors.get('account')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Currency</label>
                                    <div class="col-lg-9">
                                        <select type="email" name="currency_id" v-model="form.currency_id" :class="[ 'form-control mw-400' , form.errors.get('currency_id') ? 'is-invalid' : '' ]">
                                            <option value="">Choose Currency</option>
                                            <option v-for="currency in currencies" :key="currency.id" v-text="currency.name" :value="currency.id"/>
                                        </select>
                                        <div v-text="form.errors.get('currency_id')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <!--<div class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Transaction Types</label>
                                    <div class="col-lg-9">
                                        <multi-data-select select="name" :start="form.storage.types"  v-model="form.types" name="Types" url="/types" prefix="types">
                                            <template slot="select" slot-scope="data">
                                                <roles-select :data="data"/>
                                            </template>
                                        </multi-data-select>
                                        <div v-text="form.errors.get('types')" class="text-danger font-12"/>
                                    </div>
                                </div>-->
                                <div class="form-group mb-0 justify-content-end row">
                                    <div class="col-lg-9">
                                        <button type="submit" @click.prevent="create" :class="['btn btn-primary' , form.loading ? 'btn-loading' : '']">{{ this.edit ? 'Edit' : 'Create' }} Account</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>
