<script>
    export default {
        name: "user-view",
        data() {
            return {
                account: {
                    currency : {},
                    types : [],
                },
                loading: true
            };
        },
        methods : {
            action(action)
            {
                window.action(action , 'Account' , `${window.location.origin}/accounts/${this.$route.params.id}/${action}`).then((response) => {
                    this.account = response.data.body.model;
                });
            },
            init(){
                this.loading = true;
                window.axios.get(`${window.location.origin}/accounts/${this.$route.params.id}/view`).then((response) => {
                    this.account = response.data.body.model;
                }).finally(() => {
                    this.loading = false;
                });
            }
        },
        mounted() {
            this.init();
        }
    }
</script>
<template>
    <div :class="['dimmer' , loading ? 'active' : '']">
        <div class="loader"></div>
        <div class="dimmer-content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card ribbon-box ">
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-3 flex-wrap">
                                <h4 class="header-title m-0 flex-fill">Account Information</h4>
                                <div class="">
                                    <button v-if="!account.status" @click="action('activate')" type="button" class="btn btn-light m-1">
                                        <i class="mdi mdi-lightbulb-outline mr-1"></i> Activate
                                    </button>
                                    <button v-if="account.status" @click="action('deactivate')"  type="button" class="btn btn-light m-1">
                                        <i class="mdi mdi-lightbulb-off-outline mr-1"></i> De-Activate
                                    </button>
                                </div>
                            </div>
                            <div class="text-left">
                                <p>
                                    <strong class="mr-2">Number :</strong>
                                    <span>{{ account.account }}</span>
                                </p>
                                <p>
                                    <strong class="mr-2">Currency :</strong>
                                    <span>{{ account.currency.name }}</span>
                                </p>
                                <p v-if="account.types.length > 0">
                                    <strong class="mr-2">Transaction Types :</strong>
                                    <span> <span v-for="row in account.types" class="badge badge-light p-2 m-1 font-12">{{ row.name }}</span></span>
                                </p>
                                <p>
                                    <strong class="mr-2"> Parent :</strong>
                                    <router-link :to="`/${account.route}/${account.account_id}/view`" class="badge badge-light p-2 m-1 font-12 text-primary">{{ account.type }}</router-link>
                                </p>
                                <p>
                                    <strong class="mr-2">Created :</strong>
                                    <span>{{ account.created_at }}</span>
                                </p>
                                <p>
                                    <strong class="mr-2">Status :</strong>
                                    <span> <span class="badge badge-light p-2 font-12">{{ account.status ? 'activated' : 'de-activated' }}</span></span>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</template>
