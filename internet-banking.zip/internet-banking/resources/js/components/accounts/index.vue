<template>
    <page-index name="Accounts" url="/accounts" prefix="accounts">
        <template slot-scope="data" slot="filters">
            <div>
                <div class="form-group mr-3 my-1">
                    <select v-model="data.filters['status']" class="custom-select">
                        <option :value="undefined">Choose Type</option>
                        <option value="pending">Activated</option>
                        <option value="completed">De-Activated</option>
                    </select>
                </div>
            </div>
        </template>
        <template slot="table-header">
            <th>ID</th>
            <th>Account</th>
            <th>Currency</th>
            <th>Type</th>
            <th>Status</th>
            <th>Date</th>
            <th class="text-center"></th>
        </template>
        <template slot="table-row" slot-scope="data">
            <td>
                <span class="text-primary">#{{ data.row.id }}</span>
            </td>
            <td>{{ data.row.account }}</td>
            <td>{{ data.row.currency.name }}</td>
            <td><span class="badge badge-light p-2">{{ data.row.type }}</span></td>
            <td><span> <span class="badge badge-light p-2 font-12">{{ data.row.status ? 'activated' : 'de-activated' }}</span></span></td>
            <td>{{ data.row.created_at }}</td>
            <td>
                <router-link :to="`/accounts/${data.row.id}/view`" class="action-icon text-primary">
                    <i class="mdi mdi-eye mdi-24px"/>
                </router-link>
            </td>
        </template>
    </page-index>
</template>

<script>
    import PageIndex from "../core/page-index";
    export default {
        name: "index",
        components: {PageIndex},
        data(){
            return {
                win : window
            }
        }
    }
</script>

