<script>
    import InstitutionsForm from "./form";
    export default {
        components: {InstitutionsForm}
    }
</script>
<template>
    <institutions-form :edit="false"/>
</template>
