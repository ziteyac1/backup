<template>
    <page-index name="Authorisations" url="/authorisations" prefix="authorisations">
        <template slot-scope="data" slot="filters">
            <div>
                <div class="form-group mr-3 my-1">
                    <select v-model="data.filters['status']" class="custom-select">
                        <option :value="undefined">Choose Type</option>
                        <option value="pending">Activated</option>
                        <option value="completed">De-Activated</option>
                    </select>
                </div>
            </div>
        </template>
        <template slot="table-header">
            <th>ID</th>
            <th>Info</th>
            <th>State</th>
            <th>Type</th>
            <th>Date</th>
            <th class="text-center"></th>
        </template>
        <template slot="table-row" slot-scope="data">
            <td>
                <span class="text-primary">#{{ data.row.id }}</span>
            </td>
            <td v-if="data.row.type === 'batch'">
                File :  <strong>  {{ data.row.authorisation.name | string_limit }} </strong><br>
                Reference : <strong>  {{ data.row.authorisation.reference }} </strong><br>
                Number of Authorisations  :  <strong> {{ data.row.number }}</strong>
            </td>
            <td v-if="data.row.type === 'transaction'">
                <span>Transaction Type :  <strong> {{ data.row.authorisation.type }}</strong></span> <br>
                Number of Authorisations  :  <strong> {{ data.row.number }}</strong>
            </td>
            <td>
                <span class="badge badge-light p-2">{{ data.row.completed ? 'Authorisation Completed' : 'Authorisation Pending' }}</span> <br>
            </td>
            <td>
                <span class="badge badge-light p-2">{{ data.row.type }}</span> <br>
            </td>
            <td> created : {{ data.row.created_at }} <br>  updated : {{ data.row.read_updated }} </td>
            <td>
                <router-link v-if="data.row.type === 'batch'" :to="`/batch/${data.row.authorisation_id}/view`" class="action-icon text-primary">
                    <i class="mdi mdi-eye mdi-24px"/>
                </router-link>
                <router-link v-if="data.row.type === 'transaction'" :to="`/transactions/${data.row.authorisation.component}/${data.row.authorisation_id}/view`" class="action-icon text-primary">
                    <i class="mdi mdi-eye mdi-24px"/>
                </router-link>
            </td>
        </template>
    </page-index>
</template>

<script>
    import PageIndex from "../core/page-index";
    export default {
        name: "index",
        components: {PageIndex},
        data(){
            return {
                win : window
            }
        }
    }
</script>

