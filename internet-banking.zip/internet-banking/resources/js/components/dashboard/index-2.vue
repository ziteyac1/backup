<script>
    import Can from "../core/can";
    import VueApexCharts from 'vue-apexcharts';
    export default {
        name: "index",
        components: {
            Can,
            apexchart: VueApexCharts,
        },
        data(){
            return {
               statistics : {},
               loading : false,
               statementLoading : false,
               accounts : [],
               series: [{
                    name: "Balance",
                    data: []
                }],
               chartOptions: {
                    xaxis: {
                        categories: [],
                        labels: {
                            show: true,
                            maxHeight: 120,
                            style: {
                                colors: [],
                                fontSize: '8px',
                                fontWeight: 400,
                                cssClass: 'apexcharts-xaxis-label',
                            },
                        }
                    },
                    chart: {
                        type: 'line',
                        dropShadow: {
                            enabled: true,
                            color: '#1c4b27',
                            top: 18,
                            left: 7,
                            blur: 10,
                            opacity: 0.4
                        },
                        toolbar: {
                            show: false
                        },
                        zoom: {
                            enabled: true,
                        }
                    },
                    colors: ['#1c4b27'],
                    dataLabels: {
                        enabled: false

                    },
                    stroke: {
                        curve: 'smooth',
                        width: 3,
                    },
                    title: {
                        text: 'RUNNING BALANCE',
                        align: 'center',
                        color : '#6c757d',
                    },
                    grid: {
                        row: {
                            colors: ['transparent'],
                        },
                    },

                },
               statement : {
                    running_balance_values : [],
                    running_balance_dates : [],
                    transaction_types : [],
                    account : {
                        currency : {},
                        data : {}
                    }
                },
               auth : window.user,
            };
        },
        mounted() {
            this.init();
        },
        methods : {
            init()
            {
                this.loading = true;
                window.axios.get(`${window.location.origin}/dashboard`).then((response) => {
                    this.accounts = response.data.body.accounts;
                }).finally(() => {
                    this.loading = false;
                });

                this.statementLoading = true;
                window.axios.get(`${window.location.origin}/dashboard/statement`).then((response) => {
                    this.statement = response.data.body.statement;
                    if (this.statement)
                    {
                        this.series = [{
                            name: "Balance",
                            data: this.statement.running_balance_values
                        }];

                        this.chartOptions.xaxis.categories = this.statement.running_balance_dates;
                    }

                }).finally(() => {
                    this.statementLoading = false;
                });

            }
        }
    }
</script>
<template>
    <div class="p-3">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <h4 class="page-title">Quick Links</h4>
                </div>
            </div>
            <can permission="input-transactions" :override="!auth.is_corporate">
                <div class="col-12">
                    <div class="row">
                        <div class="col-md-6 col-xl-3">
                            <router-link to="/transactions/internal" class="card">
                                <div class="card-body py-0">
                                    <div class="d-flex align-items-center px-3 py-1">
                                        <div class="flex-fill">
                                            <h5 class="my-2 py-1 text-center">InternalTransfer </h5>
                                        </div>
                                        <div class="">
                                            <i class="font-32 uil-scroll text-primary"></i>
                                        </div>
                                    </div>
                                </div>
                            </router-link>
                        </div>
                        <div class="col-md-6 col-xl-3">
                            <router-link to="/transactions/rtgs" class="card">
                                <div class="card-body py-0">
                                    <div class="d-flex align-items-center px-3 py-1">
                                        <div class="flex-fill">
                                            <h5 class="my-2 py-1 text-center">RTGS Transfer </h5>
                                        </div>
                                        <div class="">
                                            <i class="font-32 uil-sort display-4 text-primary"></i>
                                        </div>
                                    </div>
                                </div>
                            </router-link>
                        </div>
                        <div class="col-md-6 col-xl-3">
                            <router-link to="/batch" class="card">
                                <div class="card-body py-0">
                                    <div class="d-flex align-items-center px-3 py-1">
                                        <div class="flex-fill">
                                            <h5 class="my-2 py-1 text-center">Batch Transfer </h5>
                                        </div>
                                        <div class="">
                                            <i class="font-32 uil-folder-upload display-4 text-primary"></i>
                                        </div>
                                    </div>
                                </div>
                            </router-link>
                        </div>
                        <div class="col-md-6 col-xl-3">
                            <router-link to="/statement" class="card">
                                <div class="card-body py-0">
                                    <div class="d-flex align-items-center px-3 py-1">
                                        <div class="flex-fill">
                                            <h5 class="my-2 py-1 text-center">Statement Enquiry </h5>
                                        </div>
                                        <div class="">
                                            <i class="font-32 uil-receipt display-4 text-primary"></i>
                                        </div>
                                    </div>
                                </div>
                            </router-link>
                        </div>
                    </div>
                </div>
            </can>
            <div v-if="auth.accounts.length > 0" class="col-12">
                <div class="page-title-box">
                    <div class="page-title d-flex align-items-center justify-content-between">
                        <div>Accounts</div>
                        <button @click="init" :class="['btn btn-primary mr-1' , loading ? 'btn-loading' : '']">Refresh</button>
                    </div>
                </div>
            </div>
            <div v-if="auth.accounts.length > 0" class="col-12">
                <div :class="['dimmer min-h-360px' , loading ? 'active' : '']">
                    <div class="loader"></div>
                    <div class="dimmer-content">
                        <div v-for="account in accounts" class="row">
                            <div class="col-lg-4">
                                <div class="card h-360px ">
                                    <div v-if="account.enquiry">
                                        <div class="h6 text-muted px-3 py-2 my-0">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="text-uppercase">Last Update</div>
                                                <div class="text-right">
                                                    {{ account.enquiry.read_created }} <br>
                                                    <small>
                                                        <strong>{{ account.enquiry.read_ago }} </strong>
                                                    </small>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="">
                                            <div class="bg-light py-3">
                                                <h2 class="text-center my-0">{{ account.enquiry.account }}</h2>
                                            </div>
                                            <div class="card-body pt-0">
                                                <div class="d-flex flex-wrap align-items-center justify-content-between py-2">
                                                    <div class="text-muted font-weight-bolder font-12">Balance</div>
                                                    <div class=""><strong>{{ account.enquiry.balance }}</strong></div>
                                                </div>
                                                <div class="d-flex flex-wrap align-items-center justify-content-between py-2">
                                                    <div class="text-muted font-weight-bolder font-12">Branch</div>
                                                    <div class=""><strong>{{ account.enquiry.branch | string_limit }}</strong></div>
                                                </div>
                                                <div class="d-flex flex-wrap align-items-center justify-content-between py-2">
                                                    <div class="text-muted font-weight-bolder font-12">Currency</div>
                                                    <div class=""><strong>{{ account.enquiry.currency }}</strong></div>
                                                </div>
                                                <div class="d-flex flex-wrap align-items-center justify-content-between py-2">
                                                    <div class="text-muted font-weight-bolder font-12">Type</div>
                                                    <div class=""><strong>{{ account.enquiry.type }}</strong></div>
                                                </div>
                                                <div class="d-flex flex-wrap align-items-center justify-content-between py-2">
                                                    <div class="text-muted font-weight-bolder font-12">Name</div>
                                                    <div class=""><strong>{{ account.enquiry.name | string_limit }}</strong></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div v-else class="d-flex justify-content-center align-items-center h-100">
                                        <h5 class="text-center">
                                            Internet Banking <br> Offline
                                        </h5>
                                    </div>

                                </div>
                            </div>
                            <div class="col-lg-8">
                                <div class="card h-360px overflow-auto">
                                    <div class="">
                                        <h6 class="mb-3 text-muted px-3 py-2 text-uppercase">Recent Transactions</h6>
                                    </div>
                                    <div class="table-responsive font-12">
                                        <table class="table table-centered">
                                            <thead class="thead-light">
                                            <tr>
                                                <th/>
                                                <th/>
                                                <th>Date</th>
                                                <th>Reference</th>
                                                <th>State</th>
                                                <th>Type</th>
                                                <th>Amount</th>
                                                <th/>
                                                <th/>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr v-for="transaction in account.transactions">
                                                <td/>
                                                <td class="text-primary">#{{ transaction.id }}</td>
                                                <td>
                                                    {{ transaction.created_at }}
                                                </td>
                                                <td class="font-weight-bolder">
                                                    {{ ( transaction.reference ? transaction.reference   : 'Not Available' ) | string_limit(10)  }}
                                                </td>
                                                <td class="font-weight-bolder">
                                                    {{ transaction.status.description | string_limit(10) }}
                                                </td>
                                                <td>
                                                    <span class="badge badge-light p-2">  {{ transaction.type }}</span>
                                                </td>
                                                <td>
                                                    <span class="text-primary font-weight-bolder"> {{ transaction.amount }}</span>
                                                </td>
                                                <td>
                                                    <router-link :to="`/transactions/${transaction.component}/${transaction.id}/view`" class="action-icon text-muted">
                                                        <i class="mdi mdi-eye mdi-24px"/>
                                                    </router-link>
                                                </td>
                                                <td/>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div v-if="statement && auth.accounts.length > 0 && !statementLoading" class="col-12">
            <div class="page-title-box d-flex align-items-center justify-content-between">
                <h4 class="page-title">Last Statement Run</h4>
                <h4 class="page-title">{{ statement.account.account }} - {{ statement.date_start }} : {{ statement.date_end }} </h4>
            </div>
        </div>
        <div v-if="statement && auth.accounts.length > 0 && !statementLoading" class="col-12">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card widget-inline">
                        <div class="card-body p-0">
                            <div class="row no-gutters">
                                <div class="col-sm-6 col-xl-2">
                                    <div class="card shadow-none m-0">
                                        <div class="card-body text-center text-primary">
                                            <h3><span>{{ statement.debits_count }}</span></h3>
                                            <p class="text-muted font-15 mb-0">Debits Count</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-6 col-xl-4">
                                    <div class="card shadow-none m-0 border-left text-primary">
                                        <div class="card-body text-center">
                                            <h3><span>$ {{ statement.debits }}</span></h3>
                                            <p class="text-muted font-15 mb-0">Debits Total </p>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-6 col-xl-4">
                                    <div class="card shadow-none m-0 border-left">
                                        <div class="card-body text-center text-primary">
                                            <h3><span>$ {{ statement.credits }}</span></h3>
                                            <p class="text-muted font-15 mb-0">Total Credits</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-6 col-xl-2">
                                    <div class="card shadow-none m-0 border-left">
                                        <div class="card-body text-center text-primary">
                                            <h3><span>{{ statement.credits_count }}</span></h3>
                                            <p class="text-muted font-15 mb-0">Credits Count</p>
                                        </div>
                                    </div>
                                </div>

                            </div> <!-- end row -->
                        </div>
                    </div> <!-- end card-box-->
                </div>
                <div class="col-lg-8">
                    <div  style="max-height: 400px;min-height: 400px;"  class="card">
                        <div :class="['card-body' , statement.running_balance_values.length > 4 ? '' : 'd-flex align-items-center justify-content-center']" style="position: relative">
                            <apexchart v-if="statement.running_balance_values.length > 4" type="line" height="350"  :options="chartOptions" :series="series"></apexchart>
                            <div v-else class="text-center text-muted">
                                <i class="mdi mdi-alert-circle display-1"></i>
                                <h1>No Enough Data</h1>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card" style="max-height: 400px;min-height: 400px;">
                        <h5 class="pt-3 text-center">BALANCE MOVEMENT</h5>
                        <div class="card-body d-flex flex-column justify-content-between align-items-center pb-4 pt-0">
                            <div class="text-center mt-3">
                                <h2 class="font-weight-normal mb-0">
                                    <span>{{ statement.start }}</span>
                                </h2>
                                <span class="text-muted"><small><strong>Start Balance</strong></small></span>
                            </div>
                            <div class="text-center h1 font-weight-light">
                                <span :class="['mr-2' , statement.change >= 0  ? 'text-success' : 'text-danger' ]"><i :class="['mdi' , statement.change >= 0  ? 'mdi-arrow-up-bold' : 'mdi-arrow-down-bold']"></i>{{ statement.change }}%</span>
                            </div>
                            <div class="text-center">
                                <h2 class="font-weight-normal mb-0">
                                    <span>{{ statement.end }}</span>
                                </h2>
                                <span class="text-muted"><small><strong>End Balance</strong></small></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-body pb-0">
                            <h4 class="header-title mb-3 text-center">Transactions Types</h4>
                        </div>
                        <div style="max-height: 280px;min-height: 280px;overflow: auto">
                            <div class="table-responsive">
                                <table class="table mb-0">
                                    <thead class="thead-light">
                                    <tr>
                                        <th/>
                                        <th>Type</th>
                                        <th class="text-center">Count</th>
                                        <th class="text-right">Total</th>
                                        <th/>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr v-for="item in statement.transaction_types">
                                        <td/>
                                        <td>{{ item.name }}</td>
                                        <td class="text-center">{{ item.count }}</td>
                                        <td class="text-right">$ {{ item.sum }}</td>
                                        <td/>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-body pb-0">
                            <h4 class="header-title mb-3 text-center">Statistics</h4>
                        </div>
                        <div class="d-flex flex-column justify-content-between align-items-center pb-4" style="max-height: 280px;min-height: 280px;overflow: auto">
                            <div class="text-center">
                                <h2 class="font-weight-normal mb-0">
                                    <span>$ {{ statement.min }}</span>
                                </h2>
                                <span class="text-muted"><small><strong>Min</strong></small></span>
                            </div>
                            <div class="text-center">
                                <h2 class="font-weight-normal mb-0">
                                    <span>$ {{ statement.average }}</span>
                                </h2>
                                <span class="text-muted"><small><strong>Average</strong></small></span>
                            </div>
                            <div class="text-center">
                                <h2 class="font-weight-normal mb-0">
                                    <span>${{ statement.max }}</span>
                                </h2>
                                <span class="text-muted"><small><strong>Max</strong></small></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">Contact</h4>
            </div>
        </div>
        <div class="col-12">
            <div class="row">
                <div class="col-lg-4">
                    <div class="card text-white bg-primary overflow-hidden">
                        <div class="card-body">
                            <div class="toll-free-box text-center">
                                <h4> <i class="mdi mdi-headset"></i>  customersupport@agribank.co.zw</h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card text-white bg-primary overflow-hidden">
                        <div class="card-body">
                            <div class="toll-free-box text-center">
                                <h4> <i class="mdi mdi-deskphone"></i> Need help ? Call  : 086 77 202 202 </h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card text-white bg-primary overflow-hidden">
                        <div class="card-body">
                            <div class="toll-free-box text-center">
                                <h4> <i class="mdi mdi-headset"></i>0712 837 436 | 0772 303 572</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
