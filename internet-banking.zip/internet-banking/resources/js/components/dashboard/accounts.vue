<script>
    export default {
        name: "index",
        data() {
            return {
                accounts: window.user.working,
                account: '',
                auth: window.user,
                info: {},
                accountsLoading: false,
                cardsLoading: false,
                transactionsLoading: false,
                cards: [],
                card: {},
                transactions: [],
                account_details: {},
            }
        },
        mounted() {
            if (this.accounts.length > 0) {
                this.account = this.accounts[0].id
            }
        },
        computed: {
            loading: function () {
                return this.accountsLoading || this.cardsLoading || this.transactionsLoading;
            }
        },
        watch: {
            account: function (n, o) {
                this.accountsLoading = true;
                window.axios.get(`${window.location.origin}/dashboard/${n}/account/details`).then((response) => {
                    this.account_details = response.data.body.details;
                }).finally(() => {
                    this.accountsLoading = false;
                });

                this.cardsLoading = true;
                this.cards = [];
                window.axios.get(`${window.location.origin}/dashboard/${n}/account/cards`).then((response) => {
                    this.cards = response.data.body.cards;
                    if (this.cards.length > 0) {
                        this.card = this.cards[0]
                    }
                }).finally(() => {
                    this.cardsLoading = false;
                });
            },
            card: function (n, o) {
                this.transactionsLoading = true;
                window.axios.post(`${window.location.origin}/dashboard/card/transactions`, n).then((response) => {
                    this.transactions = response.data.body.transactions;
                }).finally(() => {
                    this.transactionsLoading = false;
                });
            }
        },
    }
</script>
<template>
    <div class="py-3">
        <div class="row">
            <div class="col-lg-12">
                <div :class="['dimmer' , accountsLoading ? 'active' : '']">
                    <div class="loader"></div>
                    <div class="dimmer-content">
                        <div class="card">
                            <div class="d-flex align-items-center border-bottom p-3">
                                <h4 class="header-title flex-fill m-0">Account Info</h4>
                                <div class="">
                                    <select v-model="account" name="" :disabled="accounts.length < 2" class="form-control" id="">
                                        <option v-for="item in accounts" :value="item.id">{{ item.account }} - {{ item.currency.name }}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="card-body">
                                <div v-if="account_details" class="row align-items-center mt-2 flex-fill">
                                    <div class="col-6 border-right font-12 text-capitalize">
                                        <span class="text-muted">Name : </span> <strong class="ml-2">{{ account_details.name | string_limit(25) }} </strong> <br>
                                        <span class="text-muted">Branch : </span> <strong class="ml-2">{{ account_details.branch | string_limit(25) }} </strong> <br>
                                        <span class="text-muted">Currency : </span> <strong class="ml-2">{{ account_details.currency | string_limit(25) }} </strong> <br>
                                        <span class="text-muted">Type : </span> <strong class="ml-2">{{ account_details.type | string_limit(25) }} </strong> <br>
                                        <span class="text-muted">Account : </span> <strong class="ml-2">{{ account_details.account | string_limit(25) }} </strong> <br>
                                    </div>
                                    <div class="col-6 text-center">
                                        <strong style="font-size: 25px">{{ account_details.balance }}</strong> <br>
                                        <small>Last Updated : {{ account_details.read_ago }} </small>
                                    </div>
                                </div>
                                <div v-else class="d-flex card-body justify-content-center align-items-center h-100">
                                    <h5 class="text-center">
                                        Internet Banking <br> Offline
                                    </h5>
                                </div>
                                <div v-if="account_details.currency === 'USD'">
                                    <router-link :to="`/transactions/liquidate/${account_details.account}/funds`">
                                        <button type="button" class="form-control btn btn-primary col-3"><i data-feather="printer"></i>Liquidate Funds</button>
                                    </router-link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div style="min-height: 500px" class="col-lg-12">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="row">
                            <div class="col-12">
                                <div :class="['dimmer' , cardsLoading ? 'active' : '']">
                                    <div class="loader"></div>
                                    <div class="dimmer-content">
                                        <div class="card">
                                            <div class="d-flex align-items-center border-bottom p-3">
                                                <h4 class="header-title flex-fill m-0">Card Info</h4>
                                                <div class="">
                                                    <select v-model="card" class="form-control">
                                                        <option :value="item" v-for="item in cards"> {{ item.card }} - {{ item.expiry }} </option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="card-body text-primary d-flex align-items-center">
                                                <i class="mdi mdi-credit-card mdi-24px mr-2"></i>
                                                <div class=""><span class="font-24">{{ card.card }} </span><br><small>Card</small></div>
                                                <div class="ml-auto text-right"><span class="font-24">{{ card.expiry }}</span><br><small>Expiry</small></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div :class="['dimmer' , transactionsLoading ? 'active' : '']">
                                    <div class="loader"></div>
                                    <div class="dimmer-content">
                                        <div class="card">
                                            <div class="card-body">
                                                <h4 class="header-title flex-fill m-0">Recent Card Transactions</h4>
                                            </div>
                                            <div class="table-responsive font-12">
                                                <table class="table table-centered">
                                                    <thead class="thead-light">
                                                    <tr>
                                                        <th/>
                                                        <th>Date</th>
                                                        <th>Pan</th>
                                                        <th>Type</th>
                                                        <th>Reference</th>
                                                        <th>Location</th>
                                                        <th>Amount</th>
                                                        <th/>
                                                        <th/>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <tr v-for="transaction in transactions">
                                                        <td/>
                                                        <td> {{ transaction.date }} </td>
                                                        <td> {{ transaction.pan }} </td>
                                                        <td> {{ transaction.type }} </td>
                                                        <td> {{ transaction.ref }} </td>
                                                        <td> {{ transaction.location }} </td>
                                                        <td> {{ transaction.amount }} </td>
                                                        <td/>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
