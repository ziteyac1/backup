<script>
    import Can from "../core/can";
    import VueApexCharts from 'vue-apexcharts';
    export default {
        name: "index",
        components: {
            Can,
            apexchart: VueApexCharts,
        },
        mounted() {
            this.init();
            if (this.accounts.length > 0)
            {
                this.account = this.accounts[0].id
            }
        },
        data(){
            return {
                account : '',
                transactions : [],
                account_details : {
                    cards : [],
                },
                statistics : {},
                quote : '',
                loading : false,
                statementLoading : false,
                transactionsLoading : false,
                accounts : window.user.working ,
                series: [{
                    name: "Balance",
                    data: []
                }],
                chartOptions: {
                    xaxis: {
                        categories: [],
                        labels: {
                            show: true,
                            maxHeight: 120,
                            style: {
                                colors: [],
                                fontSize: '8px',
                                fontWeight: 400,
                                cssClass: 'apexcharts-xaxis-label',
                            },
                        }
                    },
                    chart: {
                        type: 'line',
                        dropShadow: {
                            enabled: true,
                            color: '#1c4b27',
                            top: 18,
                            left: 7,
                            blur: 10,
                            opacity: 0.4
                        },
                        toolbar: {
                            show: false
                        },
                        zoom: {
                            enabled: true,
                        }
                    },
                    colors: ['#1c4b27'],
                    dataLabels: {
                        enabled: false

                    },
                    stroke: {
                        curve: 'smooth',
                        width: 3,
                    },
                    title: {
                        text: 'RUNNING BALANCE',
                        align: 'center',
                        color : '#6c757d',
                    },
                    grid: {
                        row: {
                            colors: ['transparent'],
                        },
                    },

                },
                statement : {
                    transaction : {},
                    running_balance_values : [],
                    running_balance_dates : [],
                    transaction_types : [],
                    account : {
                        currency : {},
                        data : {}
                    }
                },
               auth : window.user,
            };
        },

        watch : {
            account : function (n , o)
            {
                this.loading = true;
                window.axios.get(`${window.location.origin}/dashboard/${n}/details`).then((response) => {
                        this.account_details = response.data.body.details;
                }).finally(() => {
                    this.loading = false;
                });

            }
        },
        methods : {
            init()
            {
                this.statementLoading = true;
                window.axios.get(`${window.location.origin}/dashboard/statement`).then((response) => {
                    this.statement = response.data.body.statement;
                    if (this.statement)
                    {
                        this.series = [{
                            name: "Balance",
                            data: this.statement.running_balance_values
                        }];

                        this.chartOptions.xaxis.categories = this.statement.running_balance_dates;
                    }
                }).finally(() => {
                    this.statementLoading = false;
                });

                this.transactionsLoading = true;
                window.axios.get(`${window.location.origin}/dashboard/transactions`).then((response) => {
                    this.transactions = response.data.body.transactions;
                }).finally(() => {
                    this.transactionsLoading = false;
                });

            }
        },
    }
</script>
<template>
    <div class="py-3">
        <div class="row">
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="min-h-135px card cta-box bg-primary text-white">
                            <div class="card-body">
                                <div class="media align-items-center">
                                    <div class="media-body">
                                        <h3 class="m-0 font-weight-normal cta-box-title">Welcome back , <b> {{ auth.name }} {{ auth.last_name }} </b> <br> Agribank 365 Banking</h3>
                                        <p class="mt-2">Stay home and Bank with us <br></p>
                                    </div>
                                    <img class="ml-3" src="/assets/images/email-campaign.svg" width="120" alt="Generic placeholder image">
                                </div>
                            </div>
                            <!-- end card-body -->
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <can permission="input-transactions" :override="!auth.is_corporate">
                            <div class="col-12">
                                <div class="row">
                                    <div class="col-md-6">
                                        <router-link to="/transactions/internal" class="card">
                                            <div class="card-body py-0">
                                                <div class="d-flex align-items-center px-3 py-1">
                                                    <div class="flex-fill">
                                                        <h5 class="my-2 py-1 text-center">InternalTransfer </h5>
                                                    </div>
                                                    <div class="">
                                                        <i class="font-28  uil-scroll text-primary"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </router-link>
                                    </div>
                                    <div class="col-md-6">
                                        <router-link to="/transactions/rtgs" class="card">
                                            <div class="card-body py-0">
                                                <div class="d-flex align-items-center px-3 py-1">
                                                    <div class="flex-fill">
                                                        <h5 class="my-2 py-1 text-center">RTGS Transfer </h5>
                                                    </div>
                                                    <div class="">
                                                        <i class="font-28  uil-sort display-4 text-primary"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </router-link>
                                    </div>
                                    <div class="col-md-6 ">
                                        <router-link to="/batch" class="card">
                                            <div class="card-body py-0">
                                                <div class="d-flex align-items-center px-3 py-1">
                                                    <div class="flex-fill">
                                                        <h5 class="my-2 py-1 text-center">Batch Transfer </h5>
                                                    </div>
                                                    <div class="">
                                                        <i class="font-28  uil-folder-upload display-4 text-primary"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </router-link>
                                    </div>
                                    <div class="col-md-6">
                                        <router-link to="/statement" class="card">
                                            <div class="card-body py-0">
                                                <div class="d-flex align-items-center px-3 py-1">
                                                    <div class="flex-fill">
                                                        <h5 class="my-2 py-1 text-center">Statement Enquiry </h5>
                                                    </div>
                                                    <div class="">
                                                        <i class="font-28  uil-receipt display-4 text-primary"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </router-link>
                                    </div>
                                </div>
                            </div>
                        </can>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-lg-7">
                        <div :class="['dimmer' , loading ? 'active' : '']">
                            <div class="loader"></div>
                            <div class="dimmer-content">
                                <div style="height: 200px" class="card bg-white text-primary">
                                    <div class="card-body d-flex flex-column">
                                        <select v-model="account" name="" :disabled="accounts.length < 2" class="form-control form-control-sm" id="">
                                            <option v-for="item in accounts" :value="item.id">{{ item.account }} - {{ item.currency.name }}</option>
                                        </select>
                                        <div v-if="account_details" class="row align-items-center mt-2 flex-fill">
                                            <div class="col-6 border-right font-12 text-capitalize">
                                                <span class="text-muted">Name : </span> <strong class="ml-2">{{ account_details.name | string_limit(25) }} </strong> <br>
                                                <span class="text-muted">Branch : </span> <strong class="ml-2">{{ account_details.branch | string_limit(25) }} </strong> <br>
                                                <span class="text-muted">Currency : </span> <strong class="ml-2">{{ account_details.currency | string_limit(25) }} </strong> <br>
                                                <span class="text-muted">Type : </span> <strong class="ml-2">{{ account_details.type | string_limit(25) }} </strong> <br>
                                                <span class="text-muted">Account : </span> <strong class="ml-2">{{ account_details.account | string_limit(25) }} </strong> <br>
                                            </div>
                                            <div class="col-6 text-center">
                                                <strong style="font-size: 25px">{{ account_details.balance }}</strong> <br>
                                                <small>Last Updated : {{ account_details.read_ago }} </small>
                                            </div>
                                        </div>
                                        <div v-else class="d-flex card-body justify-content-center align-items-center h-100">
                                            <h5 class="text-center">
                                                Internet Banking <br> Offline
                                            </h5>
                                        </div>
                                        <div v-if="account_details.currency === 'USD'">
                                            <router-link :to="`/transactions/liquidate/${account_details.account}/funds`">
                                                <button type="button" class="form-control btn btn-primary col-3"><i data-feather="printer"></i>Liquidate Funds</button>
                                            </router-link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <div style="min-height: 200px" class="card bg-white text-primary">
                            <div class="card-body profile-user-box d-flex align-items-center">
                                <div class="row align-items-center flex-fill">
                                    <div class="col-sm-8">
                                        <div class="media align-items-center">
                                            <span class="float-left m-3"><img src="/images/hiclipart.com.png" style="height: 80px;" alt="" class="rounded-circle img-thumbnail"></span>
                                            <div class="media-body border-left pl-3">
                                                <h4 class="mt-1 mb-1 text-capitalize">{{ auth.name }} {{ auth.last_name}}</h4>
                                                <p class="font-13 mb-2"> {{ auth.email }} <br> {{ auth.phone }}</p>
                                                <p class="mb-1"> <span class="badge badge-light px-2 py-1 font-12">{{ auth.type }}</span> </p>
                                            </div>
                                        </div>
                                    </div> <!-- end col-->
                                    <div class="col-sm-4">
                                        <div class="text-center mt-sm-0 mt-3 text-sm-right">
                                            <router-link to="/settings" type="button" class="btn btn-light mb-2">
                                                <i class="mdi mdi-account-edit mr-1"></i> Edit Profile
                                            </router-link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div v-if="account_details" class="col-lg-12">
                <div v-if="account_details.cards.length > 0" class="row justify-content-between">
                    <div v-for="card in account_details.cards" class="col-lg-4">
                        <div style="height: 190px" class="card cta-box bg-primary text-white">
                            <div class="card-body">
                                <div class="media align-items-center">
                                    <div class="media-body">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <h2 class="m-0">AgriCash</h2>
                                            <img height="50" class="mb-2" src="/images/app-logo-on-green.png" alt="">
                                        </div>
                                        <h2 class="m-0 font-weight-normal text-right">{{ card.card }}</h2>
                                        <p class="mt-2">
                                            <span>
                                                {{ account_details.name | string_limit(40) }}
                                            </span>
                                            <span class="float-right">{{ card.expiry }}</span>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <router-link to="/dashboard/accounts" style="min-height: 190px" class="card text-muted d-flex align-items-center justify-content-center">
                            <div class="h1 m-0 text-center">
                                <div class="mb-2">
                                    <i class="mdi mdi-plus-circle display-4"></i>
                                </div>
                                <div>View More</div>
                            </div>
                        </router-link>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div style="height: 360px;overflow-y: auto"  class="card">
                    <div class="">
                        <h6 class="text-muted px-3 py-2 text-uppercase">Recent Transactions</h6>
                    </div>
                    <div class="table-responsive font-12">
                        <table class="table table-centered">
                            <thead class="thead-light">
                            <tr>
                                <th/>
                                <th/>
                                <th>Date</th>
                                <th>Reference</th>
                                <th>State</th>
                                <th>Type</th>
                                <th>Account</th>
                                <th>Amount</th>
                                <th/>
                                <th/>
                            </tr>
                            </thead>
                            <tbody>
                            <tr v-for="transaction in transactions">
                                <td/>
                                <td class="text-primary">#{{ transaction.id }}</td>
                                <td>
                                    {{ transaction.created_at }}
                                </td>
                                <td class="font-weight-bolder">
                                    {{ ( transaction.reference ? transaction.reference   : 'Not Available' ) | string_limit(30)  }}
                                </td>
                                <td class="font-weight-bolder">
                                    {{ transaction.status.description | string_limit(30) }}
                                </td>
                                <td>
                                    <span class="badge badge-light p-2">  {{ transaction.type }}</span>
                                </td>
                                <td>
                                    <span class="">  {{ transaction.account.account }}</span>
                                </td>
                                <td>
                                    <span class="text-primary font-weight-bolder"> $ {{ transaction.amount }}</span>
                                </td>
                                <td>
                                    <router-link :to="`/transactions/${transaction.component}/${transaction.id}/view`" class="action-icon text-muted">
                                        <i class="mdi mdi-eye mdi-24px"/>
                                    </router-link>
                                </td>
                                <td/>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div v-if="statement && auth.accounts.length > 0 && !statementLoading" class="col-12">
                <div class="card">
                    <div class="page-title-box d-flex align-items-center card-body py-0">
                        <h4 class="page-title mr-auto">Last Statement Run</h4>
                        <div class="page-title"><strong>{{ statement.account.account }}</strong> - From <strong>{{ statement.date_start }}</strong> to <strong>{{ statement.date_end }}</strong> </div>
                        <router-link :to="`/transactions/statement/${statement.tran_id}/view`" class="btn btn-light ml-4">View More</router-link>
                    </div>
                </div>

            </div>
            <div v-if="statement && auth.accounts.length > 0 && !statementLoading" class="col-12">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card widget-inline">
                            <div class="card-body p-0">
                                <div class="row no-gutters">
                                    <div class="col-sm-6 col-xl-2">
                                        <div class="card shadow-none m-0">
                                            <div class="card-body text-center text-primary">
                                                <h3><span>{{ statement.debits_count }}</span></h3>
                                                <p class="text-muted font-15 mb-0">Debits Count</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-6 col-xl-4">
                                        <div class="card shadow-none m-0 border-left text-primary">
                                            <div class="card-body text-center">
                                                <h3><span>$ {{ statement.debits }}</span></h3>
                                                <p class="text-muted font-15 mb-0">Debits Total </p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-6 col-xl-4">
                                        <div class="card shadow-none m-0 border-left">
                                            <div class="card-body text-center text-primary">
                                                <h3><span>$ {{ statement.credits }}</span></h3>
                                                <p class="text-muted font-15 mb-0">Total Credits</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-6 col-xl-2">
                                        <div class="card shadow-none m-0 border-left">
                                            <div class="card-body text-center text-primary">
                                                <h3><span>{{ statement.credits_count }}</span></h3>
                                                <p class="text-muted font-15 mb-0">Credits Count</p>
                                            </div>
                                        </div>
                                    </div>

                                </div> <!-- end row -->
                            </div>
                        </div> <!-- end card-box-->
                    </div>
                    <div class="col-lg-8">
                        <div  style="max-height: 400px;min-height: 400px;"  class="card">
                            <div :class="['card-body' , statement.running_balance_values.length > 4 ? '' : 'd-flex align-items-center justify-content-center']" style="position: relative">
                                <apexchart v-if="statement.running_balance_values.length > 4" type="line" height="350"  :options="chartOptions" :series="series"></apexchart>
                                <div v-else class="text-center text-muted">
                                    <i class="mdi mdi-alert-circle display-1"></i>
                                    <h1>No Enough Data</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card" style="max-height: 400px;min-height: 400px;">
                            <h5 class="pt-3 text-center">BALANCE MOVEMENT</h5>
                            <div class="card-body d-flex flex-column justify-content-between align-items-center pb-4 pt-0">
                                <div class="text-center mt-3">
                                    <h2 class="font-weight-normal mb-0">
                                        <span>{{ statement.start }}</span>
                                    </h2>
                                    <span class="text-muted"><small><strong>Start Balance</strong></small></span>
                                </div>
                                <div class="text-center h1 font-weight-light">
                                    <span :class="['mr-2' , statement.change >= 0  ? 'text-success' : 'text-danger' ]"><i :class="['mdi' , statement.change >= 0  ? 'mdi-arrow-up-bold' : 'mdi-arrow-down-bold']"></i>{{ statement.change }}%</span>
                                </div>
                                <div class="text-center">
                                    <h2 class="font-weight-normal mb-0">
                                        <span>{{ statement.end }}</span>
                                    </h2>
                                    <span class="text-muted"><small><strong>End Balance</strong></small></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-body pb-0">
                                <h4 class="header-title mb-3 text-center">Transactions Types</h4>
                            </div>
                            <div style="max-height: 280px;min-height: 280px;overflow: auto">
                                <div class="table-responsive">
                                    <table class="table mb-0">
                                        <thead class="thead-light">
                                        <tr>
                                            <th/>
                                            <th>Type</th>
                                            <th class="text-center">Count</th>
                                            <th class="text-right">Total</th>
                                            <th/>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr v-for="item in statement.transaction_types">
                                            <td/>
                                            <td>{{ item.name }}</td>
                                            <td class="text-center">{{ item.count }}</td>
                                            <td class="text-right">$ {{ item.sum }}</td>
                                            <td/>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-body pb-0">
                                <h4 class="header-title mb-3 text-center">Statistics</h4>
                            </div>
                            <div class="d-flex flex-column justify-content-between align-items-center pb-4" style="max-height: 280px;min-height: 280px;overflow: auto">
                                <div class="text-center">
                                    <h2 class="font-weight-normal mb-0">
                                        <span>$ {{ statement.min }}</span>
                                    </h2>
                                    <span class="text-muted"><small><strong>Min</strong></small></span>
                                </div>
                                <div class="text-center">
                                    <h2 class="font-weight-normal mb-0">
                                        <span>$ {{ statement.average }}</span>
                                    </h2>
                                    <span class="text-muted"><small><strong>Average</strong></small></span>
                                </div>
                                <div class="text-center">
                                    <h2 class="font-weight-normal mb-0">
                                        <span>${{ statement.max }}</span>
                                    </h2>
                                    <span class="text-muted"><small><strong>Max</strong></small></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12">
                <div class="row font-15">
                    <div class="col-lg-4">
                        <div class="card text-white bg-primary overflow-hidden">
                            <div class="card-body">
                                <div class="toll-free-box text-center">
                                    <div> <i class="mdi mdi-headset"></i>  customersupport@agribank.co.zw</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card text-white bg-primary overflow-hidden">
                            <div class="card-body">
                                <div class="toll-free-box text-center">
                                    <div> <i class="mdi mdi-deskphone"></i> Need help ? Call  : 086 77 202 202 </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card text-white bg-primary overflow-hidden">
                            <div class="card-body">
                                <div class="toll-free-box text-center">
                                    <div> <i class="mdi mdi-headset"></i>0712 837 436 | 0772 303 572</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
