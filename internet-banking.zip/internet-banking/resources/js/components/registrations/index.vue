<template>
    <page-index name="Registrations" url="/registrations" prefix="users">
        <template slot-scope="data" slot="filters">
            <div class="d-flex">
                <div class="form-group mr-3">
                    <select v-model="data.filters['state']" class="custom-select">
                        <option :value="undefined">Choose Status</option>
                        <option value="pending">pending</option>
                        <option value="declined">declined</option>
                        <option value="completed">completed</option>
                    </select>
                </div>
                <div class="form-group mr-3">
                    <input type="text" v-model="data.filters['id']" class="form-control" placeholder="ID">
                </div>
            </div>
        </template>
        <template slot="table-header">
            <th></th>
            <th></th>
            <th>Info</th>
            <th>Contact</th>
            <th>Account</th>
            <th>State</th>
            <th>Date</th>
            <th class="text-center"></th>
        </template>
        <template slot="table-row" slot-scope="data">
            <td>
                <span class="text-primary">#{{ data.row.id }}</span>
            </td>
            <td>
               <div class="avatar-sm">
                    <span class="avatar-title bg-light text-dark font-15 rounded-circle">
                        {{ data.row.avatar_name }}
                    </span>
                </div>
            </td>
            <td>name : {{ data.row.name }} <br> surname : {{ data.row.last_name }} </td>
            <td>email : {{ data.row.email }} <br> phone : {{ data.row.phone }}</td>
            <td>account : {{ data.row.account }} <br> card : {{ data.row.card }}</td>
            <td>
                <span class="badge badge-light p-2">{{ data.row.state }}</span> <br>
            </td>
            <td> created : {{ data.row.read_created_at }} <br> updated : {{ data.row.read_updated_at }} </td>
            <td>
                <router-link :to="`/registrations/${data.row.id}/view`" class="action-icon text-primary">
                    <i class="mdi mdi-eye mdi-24px"/>
                </router-link>
            </td>
        </template>
    </page-index>
</template>

<script>
    import PageIndex from "../core/page-index";
    export default {
        name: "index",
        components: {PageIndex},
        data(){
            return {
                win : window
            }
        }
    }
</script>
