<script>
    import Form from "../../core/forms/form";
    import DataSelect from "../core/DataSelect";
    import MultiDataSelect from "../core/MultiDataSelect";
    import RolesSelect from "../roles/select";
    import CorporateSelect from "../corporates/select";
    export default {
        name: "user-form",
        components: {CorporateSelect, RolesSelect, MultiDataSelect, DataSelect},
        props: [ 'edit' , 'id' ],
        data(){
            return {
                currencies : [],
                loading : false,
                form : new Form({
                    reason : '',
                }),
            };
        },
        mounted() {
            if (this.edit)
            {
                this.init();
            }
        },
        methods: {
            init()
            {

            },
            create()
            {
                this.form.submit(`/registrations/${this.$route.params.id}/decline`).then((response) => {
                    window.alerts.success(response).then((response) => {
                        this.$router.push(`/registrations/${this.$route.params.id}/view`);
                    });
                }).catch((error) => {
                }).finally(() => {
                });
            }
        }
    }
</script>
<template>
    <div class="row pt-3">
        <div class="col-lg-12">
            <div :class="['dimmer' , form.loading ? 'active' : '']">
                <div class="loader"></div>
                <div class="dimmer-content">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="mb-3"> Decline Registration</h4>
                            <div class="form-horizontal">
                                <div class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Reason</label>
                                    <div class="col-lg-9">
                                        <textarea type="text" name="reason" v-model="form.reason" :class="[ 'form-control mw-400' , form.errors.get('reason') ? 'is-invalid' : '' ]" />
                                        <div v-text="form.errors.get('reason')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div class="form-group mb-0 justify-content-end row">
                                    <div class="col-lg-9">
                                        <button type="submit" @click.prevent="create" :class="['btn btn-primary' , form.loading ? 'btn-loading' : '']"> Decline</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>
