<script>
    import Form from "../../core/forms/form";
    import DataSelect from "../core/DataSelect";
    import MultiDataSelect from "../core/MultiDataSelect";
    import RolesSelect from "../roles/select";
    import CorporateSelect from "../corporates/select";
    export default {
        name: "user-form",
        components: {CorporateSelect, RolesSelect, MultiDataSelect, DataSelect},
        props: [ 'edit' , 'id' ],
        data(){
            return {
                currencies : [],
                loading : false,
                form : new Form({
                    name : '',
                    last_name : '',
                    phone : '',
                    email : '',
                    account : '',
                    card : '',
                    currency_id  : ''
                }),
            };
        },
        mounted() {
            if (this.edit)
            {
                this.init();
            }
        },
        methods: {
            init()
            {
                this.loading = true;
                window.axios.get(`/registrations/${this.id}/view`).then((response) => {
                    this.form.extract(response.data.body.model);
                    this.loading = false;
                    this.form.loading = true;
                    window.axios.get(`/currencies`).then((response) => {
                        this.currencies = response.data.body.currencies;
                    }).finally(() => {
                        this.form.loading = false;
                    });
                });
            },
            create()
            {
                this.form.submit(this.edit ? `/registrations/${this.id}/update`  : '').then((response) => {
                    window.alerts.success(response).then((response) => {
                        this.$router.push(`/users/${response.data.body.model.id}/view`);
                    });
                }).catch((error) => {
                }).finally(() => {
                });
            }
        }
    }
</script>
<template>
    <div class="row pt-3">
        <div class="col-lg-12">
            <div :class="['dimmer' , form.loading ? 'active' : '']">
                <div class="loader"></div>
                <div class="dimmer-content">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="mb-3">Accept Registration</h4>
                            <div class="form-horizontal">
                                <div class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">First Name</label>
                                    <div class="col-lg-9">
                                        <input type="text" name="name" v-model="form.name" :class="[ 'form-control mw-400' , form.errors.get('name') ? 'is-invalid' : '' ]" placeholder="First Name">
                                        <div v-text="form.errors.get('name')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Last Name</label>
                                    <div class="col-lg-9">
                                        <input type="text" name="last_name" v-model="form.last_name" :class="[ 'form-control mw-400' , form.errors.get('last_name') ? 'is-invalid' : '' ]" placeholder="Last Name">
                                        <div v-text="form.errors.get('last_name')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Phone</label>
                                    <div class="col-lg-9">
                                        <input type="text" name="phone" v-model="form.phone" :class="[ 'form-control mw-400' , form.errors.get('phone') ? 'is-invalid' : '' ]" placeholder="Phone">
                                        <div v-text="form.errors.get('phone')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Email</label>
                                    <div class="col-lg-9">
                                        <input type="email" name="email" v-model="form.email" :class="[ 'form-control mw-400' , form.errors.get('email') ? 'is-invalid' : '' ]" placeholder="Email">
                                        <div v-text="form.errors.get('email')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div v-if="" class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Account</label>
                                    <div class="col-lg-9">
                                        <input type="text" name="account" v-model="form.account" :class="[ 'form-control mw-400' , form.errors.get('account') ? 'is-invalid' : '' ]" placeholder="Account">
                                        <div v-text="form.errors.get('account')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Currency</label>
                                    <div class="col-lg-9">
                                        <select type="email" name="currency_id" v-model="form.currency_id" :class="[ 'form-control mw-400' , form.errors.get('currency_id') ? 'is-invalid' : '' ]">
                                            <option :value="undefined">Choose Currency</option>
                                            <option v-for="currency in currencies" :key="currency.id" v-text="currency.name" :value="currency.id"/>
                                        </select>
                                        <div v-text="form.errors.get('currency_id')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div v-if="" class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Card</label>
                                    <div class="col-lg-9">
                                        <input type="text" name="card" v-model="form.card" :class="[ 'form-control mw-400' , form.errors.get('card') ? 'is-invalid' : '' ]" placeholder="Card">
                                        <div v-text="form.errors.get('card')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div class="form-group mb-0 justify-content-end row">
                                    <div class="col-lg-9">
                                        <button type="submit" @click.prevent="create" :class="['btn btn-primary' , form.loading ? 'btn-loading' : '']"> Accept</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>
