<template>
    <div class="">
        <form @submit.prevent="register" autocomplete="off" class="card-body px-4">
            <div class="text-center w-75 m-auto">
                <h4 class="text-dark-50 text-center mt-0 font-weight-bold">Register</h4>
                <p class="text-muted mb-3">Enter your details below , Verification of information takes upto 3 to 6 working days</p>
            </div>
            <p v-if="message" :class="['alert text-center mb-0 rounded-0 mb-3 px-3' , error ? 'alert-danger' : 'alert-success']">
                {{ message }}
            </p>
            <div>
                <div class="form-row">
                    <div class="form-group col-md-12">
                        <h4>Personal Information</h4>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>Name</label>
                        <input type="text" v-model="form.name" :class="[ 'form-control' , form.errors.get('name') ? 'is-invalid' : '' ]" placeholder="Enter your name" autocomplete="unique-1">
                        <div v-text="form.errors.get('name')" class="invalid-feedback"/>
                    </div>
                    <div class="form-group col-md-6">
                        <label>Last Name</label>
                        <input type="text" v-model="form.last_name" :class="[ 'form-control' , form.errors.get('last_name') ? 'is-invalid' : '' ]" placeholder="Enter your last name" autocomplete="unique-1">
                        <div v-text="form.errors.get('last_name')" class="invalid-feedback"/>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-12">
                        <h4>Contact Information</h4>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group  col-md-6">
                        <label>Phone</label>
                        <input type="number" v-model="form.phone" :class="[ 'form-control' , form.errors.get('phone') ? 'is-invalid' : '' ]" placeholder="Enter your phone" autocomplete="unique-1">
                        <div v-text="form.errors.get('phone')" class="invalid-feedback"/>
                    </div>
                    <div class="form-group  col-md-6">
                        <label>Email address</label>
                        <input type="text" v-model="form.email" :class="[ 'form-control' , form.errors.get('email') ? 'is-invalid' : '' ]" placeholder="Enter your email" autocomplete="unique-1">
                        <div v-text="form.errors.get('email')" class="invalid-feedback"/>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-12">
                        <h4>Account Information</h4>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group  col-md-6">
                        <label>Account Number</label>
                        <input type="number" v-model="form.account" :class="[ 'form-control' , form.errors.get('account') ? 'is-invalid' : '' ]" placeholder="Enter your Account Number" autocomplete="unique-1">
                        <div v-text="form.errors.get('account')" class="invalid-feedback"/>
                    </div>
                    <div class="form-group  col-md-6">
                        <label>Card Number</label>
                        <input type="number" v-model="form.card" :class="[ 'form-control' , form.errors.get('card') ? 'is-invalid' : '' ]" placeholder="Enter last 4 digits of any of your cards" autocomplete="unique-1">
                        <div v-text="form.errors.get('card')" class="invalid-feedback"/>
                        <div class="help-block text-right"><small> [ Last 4 digits of any of your cards ] </small></div>
                    </div>
                </div>
                <div class="form-group mb-0 text-center">
                    <button @click.prevent="register" :class="['btn btn-primary px-4' , form.loading || loading ? 'btn-loading' : '']" type="submit"> Register </button>
                </div>
            </div>
            <div class="mt-3">
                <div class="text-center">
                    <p class=""><span class="text-muted">Already have an account?</span> <a href="/login" class=""><b>Login </b></a></p>
                </div> <!-- end col -->
            </div>
        </form>
    </div>
</template>

<script>
    import Form from "../../core/forms/form";
    export default {
        name: "register",
        data()
        {
            return {
                loading : false,
                otpSent : false,
                error : false,
                message : '',
                form : new Form({
                   email : '',
                   phone : '',
                   name : '',
                   last_name : '',
                   account : '',
                   card : '',
                })
            };
        },
        methods : {
            register()
            {
                this.loading = true;
                this.message = "";
                this.form.submit('/register').then((response) => {
                    this.loading = false;
                    this.message = response.data.message;
                }).catch((error) => {
                    this.loading = false;
                });
            }
        }
    }
</script>
