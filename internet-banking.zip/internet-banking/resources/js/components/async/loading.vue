<template>

    <div class="dimmer active">
        <div class="loader"></div>
        <div class="dimmer-content">
            <div class="row pt-4 min-h-60">
                <div class="col-lg-12">
                </div>
            </div>
        </div>
    </div>

</template>

<script>
    export default {
        name: "loading"
    }
</script>
