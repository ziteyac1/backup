<script>
    import VueApexCharts from 'vue-apexcharts';
    export default {
        name: "statement-view",
        components: {
            apexchart: VueApexCharts,
        },
        data(){
            return {
                series: [{
                    name: "Balance",
                    data: []
                }],
                chartOptions: {
                    xaxis: {
                        categories: [],
                        labels: {
                            show: true,
                            maxHeight: 120,
                            style: {
                                colors: [],
                                fontSize: '8px',
                                fontWeight: 400,
                                cssClass: 'apexcharts-xaxis-label',
                            },
                        }
                    },
                    chart: {
                        type: 'line',
                        dropShadow: {
                            enabled: true,
                            color: '#1c4b27',
                            top: 18,
                            left: 7,
                            blur: 10,
                            opacity: 0.4
                        },
                        toolbar: {
                            show: false
                        },
                        zoom: {
                            enabled: true,
                        }
                    },
                    colors: ['#1c4b27'],
                    dataLabels: {
                        enabled: false

                    },
                    stroke: {
                        curve: 'smooth',
                        width: 3,
                    },
                    title: {
                        text: 'RUNNING BALANCE',
                        align: 'center',
                        color : '#6c757d',
                    },
                    grid: {
                        row: {
                            colors: ['transparent'],
                        },
                    },

                },
                loading : false,
                statement : {
                    running_balance_values : [],
                    running_balance_dates : [],
                    transaction_types : [],
                    transactions : [],
                    account : {
                        currency : {},
                        data : {}
                    }
                },
                id : null,
                more : true,
            };
        },
        mounted(){
            this.init();
        },
        methods : {
            init()
            {
                this.loading = true;
                window.axios.get(`${window.location.origin}/transactions/${this.$route.params.id}/statement`).then((response) => {

                    this.statement = response.data.body.statement;
                    this.id = response.data.body.id;
                    this.series = [{
                        name: "Balance",
                        data: this.statement.running_balance_values
                    }];
                    this.chartOptions.xaxis.categories = this.statement.running_balance_dates;

                }).finally(() => {
                    this.loading = false;
                });
            }
        }
    }
</script>
<template>
    <div :class="['dimmer' , loading ? 'active' : '']">
        <div class="loader"></div>
        <div class="dimmer-content">
            <div class="row mt-4">
                <div v-if="statement.state === 99" class="col-lg-12">
                    <div class="card">
                        <div class="card-body px-5 border-bottom d-flex justify-content-end no-print">
                            <a v-if="id && statement.pdf" :href="`/transactions/${id}/statement/download?type=pdf`" target="_blank" class="btn btn-light mr-2"><i class="mdi mdi-download mr-1"/>Download PDF</a>
                            <a v-if="id && statement.csv" :href="`/transactions/${id}/statement/download?type=csv`" target="_blank" class="btn btn-light mr-2"><i class="mdi mdi-download mr-1"/>Download CSV</a>
                            <button @click.prevent="more = !more" :class="['btn mr-2' , more ? 'btn-light'  : 'btn-primary']">
                                <i class="mdi mdi-chart-line mr-1"/> {{ more ? 'Hide' : 'View' }} Statistics
                            </button>
                            <button @click.prevent="init" class="btn btn-light"><i class="mdi mdi-refresh mr-1"/>Refresh</button>
                            <button v-if="" @click="$router.back()" class="btn btn-light ml-3" type="button">
                                <i class="mdi mdi-close mr-1"></i> Close
                            </button>
                        </div>
                        <div class="card-body px-5 d-flex align-items-center border-bottom flex-wrap">
                            <div>
                                <img src="/images/logo-full.png" height="80" alt="">
                            </div>
                            <div class="text-center mx-auto">
                                <h3 class="text-center">Account Statement</h3>
                                <h6 class="text-center"> {{ statement.date }} </h6>
                            </div>
                            <div>
                                <img :src="statement.qr" height="100" alt="">
                            </div>
                        </div>
                        <div class="card-body px-5">
                            <div class="row">
                                <div class="col-lg-6 text-left">
                                    Name : <strong>{{ statement.name}}</strong> <br>
                                    Reference : <strong>{{ statement.reference }} </strong> <br>
                                    Account : <strong>{{ statement.account.account }} </strong> <br>
                                </div>
                                <div class="col-lg-6 text-right">
                                    Start Date : <strong>{{ statement.date_start }}</strong> <br>
                                    End Date : <strong>{{ statement.date_end }} </strong> <br>
                                    Currency : <strong>{{ statement.account.currency.name }} </strong> <br>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div v-if="statement.state === 99"  :class="['col-lg-12 collapse' , more  ? 'show' : '']">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card widget-inline">
                                <div class="card-body p-0">
                                    <div class="row no-gutters">
                                        <div class="col-sm-6 col-xl-2">
                                            <div class="card shadow-none m-0">
                                                <div class="card-body text-center text-primary">
                                                    <h3><span>{{ statement.debits_count }}</span></h3>
                                                    <p class="text-muted font-15 mb-0">Debits Count</p>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-sm-6 col-xl-4">
                                            <div class="card shadow-none m-0 border-left text-primary">
                                                <div class="card-body text-center">
                                                    <h3><span>$ {{ statement.debits }}</span></h3>
                                                    <p class="text-muted font-15 mb-0">Debits Total </p>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-sm-6 col-xl-4">
                                            <div class="card shadow-none m-0 border-left">
                                                <div class="card-body text-center text-primary">
                                                    <h3><span>$ {{ statement.credits }}</span></h3>
                                                    <p class="text-muted font-15 mb-0">Total Credits</p>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-sm-6 col-xl-2">
                                            <div class="card shadow-none m-0 border-left">
                                                <div class="card-body text-center text-primary">
                                                    <h3><span>{{ statement.credits_count }}</span></h3>
                                                    <p class="text-muted font-15 mb-0">Credits Count</p>
                                                </div>
                                            </div>
                                        </div>

                                    </div> <!-- end row -->
                                </div>
                            </div> <!-- end card-box-->
                        </div>
                        <div class="col-lg-8">
                            <div  style="max-height: 400px;min-height: 400px;"  class="card">
                                <div :class="['card-body' , statement.running_balance_values.length > 4 ? '' : 'd-flex align-items-center justify-content-center']" style="position: relative">
                                    <apexchart v-if="statement.running_balance_values.length > 4" type="line" height="350"  :options="chartOptions" :series="series"></apexchart>
                                    <div v-else class="text-center text-muted">
                                        <i class="mdi mdi-alert-circle display-1"></i>
                                        <h1>No Enough Data</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card" style="max-height: 400px;min-height: 400px;">
                                <h5 class="pt-3 text-center">BALANCE MOVEMENT</h5>
                                <div class="card-body d-flex flex-column justify-content-between align-items-center pb-4 pt-0">
                                    <div class="text-center mt-3">
                                        <h2 class="font-weight-normal mb-0">
                                            <span>{{ statement.start }}</span>
                                        </h2>
                                        <span class="text-muted"><small><strong>Start Balance</strong></small></span>
                                    </div>
                                    <div class="text-center h1 font-weight-light">
                                        <span :class="['mr-2' , statement.change >= 0  ? 'text-success' : 'text-danger' ]"><i :class="['mdi' , statement.change >= 0  ? 'mdi-arrow-up-bold' : 'mdi-arrow-down-bold']"></i>{{ statement.change }}%</span>
                                    </div>
                                    <div class="text-center">
                                        <h2 class="font-weight-normal mb-0">
                                            <span>{{ statement.end }}</span>
                                        </h2>
                                        <span class="text-muted"><small><strong>End Balance</strong></small></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-8">
                            <div class="card">
                                <div class="card-body pb-0">
                                    <h4 class="header-title mb-3 text-center">Transactions Types</h4>
                                </div>
                                <div style="max-height: 280px;min-height: 280px;overflow: auto">
                                        <div class="table-responsive">
                                            <table class="table mb-0">
                                                <thead class="thead-light">
                                                <tr>
                                                    <th/>
                                                    <th>Type</th>
                                                    <th class="text-center">Count</th>
                                                    <th class="text-right">Total</th>
                                                    <th/>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr v-for="item in statement.transaction_types">
                                                    <td/>
                                                    <td>{{ item.name }}</td>
                                                    <td class="text-center">{{ item.count }}</td>
                                                    <td class="text-right">$ {{ item.sum }}</td>
                                                    <td/>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card">
                                <div class="card-body pb-0">
                                    <h4 class="header-title mb-3 text-center">Statistics</h4>
                                </div>
                                <div class="d-flex flex-column justify-content-between align-items-center pb-4" style="max-height: 280px;min-height: 280px;overflow: auto">
                                    <div class="text-center">
                                        <h2 class="font-weight-normal mb-0">
                                            <span>$ {{ statement.min }}</span>
                                        </h2>
                                        <span class="text-muted"><small><strong>Min</strong></small></span>
                                    </div>
                                    <div class="text-center">
                                        <h2 class="font-weight-normal mb-0">
                                            <span>$ {{ statement.average }}</span>
                                        </h2>
                                        <span class="text-muted"><small><strong>Average</strong></small></span>
                                    </div>
                                    <div class="text-center">
                                        <h2 class="font-weight-normal mb-0">
                                            <span>${{ statement.max }}</span>
                                        </h2>
                                        <span class="text-muted"><small><strong>Max</strong></small></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div v-if="statement.state === 99" class="card">
                        <div class="card-body">
                            <h5 class="text-uppercase text-center">Transactions</h5>
                        </div>
                        <div class="table-responsive font-12">
                            <table class="table table-centered">
                                <thead class="thead-light">
                                <tr>
                                    <th/>
                                    <th>Value Date</th>
                                    <th>Booking Date</th>
                                    <th>Reference</th>
                                    <th>Description</th>
                                    <th>Location</th>
                                    <th>Debit</th>
                                    <th>Credit</th>
                                    <th>Balance</th>
                                    <th/>
                                </tr>
                                </thead>
                                <tbody>
                                <tr v-for="transaction in statement.transactions">
                                    <td/>
                                    <td class="">{{ transaction.valueDate }}</td>
                                    <td class="text-muted">{{ transaction.bookingDate }}</td>
                                    <td><strong>{{ transaction.ft }}</strong></td>
                                    <td>{{ transaction.reference }}</td>
                                    <td>{{ transaction.location }}</td>
                                    <td>{{ transaction.debit }}</td>
                                    <td>{{ transaction.credit }}</td>
                                    <td><strong>{{ transaction.balance }}</strong></td>
                                    <td/>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-centered table-nowrap mb-0 table-borderless border-top">
                                <tbody>
                                <tr class="text-center">
                                    <td/>
                                    <td>
                                        <h5 class="font-14 my-1"> [ {{ statement.total }} ] </h5>
                                        <span class="text-muted font-13">Total</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1">{{ statement.start }}</h5>
                                        <span class="text-muted font-13">Start Balance</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1">[ {{ statement.debits_count }} ] {{ statement.debits }}</h5>
                                        <span class="text-muted font-13">Debits</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1">[ {{ statement.credits_count }} ] {{ statement.credits }}</h5>
                                        <span class="text-muted font-13">Credits</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1">{{ statement.end }}</h5>
                                        <span class="text-muted font-13">End Balance</span>
                                    </td>
                                    <td/>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="card-body">
                            <h6 class="text-center"> {{ statement.code }} </h6>
                        </div>
                    </div>
                    <div v-else class="card p-5">
                        <div class="card-body">
                            <h4 class="text-center">There was an error retrieving your statement , Please try again later</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
