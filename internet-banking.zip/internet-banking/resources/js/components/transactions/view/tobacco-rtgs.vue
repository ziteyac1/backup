<script>
    import Can from "../../core/can";
    export default {
        name: "rtgs-view",
        components: {Can},
        mounted() {
            this.init();
        },
        data(){
            return {
                loading : false,
                transaction : {
                    status : {},
                    batch : {},
                    authorisation : {},
                    account : {
                        currency : {}
                    },
                    transaction: {
                        bank : {}
                    }
                }
            }
        },
        methods : {
            init()
            {
                this.loading = true;
                window.axios.get(`${window.location.origin}/transactions/${this.$route.params.id}/view`).then((response) => {
                    this.transaction = response.data.body.transaction;
                }).finally(() => {
                    this.loading = false;
                });
            },
            action(action)
            {
                this.loading = true;
                window.process(action , 'Transaction' , `${window.location.origin}/transactions/${this.$route.params.id}/${action}`).then((response) => {
                    this.transaction = response.data.body.transaction;
                    this.loading = false;
                }).catch((onerror) => {
                    this.loading = false;
                });
            },
        }
    }
</script>
<template>
    <div :class="['dimmer' , loading ? 'active' : '']">
        <div class="loader"></div>
        <div class="dimmer-content">
            <div class="row pt-3">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body border-bottom">
                            <div class="d-flex align-items-center flex-wrap">
                                <div class="mr-auto">
                                    <a :href="`/transactions/${transaction.id}/download`" v-if="transaction.pdf && transaction.state === 99" target="_blank" type="button" class="btn btn-light m-1">
                                        <i class="mdi mdi-lightbulb-outline mr-1"></i> Download Proof
                                    </a>
                                    <button v-if="!transaction.pdf &&  transaction.state === 99"  @click="action('generate')" type="button" class="btn btn-light m-1">
                                        <i class="mdi mdi-lightbulb-outline mr-1"></i> Generate Proof
                                    </button>
                                </div>
                                <div class="">
                                    <button v-if="" @click="init" type="button" :class="['btn btn-light m-1' ,  loading ? 'btn-loading' : '']">
                                        <i class="mdi mdi-refresh mr-1"></i> Refresh
                                    </button>
                                    <button v-if="transaction.retry  && transaction.state === 3" @click.prevent="action('retry')" type="button" class="btn btn-light m-1">
                                        <i class="mdi mdi-reload mr-1"></i> Retry
                                    </button>
                                    <can permission="authorise-transaction">
                                        <button v-if="transaction.authorisation && transaction.state === 2" @click.prevent="action('authorise')" type="button" class="btn btn-light m-1">
                                            <i class="mdi mdi-lightbulb-outline mr-1"></i> Authorise
                                        </button>
                                        <button v-if="transaction.authorisation && transaction.state === 2" @click.prevent="action('decline')"  type="button" class="btn btn-light m-1">
                                            <i class="mdi mdi-lightbulb-off-outline mr-1"></i> Decline
                                        </button>
                                    </can>
                                    <button v-if="" @click="$router.back()" class="ml-3 btn btn-light" type="button">
                                        <i class="mdi mdi-close mr-1"></i> Close
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="card-body px-5 d-flex align-items-center border-bottom flex-wrap">
                            <div>
                                <img src="/images/logo-full.png" height="120" alt="">
                            </div>
                            <div class="text-center mx-auto">
                                Agricultural Bank of Zimbabwe <br>
                                Hurudza House, 14-16 Nelson Mandela Harare , Zimbabwe <br>
                                Tel: (+263)(242) 774400-19
                            </div>
                            <div>
                                <img :src="transaction.qr" height="140" alt="">
                            </div>
                        </div>
                        <div class="card-body px-5">
                            <h3 class="text-center">Tobacco RTGS Payment</h3>
                            <h6 class="text-center"> {{ transaction.created_at }} </h6>
                        </div>
                        <div class="table-responsive mb-0">
                            <table class="table table-centered mb-0 font-18">
                                <tbody>
                                <tr>
                                    <td class="text-left font-15">
                                        <div class="pl-5">State </div>
                                    </td>
                                    <td class="text-right">
                                        <div class="pr-5">
                                            <strong>
                                                {{ transaction.status.description }}
                                            </strong>
                                        </div>
                                    </td>
                                </tr>
                                <tr v-if="transaction.state === 96 || transaction.state === 3">
                                    <td class="text-left font-15">
                                        <div class="pl-5">Error  </div>
                                    </td>
                                    <td class="text-right">
                                        <div class="pr-5">
                                            <strong>
                                                {{ transaction.error }}
                                            </strong>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-left font-15">
                                        <div class="pl-5">Type </div>
                                    </td>
                                    <td class="text-right">
                                        <div class="pr-5">
                                            <strong>
                                                {{ transaction.type }}
                                            </strong>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-left font-15">
                                        <div class="pl-5">From Account </div>
                                    </td>
                                    <td class="text-right">
                                        <div class="pr-5">
                                            <strong>
                                                {{ transaction.account.account }}
                                            </strong>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-left font-15">
                                        <div class="pl-5">To Account </div>
                                    </td>
                                    <td class="text-right">
                                        <div class="pr-5">
                                            <strong>
                                                {{ transaction.transaction.receive }}
                                            </strong>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-left font-15">
                                        <div class="pl-5">Name </div>
                                    </td>
                                    <td class="text-right">
                                        <div class="pr-5">
                                            <strong>
                                                {{ transaction.transaction.name }}
                                            </strong>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-left font-15">
                                        <div class="pl-5">Reason </div>
                                    </td>
                                    <td class="text-right">
                                        <div class="pr-5">
                                            <strong>
                                                {{ transaction.transaction.reason }}
                                            </strong>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-left font-15">
                                        <div class="pl-5">Bank </div>
                                    </td>
                                    <td class="text-right">
                                        <div class="pr-5">
                                            <strong>
                                                {{ transaction.transaction.bank.name }}
                                            </strong>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-left font-15">
                                        <div class="pl-5">Currency </div>
                                    </td>
                                    <td class="text-right">
                                        <div class="pr-5">
                                            <strong>
                                                {{ transaction.account.currency.name }}
                                            </strong>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-left font-15">
                                        <div class="pl-5">Amount </div>
                                    </td>
                                    <td class="text-right">
                                        <div class="pr-5">
                                            <strong>
                                                {{ transaction.transaction.amount }}
                                            </strong>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-left font-15">
                                        <div class="pl-5">Reference </div>
                                    </td>
                                    <td class="text-right">
                                        <div class="pr-5">
                                            <strong>
                                                {{ !transaction.reference ? 'Not Available' :  transaction.reference  }}
                                            </strong>
                                        </div>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="card-body border-top">
                            <h6 class="text-center"> Auth Code : {{ transaction.code }} </h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>
