<template>
    <page-index name="Transactions" url="/transactions" prefix="transactions">
        <template slot="table-header">
            <th>ID</th>
            <th>Account</th>
            <th>Amount</th>
            <th>Reference</th>
            <th>Type</th>
            <th>Mode</th>
            <th>Date</th>
            <th class="text-center"></th>
        </template>
        <template slot="sort-fields">
            <option value="account_id">Account</option>
            <option value="updated_at">Latest Update</option>
        </template>
        <template slot="table-row" slot-scope="data">
            <td>
                <span class="text-primary">#{{ data.row.id }}</span>
            </td>
            <td>
                account : <strong>{{ data.row.account.account  }} </strong> <br>
                currency : <strong>{{ data.row.account.currency.name  }} </strong>
            </td>
            <td> <span class="text-primary font-weight-bolder">${{ data.row.amount }}</span> </td>
            <td>
                reference : {{ data.row.reference ? data.row.reference  : 'Not Available' }} <br>
                state : <span class="font-weight-bolder"> {{ data.row.status.description}} </span> <br>
                <span v-if="data.row.state === 96 || data.row.state === 3">
                      error : <span class="font-weight-bolder"> {{ data.row.error }} </span>
                 </span>
            </td>
            <td>
                <span class="badge badge-light p-2">{{ data.row.type }}</span> <br>
            </td>
            <td>
                <span class="badge badge-light p-2"> {{ data.row.batch ? 'batch' : 'single' }} </span>
            </td>

            <td> created : {{ data.row.created_at }} <br>  updated : {{ data.row.read_updated }} </td>
            <td>
                <router-link :to="`/transactions/${data.row.component}/${data.row.id}/view`" class="action-icon text-primary">
                    <i class="mdi mdi-eye mdi-24px"/>
                </router-link>
            </td>
        </template>
    </page-index>
</template>

<script>
    import PageIndex from "../core/page-index";
    export default {
        name: "index",
        components: {PageIndex},
        data(){
            return {
                win : window
            }
        }
    }
</script>
