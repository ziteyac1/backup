<script>
    import Form from "../../core/forms/form";
    import AccountsService from "../../servicies/AccountsService";
    export default {
        name: "liquidation-transfer-initiate",
        mounted() {
            this.init();
        },
        data()
        {
            return {
                loading : true,
                accounts : [],
                form : new Form({
                    sending_account : this.$route.params.id,
                    receiving_account : '',
                    receiving_account_confirmation : '',
                    amount : '',
                    reference : '',
                    name : '',
                })
            }
        },
        methods : {
            init ()
            {
                AccountsService.loadAccounts(this);
            },
            submit()
            {
                window.Swal.fire({
                    title: 'Are you sure ?',
                    text: `You want to liquidate funds \$${this.form.amount} to ZWL Account${this.form.receiving_account}`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#1c4b27',
                    cancelButtonColor: '#d33',
                    confirmButtonText: `Yes, Liquidate Funds!`
                }).then((result) => {
                    if (result.value) {
                        this.form.submit('/transactions/nostro/liquidation').then((response) => {

                            window.alerts[response.data.success === true ? 'success' : 'error'](response).then((response) => {
                                this.$router.push(`/transactions/${response.data.body.transaction.component}/${response.data.body.transaction.id}/view`);
                            });

                        }).catch((error) => {
                        });
                    }
                });
            }
        }
    }
</script>
<template>
    <div class="row justify-content-center pt-4">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div :class="['dimmer' , loading || form.loading ? 'active' : '']">
                        <div class="loader"></div>
                        <div class="dimmer-content">
                            <div class="form-group mb-0 justify-content-end row">
                                <div class="col-lg-9">
                                    <h4 class="header-title mb-2">Internal Liquidation of USD Nostro Funds</h4>
                                </div>
                            </div>
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label"> From Account</label>
                                <div class="col-lg-9">
                                    <div class="help-block text-right mw-400"><small> [ Debit ] </small></div>
                                    <input type="text" name="sending_account" :value="form.sending_account" :class="[ 'form-control mw-400 ']" disabled>
                                </div>
                            </div>
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label">To Account</label>
                                <div class="col-lg-9">
                                    <div class="help-block text-right mw-400"><small> [ Credit ] </small></div>
                                    <select  name="receiving_account" v-model="form.receiving_account" :disabled="this.accounts.length < 2" :class="[ 'form-control mw-400 ' , form.errors.get('receiving_account') ? 'is-invalid' : '' ]">
                                        <option value="">Choose Account</option>
                                        <option v-for="account in accounts" :value="account.account">{{ account.account }} - {{ account.currency.name }}</option>
                                    </select>
                                    <div v-text="form.errors.get('receiving_account')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label">Confirm Account</label>
                                <div class="col-lg-9">
                                    <div class="help-block text-right mw-400"><small> [ Credit ] </small></div>
                                    <select  name="receiving_account_confirmation" v-model="form.receiving_account_confirmation" :disabled="this.accounts.length < 2" :class="[ 'form-control mw-400 ' , form.errors.get('receiving_account_confirmation') ? 'is-invalid' : '' ]">
                                        <option value="">Choose Account</option>
                                        <option v-for="account in accounts" :value="account.account">{{ account.account }} - {{ account.currency.name }}</option>
                                    </select>
                                    <div v-text="form.errors.get('receiving_account_confirmation')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label">Amount</label>
                                <div class="col-lg-9">
                                    <input type="number" name="amount" v-model="form.amount" :class="[ 'form-control mw-400' , form.errors.get('amount') ? 'is-invalid' : '' ]" placeholder="Amount">
                                    <div v-text="form.errors.get('amount')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label">Reference </label>
                                <div class="col-lg-9">
                                    <div class="help-block text-right mw-400"><small> [ Optional ] </small></div>
                                    <input type="text" name="amount" v-model="form.reference" :class="[ 'form-control mw-400' , form.errors.get('reference') ? 'is-invalid' : '' ]" placeholder="Reference">
                                    <div v-text="form.errors.get('reference')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="form-group row mb-3 align-items-center">
                                <label class="col-lg-3 col-form-label">Name </label>
                                <div class="col-lg-9">
                                    <div class="help-block text-right mw-400"><small> [ Optional ] </small></div>
                                    <input type="text" name="name" v-model="form.name" :class="[ 'form-control mw-400' , form.errors.get('name') ? 'is-invalid' : '' ]" placeholder="Name">
                                    <div v-text="form.errors.get('name')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="form-group mb-0 justify-content-end row">
                                <div class="col-lg-9">
                                    <button type="submit" @click.prevent="submit" :class="['btn btn-primary' , form.loading ? 'btn-loading' : '']">Transfer</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

