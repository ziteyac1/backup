<script>
    import Form from "../../core/forms/form";
    import DataSelect from "../core/DataSelect";
    import MultiDataSelect from "../core/MultiDataSelect";
    export default {
        name: "institutions-form",
        components: {MultiDataSelect, DataSelect},
        props: [ 'edit' , 'id' ],
        data(){
            return {
                form : new Form({
                    name : '',
                    email : '',
                    phone : '',
                    address : '',
                    contact : '',
                    auth : '',
                }),
            };
        },
        mounted() {
            if (this.edit)
            {
                this.init();
            }
        },
        methods: {
            init(){
                this.form.loading = true;
                window.axios.get(`/corporates/${this.id}/view`).then((response) => {
                    this.form.extract(response.data.body.model);
                    this.form.auth =  response.data.body.model.settings.number_of_auth;
                    this.form.loading = false;
                });
            },
            create(){
                this.form.submit(this.edit ? `/corporates/${this.id}/update`  : '/corporates/create').then((response) => {
                    window.alerts.success(response).then((response) => {
                        if (!this.edit)
                        this.$router.push(`/corporates/${response.data.body.model.id}/view`);
                    });
                }).catch((error) => {
                }).finally(() => {
                });
            }
        }
    }
</script>
<template>
    <div class="row pt-3">
        <div class="col-lg-12">
            <div :class="['dimmer' , form.loading ? 'active' : '']">
                <div class="loader"></div>
                <div class="dimmer-content">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="mb-3"> {{ this.edit ? 'Edit' : 'Create' }}  Corporate</h4>
                            <div class="form-horizontal">
                                <div class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Name</label>
                                    <div class="col-lg-9">
                                        <input type="text" name="name" v-model="form.name" :class="[ 'form-control mw-400' , form.errors.get('name') ? 'is-invalid' : '' ]" placeholder="Name"/>
                                        <div v-text="form.errors.get('name')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Email</label>
                                    <div class="col-lg-9">
                                        <input type="email" name="email" v-model="form.email" :class="[ 'form-control mw-400' , form.errors.get('email') ? 'is-invalid' : '' ]" placeholder="Email"/>
                                        <div v-text="form.errors.get('email')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Contact Name</label>
                                    <div class="col-lg-9">
                                        <input type="text" name="contact" v-model="form.contact" :class="[ 'form-control mw-400' , form.errors.get('contact') ? 'is-invalid' : '' ]" placeholder="Contact Name"/>
                                        <div v-text="form.errors.get('contact')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Phone</label>
                                    <div class="col-lg-9">
                                        <input type="number" name="phone" v-model="form.phone" :class="[ 'form-control mw-400' , form.errors.get('phone') ? 'is-invalid' : '' ]" placeholder="Phone"/>
                                        <div v-text="form.errors.get('phone')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Number of Authorises</label>
                                    <div class="col-lg-9">
                                        <input type="number" name="auth" v-model="form.auth" :class="[ 'form-control mw-400' , form.errors.get('auth') ? 'is-invalid' : '' ]" placeholder="Number of Authorises"/>
                                        <div v-text="form.errors.get('auth')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div class="form-group row mb-3 align-items-center">
                                    <label class="col-lg-3 col-form-label">Address</label>
                                    <div class="col-lg-9">
                                        <textarea type="text" name="address" v-model="form.address" :class="[ 'form-control mw-400' , form.errors.get('address') ? 'is-invalid' : '' ]" placeholder="Address"/>
                                        <div v-text="form.errors.get('address')" class="invalid-feedback"/>
                                    </div>
                                </div>
                                <div class="form-group mb-0 justify-content-end row">
                                    <div class="col-lg-9">
                                        <button type="submit" @click.prevent="create" :class="['btn btn-primary' , form.loading ? 'btn-loading' : '']">{{ this.edit ? 'Edit' : 'Create' }} Corporate</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>
