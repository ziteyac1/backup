<script>
    import Document from "../core/documents";
    export default {
        components: { Document }
    }
</script>
<template>
   <document :id="$route.params.id" type="corporate"/>
</template>
