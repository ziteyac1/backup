<script>
    export default {
        name: "institutions-view",
        data() {
            return {
                corporate: {
                    accounts : []
                },
                loading: true
            };
        },
        methods : {
            action(action)
            {
                window.action(action , 'Corporate' , `${window.location.origin}/corporates/${this.$route.params.id}/${action}`).then((response) => {
                    this.init();
                });
            },
            act(action  , id){
                window.action(action , 'Account' , `${window.location.origin}/accounts/${id}/${action}`).then((response) => {
                    this.init();
                });
            },
            init(){
                this.loading = true;
                window.axios.get(`${window.location.origin}/corporates/${this.$route.params.id}/view`).then((response) => {
                    this.corporate = response.data.body.model;
                }).finally(() => {
                    this.loading = false;
                });
            }
        },
        mounted() {
            this.init();
        }
    }
</script>
<template>
    <div :class="['dimmer' , loading ? 'active' : '']">
        <div class="loader"></div>
        <div class="dimmer-content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-3 flex-wrap">
                                <h4 class="header-title m-0 flex-fill">Corporate Information</h4>
                                <div class="">
                                    <button v-if="!corporate.status" @click="action('activate')" type="button" class="btn btn-light m-1">
                                        <i class="mdi mdi-lightbulb-outline mr-1"></i> Activate
                                    </button>
                                    <button v-if="corporate.is_tobacco_client !== 1" @click="action('add_tobacco')" type="button" class="btn btn-light m-1">
                                        <i class="mdi mdi-lightbulb-outline mr-1"></i> Add Tobacco Payments
                                    </button>
                                    <button v-if="corporate.is_tobacco_client === 1" @click="action('remove_tobacco')" type="button" class="btn btn-light m-1">
                                        <i class="mdi mdi-lightbulb-outline mr-1"></i> Remove Tobacco Payments
                                    </button>
                                    <button v-if="corporate.status" @click="action('deactivate')"  type="button" class="btn btn-light m-1">
                                        <i class="mdi mdi-lightbulb-off-outline mr-1"></i> De-Activate
                                    </button>
                                </div>
                            </div>
                            <div class="text-left">
                                <p>
                                    <strong class="mr-2">Name :</strong>
                                    <span>{{ corporate.name }}</span>
                                </p>
                                <p>
                                    <strong class="mr-2">Email :</strong>
                                    <span>{{ corporate.email }}</span>
                                </p>
                                <p>
                                    <strong class="mr-2">Phone :</strong>
                                    <span>{{ corporate.phone }}</span>
                                </p>
                                <p>
                                    <strong class="mr-2">Address :</strong>
                                    <span>{{ corporate.address }}</span>
                                </p>
                                <p>
                                    <strong class="mr-2">Contact :</strong>
                                    <span>{{ corporate.contact }}</span>
                                </p>
                            </div>
                        </div>
                        <div class="card-body border-top">
                            <div class="d-flex align-items-center flex-wrap">
                                <h4 class="header-title m-0 flex-fill">Accounts</h4>
                                <div class="">
                                    <router-link :to="`/accounts/create?parent=${corporate.id}&type=corporates`" type="button" class="btn btn-light m-1">
                                        <i class="mdi mdi-plus mr-1"></i> Create Account
                                    </router-link>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-centered table-nowrap mb-0">
                                <tbody>
                                <tr :key="`account-${account.id}`" v-for="account in corporate.accounts">
                                    <td/>
                                        <td class="text-primary">
                                            #{{ account.id }}
                                        </td>
                                        <td>
                                            <h5 class="font-14 my-1 font-weight-normal">{{ account.created_at }}</h5>
                                            <span class="text-muted font-13">Date Created</span>
                                        </td>
                                        <td>
                                            <h5 class="font-14 my-1 font-weight-normal">{{ account.updated_at }}</h5>
                                            <span class="text-muted font-13">Last Update</span>
                                        </td>
                                        <td>
                                            <h5 class="font-14 my-1 font-weight-normal">{{ account.account }}</h5>
                                            <span class="text-muted font-13">Account</span>
                                        </td>
                                        <td>
                                            <h5 class="font-14 my-1 font-weight-normal">{{ account.currency.name }}</h5>
                                            <span class="text-muted font-13">Currency</span>
                                        </td>
                                        <td>
                                            <router-link :to="`/accounts/${account.id}/edit?parent=${corporate.id}&type=corporates`" class="btn btn-light">Edit Account</router-link>
                                        </td>
                                        <td>
                                            <button v-if="!account.status" @click.prevent="act('activate' , account.id)" class="btn btn-light">Activate Account</button>
                                            <button v-if="account.status" @click.prevent="act('deactivate' , account.id)" class="btn btn-light">De-Activate Account</button>
                                        </td>
                                    <td/>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
