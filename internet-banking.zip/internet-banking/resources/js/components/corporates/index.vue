<script>
    import PageIndex from "../core/page-index";
    export default {
        components: {PageIndex}
    }
</script>
<template>
    <page-index url="/corporates" prefix="corporates" name="Corporates">
        <template slot="actions">
            <router-link to="/corporates/create" class="btn btn-primary ml-2">New Corporate</router-link>
        </template>
        <template slot-scope="data" slot="filters">

        </template>
        <template slot="sort-fields">
            <option value="created_at">Created</option>
            <option value="updated_at">Updated</option>
        </template>
        <template slot="table-header">
            <th></th>
            <th>Name</th>
            <th>Contact</th>
            <th>Contact</th>
            <th>Dates</th>
            <th class="text-center"></th>
        </template>
        <template slot="table-row" slot-scope="data">
            <td>
                <span class="text-primary">#{{ data.row.id }}</span>
            </td>
            <td>{{ data.row.name }}</td>
            <td> email : {{ data.row.email }} <br> phone : {{ data.row.phone }}</td>
            <td> name : {{ data.row.contact }}  <br> {{ data.row.address | string_limit }}</td>
            <td> created : {{ data.row.read_created_at }} <br> updated : {{ data.row.read_updated_at  }} </td>
            <td>
                <router-link :to="`/corporates/${data.row.id}/view`" class="action-icon text-primary">
                    <i class="mdi mdi-eye mdi-24px"/>
                </router-link>
            </td>
        </template>
    </page-index>
</template>
