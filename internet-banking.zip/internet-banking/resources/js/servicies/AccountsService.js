
class AccountsService {

    static load(instance , response)
    {
        instance.accounts = response.data.body.accounts;
        if (instance.accounts.length === 0)
        {
            window.warn('You don\'t have any Account(s) linked, Contact the Bank');
        }
        if (instance.accounts.length === 1)
        {
            let account = instance.accounts[0];
            instance.form.sending_account = account.id;
        }
    }

    static loadAccounts(instance){
        instance.loading = true;
        window.axios.get(`${window.location.origin}/transactions/accounts`).then((response) => {
            AccountsService.load(instance,response);
        }).finally(() => {
            instance.loading = false;
        });
    }
}

export default AccountsService;
