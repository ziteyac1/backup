window.action = function (action , name , url ) {
    return new Promise((resolve, reject) => {
        window.Swal.fire({
            title: 'Are you sure?',
            text: `You want to ${action.replace('-' , ' ')} this ${name}!`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#1c4b27',
            cancelButtonColor: '#d33',
            confirmButtonText: `Yes, ${action.replace('-' , ' ')}!`
        }).then((result) => {
            if (result.value) {
                window.axios.get(url).then((response) => {
                    window.alerts.success(response).then((response) => {
                        resolve(response);
                    });
                }).catch((error) => {
                    reject(error);
                });
            } else {
                reject({});
            }
        });
    });
};

window.warn = function(message){
    window.Swal.fire({
        icon: 'error',
        text: message,
        showConfirmButton: true,
        confirmButtonColor: '#1c4b27',
        padding: '20px',
    }).then((e) => {});
}

window.process = function(action , name , url ) {
    return new Promise((resolve, reject) => {
        window.Swal.fire({
            title: 'Are you sure?',
            text: `You want to ${action.replace('-' , ' ')} this ${name}!`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#1c4b27',
            cancelButtonColor: '#d33',
            confirmButtonText: `Yes, ${action.replace('-' , ' ')}!`
        }).then((result) => {
            if (result.value) {
                window.axios.get(url).then((response) => {
                    if (response.data.success === true){
                        window.alerts.success(response).then((response) => {
                            resolve(response);
                        });
                    } else {
                        window.alerts.error(response).then((response) => {
                            resolve(response);
                        });
                    }
                }).catch((error) => {
                    reject(error);
                });
            } else {
                reject({});
            }
        });
    });
};
