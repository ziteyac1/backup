<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Agribank</title>
    <link href="{{ asset('assets/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('assets/css/app.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('css/app.css') }}" rel="stylesheet" type="text/css" />
    <style>
        .container {
            max-width: 100% !important;
        }

        .tree {
            page-break-inside: avoid;
        }
        thead { display: table-header-group }
        tfoot { display: table-row-group }
        tr { page-break-inside: avoid }
    </style>
</head>
<body data-leftbar-theme="light">
<div id="app" class="wrapper bg-white">
    <div class="container bg-white">
        <div class="row">
            <div class="col-lg-12 p-0 font-12">
                <div class="card shadow-none border-0">
                    <div class="text-dark text-center my-3">
                        <strong> NB : <i>To verify if the below document is authentic scan the QR code below and follow the link</i></strong>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-centered">
                            <tbody>
                            <tr>
                                <td></td>
                                <td>
                                    <div class="text-left">
                                        <img src="{{ asset('/images/logo-full.png') }}" height="120" alt="">
                                    </div>
                                </td>
                                <td>
                                    <div class="text-center mx-auto text-dark">
                                        Agricultural Bank of Zimbabwe <br>
                                        Hurudza House, 14-16 Nelson Mandela Harare , Zimbabwe <br>
                                        Tel: (+263)(242) 774400-19
                                    </div>
                                </td>
                                <td>
                                    <div class="text-right">
                                        <img src="{{ asset($statement['qr']) }}" height="140" alt="">
                                    </div>
                                </td>
                                <td></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-body px-5 border-bottom border-dark text-dark border-top">
                        <h3 class="text-center">Account Statement</h3>
                        <h6 class="text-center"> {{ $statement['date'] }} </h6>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-centered">
                            <tbody>
                            <tr>
                                <td></td>
                                <td class="text-left">
                                    Name : <strong>{{ $statement['name'] }}</strong> <br>
                                    Reference : <strong>{{ $statement['reference']  }} </strong> <br>
                                    Account : <strong>{{ $statement['account']['account']}} </strong> <br>
                                </td>
                                <td class="text-right">
                                    Start Date : <strong>{{ $statement['date_start'] }}</strong> <br>
                                    End Date : <strong>{{ $statement['date_end']}} </strong> <br>
                                    Currency : <strong>{{ $statement['account']['currency']['name']}} </strong> <br>
                                </td>
                                <td></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="table-responsive text-dark">
                        <table class="table table-centered table-striped tree">
                            <thead class="">
                            <tr>
                                <th class="border-dark"></th>
                                <th width="100" class="border-dark">Value Date</th>
                                <th width="100" class="border-dark">Booking Date</th>
                                <th class="border-dark">Reference</th>
                                <th class="border-dark">Description</th>
                                <th class="border-dark">Location</th>
                                <th class="border-dark">Debit</th>
                                <th class="border-dark">Credit</th>
                                <th class="border-dark">Balance</th>
                                <th class="border-dark"></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($statement['transactions'] as $transaction)
                                <tr>
                                    <td/>
                                    <td><strong>{{ $transaction['valueDate'] }}</strong></td>
                                    <td><strong>{{ $transaction['bookingDate'] }}</strong></td>
                                    <td><strong>{{ $transaction['ft'] }}</strong></td>
                                    <td><strong>{{ $transaction['reference'] }}</strong></td>
                                    <td><strong>{{ $transaction['location'] }}</strong></td>
                                    <td><strong>{{ $transaction['debit'] }}</strong></td>
                                    <td><strong>{{ $transaction['credit'] }}</strong></td>
                                    <td><strong>{{ $transaction['balance'] }}</strong></td>
                                    <td/>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-centered table-nowrap mb-0 table-borderless border-top border-dark">
                            <tbody>
                            <tr class="text-center">
                                <td/>
                                <td>
                                    <h5 class="font-14 my-1"> [ {{ $statement['total'] }} ] </h5>
                                    <span class="text-dark font-13">Total</span>
                                </td>
                                <td>
                                    <h5 class="font-14 my-1">{{ $statement['start'] }}</h5>
                                    <span class="text-dark font-13">Start Balance</span>
                                </td>
                                <td>
                                    <h5 class="font-14 my-1">[ {{ $statement['debits_count'] }} ] {{ $statement['debits'] }}</h5>
                                    <span class="text-dark font-13">Debits</span>
                                </td>
                                <td>
                                    <h5 class="font-14 my-1">[ {{ $statement['credits_count'] }} ] {{ $statement['credits'] }}</h5>
                                    <span class="text-dark font-13">Credits</span>
                                </td>
                                <td>
                                    <h5 class="font-14 my-1">{{ $statement['end'] }}</h5>
                                    <span class="text-dark font-13">End Balance</span>
                                </td>
                                <td/>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-body border-top border-dark">
                        <h6 class="text-center"> Auth Code : {{ $statement['code'] }} </h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
