<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Agribank</title>
    <link href="{{ asset('assets/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('assets/css/app.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('css/app.css') }}" rel="stylesheet" type="text/css" />
    <style>
        .container {
            max-width: 100% !important;
        }
        .tree {
            page-break-inside: avoid;
        }
        thead { display: table-header-group }
        tfoot { display: table-row-group }
        tr { page-break-inside: avoid }
    </style>
</head>
<body data-leftbar-theme="light">
<div id="app" class="wrapper bg-white">
    <div class="container bg-white">
        <div class="row">
            <div class="col-lg-12 p-0 font-12">
                <div class="card shadow-none border-0">
                    <div class="text-dark text-center my-3">
                        <strong> NB : <i>To verify if the below document is authentic scan the QR code below and follow the link</i></strong>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-centered">
                            <tbody>
                            <tr>
                                <td></td>
                                <td>
                                    <div class="text-left">
                                        <img src="{{ asset('/images/logo-full.png') }}" height="120" alt="">
                                    </div>
                                </td>
                                <td>
                                    <div class="text-center mx-auto text-dark">
                                        Agricultural Bank of Zimbabwe <br>
                                        Hurudza House, 14-16 Nelson Mandela Harare , Zimbabwe <br>
                                        Tel: (+263)(242) 774400-19
                                    </div>
                                </td>
                                <td>
                                    <div class="text-right">
                                        <img src="{{ asset($transaction->qr) }}" height="140" alt="">
                                    </div>
                                </td>
                                <td></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-body px-5 border-bottom border-dark text-dark border-top">
                        <h3 class="text-center">Internal Transfer Confirmation</h3>
                        <h6 class="text-center"> {{ $transaction->created_at }} </h6>
                    </div>

                    <div class="table-responsive mb-0">
                        <table class="table table-centered mb-0 font-18">
                            <tbody>
                            <tr>
                                <td class="text-left font-15">
                                    <div class="pl-5">State </div>
                                </td>
                                <td class="text-right">
                                    <div class="pr-5">
                                        <strong>
                                            {{ $transaction->status->description }}
                                        </strong>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-left font-15">
                                    <div class="pl-5">Type </div>
                                </td>
                                <td class="text-right">
                                    <div class="pr-5">
                                        <strong>
                                            {{ $transaction->type }}
                                        </strong>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-left font-15">
                                    <div class="pl-5">From Account </div>
                                </td>
                                <td class="text-right">
                                    <div class="pr-5">
                                        <strong>
                                            {{ $transaction->account->account }}
                                        </strong>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-left font-15">
                                    <div class="pl-5">To Account </div>
                                </td>
                                <td class="text-right">
                                    <div class="pr-5">
                                        <strong>
                                            {{ $transaction->transaction->receive }}
                                        </strong>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-left font-15">
                                    <div class="pl-5">Name </div>
                                </td>
                                <td class="text-right">
                                    <div class="pr-5">
                                        <strong>
                                            {{ $transaction->transaction->name ?  $transaction->transaction->name : 'Not Specified' }}
                                        </strong>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-left font-15">
                                    <div class="pl-5">Reason </div>
                                </td>
                                <td class="text-right">
                                    <div class="pr-5">
                                        <strong>
                                            {{ $transaction->transaction->reference ?  $transaction->transaction->reference : 'Not Specified' }}
                                        </strong>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-left font-15">
                                    <div class="pl-5">Currency </div>
                                </td>
                                <td class="text-right">
                                    <div class="pr-5">
                                        <strong>
                                            {{ $transaction->account->currency->name }}
                                        </strong>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-left font-15">
                                    <div class="pl-5">Amount </div>
                                </td>
                                <td class="text-right">
                                    <div class="pr-5">
                                        <strong>
                                            {{ $transaction->transaction->amount }}
                                        </strong>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-left font-15">
                                    <div class="pl-5">Reference </div>
                                </td>
                                <td class="text-right">
                                    <div class="pr-5">
                                        <strong>
                                            {{ !$transaction->reference ? 'Not Available' :  $transaction->reference  }}
                                        </strong>
                                    </div>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="card-body border-top border-dark">
                        <h6 class="text-center"> Auth Code : {{ $transaction->code }} </h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
