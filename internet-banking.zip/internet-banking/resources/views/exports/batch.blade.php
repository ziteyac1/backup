<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Agribank</title>
    <link href="{{ pdf_asset('/assets/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ pdf_asset('/assets/css/app.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ pdf_asset('/css/app.css') }}" rel="stylesheet" type="text/css" />
    <style>
        .container {
            max-width: 100% !important;
        }

        .tree {
            page-break-inside: avoid;
        }
        thead { display: table-header-group }
        tfoot { display: table-row-group }
        tr { page-break-inside: avoid }
    </style>
</head>
<body data-leftbar-theme="light">
<div id="app" class="wrapper bg-white">
    <div class="container bg-white">
        <div class="row">
            <div class="col-lg-12 p-0">
                <div class="card shadow-none border-0">
                    <div class="table-responsive">
                        <table class="table table-centered">
                            <tbody>
                            <tr>
                                <td></td>
                                <td>
                                    <div class="text-left">
                                        <img src="{{ pdf_asset('/images/logo-full.png') }}" height="120" alt="">
                                    </div>
                                </td>
                                <td>
                                    <div class="text-center mx-auto text-dark">
                                        Agricultural Bank of Zimbabwe <br>
                                        Hurudza House, 14-16 Nelson Mandela Harare , Zimbabwe <br>
                                        Tel: (+263)(242) 774400-19
                                    </div>
                                </td>
                                <td>
                                    <div class="text-right">
                                        <img src="{{ pdf_asset('/images/logo-full.png') }}" height="120" alt="">
                                    </div>
                                </td>
                                <td></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-body px-5 border-bottom border-dark text-dark border-top">
                        <h3 class="text-center">Batch Report</h3>
                        <h6 class="text-center"> {{ $batch->created_at }} </h6>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-centered">
                            <tbody>
                            <tr>
                                <td></td>
                                <td> Status </td>
                                <td class="text-right"> <strong> {{ $batch->state->description }} </strong> </td>
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td> Reference </td>
                                <td class="text-right"> <strong> {{ $batch->reference }} </strong> </td>
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td> File </td>
                                <td class="text-right"> <strong> {{ $batch->name }} </strong> </td>
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td> Uploaded </td>
                                <td class="text-right"> <strong> {{ $batch->user->full_name  }} - {{ $batch->user->email }} </strong> </td>
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td> Processed Records </td>
                                <td class="text-right"> <strong> {{ $batch->proceed_count }} </strong> </td>
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td> Failed Records </td>
                                <td class="text-right"> <strong> {{ $batch->failed_count }} </strong> </td>
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td> Upload Success </td>
                                <td class="text-right"> <strong> {{ $batch->upload_success }} </strong> </td>
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td> Upload Errors </td>
                                <td class="text-right"> <strong> {{ $batch->upload_error }} </strong> </td>
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td> Batch Total </td>
                                <td class="text-right"> <strong> {{ $batch->total }} </strong> </td>
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td> Batch Debited </td>
                                <td class="text-right"> <strong> {{ $batch->total_debited }} </strong> </td>
                                <td></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="table-responsive text-dark  font-11">
                        <table class="table table-centered table-striped tree">
                            <thead class="">
                            <tr>
                                <th class="border-dark"></th>
                                <th class="border-dark text-center"></th>
                                <th class="border-dark">ID</th>
                                <th class="border-dark">Info</th>
                                <th class="border-dark">Account</th>
                                <th class="border-dark">Type</th>
                                <th class="border-dark">State</th>
                                <th class="border-dark">Amount</th>
                                <th class="border-dark"></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($batch->transactions as $transaction)
                                <tr>
                                    <td></td>
                                    <td><img height="80px" src="{{ pdf_asset($transaction->qr) }}" alt=""/></td>
                                    <td><strong>{{ $transaction->id }}</strong></td>
                                    <td>
                                        <strong>{{ $transaction->created_at }}</strong><br>
                                        <strong>{{ $transaction->reference }}</strong>
                                    </td>
                                    @if ($transaction->type === 'internal-transfer')
                                        <td>
                                            <strong>{{ $transaction->transaction->receive }}</strong> <br>
                                            <strong>{{ $transaction->transaction->reference }}</strong> <br>
                                            <strong>{{ $transaction->transaction->name }}</strong> <br>
                                        </td>
                                        @elseif ($transaction->type === 'rtgs-transfer')
                                        <td>
                                            <strong>{{ $transaction->transaction->receive }}</strong> <br>
                                            <strong>{{ $transaction->transaction->reason }}</strong> <br>
                                            <strong>{{ $transaction->transaction->name }}</strong> <br>
                                        </td>
                                    @else
                                    @endif
                                    <td><strong>{{ $transaction->type }}</strong></td>
                                    <td><strong>{{ $transaction->status->description }}</strong></td>
                                    <td><strong>{{ $transaction->amount }}</strong></td>
                                    <td></td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
