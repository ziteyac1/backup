<!--
Agribank Internet Banking - Done By Prince Gurajena
-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Agribank Internet Banking </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="user" content="{{ json_encode($user) }}">
    <link rel="shortcut icon" href="/images/logo_YDo_icon.ico">
    <link href="/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="/assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <link href="/css/app.css" rel="stylesheet" type="text/css" />
</head>
<body data-leftbar-theme="light">
<div id="app" class="wrapper">
    <div class="left-side-menu">
        <div class="h-100"  data-simplebar>
            <router-link to="/" class="logo text-center">
                <span class="logo-lg">
                    <img src="/img/logo green365-4.png" alt="" height="55">
                </span>
                <span class="logo-sm">
                    <img src="/img/logo green365-4.png" alt="" height="55">
                </span>
            </router-link>
            <ul class="metismenu side-nav">
                <li class="side-nav-title side-nav-item">Navigation</li>
                <li class="side-nav-item">
                    <router-link to="/" class="side-nav-link">
                        <i class="uil-home-alt"></i>
                        <span> Dashboard </span>
                    </router-link>
                </li>
                <li class="side-nav-item">
                    <router-link to="/dashboard/accounts" class="side-nav-link">
                        <i class="uil-panorama-v"></i>
                        <span> My Accounts </span>
                    </router-link>
                </li>
                @can('initiate', \App\Transaction::class)
                    <li class="side-nav-item">
                        <router-link to="/transactions/internal" class="side-nav-link">
                            <i class="uil-scroll"></i>
                            <span> Internal Transfer </span>
                        </router-link>
                    </li>
                @endcan
                @can('initiate', \App\Transaction::class)
                <li class="side-nav-item">
                    <router-link to="/transactions/rtgs" class="side-nav-link">
                        <i class="uil-sort"></i>
                        <span> RTGS Transfer </span>
                    </router-link>
                </li>
                @endcan
                @can('initiate', \App\Transaction::class)
                <li class="side-nav-item">
                    <router-link to="/batch" class="side-nav-link">
                        <i class="uil-folder-upload"></i>
                        <span> Batch Transfers </span>
                    </router-link>
                </li>
                @endcan
                {{--@can('tobacco', \App\Transaction::class)
                <li class="side-nav-item">
                    <router-link to="/tobacco/batch" class="side-nav-link">
                        <i class="uil-cloud"></i>
                        <span> Tobacco Payments </span>
                    </router-link>
                </li>
                @endcan--}}
                @can('run', \App\StatementEnquiry::class)
                <li class="side-nav-item">
                    <router-link to="/statement" class="side-nav-link">
                        <i class="uil-receipt"></i>
                        <span> Statement </span>
                    </router-link>
                </li>
                @endcan
                @can('list', \App\Authorisation::class)
                <li class="side-nav-item">
                    <router-link to="/authorisations" class="side-nav-link">
                        <i class="uil-lock-access"></i>
                        <span> Authorisations </span>
                    </router-link>
                </li>
                @endcan
                <li class="side-nav-item">
                    <router-link to="/transactions" class="side-nav-link">
                        <i class="uil-align-left"></i>
                        <span> Transactions </span>
                    </router-link>
                </li>
                @can('list', \App\User::class)
                <li class="side-nav-item">
                    <router-link to="/users" class="side-nav-link">
                        <i class="uil-users-alt"></i>
                        <span> Users </span>
                    </router-link>
                </li>
                @endcan
                @can('list', \App\Account::class)
                <li class="side-nav-item">
                    <router-link to="/registrations" class="side-nav-link">
                        <i class="uil-user-plus"></i>
                        <span> Registrations </span>
                    </router-link>
                </li>
                @endcan
                @can('list', \App\Corporate::class)
                <li class="side-nav-item">
                    <router-link to="/corporates" class="side-nav-link">
                        <i class="uil-building"></i>
                        <span> Corporates </span>
                    </router-link>
                </li>
                @endcan
                @can('list', \App\Account::class)
                <li class="side-nav-item">
                    <router-link to="/accounts" class="side-nav-link">
                        <i class="uil-money-withdraw"></i>
                        <span> Accounts </span>
                    </router-link>
                </li>
                @endcan
                <li class="side-nav-item">
                    <router-link to="/settings" class="side-nav-link">
                        <i class="uil-bright"></i>
                        <span> Settings </span>
                    </router-link>
                </li>
                @if (auth()->user()->is_root)
                    <li class="side-nav-item">
                        <a href="/horizon" target="_blank" class="side-nav-link">
                            <i class="uil-desktop"></i>
                            <span> Monitor </span>
                        </a>
                    </li>
                @endif
                @if (auth()->user()->is_root)
                    <li class="side-nav-item">
                        <a href="/console" target="_blank" class="side-nav-link">
                            <i class="uil-no-entry"></i>
                            <span> Console </span>
                        </a>
                    </li>
                @endif
            </ul>
            <div class="clearfix"></div>
        </div>
    </div>
    <div class="content-page">
        <div class="content">
            <div class="navbar-custom">
                <ul class="list-unstyled topbar-right-menu float-right mb-0">
                    <li class="dropdown notification-list">
                        <a class="nav-link dropdown-toggle nav-user arrow-none mr-0" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                            <span class="account-user-avatar border border-primary rounded-circle">
                                <img src="/images/hiclipart.com.png" alt="user-image" class="rounded-circle">
                            </span>
                            <span>
                                <span class="account-user-name">{{ \Illuminate\Support\Str::limit(auth()->user()->full_name , 20 , '...')  }}</span>
                                <span class="account-position text-capitalize">{{ auth()->user()->type }}</span>
                            </span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated topbar-dropdown-menu profile-dropdown">
                            <router-link to="/settings" class="dropdown-item notify-item">
                                <i class="mdi mdi-account-edit mr-1"></i>
                                <span>Settings</span>
                            </router-link>
                            <form id="logout-form" action="/logout" method="POST" style="display: none;">
                                @csrf
                            </form>
                            <a @click.prevent="logout" href="#" class="dropdown-item notify-item">
                                <i class="mdi mdi-logout mr-1"></i>
                                <span>Logout</span>
                            </a>
                        </div>
                    </li>
                </ul>
                <button class="button-menu-mobile open-left disable-btn">
                    <i class="mdi mdi-menu"></i>
                </button>
            </div>
            <div class="container-fluid">
                <keep-alive>
                    <transition name="slide-in-left">
                        <router-view></router-view>
                    </transition>
                </keep-alive>
            </div>
        </div>
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6">
                        @ {{ now()->format('Y') }} Agribank 365 Banking
                    </div>
                </div>
            </div>
        </footer>
    </div>
</div>
<script src="/assets/js/vendor.min.js"></script>
<script src="/assets/js/app.min.js"></script>
<script src="/js/app.js"></script>

</body>
</html>
