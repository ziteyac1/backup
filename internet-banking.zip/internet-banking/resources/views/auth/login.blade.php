@extends('layouts.auth')
@section('content')
    <login></login>
@endsection
