@extends('layouts.auth')
@section('content')
    <reset></reset>
@endsection
