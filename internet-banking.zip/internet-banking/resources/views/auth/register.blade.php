@extends('layouts.auth' , ['col' => 'col-lg-9'])
@section('content')
    <register></register>
@endsection
