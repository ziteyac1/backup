<?php

use App\FundLiquidition;
use App\InternalTransfer;
use App\RTGSTransfer;
use App\StatementEnquiry;
use App\TobaccoInternalPayment;
use App\TobaccoRTGSPayment;
use App\Transactions\FundsLiquidationService;
use App\Transactions\InternalTransferService;
use App\Transactions\RTGSTransferService;
use App\Transactions\StatementEnquiryService;
use App\Transactions\TobaccoInternalPaymentService;
use App\Transactions\TobaccoRTGSTransferService;

return [
    'services' => [
        InternalTransfer::class => InternalTransferService::class,
        RTGSTransfer::class => RTGSTransferService::class,
        StatementEnquiry::class => StatementEnquiryService::class,
        FundLiquidition::class => FundsLiquidationService::class,
        TobaccoInternalPayment::class => TobaccoInternalPaymentService::class,
        TobaccoRTGSPayment::class => TobaccoRTGSTransferService::class,
    ],
    'R18-Adapter-host' => env('R18_ADAPTER' , 'http://127.0.0.1:9020'),
    'Postilion-Adapter-host' => env('POSTILION_ADAPTER' , 'http://127.0.0.1:9021'),
    'url' => env('APP_URL' , 'http://196.2.66.6:8010/'),
    'internal-port' => env('APP_INTERNAL_PORT' , '9025'),
    'adapter-name' => 'internet-banking',
];
