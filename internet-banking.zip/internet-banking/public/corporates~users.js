(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["corporates~users"],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/core/documents.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/core/documents.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_array_concat__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.filter */ "./node_modules/core-js/modules/es.array.filter.js");
/* harmony import */ var core_js_modules_es_array_filter__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_splice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.splice */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_function_name__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.function.name */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.object.to-string */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_promise__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es.promise */ "./node_modules/core-js/modules/es.promise.js");
/* harmony import */ var core_js_modules_es_promise__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_promise__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_promise_finally__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es.promise.finally */ "./node_modules/core-js/modules/es.promise.finally.js");
/* harmony import */ var core_js_modules_es_promise_finally__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_promise_finally__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _core_data_Data__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../core/data/Data */ "./resources/js/core/data/Data.js");








/* harmony default export */ __webpack_exports__["default"] = ({
  name: "documents",
  props: ['id', 'type'],
  data: function data() {
    return {
      files: [],
      data: new _core_data_Data__WEBPACK_IMPORTED_MODULE_7__["default"]({
        url: "/documents/".concat(this.id, "/").concat(this.type, "/list"),
        prefix: 'documents'
      })
    };
  },
  computed: {
    upload: function upload() {
      return this.files.length > 0 && !this.close;
    },
    close: function close() {
      return this.files.length > 0 && this.files.filter(function (e) {
        return e.id === 1 || e.id === 2;
      }).length === this.files.length;
    },
    loading: function loading() {
      return this.files.filter(function (e) {
        return e.id === 3;
      }).length > 0;
    }
  },
  methods: {
    action: function action(id, _action) {
      var _this = this;

      window.action(_action, 'Document', "".concat(window.location.origin, "/documents/").concat(id, "/").concat(_action)).then(function (response) {
        _this.data.fetch();
      }).bind(this);
    },
    handleFiles: function handleFiles() {
      var uploadedFiles = this.$refs.files.files;

      for (var i = 0; i < uploadedFiles.length; i++) {
        this.files.push({
          id: 0,
          content: uploadedFiles[i]
        });
      }

      this.getImagePreviews();
    },
    reset: function reset() {
      this.files = [];
    },
    init: function init() {
      this.data.fetch();
      this.data.filters.size = 100;
    },
    getImagePreviews: function getImagePreviews() {
      var _this2 = this;

      var _loop = function _loop(i) {
        if (/\.(jpe?g|png|gif)$/i.test(_this2.files[i].content.name)) {
          var reader = new FileReader();
          reader.addEventListener("load", function () {
            this.$refs['preview' + parseInt(i)][0].src = reader.result;
          }.bind(_this2), false);
          reader.readAsDataURL(_this2.files[i].content);
        } else {
          _this2.$nextTick(function () {
            this.$refs['preview' + parseInt(i)][0].src = '/img/generic.png';
          });
        }
      };

      for (var i = 0; i < this.files.length; i++) {
        _loop(i);
      }
    },
    removeFile: function removeFile(key) {
      this.files.splice(key, 1);
      this.getImagePreviews();
    },
    submitFiles: function submitFiles() {
      var _this3 = this;

      var _loop2 = function _loop2(i) {
        if (_this3.files[i].id > 0) {
          return "continue";
        }

        var formData = new FormData();
        formData.append('file', _this3.files[i].content);
        _this3.files[i].id = 3;
        window.axios.post("/documents/".concat(_this3.id, "/").concat(_this3.type, "/upload"), formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }).then(function (data) {
          _this3.files[i].id = 1;

          _this3.files.splice(i, 1, _this3.files[i]);

          _this3.data.fetch();
        }).catch(function (data) {
          _this3.files[i].id = 2;
        }).finally(function () {});
      };

      for (var i = 0; i < this.files.length; i++) {
        var _ret = _loop2(i);

        if (_ret === "continue") continue;
      }
    }
  },
  mounted: function mounted() {
    this.init();
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/core/page-open.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/core/page-open.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  name: "page-open"
});

/***/ }),

/***/ "./node_modules/core-js/modules/es.array.splice.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es.array.splice.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
var toAbsoluteIndex = __webpack_require__(/*! ../internals/to-absolute-index */ "./node_modules/core-js/internals/to-absolute-index.js");
var toInteger = __webpack_require__(/*! ../internals/to-integer */ "./node_modules/core-js/internals/to-integer.js");
var toLength = __webpack_require__(/*! ../internals/to-length */ "./node_modules/core-js/internals/to-length.js");
var toObject = __webpack_require__(/*! ../internals/to-object */ "./node_modules/core-js/internals/to-object.js");
var arraySpeciesCreate = __webpack_require__(/*! ../internals/array-species-create */ "./node_modules/core-js/internals/array-species-create.js");
var createProperty = __webpack_require__(/*! ../internals/create-property */ "./node_modules/core-js/internals/create-property.js");
var arrayMethodHasSpeciesSupport = __webpack_require__(/*! ../internals/array-method-has-species-support */ "./node_modules/core-js/internals/array-method-has-species-support.js");
var arrayMethodUsesToLength = __webpack_require__(/*! ../internals/array-method-uses-to-length */ "./node_modules/core-js/internals/array-method-uses-to-length.js");

var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport('splice');
var USES_TO_LENGTH = arrayMethodUsesToLength('splice', { ACCESSORS: true, 0: 0, 1: 2 });

var max = Math.max;
var min = Math.min;
var MAX_SAFE_INTEGER = 0x1FFFFFFFFFFFFF;
var MAXIMUM_ALLOWED_LENGTH_EXCEEDED = 'Maximum allowed length exceeded';

// `Array.prototype.splice` method
// https://tc39.github.io/ecma262/#sec-array.prototype.splice
// with adding support of @@species
$({ target: 'Array', proto: true, forced: !HAS_SPECIES_SUPPORT || !USES_TO_LENGTH }, {
  splice: function splice(start, deleteCount /* , ...items */) {
    var O = toObject(this);
    var len = toLength(O.length);
    var actualStart = toAbsoluteIndex(start, len);
    var argumentsLength = arguments.length;
    var insertCount, actualDeleteCount, A, k, from, to;
    if (argumentsLength === 0) {
      insertCount = actualDeleteCount = 0;
    } else if (argumentsLength === 1) {
      insertCount = 0;
      actualDeleteCount = len - actualStart;
    } else {
      insertCount = argumentsLength - 2;
      actualDeleteCount = min(max(toInteger(deleteCount), 0), len - actualStart);
    }
    if (len + insertCount - actualDeleteCount > MAX_SAFE_INTEGER) {
      throw TypeError(MAXIMUM_ALLOWED_LENGTH_EXCEEDED);
    }
    A = arraySpeciesCreate(O, actualDeleteCount);
    for (k = 0; k < actualDeleteCount; k++) {
      from = actualStart + k;
      if (from in O) createProperty(A, k, O[from]);
    }
    A.length = actualDeleteCount;
    if (insertCount < actualDeleteCount) {
      for (k = actualStart; k < len - actualDeleteCount; k++) {
        from = k + actualDeleteCount;
        to = k + insertCount;
        if (from in O) O[to] = O[from];
        else delete O[to];
      }
      for (k = len; k > len - actualDeleteCount + insertCount; k--) delete O[k - 1];
    } else if (insertCount > actualDeleteCount) {
      for (k = len - actualDeleteCount; k > actualStart; k--) {
        from = k + actualDeleteCount - 1;
        to = k + insertCount - 1;
        if (from in O) O[to] = O[from];
        else delete O[to];
      }
    }
    for (k = 0; k < insertCount; k++) {
      O[k + actualStart] = arguments[k + 2];
    }
    O.length = len - actualDeleteCount + insertCount;
    return A;
  }
});


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/core/documents.vue?vue&type=template&id=74b95753&":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/core/documents.vue?vue&type=template&id=74b95753& ***!
  \*****************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { class: ["dimmer"] }, [
    _c("div", { staticClass: "loader" }),
    _vm._v(" "),
    _c("div", { staticClass: "dimmer-content" }, [
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-lg-12" }, [
          _c("div", { staticClass: "card" }, [
            _c("div", { staticClass: "card-body" }, [
              _c(
                "div",
                { staticClass: "row" },
                [
                  _c(
                    "div",
                    {
                      class: [
                        "mb-2",
                        _vm.files.length > 0 ? "col-lg-4" : "col-lg-12"
                      ]
                    },
                    [
                      _c("div", { staticClass: "filezone" }, [
                        _c("input", {
                          ref: "files",
                          staticClass: "drag-container",
                          attrs: {
                            type: "file",
                            id: "files",
                            multiple: "",
                            accept: ".xls,.xlsx,.csv,.docx,.doc,.pdf"
                          },
                          on: {
                            change: function($event) {
                              return _vm.handleFiles()
                            }
                          }
                        }),
                        _vm._v(" "),
                        _vm._m(0)
                      ])
                    ]
                  ),
                  _vm._v(" "),
                  _vm._l(_vm.files, function(file, key) {
                    return _c(
                      "div",
                      {
                        staticClass: "col-lg-4 mb-2",
                        class: ["dimmer", file.id === 3 ? "active" : ""]
                      },
                      [
                        _c("div", { staticClass: "loader" }),
                        _vm._v(" "),
                        _c("div", { staticClass: "dimmer-content" }, [
                          _c(
                            "div",
                            {
                              staticStyle: {
                                position: "relative",
                                "min-height": "200px",
                                "max-height": "200px"
                              }
                            },
                            [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "d-flex align-items-center justify-content-center",
                                  staticStyle: {
                                    position: "absolute",
                                    top: "0",
                                    bottom: "0",
                                    right: "0",
                                    left: "0"
                                  }
                                },
                                [
                                  _c("img", {
                                    ref: "preview" + parseInt(key),
                                    refInFor: true,
                                    staticStyle: {
                                      "min-height": "100px",
                                      "max-height": "100px"
                                    }
                                  })
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "text-white text-center text-wrap d-flex align-items-center justify-content-center",
                                  staticStyle: {
                                    position: "absolute",
                                    top: "0",
                                    height: "40px",
                                    right: "0",
                                    left: "0",
                                    "background-color": "rgba( 0, 0 , 0 , 0.7 )"
                                  }
                                },
                                [
                                  _c("span", [
                                    _vm._v(_vm._s(file.content.name))
                                  ])
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "a",
                                {
                                  staticClass:
                                    "text-white text-center text-wrap d-flex align-items-center justify-content-center",
                                  staticStyle: {
                                    position: "absolute",
                                    bottom: "0",
                                    height: "40px",
                                    right: "0",
                                    left: "0",
                                    "background-color": "rgba( 0, 0 , 0 , 0.7 )"
                                  },
                                  attrs: { href: "#" },
                                  on: {
                                    click: function($event) {
                                      $event.preventDefault()
                                      return _vm.removeFile(key)
                                    }
                                  }
                                },
                                [_c("span", [_vm._v("Remove")])]
                              ),
                              _vm._v(" "),
                              file.id === 1
                                ? _c(
                                    "div",
                                    {
                                      staticClass:
                                        "d-flex align-items-center justify-content-center text-white",
                                      staticStyle: {
                                        position: "absolute",
                                        top: "0",
                                        bottom: "0",
                                        right: "0",
                                        left: "0",
                                        "background-color":
                                          "rgba( 225,106,25 , 0.7 )"
                                      }
                                    },
                                    [
                                      _c("span", { staticClass: "font-24" }, [
                                        _vm._v("Success")
                                      ])
                                    ]
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              file.id === 2
                                ? _c(
                                    "div",
                                    {
                                      staticClass:
                                        "d-flex align-items-center justify-content-center text-white",
                                      staticStyle: {
                                        position: "absolute",
                                        top: "0",
                                        bottom: "0",
                                        right: "0",
                                        left: "0",
                                        "background-color":
                                          "rgba( 0,0,0 , 0.7 )"
                                      }
                                    },
                                    [
                                      _c("span", { staticClass: "font-24" }, [
                                        _vm._v("Error")
                                      ])
                                    ]
                                  )
                                : _vm._e()
                            ]
                          )
                        ])
                      ]
                    )
                  }),
                  _vm._v(" "),
                  _vm.upload
                    ? _c("div", { staticClass: "col-lg-4" }, [
                        _c(
                          "div",
                          { class: ["dimmer", _vm.loading ? "active" : ""] },
                          [
                            _c("div", { staticClass: "loader" }),
                            _vm._v(" "),
                            _c("div", { staticClass: "dimmer-content" }, [
                              _c(
                                "a",
                                {
                                  staticClass:
                                    "d-flex align-items-center justify-content-center text-center border",
                                  staticStyle: {
                                    "max-height": "200px",
                                    "min-height": "200px"
                                  },
                                  attrs: { href: "#" },
                                  on: {
                                    click: function($event) {
                                      $event.preventDefault()
                                      return _vm.submitFiles($event)
                                    }
                                  }
                                },
                                [_vm._m(1)]
                              )
                            ])
                          ]
                        )
                      ])
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.close
                    ? _c("div", { staticClass: "col-lg-4" }, [
                        _c(
                          "div",
                          { class: ["dimmer", _vm.loading ? "active" : ""] },
                          [
                            _c("div", { staticClass: "loader" }),
                            _vm._v(" "),
                            _c("div", { staticClass: "dimmer-content" }, [
                              _c(
                                "a",
                                {
                                  staticClass:
                                    "d-flex align-items-center justify-content-center text-center border",
                                  staticStyle: {
                                    "max-height": "200px",
                                    "min-height": "200px"
                                  },
                                  attrs: { href: "#" },
                                  on: {
                                    click: function($event) {
                                      $event.preventDefault()
                                      return _vm.reset($event)
                                    }
                                  }
                                },
                                [_vm._m(2)]
                              )
                            ])
                          ]
                        )
                      ])
                    : _vm._e()
                ],
                2
              )
            ])
          ])
        ]),
        _vm._v(" "),
        _vm.data.content.data.length > 0
          ? _c("div", { staticClass: "col-lg-12" }, [
              _c("div", { class: ["dimmer"] }, [
                _c("div", { staticClass: "loader" }),
                _vm._v(" "),
                _c("div", { staticClass: "dimmer-content" }, [
                  _c("div", { staticClass: "card" }, [
                    _c("div", { staticClass: "card-body border-bottom" }, [
                      _c(
                        "div",
                        { staticClass: "d-flex align-items-center flex-wrap" },
                        [
                          _c("div", { staticClass: "m-o" }, [
                            _c(
                              "button",
                              {
                                class: [
                                  "btn btn-primary",
                                  _vm.data.loading ? "btn-loading" : ""
                                ],
                                on: {
                                  click: function($event) {
                                    return _vm.data.fetch()
                                  }
                                }
                              },
                              [
                                _c("i", {
                                  staticClass: "mdi mdi-autorenew mr-2"
                                }),
                                _vm._v(
                                  " Refresh\n                                        "
                                )
                              ]
                            )
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "ml-3 mx-0 h5" }, [
                            _vm._v(
                              "\n                                        " +
                                _vm._s(_vm.data.content.data.length) +
                                " of " +
                                _vm._s(_vm.data.content.total) +
                                " Documents\n                                    "
                            )
                          ]),
                          _vm._v(" "),
                          _c(
                            "div",
                            {
                              staticClass:
                                "ml-auto mr-3 d-flex align-items-center"
                            },
                            [
                              _c("div", { staticClass: "mr-2" }, [
                                _vm._v("Showing")
                              ]),
                              _vm._v(" "),
                              _c("div", { staticClass: "form-group mb-0" }, [
                                _c(
                                  "select",
                                  {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.data.filters.size,
                                        expression: "data.filters.size"
                                      }
                                    ],
                                    staticClass: "custom-select",
                                    on: {
                                      change: [
                                        function($event) {
                                          var $$selectedVal = Array.prototype.filter
                                            .call(
                                              $event.target.options,
                                              function(o) {
                                                return o.selected
                                              }
                                            )
                                            .map(function(o) {
                                              var val =
                                                "_value" in o
                                                  ? o._value
                                                  : o.value
                                              return val
                                            })
                                          _vm.$set(
                                            _vm.data.filters,
                                            "size",
                                            $event.target.multiple
                                              ? $$selectedVal
                                              : $$selectedVal[0]
                                          )
                                        },
                                        function($event) {
                                          return _vm.data.fetch()
                                        }
                                      ]
                                    }
                                  },
                                  [
                                    _c("option", { attrs: { value: "10" } }, [
                                      _vm._v("10")
                                    ]),
                                    _vm._v(" "),
                                    _c("option", { attrs: { value: "15" } }, [
                                      _vm._v("15")
                                    ]),
                                    _vm._v(" "),
                                    _c("option", { attrs: { value: "25" } }, [
                                      _vm._v("25")
                                    ]),
                                    _vm._v(" "),
                                    _c("option", { attrs: { value: "30" } }, [
                                      _vm._v("30")
                                    ]),
                                    _vm._v(" "),
                                    _c("option", { attrs: { value: "50" } }, [
                                      _vm._v("50")
                                    ]),
                                    _vm._v(" "),
                                    _c("option", { attrs: { value: "100" } }, [
                                      _vm._v("100")
                                    ])
                                  ]
                                )
                              ])
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            { staticClass: "mr-3 d-flex align-items-center" },
                            [
                              _c("div", { staticClass: "mr-2" }, [
                                _vm._v("Sort By")
                              ]),
                              _vm._v(" "),
                              _c("div", { staticClass: "form-group mb-0" }, [
                                _c(
                                  "select",
                                  {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.data.sort.field,
                                        expression: "data.sort.field"
                                      }
                                    ],
                                    staticClass: "custom-select",
                                    on: {
                                      change: [
                                        function($event) {
                                          var $$selectedVal = Array.prototype.filter
                                            .call(
                                              $event.target.options,
                                              function(o) {
                                                return o.selected
                                              }
                                            )
                                            .map(function(o) {
                                              var val =
                                                "_value" in o
                                                  ? o._value
                                                  : o.value
                                              return val
                                            })
                                          _vm.$set(
                                            _vm.data.sort,
                                            "field",
                                            $event.target.multiple
                                              ? $$selectedVal
                                              : $$selectedVal[0]
                                          )
                                        },
                                        function($event) {
                                          return _vm.data.fetch()
                                        }
                                      ]
                                    }
                                  },
                                  [
                                    _c("option", { attrs: { value: "id" } }, [
                                      _vm._v("ID")
                                    ]),
                                    _vm._v(" "),
                                    _vm._t("sort-fields")
                                  ],
                                  2
                                )
                              ])
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            { staticClass: "d-flex align-items-center" },
                            [
                              _c("div", { staticClass: "form-group mb-0" }, [
                                _c(
                                  "select",
                                  {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.data.sort.direction,
                                        expression: "data.sort.direction"
                                      }
                                    ],
                                    staticClass: "custom-select",
                                    on: {
                                      change: [
                                        function($event) {
                                          var $$selectedVal = Array.prototype.filter
                                            .call(
                                              $event.target.options,
                                              function(o) {
                                                return o.selected
                                              }
                                            )
                                            .map(function(o) {
                                              var val =
                                                "_value" in o
                                                  ? o._value
                                                  : o.value
                                              return val
                                            })
                                          _vm.$set(
                                            _vm.data.sort,
                                            "direction",
                                            $event.target.multiple
                                              ? $$selectedVal
                                              : $$selectedVal[0]
                                          )
                                        },
                                        function($event) {
                                          return _vm.data.fetch()
                                        }
                                      ]
                                    }
                                  },
                                  [
                                    _c("option", { attrs: { value: "asc" } }, [
                                      _vm._v("Ascending")
                                    ]),
                                    _vm._v(" "),
                                    _c("option", { attrs: { value: "desc" } }, [
                                      _vm._v("Descending")
                                    ])
                                  ]
                                )
                              ])
                            ]
                          )
                        ]
                      )
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "card-body" }, [
                      _c(
                        "div",
                        { staticClass: "row" },
                        _vm._l(_vm.data.content.data, function(item) {
                          return _c(
                            "div",
                            { key: item.id, staticClass: "col-lg-4 mb-3" },
                            [
                              _c(
                                "div",
                                {
                                  class: [
                                    "border",
                                    item.cover ? "border-primary" : ""
                                  ]
                                },
                                [
                                  _c("div", { class: ["dimmer"] }, [
                                    _c("div", { staticClass: "loader" }),
                                    _vm._v(" "),
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "dimmer-content d-flex justify-content-center align-items-center",
                                        staticStyle: {
                                          width: "100%",
                                          height: "200px"
                                        }
                                      },
                                      [
                                        _c("img", {
                                          staticStyle: {
                                            "max-height": "100px",
                                            "min-height": "100px"
                                          },
                                          attrs: {
                                            src: item.thumbnail,
                                            alt: ""
                                          }
                                        })
                                      ]
                                    )
                                  ]),
                                  _vm._v(" "),
                                  _c(
                                    "div",
                                    { staticClass: "card-body border-top" },
                                    [
                                      _c("div", { staticClass: "tx-11" }, [
                                        _c("div", [
                                          _c("strong", [
                                            _vm._v(_vm._s(item.name))
                                          ])
                                        ]),
                                        _vm._v(" "),
                                        _c(
                                          "div",
                                          { staticClass: "text-muted" },
                                          [
                                            _vm._v(
                                              _vm._s(item.user.email) + "  | "
                                            ),
                                            _c("strong", [
                                              _vm._v(
                                                "  " +
                                                  _vm._s(item.user.name) +
                                                  " "
                                              )
                                            ])
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _c(
                                          "div",
                                          { staticClass: "text-muted" },
                                          [
                                            _vm._v(
                                              _vm._s(item.created_at) + "  | "
                                            ),
                                            _c("strong", [
                                              _vm._v(
                                                "  " +
                                                  _vm._s(
                                                    Math.round(item.size / 1024)
                                                  ) +
                                                  " kb "
                                              )
                                            ])
                                          ]
                                        )
                                      ]),
                                      _vm._v(" "),
                                      _c(
                                        "div",
                                        { staticClass: "d-flex mt-3" },
                                        [
                                          _c(
                                            "a",
                                            {
                                              class: [
                                                "btn btn-light mr-2",
                                                _vm.data.loading
                                                  ? "btn-loading"
                                                  : ""
                                              ],
                                              attrs: {
                                                href:
                                                  "/documents/" +
                                                  item.id +
                                                  "/download",
                                                target: "_blank"
                                              }
                                            },
                                            [
                                              _c("i", {
                                                staticClass: "mdi mdi-download"
                                              })
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "a",
                                            {
                                              class: [
                                                "btn btn-light ml-auto",
                                                _vm.data.loading
                                                  ? "btn-loading"
                                                  : ""
                                              ],
                                              on: {
                                                click: function($event) {
                                                  $event.preventDefault()
                                                  return _vm.action(
                                                    item.id,
                                                    "delete"
                                                  )
                                                }
                                              }
                                            },
                                            [
                                              _c("i", {
                                                staticClass: "mdi mdi-trash-can"
                                              })
                                            ]
                                          )
                                        ]
                                      )
                                    ]
                                  )
                                ]
                              )
                            ]
                          )
                        }),
                        0
                      )
                    ])
                  ])
                ])
              ])
            ])
          : _vm._e()
      ])
    ])
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "p",
      {
        staticStyle: {
          display: "flex",
          "align-items": "center",
          "justify-content": "center"
        }
      },
      [
        _vm._v(
          "\n                                        Drop your documents here "
        ),
        _c("br"),
        _vm._v(" or click to select\n                                    ")
      ]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", {}, [
      _c("i", { staticClass: "mdi mdi-upload-multiple font-24" }),
      _vm._v(" "),
      _c("br"),
      _vm._v(" "),
      _c("span", { staticClass: "font-24" }, [_vm._v("Upload")])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", {}, [
      _c("i", { staticClass: "mdi mdi-close font-24" }),
      _vm._v(" "),
      _c("br"),
      _vm._v(" "),
      _c("span", { staticClass: "font-24" }, [_vm._v("Close")])
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/core/page-open.vue?vue&type=template&id=d880b93a&":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/core/page-open.vue?vue&type=template&id=d880b93a& ***!
  \*****************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "pt-3" }, [
    _c("div", { staticClass: "card p-0" }, [
      _c(
        "ul",
        { staticClass: "nav nav-pills nav-justified bg-white" },
        [_vm._t("links")],
        2
      )
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "d-flex" }, [
      _c(
        "div",
        { staticClass: "flex-fill" },
        [
          _c(
            "keep-alive",
            [
              _c(
                "transition",
                { attrs: { name: "slide-in-left" } },
                [_c("router-view")],
                1
              )
            ],
            1
          )
        ],
        1
      )
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/core/documents.vue":
/*!****************************************************!*\
  !*** ./resources/js/components/core/documents.vue ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _documents_vue_vue_type_template_id_74b95753___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./documents.vue?vue&type=template&id=74b95753& */ "./resources/js/components/core/documents.vue?vue&type=template&id=74b95753&");
/* harmony import */ var _documents_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./documents.vue?vue&type=script&lang=js& */ "./resources/js/components/core/documents.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _documents_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _documents_vue_vue_type_template_id_74b95753___WEBPACK_IMPORTED_MODULE_0__["render"],
  _documents_vue_vue_type_template_id_74b95753___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/core/documents.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/core/documents.vue?vue&type=script&lang=js&":
/*!*****************************************************************************!*\
  !*** ./resources/js/components/core/documents.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_documents_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./documents.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/core/documents.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_documents_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/core/documents.vue?vue&type=template&id=74b95753&":
/*!***********************************************************************************!*\
  !*** ./resources/js/components/core/documents.vue?vue&type=template&id=74b95753& ***!
  \***********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_documents_vue_vue_type_template_id_74b95753___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./documents.vue?vue&type=template&id=74b95753& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/core/documents.vue?vue&type=template&id=74b95753&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_documents_vue_vue_type_template_id_74b95753___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_documents_vue_vue_type_template_id_74b95753___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/components/core/page-open.vue":
/*!****************************************************!*\
  !*** ./resources/js/components/core/page-open.vue ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _page_open_vue_vue_type_template_id_d880b93a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./page-open.vue?vue&type=template&id=d880b93a& */ "./resources/js/components/core/page-open.vue?vue&type=template&id=d880b93a&");
/* harmony import */ var _page_open_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./page-open.vue?vue&type=script&lang=js& */ "./resources/js/components/core/page-open.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _page_open_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _page_open_vue_vue_type_template_id_d880b93a___WEBPACK_IMPORTED_MODULE_0__["render"],
  _page_open_vue_vue_type_template_id_d880b93a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/core/page-open.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/core/page-open.vue?vue&type=script&lang=js&":
/*!*****************************************************************************!*\
  !*** ./resources/js/components/core/page-open.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_page_open_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./page-open.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/core/page-open.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_page_open_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/core/page-open.vue?vue&type=template&id=d880b93a&":
/*!***********************************************************************************!*\
  !*** ./resources/js/components/core/page-open.vue?vue&type=template&id=d880b93a& ***!
  \***********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_page_open_vue_vue_type_template_id_d880b93a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./page-open.vue?vue&type=template&id=d880b93a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/core/page-open.vue?vue&type=template&id=d880b93a&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_page_open_vue_vue_type_template_id_d880b93a___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_page_open_vue_vue_type_template_id_d880b93a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);