(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[3],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/settings/password.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/settings/password.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_forms_form__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core/forms/form */ "./resources/js/core/forms/form.js");

/* harmony default export */ __webpack_exports__["default"] = ({
  name: "internal",
  mounted: function mounted() {
    this.init();
  },
  data: function data() {
    return {
      loading: false,
      accounts: [],
      form: new _core_forms_form__WEBPACK_IMPORTED_MODULE_0__["default"]({
        old_password: '',
        password: '',
        password_confirmation: ''
      })
    };
  },
  methods: {
    init: function init() {},
    submit: function submit() {
      var _this = this;

      window.Swal.fire({
        title: 'Are you sure ?',
        text: "You want to update your password",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#1c4b27',
        cancelButtonColor: '#d33',
        confirmButtonText: "Yes, Update!"
      }).then(function (result) {
        if (result.value) {
          _this.form.submit('/password').then(function (response) {
            window.alerts.success(response);

            _this.form.reset();
          }).catch(function (error) {});
        }
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/settings/password.vue?vue&type=template&id=519ff8cc&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/components/settings/password.vue?vue&type=template&id=519ff8cc& ***!
  \********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "row justify-content-center" }, [
    _c("div", { staticClass: "col-lg-12" }, [
      _c("div", { staticClass: "card" }, [
        _c("div", { staticClass: "card-body" }, [
          _c(
            "div",
            {
              class: ["dimmer", _vm.loading || _vm.form.loading ? "active" : ""]
            },
            [
              _c("div", { staticClass: "loader" }),
              _vm._v(" "),
              _c("div", { staticClass: "dimmer-content" }, [
                _vm._m(0),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "form-group row mb-3 align-items-center" },
                  [
                    _c("label", { staticClass: "col-lg-3 col-form-label" }, [
                      _vm._v("Old Password")
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "col-lg-9" }, [
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.form.old_password,
                            expression: "form.old_password"
                          }
                        ],
                        class: [
                          "form-control mw-400",
                          _vm.form.errors.get("old_password")
                            ? "is-invalid"
                            : ""
                        ],
                        attrs: { type: "password", placeholder: "" },
                        domProps: { value: _vm.form.old_password },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(
                              _vm.form,
                              "old_password",
                              $event.target.value
                            )
                          }
                        }
                      }),
                      _vm._v(" "),
                      _c("div", {
                        staticClass: "invalid-feedback",
                        domProps: {
                          textContent: _vm._s(
                            _vm.form.errors.get("old_password")
                          )
                        }
                      })
                    ])
                  ]
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "form-group row mb-3 align-items-center" },
                  [
                    _c("label", { staticClass: "col-lg-3 col-form-label" }, [
                      _vm._v("New Password")
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "col-lg-9" }, [
                      _vm._m(1),
                      _vm._v(" "),
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.form.password,
                            expression: "form.password"
                          }
                        ],
                        class: [
                          "form-control mw-400",
                          _vm.form.errors.get("password") ? "is-invalid" : ""
                        ],
                        attrs: { type: "password", placeholder: "" },
                        domProps: { value: _vm.form.password },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(_vm.form, "password", $event.target.value)
                          }
                        }
                      }),
                      _vm._v(" "),
                      _c("div", {
                        staticClass: "invalid-feedback",
                        domProps: {
                          textContent: _vm._s(_vm.form.errors.get("password"))
                        }
                      })
                    ])
                  ]
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "form-group row mb-3 align-items-center" },
                  [
                    _c("label", { staticClass: "col-lg-3 col-form-label" }, [
                      _vm._v("Repeat Password")
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "col-lg-9" }, [
                      _c("input", {
                        directives: [
                          {
                            name: "model",
                            rawName: "v-model",
                            value: _vm.form.password_confirmation,
                            expression: "form.password_confirmation"
                          }
                        ],
                        class: [
                          "form-control mw-400",
                          _vm.form.errors.get("password_confirmation")
                            ? "is-invalid"
                            : ""
                        ],
                        attrs: { type: "password", placeholder: "" },
                        domProps: { value: _vm.form.password_confirmation },
                        on: {
                          input: function($event) {
                            if ($event.target.composing) {
                              return
                            }
                            _vm.$set(
                              _vm.form,
                              "password_confirmation",
                              $event.target.value
                            )
                          }
                        }
                      }),
                      _vm._v(" "),
                      _c("div", {
                        staticClass: "invalid-feedback",
                        domProps: {
                          textContent: _vm._s(
                            _vm.form.errors.get("password_confirmation")
                          )
                        }
                      })
                    ])
                  ]
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "form-group mb-0 justify-content-end row" },
                  [
                    _c("div", { staticClass: "col-lg-9" }, [
                      _c(
                        "button",
                        {
                          class: [
                            "btn btn-primary",
                            _vm.form.loading ? "btn-loading" : ""
                          ],
                          attrs: { type: "submit" },
                          on: {
                            click: function($event) {
                              $event.preventDefault()
                              return _vm.submit($event)
                            }
                          }
                        },
                        [_vm._v("Update Password")]
                      )
                    ])
                  ]
                )
              ])
            ]
          )
        ])
      ])
    ])
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      { staticClass: "form-group mb-0 justify-content-end row" },
      [
        _c("div", { staticClass: "col-lg-9" }, [
          _c("h4", { staticClass: "header-title mb-2" }, [
            _vm._v("Account Settings")
          ])
        ])
      ]
    )
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "help-block text-right mw-400" }, [
      _c("small", [
        _vm._v(
          " [ Must have at least one digit , capital , small letter and special character(@$!%*#?&) ] "
        )
      ])
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./resources/js/components/settings/password.vue":
/*!*******************************************************!*\
  !*** ./resources/js/components/settings/password.vue ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _password_vue_vue_type_template_id_519ff8cc___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./password.vue?vue&type=template&id=519ff8cc& */ "./resources/js/components/settings/password.vue?vue&type=template&id=519ff8cc&");
/* harmony import */ var _password_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./password.vue?vue&type=script&lang=js& */ "./resources/js/components/settings/password.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _password_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _password_vue_vue_type_template_id_519ff8cc___WEBPACK_IMPORTED_MODULE_0__["render"],
  _password_vue_vue_type_template_id_519ff8cc___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/settings/password.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/components/settings/password.vue?vue&type=script&lang=js&":
/*!********************************************************************************!*\
  !*** ./resources/js/components/settings/password.vue?vue&type=script&lang=js& ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_password_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--4-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./password.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/settings/password.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_password_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/settings/password.vue?vue&type=template&id=519ff8cc&":
/*!**************************************************************************************!*\
  !*** ./resources/js/components/settings/password.vue?vue&type=template&id=519ff8cc& ***!
  \**************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_password_vue_vue_type_template_id_519ff8cc___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./password.vue?vue&type=template&id=519ff8cc& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/components/settings/password.vue?vue&type=template&id=519ff8cc&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_password_vue_vue_type_template_id_519ff8cc___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_password_vue_vue_type_template_id_519ff8cc___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);