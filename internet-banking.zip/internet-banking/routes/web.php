<?php

use App\Authorisation;
use App\Batch;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AuthorisationController;
use App\Http\Controllers\BatchController;
use App\Http\Controllers\CorporateController;
use App\Http\Controllers\CurrencyController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DocumentController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\RegistrationsController;
use App\Http\Controllers\TransactionController;
use App\Http\Controllers\UserController;
use App\InternalTransfer;
use App\RTGSTransfer;
use App\Services\StatementService;
use App\StatementEnquiry;
use App\Transaction;
use App\TransactionManager\Core\TM;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Pipeline\Pipeline;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// Auth Custom Routes

/*
 * Login Routes
 */

Route::middleware('guest')->group(function (){
    Route::get('/login' , [ AuthController::class , 'loginView' ])->name('login');
    Route::get('/register' , [ AuthController::class , 'registerView' ])->name('register');
    Route::post('/register' , [ AuthController::class , 'register' ]);
    Route::post('/login' , [ AuthController::class , 'login']);
    Route::post('/otp' , [AuthController::class , 'otp']);
});
/*
 * Logout
 */

Route::post('/logout' , [AuthController::class , 'logout'])->name('logout');

/*
 * Password Reset Routes
 */

Route::get('/password/reset' , [AuthController::class , 'getResetForm']);
Route::post('/password/reset' , [AuthController::class , 'reset']);
Route::post('/reset' , [AuthController::class , 'resetPassword']);

/*
 * Transaction verification for Proof of payments
 */

Route::get('/transaction/verify' , [TransactionController::class , 'verify']);

Route::middleware('auth')->group(function (){

    Route::middleware('activated')->group(function (){
         /*
         * Password Change
         */
        Route::get('/password/change', [AuthController::class , 'getChangeForm']);
        Route::post('/password/change', [UserController::class , 'password']);

        Route::middleware('reset')->group(function (){

            Route::get('/', [DashboardController::class , 'dashboard'])->name('home');

            Route::get('/dashboard/{model}/details', [DashboardController::class , 'home']);
            Route::get('/dashboard/{model}/account/details', [DashboardController::class , 'account_details']);
            Route::get('/dashboard/{model}/account/cards', [DashboardController::class , 'cards']);

            Route::post('/dashboard/card/transactions', [DashboardController::class , 'card_transactions']);

            Route::get('/dashboard/statement', [DashboardController::class , 'statement']);
            Route::get('/dashboard/transactions', [DashboardController::class , 'transactions']);

            /*
             * Transactions
             */

            Route::prefix('transactions')->group(function () {

                Route::get('/'  , [ TransactionController::class  , 'index']);
                Route::get('/{model}/view'  , [ TransactionController::class  , 'view'])->middleware('can:view,model');
                Route::get('/{model}/statement'  , [ TransactionController::class  , 'statementView'])->middleware('can:view,model');
                Route::get('/{model}/statement/download'  , [ TransactionController::class  , 'statementDownload'])->middleware('can:view,model');
                Route::get('/{model}/authorise'  , [ TransactionController::class  , 'authorise'])->middleware('can:authorise,model');
                Route::get('/{model}/decline'  , [ TransactionController::class  , 'decline'])->middleware('can:authorise,model');

                Route::get('/{model}/generate'  , [ TransactionController::class  , 'generate'])->middleware('can:view,model');
                Route::get('/{model}/download'  , [ TransactionController::class  , 'download'])->middleware('can:view,model');
                Route::get('/{model}/retry'  , [ TransactionController::class  , 'retry'])->middleware('can:view,model');

                Route::post('/internal'  , [ TransactionController::class  , 'internal'])->middleware('can:initiateTransaction,'.Transaction::class);
                Route::post('/tobacco_internal'  , [ TransactionController::class  , 'tobacco_internal'])->middleware('can:initiateTransaction,'.Transaction::class);
                Route::post('/nostro/liquidation'  , [ TransactionController::class  , 'fundsLiquidation'])->middleware('can:initiateTransaction,'.Transaction::class);
                Route::post('/statement'  , [ TransactionController::class  , 'statement'])->middleware('can:runStatement,'.Transaction::class);
                Route::post('/rtgs'  , [ TransactionController::class  , 'rtgs'])->middleware('can:initiateTransaction,'.Transaction::class);
                Route::post('/tobacco_rtgs'  , [ TransactionController::class  , 'tobacco_rtgs'])->middleware('can:initiateTransaction,'.Transaction::class);

                Route::get('/rtgs/banks'  , [ TransactionController::class  , 'rtgsBanks']);
                Route::get('/accounts'  , [ TransactionController::class  , 'accounts']);

            });

            /*
            * Batches
            */

            Route::prefix('/batch')->group(function (){

                Route::get('/' , [BatchController::class , 'index']);
                Route::get('/sample' , [BatchController::class , 'sample']);
                Route::get('/codes' , [BatchController::class , 'codes']);
                Route::post('/upload' , [TransactionController::class , 'upload'])->middleware('can:initiateTransaction,'.Transaction::class);
                Route::post('/tobacco_upload' , [TransactionController::class , 'tobacco_upload'])->middleware('can:initiateTransaction,'.Transaction::class);

                Route::get('/{model}/view' , [BatchController::class , 'view'])->middleware('can:view,model');
                Route::get('/{model}/transactions' , [BatchController::class , 'transactions'])->middleware('can:view,model');
                Route::get('/{model}/process'  , [ BatchController::class  , 'process'])->middleware('can:view,model');
                Route::get('/{model}/cancel'  , [ BatchController::class  , 'cancel'])->middleware('can:cancel,model');
                Route::get('/{model}/retry'  , [ BatchController::class  , 'retry'])->middleware('can:view,model');
                Route::get('/{model}/corrections'  , [ BatchController::class  , 'corrections'])->middleware('can:view,model');
                Route::get('/{model}/report'  , [ BatchController::class  , 'report'])->middleware('can:view,model');
                Route::get('/{model}/generate-report'  , [ BatchController::class  , 'generate_report'])->middleware('can:view,model');

                Route::get('/{model}/decline'  , [ BatchController::class  , 'decline'])->middleware('can:authorise,model');
                Route::get('/{model}/authorise'  , [ BatchController::class  , 'authorise'])->middleware('can:authorise,model');


            });

            /*
            * Authorisations
            */

            Route::prefix('/authorisations')->group(function (){
                Route::get('/' , [AuthorisationController::class , 'index'])->middleware('can:list,'. Authorisation::class);
            });

            /*
             * Users
             */

            Route::prefix('users')->group(function (){
                Route::get('/' , [UserController::class , 'index'])->middleware('can:list,'. User::class);
                Route::post('/create' , [UserController::class , 'create'])->middleware('can:list,'. User::class);
                Route::post('/{model}/update' , [UserController::class , 'update'])->middleware('can:update,model');
                Route::get('/{model}/view' , [UserController::class , 'view'])->middleware('can:update,model');
                Route::get('/{model}/activate' ,  [UserController::class , 'activate'])->middleware('can:activate,model');
                Route::get('/{model}/deactivate' ,  [UserController::class , 'deactivate'])->middleware('can:deactivate,model');
                Route::get('/{model}/reset' ,  [UserController::class , 'reset'])->middleware('can:deactivate,model');
                Route::get('/{model}/root' ,  [UserController::class , 'root'])->middleware('can:root,model');
                Route::get('/{model}/remove' ,  [UserController::class , 'remove'])->middleware('can:root,model');
            });

            /*
             * Registrations
             */

            Route::prefix('registrations')->group(function (){
                Route::get('/' , [RegistrationsController::class , 'index'])->middleware('can:admin,'. User::class);
                Route::post('/{model}/update' , [RegistrationsController::class , 'update'])->middleware('can:admin,'. User::class);
                Route::get('/{model}/view' , [RegistrationsController::class , 'view'])->middleware('can:admin,'. User::class);
                Route::post('/{model}/decline' ,  [RegistrationsController::class , 'decline'])->middleware('can:admin,'. User::class);
            });

            Route::post('password' , [UserController::class , 'password']);

            /*
             * Corporates
             */

            Route::prefix('corporates')->group(function (){
                Route::get('/' , [CorporateController::class , 'index'])->middleware('can:admin,'. User::class);
                Route::post('/create' , [CorporateController::class , 'create'])->middleware('can:admin,'. User::class);
                Route::post('/{model}/update' , [CorporateController::class , 'update'])->middleware('can:admin,'. User::class);
                Route::get('/{model}/view' , [CorporateController::class , 'view'])->middleware('can:admin,'. User::class);
                Route::get('/{model}/activate' ,  [CorporateController::class , 'activate'])->middleware('can:admin,'. User::class);
                Route::get('/{model}/add_tobacco' ,  [CorporateController::class , 'add_tobacco'])->middleware('can:admin,'. User::class);
                Route::get('/{model}/remove_tobacco' ,  [CorporateController::class , 'remove_tobacco'])->middleware('can:admin,'. User::class);
                Route::get('/{model}/deactivate' ,  [CorporateController::class , 'deactivate'])->middleware('can:admin,'. User::class);
                Route::get('/settings' ,  [CorporateController::class , 'settings'])->middleware('can:corporateAdmin,'. User::class);
                Route::post('/settings' ,  [CorporateController::class , 'settingsUpdate'])->middleware('can:corporateAdmin,'. User::class);
            });

            /*
             * Accounts
             */

            Route::prefix('accounts')->group(function (){
                Route::get("/" , [AccountController::class , 'index'])->middleware('can:admin,'. User::class);
                Route::post("/{id}/{type}/create" , [AccountController::class , 'create'])->middleware('can:admin,'. User::class);
                Route::post("/{model}/update" , [AccountController::class , 'update'])->middleware('can:admin,'. User::class);
                Route::get("/{model}/view" , [AccountController::class , 'view'])->middleware('can:admin,'. User::class);
                Route::get('/{model}/activate' ,  [AccountController::class , 'activate'])->middleware('can:admin,'. User::class);
                Route::get('/{model}/deactivate' ,  [AccountController::class , 'deactivate'])->middleware('can:admin,'. User::class);
            });


            /*
             * Transaction types
             */

            Route::prefix('types')->group(function (){
                Route::get("/" , [AccountController::class , 'types'])->middleware('can:admin,'. User::class);
             });


            /*
             * Utilities
             * Documents
             */

            Route::prefix('documents')->group(function (){
                Route::get("/{id}/{type}/list" , [DocumentController::class , 'index'])->middleware('can:documents,'. User::class);
                Route::post("/{id}/{type}/upload" , [DocumentController::class , 'upload'])->middleware('can:documents,'. User::class);
                Route::get("/{document}/download" , [DocumentController::class , 'download'])->middleware('can:documents,'. User::class);
                Route::get("/{document}/delete" , [DocumentController::class , 'delete'])->middleware('can:documents,'. User::class);
            });

            /*
             * Currency
             */

            Route::prefix('currencies')->group(function (){
                Route::get('/' , [CurrencyController::class , 'index']);
            });

            /*
             * Permissions
             */

            Route::prefix('permissions')->group(function (){
                Route::get('/' , [PermissionController::class , 'index']);
            });

        });
    });

});

//
//Route::get('/test' , function (Tm $tm){
//
//    $test = 'Prince Gurajena';
//
//    /** @var Pipeline $pipeline */
//    $pipeline = app(Pipeline::class);
//
//    $string = $pipeline->send($test)->through([
//        function($value  , $next){
//            $value = strtolower($value);
//            return $next($value);
//        },
//        function($value  , $next){
//            $value = strtoupper($value);
//            return $next($value);
//        }
//    ])->thenReturn();
//
//    return $string;
//
//});



