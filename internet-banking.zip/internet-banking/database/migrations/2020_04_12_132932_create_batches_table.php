<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBatchesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('batches', function (Blueprint $table) {
            $table->id();
            $table->integer('status');
            $table->string('reference');
            $table->string('file');
            $table->string('corrections')->nullable();
            $table->string('pdf')->nullable();
            $table->boolean('errors')->default(false);
            $table->string('name');
            $table->bigInteger('user_id');
            $table->bigInteger('account_id');
            $table->timestamp('imported')->nullable();
            $table->integer('upload_success')->default(0);
            $table->integer('processed')->default(0);
            $table->integer('failed')->default(0);
            $table->integer('upload_error')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('batches');
    }
}
