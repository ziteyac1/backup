<?php

use App\TransactionType;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransactionTypesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transaction_types', function (Blueprint $table) {
            $table->id();
            $table->string('name')->nullable();
            $table->string('internal')->nullable();
            $table->string('rtgs')->nullable();
            $table->boolean('default')->default(false);
            $table->text('data')->nullable();
            $table->timestamps();
        });

        TransactionType::query()->create([
            'name' => 'IB Transfer',
            'internal' => 'IB',
            'rtgs' => 'RTGS.IB',
            'default' => true,
        ]);

        TransactionType::query()->create([
            'name' => 'Tobacco Payment',
            'internal' => 'INT.TOB',
            'rtgs' => 'RTGS.TSF',
            'default' => false,
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transaction_types');
    }
}
