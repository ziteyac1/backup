<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->id();
            $table->morphs('transaction');
            $table->bigInteger('account_id');
            $table->bigInteger('user_id');
            $table->double('amount');
            $table->integer('retry_count')->default(0);
            $table->bigInteger('batch_id')->nullable();
            $table->boolean('retry')->default(false);
            $table->timestamp('start')->nullable();
            $table->timestamp('end')->nullable();
            $table->integer('state')->nullable();
            $table->string('error')->nullable();
            $table->string('qr')->nullable();
            $table->string('pdf')->nullable();
            $table->timestamp('pop')->nullable();
            $table->string('code')->nullable();
            $table->string('reference')->nullable();
            $table->text('adapter_reference')->nullable();
            $table->boolean('view')->default(false);
            $table->timestamps();

            $table->index(['reference'  ,'state' , 'account_id']);

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transactions');
    }
}
