<?php

use App\TransactionType;
use Illuminate\Database\Seeder;

class TransactionTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        TransactionType::query()->create([
            'name' => 'IB Transfer',
            'internal' => 'IB',
            'rtgs' => 'RTGS.IB',
            'default' => true,
        ]);

        TransactionType::query()->create([
            'name' => 'Tobacco Payment',
            'internal' => 'INT.TOB',
            'rtgs' => 'RTGS.TSF',
            'default' => false,
        ]);
    }
}
