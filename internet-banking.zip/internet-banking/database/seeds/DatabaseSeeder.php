<?php

use App\Account;
use App\Bank;
use App\BatchState;
use App\Corporate;
use App\Currency;
use App\InternalTransfer;
use App\TransactionState;
use App\TransactionType;
use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\PermissionRegistrar;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        // Remove cache of permissions
        /** @var PermissionRegistrar $permissionRegistrar
         * @noinspection VirtualTypeCheckInspection
         */

        $permissionRegistrar = app()[PermissionRegistrar::class];
        $permissionRegistrar->forgetCachedPermissions();

        /** @var User $user */
        $user = User::query()->create([
            'name' => 'Cephas',
            'last_name' => 'Ziteya',
            'email' => 'cziteya@agribank.co.zw',
            'password' => Hash::make('password'),
            'is_root' => true,
            'phone' => '263777250754',
            'status' => true,
            'type' => 'admin',
            'email_verified_at' => now(),
        ]);

        /** @var Account $account */
        $account = $user->accounts()->create([
            'account' => '100003078951',
            'currency_id' => 1,
        ]);


        $account = $user->accounts()->create([
            'account' => '100003078951',
            'currency_id' => 1,
        ]);

        TransactionType::query()->create([
            'name' => 'IB Transfer',
            'internal' => 'IB',
            'rtgs' => 'RTGS.IB',
            'default' => true,
        ]);

        TransactionType::query()->create([
            'name' => 'Tobacco Payment',
            'internal' => 'INT.TOB',
            'rtgs' => 'RTGS.TSF',
            'default' => false,
        ]);


        /** @var Account $account */
        $account->types()->sync([1 , 2]);


        collect([
            'input-transactions',
            'authorise-transaction',
            'run-statement',
            'manage-users'
        ])->each(function ($permission){
            Permission::query()->create([
                'name' => $permission
            ]);
        });

        Currency::query()->create([
            'name' => 'USD',
            'primary' => 'USD',
            'secondary' => '840',
        ]);

        Currency::query()->create([
            'name' => 'ZWL',
            'primary' => 'ZWL',
            'secondary' => '932',
        ]);

        $banks = [
            [ 'FMBZZWHX' ,  '' , 0 ,'AFRICAN BANKING CORP OF ZIMBABWE' , '1' ],
            [ 'BARCZWHX' , '' , 0 ,'FIRST CAPITAL BANK' , '3' ],
            [ 'COBZZWHA' , '' , 0 ,'CBZ BANK LIMITED' , '4' ],
            [ 'CABSZWHA' , '' , 0 ,'CENTRAL AFRICA BUILDING SOCIETY' , '5' ],
            [ 'ECOCZWHX' , '' , 0 ,'ECOBANK ZIMBABWE LIMITED' , '7' ],
            [ 'FBCPZWHA' , '' , 0 ,'FBC BANK LTD' , '8' ],
            [ 'ZDBLZWHA' , '' , 0 ,'INFRASTRUCTURE DEV BANK ZIM' , '9' ],
            [ 'MBCAZWHX' , '' , 0 ,'NEDBANK LTD' , '10' ],
            [ 'MBOZZWHA' , '' , 0 ,'METROPOLITAN BANK OF ZIMBABWE LTD' , '11' ],
            [ 'NMBLZWHX' , '' , 0 ,'NMB BANK LIMITED' , '13' ],
            [ 'PWSBZWHX' , '' , 0 ,'PEOPLES OWN SAVINGS BANK' , '14' ],
            [ 'REBZZWHX' , '' , 0 ,'RESERVE BANK OF ZIMBABWE' , '15' ],
            [ 'SBICZWHX' , '' , 0 ,'STANBIC BANK ZIMBABWE LIMITED' , '18' ],
            [ 'SCBLZWHX' , '' , 0 ,'STANDARD CHARTERED BANK ZIM LTD' , '20' ],
            [ 'STBLZWHX' , '' , 0 ,'STEWARD BANK LIMITED' , '21' ],
            [ 'TTSLZWHX' , '' , 0 ,'TEDRAD INVESTMENT BANK LIMITED' , '22' ],
            [ 'ZBCOZWHX' , '' , 0 ,'ZIMBABWE BANKING CORPORATION LTD' , '24' ],
            [ 'AFCNZWHA' , '' , 0 ,'AFRICAN CENTURY LIMITED' , '25' ],
            [ 'GBSPZWHA' , '' , 0 ,'GETBUCKS MICROFINANCE' , '26' ],
            [ 'NABYZWHA' , '' , 0 ,'NATIONAL BUILDING SOCIETY LTD' , '27' ],
            [ 'AGRZZWHA' , '5048759' , 1 ,'AGRICULTURAL BANK OF ZIMBABWE' , '' ],
        ];

        foreach ($banks as $bank)
        {
            Bank::query()->create([
                'name' => $bank[3],
                'code' => $bank[0],
                'host' => $bank[2],
                'bin' => $bank[1],
                'sub' => $bank[4],
            ]);
        }

        // Transaction States

        $states = [
          1 => 'Pending , Waiting Processing',
          2 => 'Pending , Waiting Authorisation',
          3 => 'Pending , Waiting Retry',
          4 => 'Pending , Waiting Batch Processing',

          95 => 'Declined',
          96 => 'Error',
          97 => 'Processing',
          98 => 'Aborted',
          99 => 'Approved and Successful'
        ];

        foreach ($states as $key => $state)
        {
            TransactionState::query()->create([
                'id' => $key,
                'description' => $state,
            ]);
        }
        // Batch States

        $states = [
          1 => 'Queued For Import',
          2 => 'Importing',
          3 => 'Pending , Waiting Authorisation',
          4 => 'Pending , Waiting Processing',
          5 => 'Pending , Waiting Retry Failed',

          94 => 'Aborted , No Valid Records',
          95 => 'Declined',
          96 => 'Error',
          97 => 'Processing',
          98 => 'Aborted',
          99 => 'Completed'

        ];

        foreach ($states as $key => $state)
        {
            BatchState::query()->create([
                'id' => $key,
                'description' => $state,
            ]);
        }
    }

}
