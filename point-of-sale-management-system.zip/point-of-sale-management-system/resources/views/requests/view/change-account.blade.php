@extends('layouts.dashboard' , [ 'title' => 'Requests'  ,'active' => 'requests' ])
@section('content')
    <div class="container py-6">
        <div class="row justify-content-center">
            <div class="col-lg-4">
                @include('includes.request-info' , [ 'request' => $request ] )

                <div class="card bg-transparent border-0 rounded-0 shadow-none">
                    <div class="card-header">
                        <h5 class="card-title">Request Data</h5>
                    </div>
                    <table class="card-table table bg-white shadow-sm table-hover">
                        <tbody>
                        <tr>
                            <td class="small"><strong>Old Account Number :</strong></td>
                            <td class="text-right">{{ $request->data['old'] }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>New Account :</strong></td>
                            <td class="text-right">{{ $request->data['account'] }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>New Branch Code :</strong></td>
                            <td class="text-right">{{ $request->data['branch_code'] }}</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-lg-8">

                <div class="card bg-transparent border-0 rounded-0 shadow-none">
                    <div class="card-header">
                        <h5 class="card-title">Resolution</h5>
                    </div>
                    @if( $request->resolution )
                        <table class="card-table table bg-white shadow-sm table-hover">
                            <tbody>
                            <tr>
                                <td class="small"><strong>Old Account Number :</strong></td>
                                <td class="text-right">{{ $request->resolution['old'] }}</td>
                            </tr>
                            <tr>
                                <td class="small"><strong>New Account :</strong></td>
                                <td class="text-right">{{ $request->resolution['account'] }}</td>
                            </tr>
                            <tr>
                                <td class="small"><strong>New Branch Code :</strong></td>
                                <td class="text-right">{{ $request->resolution['branch_code'] }}</td>
                            </tr>
                            </tbody>
                        </table>
                    @else
                        <div class="card-body">
                            <h4 class="text-center"> Request Not Implemented </h4>
                        </div>
                    @endif
                </div>
                @include('includes.request-history-info' , [ 'audits' => $audits ] )

            </div>
        </div>
    </div>
@endsection