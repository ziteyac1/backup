@extends('layouts.dashboard' , [ 'title' => 'Requests'  ,'active' => 'requests' ])
@section('content')
    <div class="container py-6">
        <div class="row justify-content-center">
            <div class="col-lg-4">
                @include('includes.request-info' , [ 'request' => $request ] )

                <div class="card bg-transparent border-0 rounded-0 shadow-none">
                    <div class="card-header">
                        <h5 class="card-title">Request Data</h5>
                    </div>
                    <table class="card-table table bg-white shadow-sm table-hover">
                        <tbody>
                        <tr>
                            <td class="small"><strong> Trade Name :</strong></td>
                            <td class="text-right">{{ $request->data['trade_name'] }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong> Account :</strong></td>
                            <td class="text-right">{{ $request->data['account'] }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong> Location :</strong></td>
                            <td class="text-right">{{ $request->data['location'] }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong> Terminal Type :</strong></td>
                            <td class="text-right">{{ $request->data['terminal_type'] }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong> Number :</strong></td>
                            <td class="text-right">{{ $request->data['number'] }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong> Reason :</strong></td>
                            <td class="text-right">{{ $request->data['reason'] }}</td>
                        </tr>
                        @if (isset($request->data['proof']))
                            <tr>
                                <td class="small"><strong> Proof :</strong></td>
                                <td class="text-right"><a href="/download/proof/{{ $request->id }}" class="btn btn-secondary btn-sm">Download</a></td>
                            </tr>
                        @endif
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-lg-8">

                <div class="card bg-transparent border-0 rounded-0 shadow-none">
                    <div class="card-header">
                        <h5 class="card-title">Resolution</h5>
                    </div>
                    @if( $request->resolution )
                        <table class="card-table table bg-transparent table-hover">
                            <thead>
                            <tr>
                                <th>Terminal ID</th>
                                <th>Trade Name</th>
                                <th>Location</th>
                                <th>Account</th>
                                <th>Type</th>
                            </tr>
                            </thead>
                            <tbody class="bg-white shadow-sm">
                            @foreach( $request->resolution['terminals'] as  $terminal )
                                <tr>
                                    <td>{{ $terminal['terminal_id'] }}</td>
                                    <td>{{ $terminal['trade_name'] }}</td>
                                    <td>{{ $terminal['location'] }}</td>
                                    <td>{{ $terminal['account_id'] }}</td>
                                    <td>{{ $terminal['terminal_type'] }}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    @else
                        <div class="card-body">
                            <h4 class="text-center"> Request Not Implemented </h4>
                        </div>
                    @endif
                </div>
                @include('includes.request-history-info' , [ 'audits' => $audits ] )
            </div>
        </div>
    </div>
@endsection