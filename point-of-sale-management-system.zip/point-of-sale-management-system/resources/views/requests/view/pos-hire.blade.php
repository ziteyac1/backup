@extends('layouts.dashboard' , [ 'title' => 'Requests'  ,'active' => 'requests' ])
@section('content')
    <div class="container py-6">
        <div class="row justify-content-center">
            <div class="col-lg-4">
                @include('includes.request-info' , [ 'request' => $request ] )

                <div class="card bg-transparent border-0 rounded-0 shadow-none">
                    <div class="card-header">
                        <h5 class="card-title">Request Data</h5>
                    </div>
                    <table class="card-table table bg-white shadow-sm table-hover">
                        <tbody>
                        <tr>
                            <td class="small"><strong>Customer :</strong></td>
                            <td class="text-right">{{ $request->data['customer'] }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Account :</strong></td>
                            <td class="text-right">{{ $request->data['account'] }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Bank :</strong></td>
                            <td class="text-right">{{ $request->data['bank'] }}</td>
                        </tr>
                        @if (isset($request->data['proof']))
                            <tr>
                                <td class="small"><strong> Proof :</strong></td>
                                <td class="text-right"><a href="/download/proof/{{ $request->id }}" class="btn btn-secondary btn-sm">Download</a></td>
                            </tr>
                        @endif
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card bg-transparent border-0 rounded-0 shadow-none">
                    <div class="card-header">
                        <h5 class="card-title">Resolution</h5>
                    </div>
                    @if( $request->resolution )
                        <table class="card-table table bg-white shadow-sm table-hover">
                            <tbody>
                            <tr>
                                <td class="small"><strong>Terminal :</strong></td>
                                <td class="text-right">{{ $request->resolution['terminal'] }}</td>
                                <td class="small"><strong>Account :</strong></td>
                                <td class="text-right">{{ $request->resolution['account'] }}</td>
                            </tr>
                            <tr>
                                <td class="small"><strong>Customer :</strong></td>
                                <td class="text-right">{{ $request->resolution['customer']['name'] }}</td>
                                <td class="small"><strong>Last Name :</strong></td>
                                <td class="text-right">{{ $request->resolution['customer']['last_name'] }}</td>
                            </tr>
                            <tr>
                                <td class="small"><strong>Email :</strong></td>
                                <td class="text-right">{{ $request->resolution['customer']['email'] }}</td>
                                <td class="small"><strong>Address :</strong></td>
                                <td class="text-right">{{ $request->resolution['customer']['address'] }}</td>
                            </tr>
                            <tr>
                                <td class="small"><strong>Phone :</strong></td>
                                <td colspan="3" class="text-right">{{ $request->resolution['customer']['phone'] }}</td>
                            </tr>
                            </tbody>
                        </table>
                    @else
                        <div class="card-body">
                            <h4 class="text-center"> Request Not Implemented </h4>
                        </div>
                    @endif
                </div>
                @include('includes.request-history-info' , [ 'audits' => $audits ] )

            </div>
        </div>
    </div>
@endsection