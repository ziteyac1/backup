@extends('layouts.dashboard' , [ 'title' => 'Requests'  ,'active' => 'requests' ])
@section('content')
    <div class="container py-6">
        <div class="row justify-content-center">
            <div class="col-lg-4">
                @include('includes.request-info' , [ 'request' => $request ] )

                <div class="card bg-transparent border-0 rounded-0 shadow-none">
                    <div class="card-header">
                        <h5 class="card-title">Request Data</h5>
                    </div>
                    <table class="card-table table bg-white shadow-sm table-hover">
                        <tbody>
                        <tr>
                            <td class="small"><strong>ID :</strong></td>
                            <td class="text-right">{{ $request->data['id'] }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Name :</strong></td>
                            <td class="text-right">{{ $request->data['new']['name'] }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Last Name :</strong></td>
                            <td class="text-right">{{ $request->data['new']['last_name'] }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Phone :</strong></td>
                            <td class="text-right">{{ $request->data['new']['phone'] }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Email :</strong></td>
                            <td class="text-right">{{ $request->data['new']['email'] }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Address :</strong></td>
                            <td class="text-right">{{ $request->data['new']['address'] }}</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-lg-8">

                <div class="card bg-transparent border-0 rounded-0 shadow-none">
                    <div class="card-header">
                        <h5 class="card-title">Resolution</h5>
                    </div>
                    @if( $request->resolution )
                        <table class="card-table table bg-white shadow-sm table-hover">
                            <tbody>
                            <tr>
                                <td class="small"><strong>Name :</strong></td>
                                <td class="text-right">{{ $request->resolution['name'] }}</td>
                            </tr>
                            <tr>
                                <td class="small"><strong>Last Name :</strong></td>
                                <td class="text-right">{{ $request->resolution['last_name'] }}</td>
                            </tr>
                            <tr>
                                <td class="small"><strong>Phone :</strong></td>
                                <td class="text-right">{{ $request->resolution['phone'] }}</td>
                            </tr>
                            <tr>
                                <td class="small"><strong>Email :</strong></td>
                                <td class="text-right">{{ $request->resolution['email'] }}</td>
                            </tr>
                            <tr>
                                <td class="small"><strong>Address :</strong></td>
                                <td class="text-right">{{ $request->resolution['address'] }}</td>
                            </tr>
                            </tbody>
                        </table>
                    @else
                        <div class="card-body">
                            <h4 class="text-center"> Request Not Implemented </h4>
                        </div>
                    @endif
                </div>
                @include('includes.request-history-info' , [ 'audits' => $audits ] )

            </div>
        </div>
    </div>
@endsection