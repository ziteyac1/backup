@can('input' , \App\models\system\Input::class)
    <div class="col-lg-12 row">
        <div class="col-lg-2 pr-0 pl-0 mb-2">
            <a href="/requests/new-terminal/create" class="btn btn-primary btn-block"><i class="fe fe-git-pull-request mr-2"></i> New Terminal </a>
        </div>
        <div class="col-lg-2 pr-0 mb-2">
            <a href="/requests/re-allocation/create" class="btn btn-primary btn-block"><i class="fe fe-share-2 mr-2"></i> Reallocation </a>
        </div>
        <div class="col-lg-2 pr-0 mb-2">
            <a href="/requests/change-details/create" class="btn btn-primary btn-block"><i class="fe fe-edit-3 mr-1"></i> Change of Details </a>
        </div>
        <div class="col-lg-2 pr-0 mb-2">
            <a href="/requests/pos-repair/create" class="btn btn-primary btn-block"><i class="fe fe-git-merge mr-2"></i> POS Repair </a>
        </div>
        <div class="col-lg-2 pr-0 mb-2">
            <a href="/requests/terminal-testing/create" class="btn btn-primary btn-block"><i class="fe fe-radio mr-2"></i> Terminal Testing </a>
        </div>
        <div class="col-lg-2 pr-0 mb-2">
            <a href="/requests/pos-hire/create" class="btn btn-primary btn-block"><i class="fe fe-feather mr-2"></i>POS Hire</a>
        </div>
        <div class="col-lg-2 pr-0 mb-2 pl-0">
            <a href="/requests/change-account/create" class="btn btn-primary btn-block"><i class="fe fe-edit-2 mr-2"></i>Change Account</a>
        </div>
        <div class="col-lg-2 pr-0 mb-2">
            <a href="/requests/change-customer/create" class="btn btn-primary btn-block"><i class="fe fe-users mr-2"></i>Change Customer</a>
        </div>
    </div>

@endcan
<div class="col-lg-12 row mt-3 border-top pt-5">
    <div class="col-lg-2">
        <input type="text" class="form-control" name="id" placeholder="Request ID" value="{{ old('search' , request('id')) }}">
    </div>
    <div class="col-lg-2">
        <select class="form-control custom-select" name="state" id="">
            <option value="">Choose State</option>
            <option value="open" {{ old('state' , request('state') ) ===  'open' ? 'selected' : '' }}>Open</option>
            <option value="closed" {{ old('state' , request('state') ) ===  'closed' ? 'selected' : '' }}>Closed</option>
        </select>
    </div>
    <div class="col-lg-2">
        <select class="form-control custom-select" name="type" id="">
            <option value="">Choose Type</option>
            @foreach(\App\models\system\RequestType::all() as $request )
                <option value="{{ $request->name }}" {{ old('type' , request('type') ) ===  $request->name ? 'selected' : '' }}>{{ $request->description }}</option>
            @endforeach
        </select>
    </div>
    <div class="col-lg-4 ml-auto">
        <input type="text" class="form-control" name="search" placeholder="Search" value="{{ old('search' , request('search')) }}">
    </div>
    <div class="col-lg-2">
        <button class="btn btn-block btn-primary" type="submit"><i class="fe fe-filter mr-1"></i> Filter</button>
    </div>
</div>
