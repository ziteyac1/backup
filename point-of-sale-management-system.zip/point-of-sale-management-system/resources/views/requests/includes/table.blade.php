<tr class="bg-white shadow-sm shadow-lg--hover">
    <td class="border-left border-lg {{ $request->role_assigned === 'root'  ? 'border-danger' : 'border-info' }} ">
        <div><span class="text-muted">Request ID : </span>{{ $request->id }}</div>
        <div><span class="text-muted">Type : </span>{{ $request->name->description }}</div>
        <div><span class="text-muted">Date : </span>{{ $request->created_at }}</div>
        <div><span class="text-muted">State : </span>{{ $request->state_name->description_name->description  }}</div>
    </td>

    {{--New Terminal--}}

    @if($request->type === 'new-terminal')

        <td>
            <div><span class="text-muted">Number of Terminals : </span>{{ $request->data['number'] }}</div>
            <div><span class="text-muted">Account : </span>{{ $request->data['account'] }}</div>
            <div><span class="text-muted">Location : </span>{{ $request->data['location'] }}</div>
            <div><span class="text-muted">Trade Name : </span>{{ $request->data['trade_name'] }}</div>
            <div><span class="text-muted">POS Type : </span>{{ $request->data['terminal_type'] }}</div>
        </td>

    @elseif($request->type === 're-allocation' )

        <td>
            <div><span class="text-muted">Terminal ID : </span>{{ $request->data['terminal'] }}</div>
            <div><span class="text-muted">Account : </span>{{ $request->data['new']['account'] }}</div>
            <div><span class="text-muted">Location : </span>{{ $request->data['new']['location'] }}</div>
            <div><span class="text-muted">Trade Name : </span>{{ $request->data['new']['trade_name'] }}</div>
        </td>

    @elseif($request->type === 'change-of-details' )

        <td>
            <div><span class="text-muted">Terminal ID : </span>{{ $request->data['terminal'] }}</div>
            <div><span class="text-muted">Account : </span>{{ $request->data['new']['account'] }}</div>
            <div><span class="text-muted">Location : </span>{{ $request->data['new']['location'] }}</div>
            <div><span class="text-muted">Trade Name : </span>{{ $request->data['new']['trade_name'] }}</div>
        </td>

    @elseif($request->type === 'pos-repair' )

        <td>
            <div><span class="text-muted">Log ID : </span>{{ $request->data['log'] }}</div>
            <div><span class="text-muted">Terminal : </span>{{ $request->data['terminal'] }}</div>
            <div><span class="text-muted">Serial Number : </span>{{ $request->data['serial_number'] }}</div>
        </td>

    @elseif($request->type === 'terminal-testing' )

        <td>
            <div><span class="text-muted">Terminal : </span>{{ $request->data['terminal'] }}</div>
            <div><span class="text-muted">Serial Number : </span>{{ $request->data['serial_number'] }}</div>
        </td>

    @elseif($request->type === 'replacement' )

        <td>
            <div><span class="text-muted">Terminal : </span>{{ $request->data['terminal'] }}</div>
            <div><span class="text-muted">Serial Number : </span>{{ $request->data['serial_number'] }}</div>
        </td>


    @elseif($request->type === 'pos-hire' )

        <td>
            <div><span class="text-muted">Customer : </span>{{ $request->data['customer'] }}</div>
            <div><span class="text-muted">Bank : </span>{{ $request->data['bank'] }}</div>
            <div><span class="text-muted">Account : </span>{{ $request->data['account'] }}</div>
        </td>

    @elseif($request->type === 'change-customer' )

        <td>
            <div><span class="text-muted">Customer : </span>{{ $request->data['id'] }}</div>
            <div><span class="text-muted">Name : </span>{{ $request->data['new']['name'] }}</div>
            <div><span class="text-muted">Last Name : </span>{{ $request->data['new']['last_name'] }}</div>
            <div><span class="text-muted">Phone : </span>{{ $request->data['new']['phone'] }}</div>
        </td>

    @elseif($request->type === 'change-account')

        <td>
            <div><span class="text-muted">Old : </span>{{ $request->data['old'] }}</div>
            <div><span class="text-muted">New Account : </span>{{ $request->data['account'] }}</div>
            <div><span class="text-muted">New Branch : </span>{{ $request->data['branch_code'] }}</div>
        </td>

    @endif

    <td>
        <div><span class="text-muted">Name : </span>{{ $request->requester->name }}</div>
        <div><span class="text-muted">Email : </span>{{ $request->requester->email }}</div>
        <div><span class="text-muted">Role : </span>{{ $request->requester->role_name->name }}</div>
        <div><span class="text-muted">Branch : </span>{{ $request->requester->branch_name->name }}</div>
    </td>

    <td class="text-center">

        {{--<div class="mb-1"><a href="/requests/{{ $request->id }}/open" class="card-link"><i class="fe fe-eye mr-2"></i>Open</a></div>--}}
        <div class="mb-1"><a href="/request/{{ $request->id }}/view" class="card-link"><i class="fe fe-eye mr-2"></i>View</a></div>

        @if($request->name->execution !== 'instant' )

            @can( 'edit' ,$request )
                <div class="mb-1"><a href="/request/{{ $request->id }}/edit" class="card-link"><i class="fe fe-edit-3 mr-2"></i>Edit</a></div>
            @endcan

            @can( $request->state_name->action , $request )
                <div class="mb-1"><a href="/request/{{ $request->id }}/action" class="card-link text-success"><i class="fe fe-check-circle mr-2"></i> {{ \ucwords( $request->state_name->action ) }}</a></div>
            @endcan

            @can('close', $request )
                <div class="mb-1"><a href="/request/{{ $request->id }}/close" class="card-link text-danger"><i class="fe fe-trash-2 mr-2"></i>Close</a></div>
            @endcan

        @endif

    </td>

</tr>