@extends('layouts.dashboard' , [ 'title' => 'POS Replacement Request'  ,'active' => 'requests' ])
@section('content')
    <div class="container p-5">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <form method="POST" action="/requests/replacement/create" class="card rounded-0 border-0 shadow-lg">
                    @csrf
                    <div class="card-body">
                        <h1 class="card-title">POS Replacement Request</h1>
                    </div>
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-icon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <h6 class="text-muted">Terminal Info</h6>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="trade_name" class=""> Terminal ID </label>
                                    <input id="trade_name" type="text" class="form-control {{ $errors->has('terminal') ? ' is-invalid' : '' }}" name="terminal" value="{{ old('terminal', request()->get('terminal')) }}" required autofocus>
                                    @if ($errors->has('terminal'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('terminal') }}</strong>
                                    </span>
                                    @endif
                                </div>
                                <div class="form-group">
                                    <label for="serial_number" class="">From Serial Number </label>
                                    <input id="serial_number" type="text" class="form-control{{ $errors->has('serial_number') ? ' is-invalid' : '' }}" name="serial_number" value="{{ old('serial_number', request()->get('serial_number')) }}" required autofocus>
                                    @if ($errors->has('serial_number'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('serial_number') }}</strong>
                                    </span>
                                    @endif
                                </div>
                                <div class="form-group">
                                    <label for="to_serial_number" class="">To Serial Number </label>
                                    <input id="to_serial_number" type="text" class="form-control {{ $errors->has('to_serial_number') ? ' is-invalid' : '' }}" name="to_serial_number" value="{{ old('to_serial_number', request()->get('to_serial_number')) }}" required autofocus>
                                    @if ($errors->has('to_serial_number'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('to_serial_number') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-center">
                        <div class="col-lg-7">
                            <button type="submit" class="btn btn-primary btn-block">Create POS Replacement Request</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
