@extends('layouts.dashboard' , [ 'title' => 'Change Of Details'  ,'active' => 'requests' ])
@section('content')
    <div class="container p-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form method="POST" action="/request/{{ $request->id }}/edit" class="card rounded-0 border-0 shadow-lg">
                    @csrf
                    <div class="card-body">
                        <h1 class="card-title">Change Account Request</h1>
                    </div>
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-icon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <h6 class="text-muted">Old Account Info</h6>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="old" class="">Account</label>
                                    <input id="old" type="text" class="form-control {{ $errors->has('old') ? ' is-invalid' : '' }}" name="old" value="{{ old('old' , $request->data['old'] ) }}" required autofocus>
                                    @if ($errors->has('old'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('old') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <h6 class="text-muted">New Account Info</h6>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="account" class="">Account</label>
                                    <input id="account" type="text" class="form-control {{ $errors->has('account') ? ' is-invalid' : '' }}" name="account" value="{{ old('account', $request->data['account'] ) }}" required autofocus>
                                    @if ($errors->has('account'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('account') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="branch_code" class="">Branch</label>
                                    <select id="branch_code" type="branch_code" class="form-control {{ $errors->has('branch_code') ? ' is-invalid' : '' }}" name="branch_code" value="{{ old('branch_code' , $request->data['branch_code']) }}" required>
                                        <option value="">Choose Branch Name</option>
                                        @foreach( \App\models\Branch::all() as $branch )
                                            <option value="{{ $branch->branch_code }}" {{ old('branch_code', $request->data['branch_code'] ) === $branch->branch_code ? 'selected' : '' }}>{{ $branch->short_name }} - {{ $branch->name }}</option>
                                        @endforeach
                                    </select>
                                    @if ($errors->has('branch_code'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('branch_code') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-center">
                        <div class="col-lg-6">
                            <button type="submit" class="btn btn-primary btn-block">Update Request</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
