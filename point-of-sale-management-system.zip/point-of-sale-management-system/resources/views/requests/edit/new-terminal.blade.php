@extends('layouts.dashboard' , [ 'title' => 'New Terminal Request'  ,'active' => 'requests-terminals-create' ])
@section('content')
    <!--suppress ALL -->
    <div class="container p-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form method="POST" action="/request/{{ $request->id }}/edit" class="card rounded-0 border-0 shadow-lg">
                    @csrf
                    <div class="card-header">
                        <div class="card-title">Edit Terminal Request</div>
                        <div class="card-options px-3">
                            @can( $request->state_name->action , $request )
                                <a href="/request/{{ $request->id }}/action" class="btn btn-sm btn-success px-3 mr-2"><i class="fe fe-check-circle mr-2"></i> {{ \ucwords( $request->state_name->action ) }}</a>
                            @endcan
                            @can('close', $request )
                                <a href="/request/{{ $request->id }}/close" class="btn btn-sm btn-danger px-3"><i class="fe fe-trash-2 mr-2"></i>Close</a>
                            @endcan
                        </div>
                    </div>
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-icon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <h6 class="text-muted">Account Info</h6>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="account" class="">Account Number </label>
                                    <input id="account" type="text" class="form-control {{ $errors->has('account') ? ' is-invalid' : '' }}" name="account" value="{{ old('account' , $request->data['account']) }}" required autofocus>
                                    @if ($errors->has('account'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('account') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <h6 class="text-muted">Terminal Info</h6>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="trade_name" class=""> Trade Name </label>
                                    <input id="trade_name" type="text" class="form-control{{ $errors->has('trade_name') ? ' is-invalid' : '' }}" name="trade_name" value="{{ old('trade_name', $request->data['trade_name']) }}" required autofocus>
                                    @if ($errors->has('trade_name'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('trade_name') }}</strong>
                                    </span>
                                    @endif
                                </div>
                                <div class="form-group">
                                    <label for="location" class=""> Location </label>
                                    <input id="location" type="text" class="form-control{{ $errors->has('location') ? ' is-invalid' : '' }}" name="location" value="{{ old('location', $request->data['location']) }}" required autofocus>
                                    @if ($errors->has('location'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('location') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-7">
                                <div class="form-group">
                                    <label for="term_type" class=""> Terminal Type </label>
                                    <select id="term_type" type="branch_code" class="form-control{{ $errors->has('term_type') ? ' is-invalid' : '' }}" name="term_type" value="{{ old('term_type', $request->data['terminal_type']) }}" required>
                                        <option value=""> Choose Terminal Type </option>
                                        <option value="merchant" {{ old('term_type', $request->data['terminal_type']) === 'merchant' ? 'selected' : '' }}> Merchant POS </option>
                                        <option value="agency"{{ old('term_type', $request->data['terminal_type']) === 'agency' ? 'selected' : '' }}> Agency POS </option>
                                        <option value="mpos"{{ old('term_type', $request->data['terminal_type']) === 'mpos' ? 'selected' : '' }}> MPOS POS </option>
                                        <option value="branch"{{ old('term_type', $request->data['terminal_type']) === 'branch' ? 'selected' : '' }}> Agency POS </option>
                                    </select>
                                    @if ($errors->has('term_type'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('term_type') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-5">
                                <div class="form-group">
                                    <label for="number" class=""> Number </label>
                                    <input id="number" type="number" class="form-control{{ $errors->has('number') ? ' is-invalid' : '' }}" name="number" value="{{ old('number', $request->data['number']) }}" required autofocus>
                                    @if ($errors->has('number'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('number') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="form-group">
                                <label for="reason" class=""> Justification </label>
                                <textarea id="reason" type="text" class="form-control{{ $errors->has('reason') ? ' is-invalid' : '' }}" name="reason" value="{{ old('reason', $request->data['reason']) }}" required autofocus>{{ old('reason', $request->data['reason'] ) }}</textarea>
                                @if ($errors->has('reason'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('reason') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-center">
                        <div class="col-lg-6">
                            <button type="submit" class="btn btn-primary btn-block">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
