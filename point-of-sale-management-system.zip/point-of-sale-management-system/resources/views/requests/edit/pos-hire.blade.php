@extends('layouts.dashboard' , [ 'title' => 'POS Repair Request'  ,'active' => 'requests' ])
@section('content')
    <div class="container p-5">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <form method="POST" action="/request/{{ $request->id }}/edit" class="card rounded-0 border-0 shadow-lg">
                    @csrf
                    <div class="card-header">
                        <div class="card-title">Edit POS Hire Request</div>
                        <div class="card-options px-3">
                            @can( $request->state_name->action , $request )
                                <a href="/request/{{ $request->id }}/action" class="btn btn-sm btn-success px-3 mr-2"><i class="fe fe-check-circle mr-2"></i> {{ \ucwords( $request->state_name->action ) }}</a>
                            @endcan
                            @can('close', $request )
                                <a href="/request/{{ $request->id }}/close" class="btn btn-sm btn-danger px-3"><i class="fe fe-trash-2 mr-2"></i>Close</a>
                            @endcan
                        </div>
                    </div>
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-icon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <h6 class="text-muted">Info</h6>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="customer" class="">Customer ID</label>
                                    <input id="customer" type="text" class="form-control {{ $errors->has('customer') ? ' is-invalid' : '' }}" name="customer" value="{{ old('customer' , $request->data['customer'] ) }}" required autofocus>
                                    @if ($errors->has('customer'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('customer') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
							<div class="col-lg-12">
                                <div class="form-group">
                                    <label for="terminal" class="">Terminal</label>
                                    <input id="terminal" type="text" class="form-control {{ $errors->has('terminal') ? ' is-invalid' : '' }}" name="terminal" value="{{ old('terminal',$request->data['terminal'])) }}" autofocus>
                                    @if ($errors->has('terminal'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('terminal') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="account" class="">Account</label>
                                    <input id="account" type="text" class="form-control {{ $errors->has('account') ? ' is-invalid' : '' }}" name="account" value="{{ old('account' , $request->data['account'] ) }}" required autofocus>
                                    @if ($errors->has('account'))
                                        <span class="invalid-feedback" role="alert">
                                         <strong>{{ $errors->first('account') }}</strong>
                                        </span>
                                    @endif
                                </div>
                                <div class="form-group">
                                    <label for="bank" class="">Bank</label>
                                    <select id="bank" type="branch_code" class="form-control {{ $errors->has('bank') ? ' is-invalid' : '' }}" name="bank" value="{{ old('bank', $request->data['bank'] ) }}" required>
                                        <option value=""> Choose Bank </option>
                                        @php

                                            $banks = [
                                                    'Agricultural Development Bank of Zimbabwe',
                                                    'Banc ABC',
                                                    'CBZ Bank Limited',
                                                    'Ecobank',
                                                    'FBC Bank Limited',
                                                    'First Capital Bank Limited',
                                                    'MetBank',
                                                    'Nedbank Zimbabwe Limited',
                                                    'NMB Bank Limited',
                                                    'Stanbic Bank Zimbabwe Limited',
                                                    'Standard Chartered Bank Zimbabwe Limited',
                                                    'Steward Bank',
                                                    'ZB Bank Limited',
                                                    'CBZ Building Society',
                                                    'Central Africa Building Society',
                                                    'FBC Building Society',
                                                    'National Building Society Limited',
                                                    'ZB Building Society',
                                                    'Tetrad Investment Bank',
                                                    'African Century Limited',
                                                    'Success Micro-finance Bank Limited',
                                                    'Getbucks Microfinance Bank',
                                                    'Lion Micro-finance Limited',
                                                    'EmpowerBank Limited',
                                                    'Zimbabwe Womens Microfinance Bank Limited',
                                                    'Peoples Own Savings Bank',
                                                    'Infrastructure Development Bank of Zimbabwe',
                                            ];

                                        @endphp
                                        @foreach( $banks as $bank )
                                            <option value="{{ $bank }}" {{ old('bank' , $request->data['bank'] ) === $bank ? 'selected' : '' }}>{{ $bank }}</option>
                                        @endforeach
                                    </select>
                                    @if ($errors->has('bank'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('bank') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer justify-content-center">
                        <div class="col-lg-7">
                            <button type="submit" class="btn btn-primary btn-block">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
