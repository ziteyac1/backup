@extends('layouts.dashboard' , [ 'title' => 'POS Hire'  ,'active' => 'pos-hire' ])
@section('content')
    <div class="container py-5">
        <div class="py-3">
            <h1 class="mb-0">POS Hire Terminals</h1>
        </div>
        <form class="page-header row px-0" method="GET">
            {{--<div class="col-lg-2 pl-0">--}}
                {{--<a href="" class="btn btn-primary btn-block">View Statics</a>--}}
            {{--</div>--}}
            <div class="input-group col-lg-6 ml-auto">
                <input type="text" class="form-control" name="search" placeholder="Search" value="{{ old('search' , request('search')) }}">
                <span class="input-group-append">
                    <button class="btn btn-primary" type="submit">Search</button>
                </span>
            </div>
            <div class="col-lg-2 pr-0">
                <a href="/pos-hire/add" class="btn btn-primary btn-block"><i class="fe fe-plus mr-2"></i> POS Hire </a>
            </div>
        </form>
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="card border-0 bg-transparent">
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-icon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    <div class="table-responsive">
                        <table style="border-collapse:separate; border-spacing:0 15px;"
                               class="table table-hover table-outline table-vcenter text-nowrap card-table table-borderless">
                            <thead class="text-dark">
                            <tr>
                                <th>Info</th>
                                <th>Info</th>
                                <th>Account</th>
                                <th class="text-center"><i class="fe fe-info"></i></th>
                                {{--<th class="text-center"><i class="fe fe-settings"></i></th>--}}
                            </tr>
                            </thead>
                            <tbody>

                            @foreach( $terminals as $terminal )

                                <tr class="bg-white shadow-sm shadow-lg--hover">
                                    <td class="border-left border-lg {{ $terminal->customer_id  ? 'border-success' : 'border-danger' }} ">
                                        <div><span class="text-muted">Trade Name : </span>{{ $terminal->terminal_name->trade_name }}</div>
                                        <div><span class="text-muted">Location : </span>{{ $terminal->terminal_name->location }}</div>
                                        <div><span class="text-muted">Auto Serial Number : </span>{{ $terminal->terminal_name->system_serial_number }}</div>
                                        <div><span class="text-muted">Serial Number : </span>{{ $terminal->serial_number }}</div>
                                    </td>
                                    <td>
                                        <div><span class="text-muted">ID : </span>{{ $terminal->terminal_name->terminal_id }}</div>
                                        <div><span class="text-muted">Customer ID : </span>{{ $terminal->customer_id }}</div>
                                        <div><span class="text-muted">Model : </span>{{ $terminal->terminal_name->model }}</div>
                                        <div><span class="text-muted">Term type : </span>{{ $terminal->terminal_name->override_term_type }}</div>
                                        <div><span class="text-muted">Created : </span>{{ $terminal->created_at }}</div>
                                    </td>
                                    <td>
                                        <div><span class="text-muted">Account : </span>{{ $terminal->terminal_name->account->account }}</div>
                                        <div><span class="text-muted">Branch Name : </span>{{ $terminal->terminal_name->account->branch->name }}</div>
                                        <div><span class="text-muted">Branch Code : </span>{{ $terminal->terminal_name->account->branch->branch_code  }}</div>
                                        <div><span class="text-muted">Customer Name :  </span> {{ $terminal->terminal_name->account->customer->full_name }} </div>
                                    </td>
                                    <td class="text-center">
                                        <div class="mb-1"><a href="/pos-hire/{{ $terminal->id }}/view" class="card-link"><i class="fe fe-eye mr-2"></i>View</a></div>
                                        <div class="mb-1"><a href="/pos-hire/{{ $terminal->id }}/edit" class="card-link"><i class="fe fe-edit-2 mr-2"></i>Edit</a></div>
                                        <div class="mb-1"><a href="/terminal/{{ $terminal->terminal_name->id }}/view" class="card-link text-success"><i class="fe fe-git-pull-request mr-2"></i>View Terminal</a></div>
                                        @if( $terminal->customer_id )
                                            <div class="mb-1"><a href="/pos-hire/{{ $terminal->id }}/remove" class="card-link text-danger"><i class="fe fe-trash-2 mr-2"></i>Remove Customer</a></div>
                                        @endif
                                        <div class="mb-1"><a href="/pos-hire/{{ $terminal->id }}/remove" class="card-link text-danger"><i class="fe fe-trash mr-2"></i>Delete</a></div>
                                    </td>

                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer row justify-content-center col-lg-12 border-0 bg-white pt-5 m-0">
                        {{ $terminals->appends(request()->query())->links()  }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
