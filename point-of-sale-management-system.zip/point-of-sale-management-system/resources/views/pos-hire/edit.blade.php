@extends('layouts.dashboard' , [ 'title' => 'POS Hire'  ,'active' => 'pos-hire' ])
@section('content')
    <div class="container p-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form method="POST" action="/pos-hire/{{ $terminal->id }}/edit" class="card">
                    @csrf
                    <div class="card-body">
                        <h1 class="card-title"> POS Hire </h1>
                    </div>
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-icon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <h6 class="text-muted">Terminal Info</h6>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="terminal" class=""> Terminal ID </label>
                                    <input id="terminal" type="text" class="form-control{{ $errors->has('terminal') ? ' is-invalid' : '' }}" name="terminal" value="{{ old('terminal' , $terminal->terminal) }}" required autofocus>
                                    @if ($errors->has('terminal'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('terminal') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="serial_number" class=""> Serial Number </label>
                                    <input id="serial_number" type="text" class="form-control{{ $errors->has('serial_number') ? ' is-invalid' : '' }}" name="serial_number" value="{{ old('serial_number', $terminal->serial_number) }}" required autofocus>
                                    @if ($errors->has('serial_number'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('serial_number') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="customer" class=""> Customer ID </label>
                                    <input id="customer" type="text" class="form-control{{ $errors->has('customer') ? ' is-invalid' : '' }}" name="customer" value="{{ old('customer', $terminal->customer_id ) }}" required autofocus>
                                    @if ($errors->has('customer'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('customer') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="col-lg-6 ml-auto">
                            <button type="submit" class="btn btn-primary btn-block">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
