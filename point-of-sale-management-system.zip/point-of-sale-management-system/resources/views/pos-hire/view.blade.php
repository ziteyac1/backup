@extends('layouts.dashboard' , [ 'title' => 'POS Hire'  ,'active' => 'pos-hire' ])
@section('content')
    <div class="container pt-6">
        <div class="row">
            <div class="col-lg-12">
                @if(session()->has('message'))
                    <div class="card-alert alert alert-icon alert-success">
                        <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                    </div>
                @endif
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-4">
                <div class="card bg-transparent border-0 rounded-0 shadow-none">
                    <div class="card-header">
                        <h5 class="card-title">POS Hire Info</h5>
                        <div class="card-options">
                            <a href="/pos-hire/{{ $terminal->id }}/edit" class="btn btn-secondary btn-sm ml-2 px-3">Edit</a>
                            <a href="/pos-hire/{{ $terminal->id }}/history" class="btn btn-secondary btn-sm ml-2 px-3">History</a>
                            @if( $terminal->customer_id )
                               <a href="/pos-hire/{{ $terminal->id }}/remove" class="btn btn-secondary btn-sm ml-2">Remove Customer</a>
                            @endif
                        </div>
                    </div>
                    <table class="card-table table bg-white shadow-sm table-hover">
                        <tbody>
                        <tr>
                            <td class="small"><strong>Customer :</strong></td>
                            <td class="text-right">
                                @if($terminal->customer_id)
                                    <a href="/customer/{{ $terminal->customer_id }}/view" class="btn btn-secondary btn-outline-info btn-sm ml-2 px-3">View Customer</a>
                                @else
                                    <span class="px-2 border border-danger text-danger small ml-2">Not linked</span>
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Terminal ID :</strong></td>
                            <td class="text-right">{{ $terminal->terminal }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Serial :</strong></td>
                            <td class="text-right">{{ $terminal->serial_number }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Created :</strong></td>
                            <td class="text-right">{{ $terminal->created_at }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Updated :</strong></td>
                            <td class="text-right">{{ $terminal->updated_at->diffForHumans() }}</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                @include('includes.terminal-info' ,['terminal' => $terminal->terminal_name ])
            </div>
            <div class="col-lg-8">
                <div class="card bg-transparent border-0 rounded-0 shadow-none">
                    <div class="card-header">
                        <h3 class="card-title">Transactions</h3>
                        <div class="card-options">
                            <a href="/transactions/all?terminal={{ $terminal->terminal_name->terminal_id }}" class="btn btn-secondary btn-sm ml-2 px-5"><i class="fe fe-git-pull-request mr-3"></i>View all Transactions</a>
                        </div>
                    </div>
                    <table class="card-table table table-vcenter table-hover">
                        <thead>
                        <tr>
                            <th>Info</th>
                            <th>Info</th>
                            <th>Info</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody class="bg-white shadow-sm">

                        @foreach($transactions as $transaction )

                            <tr class="">
                                <td class="">
                                    <div><span class="text-muted">Transaction No : </span>{{ $transaction->tran_nr }}</div>
                                    <div><span class="text-muted">Terminal ID : </span>{{ $transaction->card_acceptor_id }}</div>
                                    <div><span class="text-muted">Location : </span>{{ $transaction->card_acceptor_name_loc }}</div>
                                </td>
                                <td>
                                    <div><span class="text-muted">Date : </span>{{ $transaction->in_req }}</div>
                                    <div><span class="text-muted">Date Retrieved: </span>{{ $transaction->created_at }}</div>
                                    <div><span class="text-muted">Pan : </span>{{ $transaction->pan }}</div>
                                </td>
                                <td>
                                    <div><span class="text-muted">Amount : </span>{{ $transaction->amount }}</div>
                                    <div><span class="text-muted">Tran Type : </span>{{ $transaction->tran_type }}</div>
                                    <div><span class="text-muted">Response Code : </span>{{ $transaction->response_code }}</div>
                                </td>
                                <td class="text-center">
                                    <div class="item-action dropdown">
                                        <a href="javascript:void(0)" data-toggle="dropdown" class="icon" aria-expanded="false"><i class="fe fe-more-vertical"></i></a>
                                        <div class="dropdown-menu dropdown-menu-right" x-placement="bottom-end" style="position: absolute; transform: translate3d(15px, 20px, 0px); top: 0px; left: 0px; will-change: transform;">
                                            <a href="/transaction/{{ $transaction->id }}/view" class="dropdown-item"><i class="dropdown-icon fe fe-eye mr-3"></i> View Transaction</a>
                                            <a href="/terminal/{{ $transaction->terminal->id }}/view" class="dropdown-item"><i class="dropdown-icon fe fe-git-pull-request mr-3"></i> View Terminal</a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    <div class="card-footer row justify-content-center col-lg-12 border-0 bg-white pt-5 m-0">
                        {{ $transactions->appends(request()->query())->links()  }}
                    </div>

                </div>
            </div>
        </div>
    </div>
@endsection
