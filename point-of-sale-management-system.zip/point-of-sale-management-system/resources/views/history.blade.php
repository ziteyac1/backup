@extends('layouts.dashboard' , [ 'title' => 'History'  ,'active' => 'customers' ])
@section('content')
    <div class="container">
        <div class="page-header">
            <h1 class="page-title">
                History
            </h1>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card bg-transparent border-0 rounded-0 shadow-none">
                    <table class="card-table table">
                        <thead>
                        <tr>
                            <th>Old</th>
                            <th>New</th>
                            <th>User</th>
                            <th>Info</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody class="bg-white shadow-sm">
                        @foreach($audits as $audit)
                            <tr>
                                <td>
                                    @foreach($audit->getModified() as $key => $item )
                                        @if(isset($item['old']))
                                            <div class=""><small style="font-weight: bolder">{{ ucwords($key) }}</small></div>
                                            @if(is_array($item['old']))
                                                @foreach( $item['old'] as $name => $value )
                                                    <div class=""><small style="font-weight: bolder">{{ ucwords($name) }}</small></div>
                                                    @if(is_array($value))
                                                        @foreach( $value as $i => $a )
                                                            <div class=""><small style="font-weight: bolder">{{ ucwords($i) }}</small></div>
                                                            <div> {{ $a }}</div>
                                                        @endforeach
                                                    @else
                                                        <div> {{ $value }}</div>
                                                    @endif
                                                @endforeach
                                            @else
                                                {{ $item['old'] }}
                                            @endif
                                        @endif
                                    @endforeach
                                </td>
                                <td>
                                    @foreach($audit->getModified() as $key => $item )
                                        @if(isset($item['new']))
                                            <div class=""><small style="font-weight: bolder">{{ ucwords($key) }}</small></div>
                                            @if(is_array($item['new']))
                                                @foreach( $item['new'] as $name => $value )
                                                    <div class=""><small style="font-weight: bolder">{{ ucwords($name) }}</small></div>
                                                    @if(is_array($value))
                                                        @foreach( $value as $i => $a )
                                                            <div class=""><small style="font-weight: bolder">{{ ucwords($i) }}</small></div>
                                                            <div> {{ $a }}</div>
                                                        @endforeach
                                                    @else
                                                        <div> {{ $value }}</div>
                                                    @endif
                                                @endforeach
                                            @else
                                                {{ $item['new'] }}
                                            @endif
                                        @endif
                                    @endforeach
                                </td>
                                <td>
                                    <div><span class="text-muted">Name : </span>{{ $audit->user->name }}</div>
                                    <div><span class="text-muted">Email : </span>{{ $audit->user->email }}</div>
                                    <div><span class="text-muted">IP : </span>{{  $audit->ip_address }}</div>
                                    <div><span class="text-muted">Agent : </span>{{ str_limit($audit->user_agent , '20', '...' )  }}</div>
                                 </td>
                                <td>
                                    <div><span class="text-muted">Event : </span><span class="px-2 border border-success text-success small ml-1">{{ $audit->event }}</span></div>
                                    <div><span class="text-muted">Date : </span>{{ $audit->created_at->diffForHumans() }}</div>
                                    <div><span class="text-muted">Branch : </span>{{ $audit->user->branch_name->name }}</div>
                                    <div><span class="text-muted">Type : </span>{{  str_replace('App\\models\\' , '' , $audit->auditable_type ) }}</div>
                                </td>
                                <td>
                                    <div class="mt-5"><a href="/audits/{{ $audit->id }}/view" class="card-link text-info"><i class="fe fe-eye"></i></a></div>
                                </td>

                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="card-footer row justify-content-center col-lg-12 border-0 bg-white pt-5 m-0 mb-5">
                    {{ $audits->appends(request()->query())->links()  }}
                </div>

            </div>
        </div>
    </div>
@endsection
