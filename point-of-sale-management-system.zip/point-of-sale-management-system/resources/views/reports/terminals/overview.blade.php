<div class="col-lg-3">
    <div class="card">
        <div class="card-body">
            <div class="row text-center">
                <div class="col">
                    <h2 class="mb-1">{{ $overview['total'] }}</h2>
                    <div class="text-muted-dark">Total</div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col-lg-9">
    <div class="card">
        <div class="card-body">
            <div class="row text-center justify-content-around px-5">
                @foreach($overview['term_type'] as $group )
                    <div class="col col-auto">
                        <h2 class="mb-1">{{ $group['term_type_count'] }}</h2>
                        <div class="text-muted-dark"><a class="card-link" href="{{ request()->fullUrlWithQuery(['term_type' => $group['term_type'] ]) }}">{{ $group['term_type'] }}</a></div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
</div>
<div class="col-lg-4 col-md-6">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Branches</h4>
        </div>
        <div style="height: 20rem" class="table-responsive">
            <table class="table card-table table-vcenter">
                <tbody>
                @foreach($overview['branch_code'] as $group )
                    <tr>
                        <td width="1"><span class="avatar">{{ $group['branch_code'] }}</span></td>
                        <td><a href="{{ request()->fullUrlWithQuery(['branch_code' => $group['branch_code'] ]) }}" class="card-link">{{ \App\core\Helper::getBranchName($group['branch_code'])  }}</a></td>
                        <td class="text-right"><span class="text-muted">{{ $group['branch_code_count'] }}</span></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="col-lg-4 col-md-6">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Top Accounts </h4>
        </div>
        <div style="height: 20rem" class="table-responsive">
            <table class="table card-table table-vcenter">
                <tbody>
                @foreach($overview['accounts'] as $group )
                    <tr>
                        <td><a href="{{ request()->fullUrlWithQuery(['account_id' => $group['account_id'] ]) }}" class="card-link">{{ $group['account_id'] }}</a></td>
                        <td class="text-right"><span class="text-muted">{{ $group['account_id_count'] }}</span></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="col-lg-4 col-md-6">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Models</h4>
        </div>
        <div style="height: 9rem" class="table-responsive">
            <table class="table card-table table-vcenter">
                <tbody>
                @foreach($overview['model'] as $group )
                    <tr>
                        <td><a href="{{ request()->fullUrlWithQuery(['model' => $group['model'] ]) }}" class="card-link">{{ $group['model'] ? $group['model'] : 'Un-kown' }}</a></td>
                        <td class="text-right"><span class="text-muted">{{ $group['model_count'] }}</span></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
    <div class="card mt-2">
        <div class="card-header">
            <h4 class="card-title">Active State</h4>
        </div>
        <div style="height: 6rem" class="table-responsive">
            <table class="table card-table table-vcenter">
                <tbody>
                @foreach($overview['active'] as $group )
                    <tr>
                        <td><a href="{{ request()->fullUrlWithQuery(['active' => $group['active'] ]) }}" class="card-link">{{ $group['active'] ? 'Active' : 'De-activated' }}</a></td>
                        <td class="text-right"><span class="text-muted">{{ $group['active_count'] }}</span></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            <div class="card-title">Terminal Creating</div>
            <div class="card-options">
                <a href="#" class="card-options-fullscreen" data-toggle="card-fullscreen"><i class="fe fe-maximize"></i></a>
            </div>
        </div>
        <div class="card-body">
            @if ($overview['chart_created_at']->datasets)
                {!! $overview['chart_created_at']->container() !!}
            @endif
        </div>
    </div>
</div>
<div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            <div class="card-title">Terminal Activity</div>
            <div class="card-options">
                <a href="#" class="card-options-fullscreen" data-toggle="card-fullscreen"><i class="fe fe-maximize"></i></a>
            </div>
        </div>
        <div class="card-body">
            @if ($overview['chart_updated_at']->datasets)
                {!! $overview['chart_updated_at']->container() !!}
            @endif
        </div>
    </div>
</div>
