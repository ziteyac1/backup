@if ($overview['chart_created_at']->datasets)
    {!! $overview['chart_created_at']->script() !!}
@endif

@if ($overview['chart_updated_at']->datasets)
    {!! $overview['chart_updated_at']->script() !!}
@endif


