<div class="form-group col-12">
    <label for="">Search</label>
    <input type="text" class="form-control" name="search" placeholder="Search" value="{{ old('search' , request('search')) }}">
</div>
<div class="form-group col-12">
    <label for="">Account</label>
    <input type="text" class="form-control" name="account_id" placeholder="account_id" value="{{ old('account_id' , request('account_id')) }}">
</div>

<div class="form-group col-12">
    <label for="">Model</label>
    <input type="text" class="form-control" name="model" placeholder="model" value="{{ old('model' , request('model')) }}">
</div>
<div class="form-group col-12">
    <label for="">Active</label>
    <input type="text" class="form-control" name="active" placeholder="active" value="{{ old('active' , request('active')) }}">
</div>

<div class="form-group col-12">
    <label for="">Customer</label>
    <input type="text" class="form-control" name="customer" placeholder="customer" value="{{ old('customer' , request('customer')) }}">
</div>

<div class="form-group col-6">
    <label for="">Start Date</label>
    <input type="date" class="form-control" name="start_date"  value="{{ old('start_date' , request('start_date')) }}">
</div>
<div class="form-group col-6">
    <label for="">End Date</label>
    <input type="date" class="form-control" name="end_date" value="{{ old('end_date' , request('end_date')) }}">
</div>
<div class="form-group col-12">
    <label for="">Branch</label>
    <select type="text" class="form-control" name="branch_code"  value="{{ old('branch_code' , request('branch_code')) }}">
        <option value="">Choose Branch</option>
        @foreach(\App\models\Branch::all()  as $branch )
            <option value="{{ $branch->branch_code }}" {{ old('branch_code' , request('branch_code') === $branch->branch_code ? 'selected' : '' ) }}>{{ $branch->branch_code }} - {{ $branch->name }}</option>
        @endforeach
    </select>
</div>

