<div class="form-group col-12">
    <label for="">Search</label>
    <input type="text" class="form-control" name="search" placeholder="Search" value="{{ old('search' , request('search')) }}">
</div>
<div class="form-group col-6">
    <label for="">Start Date</label>
    <input type="date" class="form-control" name="start_date"  value="{{ old('start_date' , request('start_date')) }}">
</div>
<div class="form-group col-6">
    <label for="">End Date</label>
    <input type="date" class="form-control" name="end_date" value="{{ old('end_date' , request('end_date')) }}">
</div>
<div class="form-group col-12">
    <label for="">Terminal</label>
    <input type="text" class="form-control" name="terminal" placeholder="terminal" value="{{ old('terminal' , request('terminal')) }}">
</div>
<div class="form-group col-12">
    <label for="">Sender</label>
    <input type="text" class="form-control" name="sender" placeholder="sender" value="{{ old('sender' , request('sender')) }}">
</div>
<div class="form-group col-12">
    <label for="">Receiver</label>
    <input type="text" class="form-control" name="receiver" placeholder="receiver" value="{{ old('receiver' , request('receiver')) }}">
</div>
<div class="form-group col-12">
    <label for="">to</label>
    <input type="text" class="form-control" name="to" placeholder="to" value="{{ old('to' , request('to')) }}">
</div>
<div class="form-group col-12">
    <label for="">batch</label>
    <input type="text" class="form-control" name="batch" placeholder="batch" value="{{ old('batch' , request('batch')) }}">
</div>
<div class="form-group col-12">
    <label for="">To Role</label>
    <input type="text" class="form-control" name="to" placeholder="to" value="{{ old('to' , request('to')) }}">
</div>
<div class="form-group col-12">
    <label for="">To branch</label>
    <input type="text" class="form-control" name="to_branch" placeholder="to" value="{{ old('to_branch' , request('to_branch')) }}">
</div>
<div class="form-group col-12">
    <label for="">Transport</label>
    <input type="text" class="form-control" name="transport" placeholder="transport" value="{{ old('transport' , request('transport')) }}">
</div>

<div class="form-group col-12">
    <label for="">Transport</label>
    <input type="text" class="form-control" name="transport" placeholder="transport" value="{{ old('transport' , request('transport')) }}">
</div>
<div class="col-lg-12">
    <label class="selectgroup-item"><input type="checkbox" name="sent" value="1" class="selectgroup-input"> <span class="selectgroup-button rounded-0 text-uppercase"><strong>Sent</strong></span></label>
    <label class="selectgroup-item"><input type="checkbox" name="received" value="1" class="selectgroup-input"> <span class="selectgroup-button rounded-0 text-uppercase"><strong>Received</strong></span></label>
</div>



