<div style="height: 90vh" class="table-responsive">
    <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
        <thead class="">
        <tr>
            <th>#</th>
            <th>Batch</th>
            <th>Terminal</th>
            <th>Serial Number</th>
            <th>Asset Code</th>
            <th>To</th>
            <th>Branch</th>
            <th class="decide-full-screen hide">Transport</th>
            <th class="decide-full-screen hide">Sender</th>
            <th class="decide-full-screen hide">Sent</th>
            <th class="decide-full-screen hide">Received</th>
            <th class="decide-full-screen hide">Checked</th>
            <th>Created</th>
            <th class="decide-full-screen hide">Updated</th>
        </tr>
        </thead>
        <tbody>
        @foreach($results as $pos )
            <tr>
                <td class="">{{ $pos->id }}</td>
                <td class="">{{ $pos->batch->id }}</td>
                <td class="">{{ $pos->terminal }}</td>
                <td class="">{{ $pos->serial_number }}</td>
                <td class="">{{ $pos->asset_code }}</td>
                <td class="">{{ $pos->batch->to }}</td>
                <td class="">{{ $pos->batch->to_branch }}</td>
                <td class="decide-full-screen hide">{{ $pos->batch->transport }}</td>
                <td class="decide-full-screen hide">{{ $pos->batch->sender->email }}</td>
                <td class="decide-full-screen hide">{{ $pos->sent }}</td>
                <td class="decide-full-screen hide">{{ $pos->received }}</td>
                <td class="decide-full-screen hide">{{ $pos->checked }}</td>
                <td class="">{{ $pos->created_at }}</td>
                <td class="decide-full-screen hide">{{ $pos->updated_at }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <div class="card-footer">
        {{ $results->appends(request()->query())->links()  }}
    </div>
</div>