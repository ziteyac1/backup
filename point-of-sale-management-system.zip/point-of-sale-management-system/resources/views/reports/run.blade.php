@extends('layouts.dashboard' , [ 'title' => 'Reports'  ,'active' => 'reports' ])
@section('content')

    <div class="container py-5">
        <div class="page-header">
            <h1 class="page-title">
                Reports Schedule
            </h1>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="card">
                    <form class="card-header">
                        <h3 class="card-title">Reports</h3>
                        <div class="card-options">
                            <div class="input-group">
                                <input type="text" value="{{ request('search') }}" class="form-control form-control-sm" placeholder="Search something..." name="search">
                                <span class="input-group-btn ml-2">
                                    <button class="btn btn-sm btn-primary" type="submit">
                                      <span class="fe fe-search"></span>
                                    </button>
                                 </span>
                            </div>
                        </div>
                    </form>
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-icon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    <div class="table-responsive">
                        <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
                            <thead>
                            <tr>
                                <th class="text-center w-1"><i class="fe fe-users"></i></th>
                                <th>User</th>
                                <th>Progress</th>
                                <th>Update</th>
                                <th>Info</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($reports as $report)
                                <tr class="">
                                    <td class="text-center">
                                        <span class="avatar avatar-green">{{ $report->user->short_name }}</span>
                                    </td>
                                    <td>
                                        <div>{{ ucwords( $report->user->name ) }}</div>
                                        <div class=""><span class="text-muted mr-2">Report : </span>{{ $report->report->name }}</div>
                                        <div class="small text-muted">
                                            Requested: {{ $report->created_at }}
                                        </div>
                                    </td>
                                    <td>
                                        <div class="clearfix">
                                            <div class="float-left">
                                                @if (!$report->canceled)
                                                    <strong>{{ (double)$report->progress * 100 }}%</strong>
                                                @endif
                                            </div>
                                            <div class="float-right">
                                                <small class="text-muted">{{ $report->created_at }} - {{ $report->updated_at }}</small>
                                            </div>
                                        </div>
                                        <div class="progress progress-xs">
                                            <div class="progress-bar {{ $report->completed ? 'bg-success' : 'bg-warning' }} {{ $report->canceled ? 'bg-danger' : '' }}" role="progressbar" style="width:{{ (double)$report->progress * 100 }}%" aria-valuenow="{{ (double)$report->progress * 100 }}" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <div class="pt-1"><span class="text-muted mr-2">State : </span>{{ $report->state }}</div>
                                    </td>
                                    <td>
                                        <div class="small text-muted">Last Updated</div>
                                        <div>{{ $report->updated_at->diffForHumans()}}</div>
                                    </td>
                                    <td>
                                        <div><span class="text-muted mr-3">ID : </span>{{ $report->id }}</div>
                                        <div><span class="text-muted mr-3">Size : </span>{{ $report->size }}</div>
                                        <div><span class="text-muted mr-3">Number : </span>{{ $report->number }}</div>
                                    </td>
                                    <td class="text-center">
                                        @can('download' , $report )
                                            <div><a href="/reports/download/{{ $report->id }}" class="btn btn-sm btn-secondary px-4 mb-1">Download</a></div>
                                        @endcan
                                        @can('view' , $report )
                                            <div><a href="/reports/reports-run/{{ $report->id }}" class="btn btn-sm btn-secondary px-4 mb-1">View</a></div>
                                        @endcan
                                        @can('cancel' , $report )
                                            <div><a href="/reports/cancel/{{ $report->id }}"  class="btn btn-sm btn-secondary px-3">Cancel</a></div>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer">
                        {{ $reports->appends(request()->query())->links()  }}
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('scripts')


@endsection

