
@foreach( $overview['charts'] as $chart )
    @if ($chart->datasets)
        {!! $chart->script() !!}
    @endif
@endforeach