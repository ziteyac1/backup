<div class="col-lg-4">
    <div class="card">
        <div class="card-body">
            <div class="row text-center">
                <div class="col">
                    <h2 class="mb-1">{{ $overview['total'] }}</h2>
                    <div class="text-muted-dark">Total</div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col-lg-8">
    <div class="card">
        <div class="card-body">
            <div class="row text-center justify-content-around px-5">
                @if (isset($overview['groups']))
                    @foreach($overview['groups'] as $group )
                        <div class="col col-auto">
                            <h2 class="mb-1">{{ $group['value'] }}</h2>
                            <div class="text-muted-dark"><a class="card-link" href="{{ request()->fullUrlWithQuery(['source_node' => $group['code'] ]) }}">{{ $group['name'] }}</a></div>
                        </div>
                    @endforeach
                @endif
            </div>
        </div>
    </div>
</div>

<div class="col-lg-4 col-md-6 {{ $report ? 'col-lg-6' : '' }}">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Transaction Types</h4>
        </div>
        <div style="height: 20rem" class="table-responsive">
            <table class="table card-table table-vcenter">
                <tbody>
                @if (isset($overview['tran_types']))
                    @foreach($overview['tran_types'] as $group )
                        <tr>
                            <td width="1"><span class="avatar">{{ $group['code'] }}</span></td>
                            <td><a href="{{ request()->fullUrlWithQuery(['tran_type' => $group['code'] ]) }}" class="card-link">{{ $group['name'] }}</a></td></td>
                            <td class="text-right"><span class="text-muted">{{ $group['value'] }}</span></td>
                        </tr>
                    @endforeach
                @endif
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="col-lg-4 col-md-6 {{ $report ? 'col-lg-6' : '' }}">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Response Codes</h4>
        </div>
        <div style="height: 20rem" class="table-responsive">
            <table class="table card-table table-vcenter">
                <tbody>
                @if (isset($overview['response_codes']))
                    @foreach($overview['response_codes'] as $group )
                        <tr>
                            <td width="1"><span class="avatar">{{ $group['code'] }}</span></td>
                            <td><a href="{{ request()->fullUrlWithQuery(['response_code' => $group['code'] ]) }}" class="card-link">{{ $group['name'] }}</a></td>
                            <td class="text-right"><span class="text-muted">{{ $group['value'] }}</span></td>
                        </tr>
                    @endforeach
                @endif
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="col-lg-4 col-md-6 row {{ $report ? 'col-lg-12' : '' }}">
    @if (isset($overview['amount_stats']))
        @foreach($overview['amount_stats'] as $key => $item )
            <div class="col-6 @if($loop->last) col-12 @endif">
                <div class="card">
                    <div class="card-body p-3 text-center">
                        <div class="h1 m-0">{{ $item }}</div>
                        <div class="text-muted mb-4">{{ ucwords($key) }}</div>
                    </div>
                </div>
            </div>
        @endforeach
    @endif
</div>
@if (isset($overview['charts']))
    @foreach( $overview['charts'] as $key => $chart)
        <div class="col-lg-4 {{ $report ? 'col-lg-12' : '' }}">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">{{ $key }}</div>
                    <div class="card-options">
                        <a href="#" class="card-options-fullscreen" data-toggle="card-fullscreen"><i class="fe fe-maximize"></i></a>
                    </div>
                </div>
                <div class="card-body">
                    @if ($chart->datasets)
                        {!! $chart->container() !!}
                    @endif
                </div>
            </div>
        </div>
    @endforeach
@endif
