<div style="height: 90vh" class="table-responsive">
    <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
        <thead class="">
        <tr>
            <th class="decide-full-screen hide">Tran Number</th>
            <th class="decide-full-screen hide">RRN</th>
            <th>Terminal</th>
            <th>Location</th>
            <th>Pan</th>
            <th class="decide-full-screen hide">Expiry</th>
            <th>Amount</th>
            <th>Date</th>
            <th class="decide-full-screen hide">Type</th>
            <th class="decide-full-screen hide">Response</th>
            <th class="decide-full-screen hide">Source Node</th>
            <th></th>
        </tr>
        </thead>
        <tbody>
        @foreach($results as $transaction )
            <tr>
                <td class="decide-full-screen hide">{{ $transaction->tran_nr }}</td>
                <td class="decide-full-screen hide">{{ $transaction->ret_ref_no }}</td>
                <td class=""><a class="card-link" href="{{ request()->fullUrlWithQuery(['terminal' => $transaction->card_acceptor_id ]) }}">{{ $transaction->card_acceptor_id }}</a></td>
                <td>{{ $transaction->card_acceptor_name_loc }}</td>
                <td>{{ $transaction->pan }}</td>
                <td class="decide-full-screen hide">{{ $transaction->expiry_date }}</td>
                <td>{{ $transaction->amount }}</td>
                <td>{{ $transaction->in_req }}</td>
                <td class="decide-full-screen hide">{{ $transaction->tran_type }}</td>
                <td class="decide-full-screen hide">{{ $transaction->response_code }}</td>
                <td class="decide-full-screen hide">{{ $transaction->source_node }}</td>
                <td>
                    @if ($transaction->response_code === '00')
                        <i class="text-success fe fe-check-circle"></i>
                    @else
                        <i class="text-danger fe fe-minus-square"></i>
                    @endif
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <div class="card-footer">
        {{ $results->appends(request()->query())->links()  }}
    </div>
</div>