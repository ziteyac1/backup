<div class="form-group col-12">
    <label for="">Terminal ID</label>
    <input type="text" class="form-control" name="terminal" placeholder="Terminal" value="{{ old('terminal' , request('terminal')) }}">
</div>
<div class="form-group col-6">
    <label for="">Start Date</label>
    <input type="date" class="form-control" name="start_date"  value="{{ old('start_date' , request('start_date')) }}">
</div>
<div class="form-group col-6">
    <label for="">End Date</label>
    <input type="date" class="form-control" name="end_date" value="{{ old('end_date' , request('end_date')) }}">
</div>
<div class="form-group col-12">
    <label for="">Branch</label>
    <select type="text" class="form-control" name="branch_code"  value="{{ old('branch_code' , request('branch_code')) }}">
        <option value="">Choose Branch</option>
        @foreach(\App\models\Branch::all()  as $branch )
            <option value="{{ $branch->branch_code }}" {{ old('branch_code' , request('branch_code') === $branch->branch_code ? 'selected' : '' ) }}>{{ $branch->branch_code }} - {{ $branch->name }}</option>
        @endforeach
    </select>
</div>
<div class="form-group col-12">
    <label for="">Account</label>
    <input type="text" class="form-control" name="account" placeholder="Account" value="{{ old('account' , request('account')) }}">
</div>
<div class="form-group col-12">
    <label for="">Customer</label>
    <input type="text" class="form-control" name="customer_id" placeholder="Customer Id" value="{{ old('customer_id' , request('customer_id')) }}">
</div>
<div class="form-group col-12">
    <label for="terminal_type">Terminal Type</label>
    <select type="text" class="form-control" name="source_node"  value="{{ old('source_node' , request('source_node')) }}">
        <option value="">Choose Type</option>
        <option value="AgriPosSrc" {{ old('source_node' , request('source_node') === 'AgriPosSrc' ? 'selected' : '' ) }}>MPOS</option>
        <option value="AgriMerchSrc" {{ old('source_node' , request('source_node') === 'AgriMerchSrc' ? 'selected' : '' ) }}>Merchant</option>
        <option value="AgriTellSrc" {{ old('source_node' , request('source_node') === 'AgriTellSrc' ? 'selected' : '' ) }}>Branch</option>
        <option value="AgriPosSrc" {{ old('source_node' , request('source_node') === 'AgriPosSrc' ? 'selected' : '' ) }}>Agency</option>
    </select>
</div>
<div class="form-group col-6">
    <label for="">Min Amount</label>
    <input type="text" class="form-control" name="min_amount" placeholder="Min" value="{{ old('min_amount' , request('min_amount')) }}">
</div>
<div class="form-group col-6">
    <label for="">Max Amount</label>
    <input type="text" class="form-control" name="max_amount" placeholder="Max" value="{{ old('max_amount' , request('max_amount')) }}">
</div>
<div class="form-group col-12">
    <label for="">Transaction Type</label>
    <select type="text" class="form-control" name="tran_type"  value="{{ old('tran_type' , request('tran_type')) }}">
        <option value="">Choose Code</option>
        @foreach(\App\models\TransactionType::all()  as $type )
            <option value="{{ $type->code }}" {{ old('tran_type' , request('tran_type') === $type->code ? 'selected' : '' ) }}>{{ $type->code }} - {{ $type->description }}</option>
        @endforeach
    </select>
</div>
<div class="form-group col-12">
    <label for="">Transaction Number</label>
    <input type="text" class="form-control" name="tran_nr" placeholder="Tran nr" value="{{ old('tran_nr' , request('tran_nr')) }}">
</div>
<div class="form-group col-12">
    <label for="">RRN</label>
    <input type="text" class="form-control" name="ret_ref_no" placeholder="RRN" value="{{ old('ret_ref_no' , request('ret_ref_no')) }}">
</div>
<div class="form-group col-12">
    <label for="">Sink Node</label>
    <input type="text" class="form-control" name="sink_node" placeholder="Sink Node" value="{{ old('sink_node' , request('sink_node')) }}">
</div>
<div class="form-group col-12">
    <label for="">Response Code</label>
    <select type="text" class="form-control" name="response_code"  value="{{ old('response_code' , request('response_code')) }}">
        <option value="">Choose Code</option>
        @foreach(\App\models\ResponseCode::all()  as $tran )
            <option value="{{ $tran->code }}" {{ old('response_code' , request('response_code') === $tran->code ? 'selected' : '' ) }}>{{ $tran->code }} - {{ $tran->description }}</option>
        @endforeach
    </select>
</div>