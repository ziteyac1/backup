<div class="form-group col-12">
    <label for="">Search</label>
    <input type="text" class="form-control" name="search" placeholder="Search" value="{{ old('search' , request('search')) }}">
</div>
<div class="form-group col-6">
    <label for="">Start Date</label>
    <input type="date" class="form-control" name="start_date"  value="{{ old('start_date' , request('start_date')) }}">
</div>
<div class="form-group col-6">
    <label for="">End Date</label>
    <input type="date" class="form-control" name="end_date" value="{{ old('end_date' , request('end_date')) }}">
</div>
<div class="form-group col-12">
    <label for="">Terminal</label>
    <input type="text" class="form-control" name="terminal" placeholder="terminal" value="{{ old('terminal' , request('terminal')) }}">
</div>
<div class="form-group col-12">
    <label for="">Serial Number</label>
    <input type="text" class="form-control" name="serial_number" placeholder="serial_number" value="{{ old('serial_number' , request('serial_number')) }}">
</div>
<div class="form-group col-12">
    <label for="">level</label>
    <input type="text" class="form-control" name="level" placeholder="level" value="{{ old('level' , request('level')) }}">
</div>
<div class="form-group col-12">
    <label for="">account</label>
    <input type="text" class="form-control" name="account" placeholder="account" value="{{ old('account' , request('account')) }}">
</div>
<div class="form-group col-12">
    <label for="">Log</label>
    <select type="text" class="form-control" name="log_id"  value="{{ old('log_id' , request('log_id')) }}">
        <option value="">Choose Log</option>
        @foreach(\App\models\system\Log::all()  as $log )
            <option value="{{ $log->id }}" {{ old('log_id' , (int)request('log_id') === (int)$log->id ? 'selected' : '' ) }}>{{ $log->id }} - {{ $log->description }}</option>
        @endforeach
    </select>
</div>


