<div style="height: 90vh" class="table-responsive">
    <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
        <thead class="">
        <tr>
            <th>Serial Number</th>
            <th>Log</th>
            <th>Level</th>
            <th>Terminal</th>
            <th>Account</th>
            <th>Created</th>
        </tr>
        </thead>
        <tbody>
        @foreach($results as $log )
            <tr>
                <td class="">{{ $log->serial_number }}</td>
                <td class="">{{ $log->log }}</td>
                <td class="">{{ $log->level }}</td>
                <td class="">{{ $log->terminal }}</td>
                <td class="">{{ $log->account }}</td>
                <td class="">{{ $log->created_at }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <div class="card-footer">
        {{ $results->appends(request()->query())->links()  }}
    </div>
</div>