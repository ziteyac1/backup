<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Language" content="en" />
    <meta name="msapplication-TileColor" content="#2d89ef">
    <meta name="theme-color" content="#4188c9">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"/>
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="HandheldFriendly" content="True">
    <meta name="MobileOptimized" content="320">
    <link rel="icon" href="{{asset('favicon.ico')}}" type="image/x-icon"/>
    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />
    <link href="{{asset('css/argon-dash.css')}}" rel="stylesheet" />
    <link href="{{asset('/assets/css/dashboard.css')}}" rel="stylesheet" />

</head>
<body class="">
<div  id="app">
    <div class="page">
        <div class="page-main">
            <div class="pt-5">
                <div class="container ">
                    <div class="row">
                        <div class="col-lg-12 text-center">
                            <span class="avatar avatar-lime avatar-xxl"><i class="fe fe-check"></i></span>
                        </div>
                        <div class="col-lg-12 mb-5">
                            <div class="display-4 text-center">{{ $report->name }} Summary</div>
                        </div>
                    </div>
                    <div class="row">
                        @if (view()->exists('reports.'.$report->views.'.overview'))
                            @include('reports.'.$report->views.'.overview', [ 'overview' => $overview , 'report' => true ])
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="{{ asset('js/app.js') }}"></script>
<script src="{{ asset('assets/js/core.js') }}"></script>
<script src="{{ asset('js/Chart.min.js') }}"></script>
@if (view()->exists('reports.'.$report->views.'.scripts'))
    @include('reports.'.$report->views.'.scripts',[ 'overview' => $overview ])
@endif
</body>
</html>


