<div style="height: 90vh" class="table-responsive">
    <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
        <thead class="">
        <tr>
            <th>#</th>
            <th>Terminal</th>
            <th>Serial Number</th>
            <th class="decide-full-screen hide">User</th>
            <th>Account</th>
            <th>Branch</th>
            <th>State</th>
            <th class="decide-full-screen hide">Reason</th>
            <th class="decide-full-screen hide">Charger</th>
            <th class="decide-full-screen hide">Battery</th>
            <th class="decide-full-screen hide">Line</th>
            <th class="decide-full-screen hide">Card</th>
            <th>Created</th>
            <th  class="decide-full-screen hide">Updated</th>
        </tr>
        </thead>
        <tbody>
        @foreach($results as $return )
            <tr>
                <td class="">{{ $return->id }}</td>
                <td class="">{{ $return->terminal }}</td>
                <td class="">{{ $return->serial_number }}</td>
                <td class="decide-full-screen hide">{{ $return->input->email }}</td>
                <td class="">{{ $return->account }}</td>
                <td class="">{{ $return->branch }}</td>
                <td class="">{{ $return->state }}</td>
                <td class="decide-full-screen hide">{{ $return->reason }}</td>
                <td class="decide-full-screen hide">{{ $return->charger }}</td>
                <td class="decide-full-screen hide">{{ $return->battery }}</td>
                <td class="decide-full-screen hide">{{ $return->line }}</td>
                <td class="decide-full-screen hide">{{ $return->card }}</td>
                <td class="">{{ $return->created_at }}</td>
                <td  class="decide-full-screen hide">{{ $return->updated_at }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <div class="card-footer">
        {{ $results->appends(request()->query())->links()  }}
    </div>
</div>