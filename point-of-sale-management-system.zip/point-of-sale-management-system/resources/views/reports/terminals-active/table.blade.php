<div style="height: 90vh" class="table-responsive">
    <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
        <thead class="">
        <tr>
            <th>Terminal ID</th>
            <th>Last Tran Date</th>
            <th class="decide-full-screen hide">Account</th>
            <th class="decide-full-screen hide">Trade Name</th>
            <th>Branch</th>
            <th  class="decide-full-screen hide">Override Term Type </th>
            <th>Model</th>
            <th>Type</th>
            <th>Active</th>
            <th>Location</th>
            <th  class="decide-full-screen hide">Serial Number</th>
            <th   class="decide-full-screen hide">System Serial Number</th>
            <th class="decide-full-screen hide">Created</th>
        </tr>
        </thead>
        <tbody>
        @foreach($results as $terminal )
            <tr>
                <td class="">{{ $terminal->terminal_id }}</td>
                <td class="">{{ \App\core\Helper::getLastTransaction($terminal->terminal_id ) }}</td>
                <td class="decide-full-screen hide">{{ $terminal->account_id }}</td>
                <td class="decide-full-screen hide">{{ $terminal->trade_name }}</td>
                <td class="">{{ \App\core\Helper::getBranchName($terminal->account->branch_code )}}</td>
                <td class="decide-full-screen hide">{{ $terminal->override_term_type }}</td>
                <td class="">{{ $terminal->model }}</td>
                <td class="">{{ $terminal->term_type }}</td>
                <td class="">{{ $terminal->active }}</td>
                <td class="">{{ $terminal->location }}</td>
                <td class="decide-full-screen hide">{{ $terminal->serial_number }}</td>
                <td class="decide-full-screen hide">{{ $terminal->system_serial_number }}</td>
                <td class="decide-full-screen hide">{{ $terminal->created_at }}</td>
                </tr>
        @endforeach
        </tbody>
    </table>
</div>