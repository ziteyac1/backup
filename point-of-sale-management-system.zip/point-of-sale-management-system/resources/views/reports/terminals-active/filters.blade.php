<div class="form-group col-12">
    <label for="">Account</label>
    <input type="text" class="form-control" name="account" placeholder="account" value="{{ old('account' , request('account')) }}">
</div>
<div class="form-group col-12">
    <label for="">Active</label>
    <select type="text" class="form-control" name="active"  value="{{ old('active' , request('active')) }}">
        <option value="">Choose Status</option>
        <option value="0" {{ old('active' , request('active') === 0 ? 'selected' : '' ) }}>De-activated</option>
        <option value="1" {{ old('active' , request('active') === 1 ? 'selected' : '' ) }}>Activated</option>
    </select>
</div>
<div class="form-group col-6">
    <label for="">Min Amount</label>
    <input type="text" class="form-control" name="min_amount" placeholder="Min" value="{{ old('min_amount' , request('min_amount')) }}">
</div>
<div class="form-group col-6">
    <label for="">Max Amount</label>
    <input type="text" class="form-control" name="max_amount" placeholder="Max" value="{{ old('max_amount' , request('max_amount')) }}">
</div>
<div class="form-group col-12">
    <label for="">Transaction Type</label>
    <select type="text" class="form-control" name="tran_type"  value="{{ old('tran_type' , request('tran_type')) }}">
        <option value="">Choose Code</option>
        @foreach(\App\models\TransactionType::all()  as $type )
            <option value="{{ $type->code }}" {{ old('tran_type' , request('tran_type') === $type->code ? 'selected' : '' ) }}>{{ $type->code }} - {{ $type->description }}</option>
        @endforeach
    </select>
</div>
<div class="form-group col-12">
    <label for="">Response Code</label>
    <select type="text" class="form-control" name="response_code"  value="{{ old('response_code' , request('response_code')) }}">
        <option value="">Choose Code</option>
        @foreach(\App\models\ResponseCode::all()  as $tran )
            <option value="{{ $tran->code }}" {{ old('response_code' , request('response_code') === $tran->code ? 'selected' : '' ) }}>{{ $tran->code }} - {{ $tran->description }}</option>
        @endforeach
    </select>
</div>
<div class="form-group col-6">
    <label for="">Start Date</label>
    <input type="date" class="form-control" name="start_date"  value="{{ old('start_date' , request('start_date')) }}">
</div>
<div class="form-group col-6">
    <label for="">End Date</label>
    <input type="date" class="form-control" name="end_date" value="{{ old('end_date' , request('end_date')) }}">
</div>
<input type="text" name="account_id" value="{{ request('account_id') }}" class="d-none">
<input type="text" name="branch_code" value="{{ request('branch_code') }}" class="d-none">
<input type="text" name="term_type" value="{{ request('term_type') }}" class="d-none">
<input type="text" name="model" value="{{ request('model') }}" class="d-none">
<input type="text" name="active" value="{{ request('active') }}" class="d-none">


