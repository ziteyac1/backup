<div class="col-lg-3">
    <div class="card">
        <div class="card-body">
            <div class="row text-center">
                <div class="col">
                    <h2 class="mb-1">{{ $overview['total'] }}</h2>
                    <div class="text-muted-dark">Total</div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col-lg-9">
    <div class="card">
        <div class="card-body">
            <div class="row text-center justify-content-around px-5">

                @foreach($overview['term_type'] as $key => $value )
                    <div class="col col-auto">
                        <h2 class="mb-1">{{ $key }}</h2>
                        <div class="text-muted-dark"><a class="card-link" href="{{ request()->fullUrlWithQuery(['term_type' =>  $key ]) }}">{{ $value }}</a></div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
</div>
<div class="col-lg-4 col-md-6">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Branches</h4>
        </div>
        <div style="height: 20rem" class="table-responsive">
            <table class="table card-table table-vcenter">
                <tbody>
                @foreach($overview['branch_code'] as $key => $value )
                    <tr>
                        <td width="1"><span class="avatar">{{ $key }}</span></td>
                        <td><a href="{{ request()->fullUrlWithQuery(['branch_code' => $key ]) }}" class="card-link">{{ \App\core\Helper::getBranchName($key)  }}</a></td>
                        <td class="text-right"><span class="text-muted">{{ $value }}</span></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="col-lg-4 col-md-6">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Top Accounts </h4>
        </div>
        <div style="height: 20rem" class="table-responsive">
            <table class="table card-table table-vcenter">
                <tbody>
                @foreach($overview['accounts'] as $key => $value  )
                    <tr>
                        <td><a href="{{ request()->fullUrlWithQuery(['account_id' => $key ]) }}" class="card-link">{{ $key }}</a></td>
                        <td class="text-right"><span class="text-muted">{{ $value }}</span></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="col-lg-4 col-md-6">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Models</h4>
        </div>
        <div style="height: 9rem" class="table-responsive">
            <table class="table card-table table-vcenter">
                <tbody>
                @foreach($overview['model'] as $key => $value   )
                    <tr>
                        <td><a href="{{ request()->fullUrlWithQuery(['model' => $key ]) }}" class="card-link">{{ $key ?: 'Un-known' }}</a></td>
                        <td class="text-right"><span class="text-muted">{{ $value }}</span></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
    <div class="card mt-2">
        <div class="card-header">
            <h4 class="card-title">Active State</h4>
        </div>
        <div style="height: 6rem" class="table-responsive">
            <table class="table card-table table-vcenter">
                <tbody>
                @foreach( $overview['active'] as $key => $value   )
                    <tr>
                        <td><a href="{{ request()->fullUrlWithQuery(['active' => $key ]) }}" class="card-link">{{ $key ? 'Active' : 'De-activated' }}</a></td>
                        <td class="text-right"><span class="text-muted">{{ $value }}</span></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@foreach($overview['rankings'] as $key => $ranking )
    <div class="col-lg-4 col-md-6">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">{{ $key }}</h4>
            </div>
            <div style="height: 20rem" class="table-responsive">
                <table class="table card-table table-vcenter">
                    <thead>
                       <tr>
                           <th>ID</th>
                           <th>Count</th>
                           <th>Value</th>
                       </tr>
                    </thead>
                    <tbody>
                    @foreach( $ranking as $group )
                        <tr>
                          <td>{{ $group['id'] }}</td>
                          <td>{{ $group['count'] }}</td>
                          <td>{{ $group['total_value'] }}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endforeach
