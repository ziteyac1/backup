<div style="height: 90vh" class="table-responsive">
    <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
        <thead class="">
        <tr>
            <th>Card</th>
            <th>Terminal</th>
            <th>Supervisor</th>
            <th>Name</th>
            <th>Created</th>
            <th>Last Update</th>
        </tr>
        </thead>
        <tbody>
        @foreach($results as $teller )
            <tr>
                <td class="">{{ $teller->card_number }}</td>
                <td class="">{{ $teller->linked_terminal }}</td>
                <td class="">{{ $teller->supervisor }}</td>
                <td class="">{{ $teller->name }}</td>
                <td class="">{{ $teller->created_at }}</td>
                <td class="">{{ $teller->updated_at }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <div class="card-footer">
        {{ $results->appends(request()->query())->links()  }}
    </div>
</div>