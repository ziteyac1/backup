<div class="form-group col-12">
    <label for="">Search</label>
    <input type="text" class="form-control" name="search" placeholder="Search" value="{{ old('search' , request('search')) }}">
</div>
<div class="form-group col-6">
    <label for="">Start Date</label>
    <input type="date" class="form-control" name="start_date"  value="{{ old('start_date' , request('start_date')) }}">
</div>
<div class="form-group col-6">
    <label for="">End Date</label>
    <input type="date" class="form-control" name="end_date" value="{{ old('end_date' , request('end_date')) }}">
</div>





