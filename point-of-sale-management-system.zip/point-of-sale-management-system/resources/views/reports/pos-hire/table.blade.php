<div style="height: 90vh" class="table-responsive">
    <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
        <thead class="">
        <tr>
            <th>#</th>
            <th>Terminal</th>
            <th>Serial Number</th>
            <th>Customer ID</th>
            <th>Created</th>
            <th>Updated</th>
        </tr>
        </thead>
        <tbody>
        @foreach($results as $hire )
            <tr>
                <td class="">{{ $hire->id }}</td>
                <td class="">{{ $hire->terminal }}</td>
                <td class="">{{ $hire->serial_number }}</td>
                <td class="">{{ $hire->customer_id }}</td>
                <td class="">{{ $hire->created_at }}</td>
                <td>{{ $hire->updated_at }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <div class="card-footer">
        {{ $results->appends(request()->query())->links()  }}
    </div>
</div>