<div style="height: 90vh" class="table-responsive">
    <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
        <thead class="">
        <tr>
            <th>#</th>
            <th>To</th>
            <th>Branch</th>
            <th>Transport</th>
            <th>Sender</th>
            <th class="decide-full-screen hide">Sent</th>
            <th class="decide-full-screen hide">Received</th>
            <th class="decide-full-screen hide">Checked</th>
            <th>Created</th>
            <th>Updated</th>
        </tr>
        </thead>
        <tbody>
        @foreach($results as $batch )
            <tr>
                <td class="">{{ $batch->id }}</td>
                <td class="">{{ $batch->to }}</td>
                <td class="">{{ $batch->to_branch }}</td>
                <td class="">{{ $batch->transport }}</td>
                <td class="">{{ $batch->sender->email }}</td>
                <td class="decide-full-screen hide">{{ $batch->sent }}</td>
                <td class="decide-full-screen hide">{{ $batch->received }}</td>
                <td class="decide-full-screen hide">{{ $batch->checked }}</td>
                <td class="">{{ $batch->created_at }}</td>
                <td class="">{{ $batch->updated_at }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <div class="card-footer">
        {{ $results->appends(request()->query())->links()  }}
    </div>
</div>