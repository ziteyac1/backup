<div class="col-lg-12">
    <div class="card">
        <div class="card-body">
            <div class="row text-center">
                <div class="col">
                    <h2 class="mb-1">{{ $overview['total'] }}</h2>
                    <div class="text-muted-dark">Total</div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            <div class="card-title">Tellers Activity</div>
            <div class="card-options">
                <a href="#" class="card-options-fullscreen" data-toggle="card-fullscreen"><i class="fe fe-maximize"></i></a>
            </div>
        </div>
        <div class="card-body">
            @if (isset($overview['chart_updated_at']->datasets[0]))
                @if ($overview['chart_updated_at']->datasets[0]->values)
                    @if ($overview['chart_updated_at']->datasets)
                        {!! $overview['chart_updated_at']->container() !!}
                    @endif
                @endif
            @endif
        </div>
    </div>
</div>
