<div style="height: 90vh" class="table-responsive">
    <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
        <thead class="">
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th class="decide-full-screen hide">Branch</th>
            <th class="decide-full-screen hide">Email Verified</th>
            <th>Allowed</th>
            <th class="decide-full-screen hide">Created</th>
            <th>Updated</th>
        </tr>
        </thead>
        <tbody>
        @foreach($results as $user )
            <tr>
                <td class="">{{ $user->id }}</td>
                <td class="">{{ $user->name }}</td>
                <td class="">{{ $user->email }}</td>
                <td class="">{{ $user->role_name->name }}</td>
                <td class="decide-full-screen hide">{{ $user->branch_name->name }}</td>
                <td class="decide-full-screen hide">{{ $user->email_verified_at }}</td>
                <td class="">{{ $user->allowed }}</td>
                <td class="decide-full-screen hide">{{ $user->created_at }}</td>
                <td>{{ $user->updated_at }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <div class="card-footer">
        {{ $results->appends(request()->query())->links()  }}
    </div>
</div>