@if ($overview['chart']->datasets)
    {!! $overview['chart']->script() !!}
@endif


