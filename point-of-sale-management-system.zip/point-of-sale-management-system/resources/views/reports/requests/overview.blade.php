<div class="col-lg-3">
    <div class="card">
        <div class="card-body">
            <div class="row text-center">
                <div class="col">
                    <h2 class="mb-1">{{ $overview['total'] }}</h2>
                    <div class="text-muted-dark">Total</div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col-lg-9">
    <div class="card">
        <div class="card-body">
            <div class="row text-center justify-content-around px-5">
                @foreach($overview['request_types'] as $group )
                    <div class="col col-auto">
                        <h2 class="mb-1">{{ $group['type_count'] }}</h2>
                        <div class="text-muted-dark"><a class="card-link" href="{{ request()->fullUrlWithQuery(['type' => $group['type'] ]) }}">{{ ucwords(str_replace( '-', ' ' , $group['type'] )) }}</a></div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
</div>
<div class="col-lg-4 col-md-6">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Branches</h4>
        </div>
        <div style="height: 20rem" class="table-responsive">
            <table class="table card-table table-vcenter">
                <tbody>
                @foreach($overview['branches'] as $group )
                    <tr>
                        <td width="1"><span class="avatar">{{ $group['branch_code'] }}</span></td>
                        <td><a href="{{ request()->fullUrlWithQuery(['branch_code' => $group['branch_code'] ]) }}" class="card-link">{{ \App\core\Helper::getBranchName($group['branch_code'])  }}</a></td>
                        <td class="text-right"><span class="text-muted">{{ $group['branch_code_count'] }}</span></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="col-lg-4 col-md-6">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Role Assigned</h4>
        </div>
        <div style="height: 20rem" class="table-responsive">
            <table class="table card-table table-vcenter">
                <tbody>
                @foreach($overview['role_assigned'] as $group )
                    <tr>
                        <td><a href="{{ request()->fullUrlWithQuery(['role_assigned' => $group['role_assigned'] ]) }}" class="card-link">{{ $group['role_assigned'] }}</a></td>
                        <td class="text-right"><span class="text-muted">{{ $group['role_assigned_count'] }}</span></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="col-lg-4 col-md-6">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Request States</h4>
        </div>
        <div style="height: 20rem" class="table-responsive">
            <table class="table card-table table-vcenter">
                <tbody>
                @foreach($overview['states'] as $group )
                    <tr>
                        <td><a href="{{ request()->fullUrlWithQuery(['description' => $group['description'] ]) }}" class="card-link">{{ $group['description'] }}</a></td>
                        <td class="text-right"><span class="text-muted">{{ $group['state_count'] }}</span></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            <div class="card-title">Requests</div>
            <div class="card-options">
                <a href="#" class="card-options-fullscreen" data-toggle="card-fullscreen"><i class="fe fe-maximize"></i></a>
            </div>
        </div>
        <div class="card-body">
            @if ($overview['chart']->datasets)
                {!! $overview['chart']->container() !!}
            @endif
        </div>
    </div>
</div>
