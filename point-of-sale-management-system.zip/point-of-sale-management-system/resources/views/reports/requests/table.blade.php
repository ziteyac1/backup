<div style="height: 90vh" class="table-responsive">
    <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
        <thead class="">
        <tr>
            <th>ID</th>
            <th>User</th>
            <th>Role Assigned</th>
            <th>Type</th>
            <th>Created At</th>
            <th>Updated At</th>
            <th class="decide-full-screen ">State</th>
            <th class="decide-full-screen hide">State</th>
        </tr>
        </thead>
        <tbody>
        @foreach($results as $request )
            <tr>
                <td class="">{{ $request->id }}</td>
                <td class="">{{ $request->requester_id }}</td>
                <td class="">{{ $request->role_assigned }}</td>
                <td class="">{{ $request->type }}</td>
                <td class="">{{ $request->created_at }}</td>
                <td class="">{{ $request->updated_at }}</td>
                <td class="decide-full-screen ">{{ $request->state }}</td>
                <td class="decide-full-screen hide">{{ $request->state_name->description_name->description  }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <div class="card-footer">
        {{ $results->appends(request()->query())->links()  }}
    </div>
</div>