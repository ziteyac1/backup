<div class="form-group col-12">
    <label for="">Request ID</label>
    <input type="text" class="form-control" name="terminal" placeholder="Request ID" value="{{ old('id' , request('id')) }}">
</div>
<div class="form-group col-12">
    <label for="terminal_type">Request Type</label>
    <select type="text" class="form-control" name="type"  value="{{ old('type' , request('type')) }}">
        <option value="">Choose Type</option>
        @foreach(\App\models\system\RequestType::all() as $request )
            <option value="{{ $request->name }}" {{ old('type' , request('type') ) ===  $request->name ? 'selected' : '' }}>{{ $request->description }}</option>
        @endforeach
    </select>
</div>
<div class="form-group col-12">
    <label for="terminal_type">Request State</label>
    <select class="form-control custom-select" name="state" id="">
        <option value="">Choose State</option>
        <option value="open" {{ old('state' , request('state') ) ===  'open' ? 'selected' : '' }}>Open</option>
        <option value="closed" {{ old('state' , request('state') ) ===  'closed' ? 'selected' : '' }}>Closed</option>
    </select>
</div>
<div class="form-group col-6">
    <label for="">Start Date</label>
    <input type="date" class="form-control" name="start_date"  value="{{ old('start_date' , request('start_date')) }}">
</div>
<div class="form-group col-6">
    <label for="">End Date</label>
    <input type="date" class="form-control" name="end_date" value="{{ old('end_date' , request('end_date')) }}">
</div>
<div class="form-group col-12">
    <label for="">Branch</label>
    <select type="text" class="form-control" name="branch_code"  value="{{ old('branch_code' , request('branch_code')) }}">
        <option value="">Choose Branch</option>
        @foreach(\App\models\Branch::all()  as $branch )
            <option value="{{ $branch->branch_code }}" {{ old('branch_code' , request('branch_code') === $branch->branch_code ? 'selected' : '' ) }}>{{ $branch->branch_code }} - {{ $branch->name }}</option>
        @endforeach
    </select>
</div><div class="form-group col-12">
    <label for="">Role Assigned</label>
    <select type="text" class="form-control" name="role_assigned"  value="{{ old('role_assigned' , request('role_assigned')) }}">
        <option value="">Choose Role</option>
        @foreach(\App\models\system\Role::all()  as $role )
            <option value="{{ $role->name }}" {{ old('role_assigned' , request('role_assigned') === $role->name ? 'selected' : '' ) }}>{{ $role->id }} - {{ $role->name }}</option>
        @endforeach
    </select>
</div>
