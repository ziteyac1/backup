<div style="height: 90vh" class="table-responsive">
    <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
        <thead class="">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Address</th>
            <th>Phone</th>
            <th>Created</th>
            <th>Updated</th>
        </tr>
        </thead>
        <tbody>
        @foreach($results as $customer )
            <tr>
                <td class="">{{ $customer->id }}</td>
                <td class="">{{ $customer->name }}</td>
                <td class="">{{ $customer->last_name }}</td>
                <td class="">{{ $customer->email }}</td>
                <td class="">{{ $customer->address }}</td>
                <td class="">{{ $customer->phone }}</td>
                <td class="">{{ $customer->created_at }}</td>
                <td class="">{{ $customer->updated_at }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <div class="card-footer">
        {{ $results->appends(request()->query())->links()  }}
    </div>
</div>