<div style="height: 90vh" class="table-responsive">
    <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
        <thead class="">
        <tr>
            <th>Serial Number</th>
            <th>Terminal ID</th>
            <th>Auto Terminal ID</th>
            <th>Asset Code</th>
            <th>Location</th>
            <th>Branch</th>
            <th>Last Update</th>
        </tr>
        </thead>
        <tbody>
        @foreach($results as $pos )
            <tr>
                <td class="">{{ $pos->serial_number }}</td>
                <td class="">
                    @if ($pos->terminal)
                        {{ $pos->terminal->terminal_id }}
                    @endif
                </td>
                <td class="">
                    @if ($pos->auto_terminal)
                        {{ $pos->auto_terminal->terminal_id }}
                    @endif
                </td>
                <td class="">{{ $pos->asset_code }}</td>
                <td class="">{{ $pos->location }}</td>
                <td class="">{{ $pos->branch }}</td>
                <td class="">{{ $pos->updated_at }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <div class="card-footer">
        {{ $results->appends(request()->query())->links()  }}
    </div>
</div>