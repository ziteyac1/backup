<div class="col-lg-4">
    <div class="card">
        <div class="card-body">
            <div class="row text-center">
                <div class="col">
                    <h2 class="mb-1">{{ $overview['total'] }}</h2>
                    <div class="text-muted-dark">Total</div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="col-lg-4 col-md-6">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Branches</h4>
        </div>
        <div style="height: 10rem" class="table-responsive">
            <table class="table card-table table-vcenter">
                <tbody>
                @foreach($overview['branch'] as $group )
                    <tr>
                        <td width="1"><span class="avatar">{{ $group['branch'] }}</span></td>
                        <td><a href="{{ request()->fullUrlWithQuery(['branch' => $group['branch'] ]) }}" class="card-link">{{ \App\core\Helper::getBranchName($group['branch'])  }}</a></td>
                        <td class="text-right"><span class="text-muted">{{ $group['branch_count'] }}</span></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="col-lg-4 col-md-6">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Locations </h4>
        </div>
        <div style="height: 10rem" class="table-responsive">
            <table class="table card-table table-vcenter">
                <tbody>
                @foreach($overview['location'] as $group )
                    <tr>
                        <td><a href="{{ request()->fullUrlWithQuery(['location' => $group['location'] ]) }}" class="card-link">{{ $group['location'] ?: 'Un-known' }}</a></td>
                        <td class="text-right"><span class="text-muted">{{ $group['location_count'] }}</span></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            <div class="card-title">POS Machines Activity</div>
            <div class="card-options">
                <a href="#" class="card-options-fullscreen" data-toggle="card-fullscreen"><i class="fe fe-maximize"></i></a>
            </div>
        </div>
        <div class="card-body">
            @if (isset($overview['chart_updated_at']->datasets[0]))
                @if ($overview['chart_updated_at']->datasets[0]->values)
                    @if ($overview['chart_updated_at']->datasets)
                        {!! $overview['chart_updated_at']->container() !!}
                    @endif
                @endif
            @endif
        </div>
    </div>
</div>
