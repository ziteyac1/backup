<div style="height: 90vh" class="table-responsive">
    <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
        <thead class="">
        <tr>
            <th>Account</th>
            <th>Branch Code</th>
            <th>Customer ID</th>
            <th>Customer Name</th>
            <th>Created</th>
            <th>Last Update</th>
        </tr>
        </thead>
        <tbody>
        @foreach($results as $account )
            <tr>
                <td class="">{{ $account->account }}</td>
                <td class="">{{ $account->branch_code }}</td>
                <td class="">{{ $account->customer->id }}</td>
                <td class="">{{ $account->customer->full_name }}</td>
                <td class="">{{ $account->created_at }}</td>
                <td class="">{{ $account->updated_at }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <div class="card-footer">
        {{ $results->appends(request()->query())->links()  }}
    </div>
</div>