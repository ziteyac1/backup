@extends('layouts.dashboard' , [ 'title' => 'Reports - '.$report->name  ,'active' => 'report-transactions' ])
@section('content')

    <div class="container py-5">
        <div class="page-header">
            <h1 class="page-title">
                {{ $report->name }}
            </h1>
        </div>
        <div class="row">
            @if (view()->exists('reports.'.$report->views.'.overview'))
                @include('reports.'.$report->views.'.overview',  [ 'overview' => $overview , 'report' => false ])
            @endif
        </div>
        <form class="row justify-content-center">
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Filter</h3>
                        <div class="card-options">
                            <a href="#" class="card-options-fullscreen mr-5" data-toggle="card-fullscreen"><i class="fe fe-maximize"></i></a>
                            <button name="filter" value="1" type="submit" class="btn btn-primary btn-sm px-4"><i class="fe fe-filter mr-3 small"></i>Filter</button>
                        </div>
                    </div>
                    <div class="card-body p-3 row">
                        @if (view()->exists('reports.'.$report->views.'.filters'))
                            @include('reports.'.$report->views.'.filters')
                        @endif
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{ $report->name }}</h3>
                        <div class="card-options">
                            <a href="#" class="card-options-fullscreen mr-5" data-toggle="card-fullscreen"><i class="fe fe-maximize"></i></a>
                            <button name="request" value="1" type="submit" class="btn btn-primary btn-sm"> <i class="fe fe-zap mr-3"></i>Run Report</button>
                        </div>
                    </div>
                    @if (view()->exists('reports.'.$report->views.'.table'))
                        @include('reports.'.$report->views.'.table', [ 'results' => $results ])
                    @endif
                </div>
            </div>
        </form>
    </div>

@endsection

@section('scripts')

    <script src="{{ asset('js/Chart.min.js') }}"></script>
    @if (view()->exists('reports.'.$report->views.'.scripts'))
        @include('reports.'.$report->views.'.scripts',[ 'overview' => $overview ])
    @endif

@endsection

