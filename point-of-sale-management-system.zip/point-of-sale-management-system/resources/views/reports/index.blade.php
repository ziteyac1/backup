@extends('layouts.dashboard' , [ 'title' => 'Reports'  ,'active' => 'reports' ])
@section('content')

    <div class="container py-5">
        <div class="page-header">
            <h1 class="page-title">
                Reports
            </h1>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="card">
                    <form class="card-header">
                        <h3 class="card-title">Reports</h3>
                        <div class="card-options">
                            <div class="input-group">
                                <input type="text" value="{{ request('search') }}" class="form-control form-control-sm" placeholder="Search something..." name="search">
                                <span class="input-group-btn ml-2">
                                    <button class="btn btn-sm btn-primary" type="submit">
                                      <span class="fe fe-search"></span>
                                    </button>
                                 </span>
                            </div>
                        </div>
                    </form>
                    <table class="table card-table table-striped table-vcenter">
                        <thead class="">
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Type</th>
                            <th>Section</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($reports as $report)
                            <tr>
                                <td>{{ $report->id }}</td>
                                <td>{{ $report->name }}</td>
                                <td>{{ $report->description }}</td>
                                <td>{{ $report->type }}</td>
                                <td>{{ $report->section }}</td>
                                <td><a href="/reports/view/{{ $report->id }}?start_date={{ now()->subMonth(1)->format('Y-m-d') }}" class="card-link"><i class="fe fe-eye mr-3"></i>View</a></td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    <div class="card-footer">
                        {{ $reports->appends(request()->query())->links()  }}
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('scripts')


@endsection

