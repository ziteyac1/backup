@extends('layouts.dashboard' , [ 'title' => 'Quick Panel'  ,'active' => 'quick-panel' ])
@section('content')
    <div class="container">
        <div class="page-header">
            <h1 class="page-title">
                Quick Panel
            </h1>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card rounded-0  border-0 shadow-lg">
                        {!! $chart->container() !!}
                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')

    <script src="{{ asset('js/Chart.min.js') }}"></script>
    {!! $chart->script() !!}

@endsection
