<div class="card bg-transparent border-0 rounded-0 shadow-none">
    <div class="card-header">
        <h5 class="card-title">POS Info</h5>
        <div class="card-options">
            <a href="/pos-machine/{{ $machine->id }}/history" class="btn btn-secondary btn-sm ml-2 ">History</a>
            <a href="/pos-machines/{{ $machine->id }}/edit" class="btn btn-secondary btn-sm ml-2 ">Edit</a>
            <a href="/pos-machines/add-log?serial_number={{ $machine->serial_number }}&terminal=@if($machine->terminal){{ $machine->terminal->terminal_id }}@endif" class="btn btn-secondary btn-sm ml-2 ">Add log</a>
        </div>
    </div>
    <table class="card-table table bg-white shadow-sm table-hover">
        <tbody>
        <tr>
            <td class="small"><strong>Serial Number :</strong></td>
            <td class="text-right">{{ $machine->serial_number }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Asset Code :</strong></td>
            <td class="text-right">{{ $machine->asset_code }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Model :</strong></td>
            <td class="text-right">{{ $machine->model }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Location :</strong></td>
            <td class="text-right">{{ $machine->location }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Branch :</strong></td>
            <td class="text-right">{{ $machine->branch }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Working State :</strong></td>
            <td class="text-right">{{ $machine->working_state }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Condition:</strong></td>
            <td class="text-right">{{ $machine->pos_condition }}</td>
        </tr>

        <tr>
            <td class="small"><strong>Created :</strong></td>
            <td class="text-right">{{ $machine->created_at }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Updated :</strong></td>
            <td class="text-right">{{ $machine->updated_at->diffForHumans() }}</td>
        </tr>
        </tbody>
    </table>
</div>