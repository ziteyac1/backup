<div class="card bg-transparent border-0 rounded-0 shadow-none">
    <div class="card-header">
        <h5 class="card-title">Account Info</h5>
        <div class="card-options">
            @can('input' , \App\models\system\Input::class )
                <a href="/requests/change-account/create?old={{ $account->account }}" class="btn btn-primary btn-sm px-5">Request change account</a>
            @endcan
            <a href="/account/{{ $account->id }}/history" class="btn btn-secondary btn-sm ml-2 px-3">History</a>
        </div>
    </div>
    <table class="card-table table bg-white shadow-sm table-hover">
        <tbody>
        <tr>
            <td class="small"><strong>ID :</strong></td>
            <td class="text-right">{{ $account->id }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Account :</strong></td>
            <td class="text-right">{{ $account->account }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Branch Code :</strong></td>
            <td class="text-right">{{ $account->branch_code }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Branch Name :</strong></td>
            <td class="text-right">{{ $account->branch->name }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Branch Short Name :</strong></td>
            <td class="text-right">{{ $account->branch->short_name}}</td>
        </tr>
        <tr>
            <td class="small"><strong>Customer ID :</strong></td>
            <td class="text-right">{{ $account->customer_id }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Created :</strong></td>
            <td class="text-right">{{ $account->created_at }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Updated :</strong></td>
            <td class="text-right">{{ $account->updated_at->diffForHumans() }}</td>
        </tr>
        </tbody>
    </table>
</div>