<div class="card bg-transparent border-0 rounded-0 shadow-none">
    <div class="card-header">
        <h5 class="card-title">Terminal Info @if(isset($type)){{  ' : '.$type }}@endif</h5>
    </div>
    <div class="card-header">
        <div class="">
            <a href="/terminal/{{ $terminal->id }}/history" class="btn btn-secondary btn-sm ml-2 ">History</a>
            @can('input' , \App\models\system\Input::class )
                <a href="/requests/re-allocation/create?terminal={{ $terminal->terminal_id }}" class="btn btn-secondary btn-sm ml-2 ">Reallocation</a>
                <a href="/requests/change-details/create?account={{ $terminal->account_id }}&terminal={{ $terminal->terminal_id }}&trade_name={{ $terminal->trade_name }}&location={{ $terminal->location }}" class="btn btn-secondary btn-sm ml-2">Change details</a>
                @can('deactivate' , $terminal )
                    @if($terminal->active)
                        <a href="/terminal/{{ $terminal->id }}/deactivate" class="btn btn-danger btn-sm ml-2 ">Deactivate</a>
                    @else
                        <a href="/terminal/{{ $terminal->id }}/activate" class="btn btn-success btn-sm ml-2 ">Activate</a>
                    @endif
                @endcan
            @endcan
        </div>
    </div>
    <table class="card-table table bg-white shadow-sm table-hover">
        <tbody>
        <tr>
            <td class="small"><strong>ID :</strong></td>
            <td class="text-right">{{ $terminal->id }} -
                @if($terminal->active)
                    <span class="px-2 border border-success text-success small ml-2">Active</span>
                @else
                    <span class="px-2 border border-danger text-danger small ml-2">Deactivated</span>
                @endif
            </td>
        </tr>
        <tr>
            <td class="small"><strong>Terminal ID :</strong></td>
            <td class="text-right">{{ $terminal->terminal_id }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Account :</strong></td>
            <td class="text-right">{{ $terminal->account_id }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Trade name :</strong></td>
            <td class="text-right">{{ $terminal->trade_name }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Location :</strong></td>
            <td class="text-right">{{ $terminal->location }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Term Type  :</strong></td>
            <td class="text-right">{{ $terminal->override_term_type }} - {{ $terminal->term_type }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Model :</strong></td>
            <td class="text-right">{{ $terminal->model }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Serial Number :</strong></td>
            <td class="text-right">{{ $terminal->serial_number }}</td>
        </tr>
        <tr>
            <td class="small"><strong>System Serial Number :</strong></td>
            <td class="text-right">{{ $terminal->system_serial_number }}</td>
        </tr>
		@if($terminal->account)
        <tr>
            <td class="small"><strong>Branch :</strong></td>
            <td class="text-right">{{ $terminal->account->branch_code }} - {{ $terminal->account->branch->name }}</td>
        </tr>
		@endif
        <tr>
            <td class="small"><strong>Created :</strong></td>
            <td class="text-right">{{ $terminal->created_at }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Updated :</strong></td>
            <td class="text-right">{{ $terminal->updated_at->diffForHumans() }}</td>
        </tr>
        </tbody>
    </table>
</div>