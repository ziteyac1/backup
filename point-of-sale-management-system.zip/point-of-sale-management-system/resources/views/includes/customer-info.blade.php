<div class="card bg-transparent border-0 rounded-0 shadow-none">
    <div class="card-header">
        <h5 class="card-title">Customer Info</h5>
        <div class="card-options">
            @can('input' , \App\models\system\Input::class)
                <a href="/customer/{{ $customer->id }}/edit" class="btn btn-primary btn-sm px-5">Edit</a>
            @endcan
            <a href="/customer/{{ $customer->id }}/history" class="btn btn-secondary btn-sm ml-2 px-3">History</a>
        </div>
    </div>
    <table class="card-table table bg-white shadow-sm table-hover">
        <tbody>
        <tr>
            <td class="small"><strong>ID :</strong></td>
            <td class="text-right">{{ $customer->id }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Name :</strong></td>
            <td class="text-right">{{ $customer->name }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Last Name :</strong></td>
            <td class="text-right">{{ $customer->last_name }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Email :</strong></td>
            <td class="text-right">{{ $customer->email }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Phone :</strong></td>
            <td class="text-right">{{ $customer->phone }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Address :</strong></td>
            <td class="text-right">{{ $customer->address }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Created :</strong></td>
            <td class="text-right">{{ $customer->created_at }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Updated :</strong></td>
            <td class="text-right">{{ $customer->updated_at->diffForHumans() }}</td>
        </tr>
        </tbody>
    </table>
</div>