<div class="card bg-transparent border-0 rounded-0 shadow-none">
    <div class="card-header">
        <h5 class="card-title">Request Info</h5>
        <div class="card-options">
            @if($request->name->execution !== 'instant' )
                <a href="/request/{{ $request->id }}/view" class="btn btn-secondary btn-sm ml-2">View</a>
                @can( 'edit' ,$request )
                    <a href="/request/{{ $request->id }}/edit" class="btn btn-secondary btn-sm ml-2">Edit</a>
                @endcan
                @can( $request->state_name->action , $request )
                    <a href="/request/{{ $request->id }}/action" class="btn btn-secondary btn-sm ml-2">{{ \ucwords( $request->state_name->action ) }}</a>
                @endcan
                @can('close', $request )
                    <a href="/request/{{ $request->id }}/close" class="btn btn-secondary btn-sm ml-2">Close</a>
                @endcan
            @endif
        </div>
    </div>
    <table class="card-table table bg-white shadow-sm table-hover">
        <tbody>
        <tr>
            <td class="small"><strong>ID :</strong></td>
            <td class="text-right">{{ $request->id }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Branch : </strong></td>
            <td class="text-right">{{ $request->branch_code }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Role Assigned :</strong></td>
            <td class="text-right">{{ $request->role_assigned }}</td>
        </tr>
        <tr>
            <td class="small"><strong>State :</strong></td>
            <td class="text-right">{{ $request->state_name->description_name->description }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Request Type :</strong></td>
            <td class="text-right">{{ $request->type }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Created :</strong></td>
            <td class="text-right">{{ $request->created_at }}</td>
        </tr>
        <tr>
            <td class="small"><strong>Updated :</strong></td>
            <td class="text-right">{{ $request->updated_at->diffForHumans() }}</td>
        </tr>
        </tbody>
    </table>
</div>