<div class="card bg-transparent border-0 rounded-0 shadow-none">
    <div class="card-header">
        <h3 class="card-title">Terminals</h3>
        <div class="card-options">
		@if(isset($account))
            @can('input' , \App\models\system\Input::class)
                <a href="/requests/new-terminal/create?account={{ $account->account }}" class="btn btn-secondary btn-sm ml-2 px-5"><i class="fe fe-plus-circle mr-3"></i>Request Terminal</a>
            @endcan
            <a href="/terminals/all?{{ $name }}={{ $ref->id }}" class="btn btn-secondary btn-sm ml-2 px-5"><i class="fe fe-git-pull-request mr-3"></i>View all terminals</a>
		@endif
        </div>
    </div>
    <table class="card-table table table-vcenter table-hover">
        <thead>
        <tr>
            <th>Info</th>
            <th>Info</th>
            <th></th>
            <th></th>
        </tr>
        </thead>
        <tbody class="bg-white shadow-sm">

        @foreach($terminals as $terminal )

            <tr class="">
                <td class="">
                    <div><span class="text-muted">ID : </span>{{ $terminal->terminal_id }}</div>
                    <div><span class="text-muted">Trade Name : </span>{{ $terminal->trade_name }}</div>
                    <div><span class="text-muted">Location : </span>{{ $terminal->location }}</div>
                </td>
                <td>
                    <div><span class="text-muted">Term type : </span>{{ $terminal->override_term_type }}</div>
                    <div><span class="text-muted">Account : </span>{{ $terminal->account->account }}</div>
                </td>
                <td class="text-center">
                    @if($terminal->active)
                        <div class="small"><span class="px-2 border border-success text-success small">Activated</span></div>
                    @else
                        <div class="small"><span class="px-2 border border-danger text-danger small">De-Activated</span></div>
                    @endif
                </td>
                <td class="text-center">
                    <div class="item-action dropdown">
                        <a href="javascript:void(0)" data-toggle="dropdown" class="icon" aria-expanded="false"><i class="fe fe-more-vertical"></i></a>
                        <div class="dropdown-menu dropdown-menu-right text-center" x-placement="bottom-end" style="position: absolute; transform: translate3d(15px, 20px, 0px); top: 0px; left: 0px; will-change: transform;">
                            <a href="/terminal/{{ $terminal->id }}/view" class="dropdown-item"><i class="dropdown-icon fe fe-eye mr-3"></i> View Terminal</a>
                            @can('input' , \App\models\system\Input::class)

                                <a href="/requests/change-details/create?account={{ $terminal->account_id }}&terminal={{ $terminal->terminal_id }}&trade_name={{ $terminal->trade_name }}&location={{ $terminal->location }}" class="dropdown-item"><i class="dropdown-icon fe fe-edit-3 mr-3"></i> Request Change Details </a>
                                <a href="/requests/re-allocation/create?terminal={{ $terminal->terminal_id }}" class="dropdown-item"><i class="dropdown-icon fe fe-share-2 mr-3"></i> Request Reallocation</a>
                                <div class="dropdown-divider"></div>

                                @can('deactivate' , $terminal )
                                    @if($terminal->active)
                                        <a href="/terminal/{{ $terminal->id }}/deactivate" class="dropdown-item text-danger"><i class="dropdown-icon fe fe-zap-off mr-2 text-danger mr-3"></i> De-activate Terminal</a>
                                    @else
                                        <a href="/terminal/{{ $terminal->id }}/activate" class="dropdown-item text-success"><i class="dropdown-icon fe fe-zap mr-2 text-success mr-3"></i> Activate Terminal </a>
                                    @endif
                                @endcan
                            @endcan

                        </div>
                    </div>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>