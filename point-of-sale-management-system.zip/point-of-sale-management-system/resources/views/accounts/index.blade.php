@extends('layouts.dashboard' , [ 'title' => 'Accounts'  ,'active' => 'accounts' ])
@section('content')
    <div class="container py-5">
        <div class="py-3">
            <h1 class="mb-0">Accounts</h1>
        </div>
        <form class="page-header row px-0" method="GET">
            {{--<div class="col-lg-2 pl-0">--}}
            {{--<a href="" class="btn btn-primary btn-block">View Statics</a>--}}
            {{--</div>--}}
            <div class="input-group col-lg-6 ml-auto">
                <input type="text" class="form-control" name="search" placeholder="Search" value="{{ old('search' , request('search')) }}">
                <span class="input-group-append">
                    <button class="btn btn-primary" type="submit">Search</button>
                </span>
            </div>
            @can('input' , \App\models\system\Input::class )
                <div class="col-lg-2 pr-0">
                    <a href="/accounts/add" class="btn btn-primary btn-block"><i class="fe fe-plus mr-2"></i> Add Account </a>
                </div>
            @endcan
        </form>
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="card border-0 bg-transparent">
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-icon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    <div class="table-responsive">
                        <table style="border-collapse:separate; border-spacing:0 15px;"
                               class="table table-hover table-outline table-vcenter text-nowrap card-table table-borderless">
                            <thead class="text-dark">
                            <tr>
                                <th>Info</th>
                                <th>Customer</th>
                                <th>Account</th>
                                <th class="text-center"><i class="fe fe-info"></i></th>
                                {{--<th class="text-center"><i class="fe fe-settings"></i></th>--}}
                            </tr>
                            </thead>
                            <tbody>

                            @foreach( $accounts as $account )

                                <tr class="bg-white shadow-sm shadow-lg--hover">
                                    <td>
                                        <div><span class="text-muted">Account No : </span>{{ $account->account }}</div>
                                        <div><span class="text-muted">Branch : </span>{{ $account->branch_code }}</div>
                                        <div><span class="text-muted">Created : </span>{{ $account->created_at }}</div>
                                    </td>
                                    <td>
                                        <div><span class="text-muted">Name : </span>{{ $account->customer->full_name }}</div>
                                        <div><span class="text-muted">Phone : </span>{{ $account->customer->phone }}</div>
                                        <div><span class="text-muted">ID : </span>{{ $account->customer->id }}</div>
                                    </td>
                                    <td>
                                        <div><span class="text-muted">Name:  </span> {{ $account->branch->name }} </div>
                                        <div><span class="text-muted">Short Name :  </span> {{ $account->branch->short_name }} </div>
                                        <div><span class="text-muted">Code :  </span> {{ $account->branch->branch_code }} </div>
                                    </td>

                                    <td class="text-center">
                                        <div class="mb-1"><a href="/account/{{ $account->id }}/view" class="card-link"><i class="fe fe-eye mr-2"></i>View account</a></div>
                                        @can('input' , \App\models\system\Input::class )
                                            <div class="mb-1"><a href="/requests/change-account/create?old={{ $account->account }}" class="card-link"><i class="fe fe-link mr-2"></i>Change account</a></div>
                                            <div class="mb-1"><a href="/requests/new-terminal/create?account={{ $account->account }}" class="card-link text-success"><i class="fe fe-git-pull-request mr-3"></i>Request Terminal</a></div>
                                            <div class="mb-1"><a href="/account/{{ $account->id }}/delete" class="card-link text-danger"><i class="fe fe-trash-2 mr-2"></i>Delete</a></div>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer row justify-content-center col-lg-12 border-0 bg-white pt-5 m-0">
                        {{ $accounts->appends(request()->query())->links()  }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
