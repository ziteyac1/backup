@extends('layouts.dashboard' , [ 'title' => 'Quick Panel'  ,'active' => 'quick-panel' ])
@section('content')
<div class="container">
    <div class="page-header">
        <h1 class="page-title">
            Quick Panel
        </h1>
    </div>
</div>
@endsection
