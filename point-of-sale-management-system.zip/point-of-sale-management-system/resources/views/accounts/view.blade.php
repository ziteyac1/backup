@extends('layouts.dashboard' ,[ 'title' => 'Accounts'  ,'active' => 'accounts' ])
@section('content')
    <div class="container">
        <div class="row py-5">
            <div class="col-lg-4">
                @include('includes.account-info' ,['account' => $account ])
                @include('includes.customer-info' ,['customer' => $account->customer ])
            </div>
            <div class="col-lg-8">
                @include('includes.terminal-list' , [ 'terminals'=> $account->terminals_limit , 'ref'=> $account , 'name'=> 'account'])
            </div>
        </div>
    </div>
@endsection
