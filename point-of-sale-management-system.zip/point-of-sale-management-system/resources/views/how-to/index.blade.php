@extends('layouts.dashboard' , [ 'title' => 'Documentation'  ,'active' => 'documentation' ])
@section('content')

    <div class="container py-5">
        <div class="page-header">
            <h1 class="page-title">
                Documentation and Guide
            </h1>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="card">
                    <form class="card-header">
                        <h3 class="card-title">How To</h3>
                        <div class="card-options">
                            <div class="input-group">
                                <input type="text" value="{{ request('search') }}" class="form-control form-control-sm" placeholder="Search something..." name="search">
                                <span class="input-group-btn ml-2">
                                    <button class="btn btn-sm btn-primary" type="submit">
                                      <span class="fe fe-search"></span>
                                    </button>
                                 </span>
                            </div>
                            @can('view',\App\User::class)
                                <a href="/how-to/add" class="btn btn-sm btn-primary px-7 ml-3 text-white"><i class="fe fe-plus-circle mr-3"></i></a>
                            @endcan
                        </div>
                    </form>
                    <table class="table card-table table-striped table-vcenter">
                        <thead class="">
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Type</th>
                            <th>Section</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($guides as $guide)
                            <tr>
                                <td>{{ $guide->id }}</td>
                                <td>{{ $guide->name }}</td>
                                <td>{{ $guide->description }}</td>
                                <td>{{ $guide->type }}</td>
                                <td>{{ $guide->section }}</td>
                                <td class="text-center">
                                    <a href="/how-to/view/{{ $guide->id }}" class="card-link"><i class="fe fe-eye mr-2"></i>View</a>
                                    @can('view',\App\User::class)
                                        <a href="/how-to/edit/{{ $guide->id }}" class="card-link"><i class="fe fe-edit-3 mr-2"></i>Edit</a>
                                        <a href="/how-to/delete/{{ $guide->id }}" class="card-link text-danger"><i class="fe fe-trash-2 mr-2"></i>Delete</a>
                                    @endcan
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    <div class="card-footer">
                        {{ $guides->appends(request()->query())->links()  }}
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('scripts')

@endsection

