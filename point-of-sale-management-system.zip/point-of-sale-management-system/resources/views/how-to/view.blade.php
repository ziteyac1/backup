@extends('layouts.dashboard' , [ 'title' => 'Documentation'  ,'active' => 'documentation' ])
@section('content')
    <div class="container">
        <div class="row py-5 justify-content-center">
            <div class="col-lg-12">
                @if(session()->has('message'))
                    <div class="card-alert alert alert-icon alert-success">
                        <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                    </div>
                @endif
            </div>
            <div class="col-lg-7">
                <div class="card">
                    <div class="card-header">
                        {{ $howto->name }} - {{ $howto->description }}
                    </div>
                    <div class="card-body">
                        {!! $howto->content !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


