@extends('layouts.dashboard' , [ 'title' => 'Documentation'  ,'active' => 'documentation' ])
@section('content')
    <div class="container p-5">

        <div class="row justify-content-center">
            <div class="col-lg-8">
                <form method="POST" action="/how-to/edit/{{ $howto->id }}" class="card">
                    <div class="card-header">
                        <h1 class="card-title">Edit Documentation - {{ $howto->name }}</h1>
                    </div>
                    @csrf
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-iscon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <label for="name" class="">Name</label>
                                    <input id="name" type="text" class="form-control rounded-0 {{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ old('name' , $howto->name ) }}" required autofocus>
                                    @if ($errors->has('name'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <label for="name" class="">Type</label>
                                    <select id="name" type="text" class="form-control  rounded-0 {{ $errors->has('type') ? ' is-invalid' : '' }}" name="type" value="{{ old('type', $howto->type) }}" required autofocus>
                                        <option value="">Choose Type </option>
                                        <option value="Portal Guide" {{ old('type', $howto->type) === 'Portal Guide' ? 'selected' : ''}} >Portal Guide </option>
                                        <option value="POS Machines and Terminals Guide" {{ old('type', $howto->type) === 'POS Machines and Terminals Guide' ? 'selected' : '' }} >POS Machines and Terminals Guide</option>
                                        <option value="Other" {{ old('type', $howto->type)  === 'Other' ? 'selected' : '' }}>Other</option>
                                    </select>
                                    @if ($errors->has('type'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('type') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <label for="name" class="">Section</label>
                                    <select id="section" type="text" class="form-control  rounded-0 {{ $errors->has('section') ? ' is-invalid' : '' }}" name="section" value="{{ old('section' , $howto->section) }}" required autofocus>
                                        <option value="">Choose Section</option>
                                        <option value="Home" {{ old('section' , $howto->section) === 'Home' ? 'selected' : '' }}>Home</option>
                                        <option value="Customers"  {{ old('section' , $howto->section) === 'Customers' ? 'selected' : '' }}>Customers</option>
                                        <option value="Accounts"  {{ old('section' , $howto->section) === 'Accounts' ? 'selected' : '' }}>Accounts</option>
                                        <option value="Terminals"  {{ old('section' , $howto->section) === 'Terminals' ? 'selected' : '' }}>Terminals</option>
                                        <option value="Tellers"  {{ old('section' , $howto->section) === 'Tellers' ? 'selected' : '' }}>Tellers</option>
                                        <option value="Transactions"  {{ old('section' , $howto->section) === 'Transactions' ? 'selected' : '' }}>Transactions</option>
                                        <option value="POS Machines"  {{ old('section' , $howto->section) === 'POS Machines' ? 'selected' : '' }}>POS Machines</option>
                                        <option value="Logs"  {{ old('section' , $howto->section) === 'Logs' ? 'selected' : '' }}>Logs</option>
                                        <option value="Transfer Batches"  {{ old('section' , $howto->section) === 'Transfer Batches' ? 'selected' : '' }}>Transfer Batches</option>
                                        <option value="POS Transfers"  {{ old('section' , $howto->section) === 'POS Transfers' ? 'selected' : '' }}>POS Transfers</option>
                                        <option value="Requests"  {{ old('section' , $howto->section) === 'Requests' ? 'selected' : '' }}>Requests</option>
                                        <option value="Reports"  {{ old('section' , $howto->section) === 'Home' ? 'selected' : '' }}>Reports</option>
                                        <option value="Users"  {{ old('section' , $howto->section) === 'Reports' ? 'selected' : '' }}>Users</option>
                                        <option value="Other"  {{ old('section' , $howto->section) === 'Other' ? 'selected' : '' }}>Other</option>
                                    </select>
                                    @if ($errors->has('section'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('section') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="name" class="">Description</label>
                                    <textarea id="name" type="text" class="form-control  rounded-0 {{ $errors->has('description') ? ' is-invalid' : '' }}" name="description" value="{{ old('description' , $howto->description ) }}" required autofocus>{{ old('description' , $howto->description ) }}</textarea>
                                    @if ($errors->has('description'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('description') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="name" class="">Content</label>
                                    <textarea name="content" class="form-control summernote"></textarea>
                                    @if ($errors->has('content'))
                                        <span class="text-danger small" role="alert">
                                        <strong>{{ $errors->first('content') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-center">
                        <div class="col-lg-4">
                            <button type="submit" class="btn btn-primary btn-block shadow-sm border-0 rounded-0">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('css')
    <link href="{{ asset('vendor/wysiwyg/summernote-lite.css') }}" rel="stylesheet">
@endsection

@section('scripts')
    <script src="{{ asset('vendor/wysiwyg/jquery.js') }}"></script>
    <script src="{{ asset('vendor/wysiwyg/summernote-lite.js') }}"></script>
    <script>
        $(document).ready(function() {

            $('.summernote').summernote({
                height: 400,   //set editable area's height
                tabsize: 2,
                codemirror: { // codemirror options
                    theme: 'paper'
                }
            });

            var content = {!! json_encode( $howto->content ) !!};
            //set the content to summernote using `code` attribute.
            $('.summernote').summernote('code', content);
        });

    </script>

@endsection