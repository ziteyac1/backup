@extends('layouts.dashboard' , [ 'title' => 'Terminals'  ,'active' => 'terminals' ])
@section('content')
    <div class="container py-5">
        <div class="py-3">
            <h1 class="mb-0">Terminals</h1>
        </div>
        <form class="page-header row px-0" method="GET">
            {{--<div class="col-lg-2 pl-0">--}}
            {{--<a href="" class="btn btn-primary btn-block">View Statics</a>--}}
            {{--</div>--}}
            @can('input' , \App\models\system\Input::class)
                <div class="col-lg-2 pr-0 pl-0">
                    <a href="/terminals/give-customer" class="btn btn-primary btn-block"><i class="fe fe-user mr-2"></i>Issue Terminal</a>
                </div>
            @endcan
            @can('input' , \App\models\system\Input::class)
                <div class="col-lg-2 pr-0">
                    <a href="/terminals/return-terminal" class="btn btn-primary btn-block"><i class="fe fe-git-pull-request mr-2"></i>Return Terminal</a>
                </div>
            @endcan

            <div class="input-group col-lg-6 ml-auto">
                <input type="text" class="form-control" name="search" placeholder="Search" value="{{ old('search' , request('search')) }}">
                <span class="input-group-append">
                    <button class="btn btn-primary" type="submit">Search</button>
                </span>
            </div>

        </form>
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="card border-0 bg-transparent">
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-icon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    <div class="table-responsive">
                        <table style="border-collapse:separate; border-spacing:0 15px;"
                               class="table table-hover table-outline table-vcenter text-nowrap card-table table-borderless">
                            <thead class="text-dark">
                            <tr>
                                <th>Info</th>
                                <th>Info</th>
                                <th>Account</th>
                                <th class="text-center"><i class="fe fe-info"></i></th>
                                {{--<th class="text-center"><i class="fe fe-settings"></i></th>--}}
                            </tr>
                            </thead>
                            <tbody>

                            @foreach( $terminals as $terminal )

                                <tr class="bg-white shadow-sm shadow-lg--hover">
                                    <td class="border-left border-lg {{ $terminal->active  ? 'border-success' : 'border-danger' }} ">
                                        <div><span class="text-muted">Trade Name : </span>{{ $terminal->trade_name }}</div>
                                        <div><span class="text-muted">Location : </span>{{ $terminal->location }}</div>
                                        <div><span class="text-muted">Serial Number : </span>{{ $terminal->serial_number }}</div>
                                        <div><span class="text-muted">Last Tran : </span>{{ \App\core\Helper::getLastTransaction($terminal->terminal_id) }}</div>
                                    </td>
                                    <td>
                                        <div><span class="text-muted">ID : </span>{{ $terminal->terminal_id }}</div>
                                        <div><span class="text-muted">Model : </span>{{ $terminal->model }}</div>
                                        <div><span class="text-muted">Term type : </span>{{ $terminal->override_term_type }}</div>
                                        <div><span class="text-muted">Created : </span>{{ $terminal->created_at }}</div>
                                    </td>
                                    <td>
                                        <div><span class="text-muted">Account : </span>{{ $terminal->account->account }}</div>
                                        <div><span class="text-muted">Branch Name : </span>{{ $terminal->account->branch->name }}</div>
                                        <div><span class="text-muted">Branch Code : </span>{{ $terminal->account->branch->branch_code  }}</div>
                                        <div><span class="text-muted">Customer Name :  </span> {{ $terminal->account->customer->full_name }} </div>
                                    </td>

                                    <td class="text-center">
                                        <div class="mb-1"><a href="/terminal/{{ $terminal->id }}/view" class="card-link"><i class="fe fe-eye mr-2"></i>View More</a></div>
                                        @can('input' , \App\models\system\Input::class )
                                            <div class="mb-1"><a href="/requests/re-allocation/create?terminal={{ $terminal->terminal_id }}" class="card-link text-success"><i class="fe fe-share-2 mr-3"></i>Reallocation</a></div>
                                            <div class="mb-1"><a href="/requests/change-details/create?account={{ $terminal->account_id }}&terminal={{ $terminal->terminal_id }}&trade_name={{ $terminal->trade_name }}&location={{ $terminal->location }}" class="card-link text-success"><i class="fe fe-edit-3 mr-3"></i>Change Details </a></div>
                                            @can('deactivate' , $terminal )
                                                @if($terminal->active)
                                                    <a href="/terminal/{{ $terminal->id }}/deactivate" class="dropdown-item text-danger"><i class="dropdown-icon fe fe-zap-off mr-2 text-danger mr-3"></i> De-activate </a>
                                                @else
                                                    <a href="/terminal/{{ $terminal->id }}/activate" class="dropdown-item text-success"><i class="dropdown-icon fe fe-zap mr-2 text-success mr-3"></i> Activate  </a>
                                                @endif
                                            @endcan
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer row justify-content-center col-lg-12 border-0 bg-white pt-5 m-0">
                        {{ $terminals->appends(request()->query())->links()  }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
