@extends('layouts.dashboard' , [ 'title' => 'Terminals - Add '  ,'active' => 'terminals' ])
@section('content')
    <div class="container p-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form method="POST" action="/terminals/give-customer" class="card rounded-0 border-0 shadow-lg">
                    @csrf
                    <div class="card-body">
                        <h1 class="card-title text-center">Issue Terminal</h1>
                    </div>
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-icon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <h6 class="text-muted">Terminal ID</h6>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="terminal" class="">Terminal</label>
                                    <input id="terminal" type="text" class="form-control {{ $errors->has('terminal') ? ' is-invalid' : '' }}" name="terminal" value="{{ old('terminal', request()->get('terminal')) }}" required autofocus>
                                    @if ($errors->has('terminal'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('terminal') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="serial_number" class="">Serial Number</label>
                                    <input id="serial_number" type="text" class="form-control {{ $errors->has('serial_number') ? ' is-invalid' : '' }}" name="serial_number" value="{{ old('serial_number', request()->get('serial_number')) }}" required autofocus>
                                    @if ($errors->has('serial_number'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('serial_number') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-12 mb-4">
                                <h6 class="text-muted">Check List</h6>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="selectgroup-item">
                                        <input type="checkbox" name="charger" value="1" class="selectgroup-input" >
                                        <span class="selectgroup-button rounded-0 text-uppercase"><strong>Charger</strong></span>
                                    </label>
                                    <label class="selectgroup-item">
                                        <input type="checkbox" name="battery" value="1" class="selectgroup-input" >
                                        <span class="selectgroup-button rounded-0 text-uppercase"><strong>Battery</strong></span>
                                    </label>
                                    <label class="selectgroup-item">
                                        <input type="checkbox" name="line" value="1" class="selectgroup-input" >
                                        <span class="selectgroup-button rounded-0 text-uppercase"><strong>Line</strong></span>
                                    </label>
                                    <label class="selectgroup-item">
                                        <input type="checkbox" name="card" value="1" class="selectgroup-input" >
                                        <span class="selectgroup-button rounded-0 text-uppercase"><strong>Teller card</strong></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-center">
                        <div class="col-lg-8">
                            <button type="submit" class="btn btn-primary btn-block">Issue Terminal</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
