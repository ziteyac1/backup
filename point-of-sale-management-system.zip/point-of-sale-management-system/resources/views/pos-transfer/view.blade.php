@extends('layouts.dashboard' , [ 'title' => 'POS Transfer'  ,'active' => 'pos-transfer' ])
@section('content')
    <div class="container">
        <div class="row justify-content-center py-6">
            <div class="col-lg-4">
                <div class="card bg-transparent border-0 rounded-0 shadow-none">
                    <div class="card-header">
                        <h5 class="card-title">POS Transfer Info</h5>
                        <div class="card-options">

                            <a href="/pos-transfer/{{ $pos->id }}/history" class="btn btn-secondary btn-sm ml-2 ">History</a>

                            @can('check', $pos )
                                <a href="/pos-transfer/{{ $pos->id }}/check" class="btn btn-secondary btn-sm ml-2">Check</a>
                            @endcan
                            @can('send', $pos )
                            <a href="/pos-transfer/{{ $pos->id }}/send" class="btn btn-secondary btn-sm ml-2">Send</a>
                            @endcan
                            @can('receive', $pos )
                            <a href="/pos-transfer/{{ $pos->id }}/receive" class="btn btn-secondary btn-sm ml-2">Confirm Receive</a>
                            @endcan
                            @can('edit', $pos )
                            <a href="/pos-transfer/{{ $pos->id }}/edit" class="btn btn-secondary btn-sm ml-2">Edit</a>
                            @endcan
                        </div>
                    </div>
                    <table class="card-table table bg-white shadow-sm table-hover">
                        <tbody>
                        <tr>
                            <td class="small"><strong>  ID :</strong></td>
                            <td class="text-right">{{ $pos->id }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong> Terminal :</strong></td>
                            <td class="text-right">{{ $pos->terminal }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong> Asset Code :</strong></td>
                            <td class="text-right">{{ $pos->asset_code }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong> Serial Number :</strong></td>
                            <td class="text-right">{{ $pos->serial_number }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Batch ID :</strong></td>
                            <td class="text-right">{{ $pos->batch_id }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Received :</strong></td>
                            <td class="text-right">{{ $pos->received }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Checked :</strong></td>
                            <td class="text-right">{{ $pos->checked }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Created :</strong></td>
                            <td class="text-right">{{ $pos->created_at }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Updated :</strong></td>
                            <td class="text-right">{{ $pos->updated_at->diffForHumans() }}</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                @include('includes.pos-info' , [ 'machine' => $pos->pos ])
            </div>
            <div class="col-lg-8">
                <div class="card bg-transparent border-0 rounded-0 shadow-none">
                    <div class="card-header">
                        <h3 class="card-title">Logs</h3>
                    </div>
                    <table class="card-table table table-vcenter table-hover">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>LOG</th>
                            <th>LEVEL</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody class="bg-white shadow-sm">
                        @foreach( $pos->pos->logs as $log )
                            <tr class="">
                                <td>
                                    <div><span class="text-muted">Log ID: </span>{{ $log->id }}</div>
                                </td>
                                <td>
                                    <div><span class="text-muted">Log : </span>{{ $log->log }}</div>
                                    <div><span class="text-muted">Created : </span>{{ $log->created_at }}</div>
                                </td>
                                <td>
                                    <div><span class="text-muted">Level : </span>{{ $log->level }}</div>
                                    <div><span class="text-muted">Updated : </span>{{ $log->updated_at->diffForHumans() }}</div>
                                </td>
                                <td class="text-center">
                                    <div class="mb-1"><a href="/pos-log/{{ $log->id }}/view" class="card-link"><i class="fe fe-eye mr-2"></i>View</a></div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
