@extends('layouts.dashboard' , [ 'title' => 'POS Transfer'  ,'active' => 'pos-transfer' ])
@section('content')
<div class="container">
    <div class="page-header">
        <h1 class="page-title">
            Quick Panel
        </h1>
    </div>
</div>
@endsection
