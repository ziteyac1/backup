@extends('layouts.dashboard' , [ 'title' => 'POS Transfer'  ,'active' => 'pos-transfer' ])
@section('content')
    <div class="container py-5">
        <div class="py-3">
            <h1 class="mb-0">POS Transfer</h1>
        </div>
        <form class="page-header row px-0" method="GET">
            {{--<div class="col-lg-2 pl-0">--}}
            {{--<a href="" class="btn btn-primary btn-block">View Statics</a>--}}
            {{--</div>--}}
            <div class="input-group col-lg-6 ml-auto">
                <input type="text" class="form-control" name="search" placeholder="Search" value="{{ old('search' , request('search')) }}">
                <span class="input-group-append">
                    <button class="btn btn-primary" type="submit">Search</button>
                </span>
            </div>
            <div class="col-lg-2 pr-0">
                <a href="/pos-transfers/add" class="btn btn-primary btn-block"><i class="fe fe-plus mr-2"></i> POS Transfer </a>
            </div>
        </form>
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="card border-0 bg-transparent">
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-icon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    <div class="table-responsive">
                        <table style="border-collapse:separate; border-spacing:0 15px;"
                               class="table table-hover table-outline table-vcenter text-nowrap card-table table-borderless">
                            <thead class="text-dark">
                            <tr>
                                <th>Info</th>
                                <th>Batch Info</th>
                                <th>Receiver</th>
                                <th class="text-center">Info</th>
                                <th class="text-center"><i class="fe fe-info"></i></th>
                            </tr>
                            </thead>
                            <tbody>

                            @foreach( $pos_machines as $pos_machine )

                                <tr class="bg-white shadow-sm shadow-lg--hover">
                                    <td class="border-left border-lg {{ $pos_machine->received  ? 'border-success' : 'border-warning' }} ">
                                        <div><span class="text-muted">Serial : </span>{{ $pos_machine->serial_number }}</div>
                                        <div><span class="text-muted">Terminal : </span>{{ $pos_machine->terminal }}</div>
                                        <div><span class="text-muted">Asset Code : </span>{{ $pos_machine->asset_code }}</div>
                                        <div><span class="text-muted">Created : </span>{{ $pos_machine->created_at }}</div>
                                    </td>
                                    <td>
                                        <div><span class="text-muted">Bath ID : </span>{{ $pos_machine->batch->id }}</div>
                                        <div><span class="text-muted">To : </span>{{ $pos_machine->batch->to }}</div>
                                        <div><span class="text-muted">Branch : </span>{{ $pos_machine->batch->branch->name }}</div>
                                        <div><span class="text-muted">Transport : </span>{{ $pos_machine->batch->transport }}</div>

                                    </td>
                                    <td>
                                        @if($pos_machine->batch->receiver)
                                            <div><span class="text-muted">Bath ID : </span>{{ $pos_machine->batch->receiver->name }}</div>
                                            <div><span class="text-muted">To : </span>{{ $pos_machine->batch->receiver->email }}</div>
                                            <div><span class="text-muted">Branch : </span>{{ $batch->receiver->branch_name->name }}</div>
                                        @else
                                            <div><span class="px-2 border border-info text-info small">Not received</span></div>
                                        @endif
                                    </td>
                                    <td class="text-center">
                                        @if($pos_machine->checked)
                                            <div class="mb-1"><span class="px-2 border border-success text-success small">Checked</span></div>
                                        @else
                                            <div class="mb-1"><span class="px-2 border border-danger text-danger small">Not Checked</span></div>
                                        @endif

                                        @if($pos_machine->recieved)
                                            <div><span class="px-2 border border-success text-success small">Received</span></div>
                                        @else
                                            <div><span class="px-2 border border-danger text-danger small">Not Received</span></div>
                                        @endif
                                    </td>

                                    <td class="text-center">
                                        <div class="item-action dropdown">
                                            <a href="javascript:void(0)" data-toggle="dropdown" class="icon" aria-expanded="false"><i class="fe fe-more-vertical"></i></a>
                                            <div class="dropdown-menu dropdown-menu-right text-center" x-placement="bottom-end" style="position: absolute; transform: translate3d(15px, 20px, 0px); top: 0px; left: 0px; will-change: transform;min-width: 5rem">

                                                <a href="/pos-transfer/{{ $pos_machine->id }}/view" class="dropdown-item"><i class="dropdown-icon fe fe-eye mr-2"></i>View</a>
                                                @can('check' , $pos_machine )
                                                    <a href="/pos-transfer/{{ $pos_machine->id }}/check" class="dropdown-item"><i class="dropdown-icon fe fe-check mr-2"></i>Check</a>
                                                @endcan
                                                @can('receive' , $pos_machine )
                                                    <a href="/pos-transfer/{{ $pos_machine->id }}/receive" class="dropdown-item"><i class="dropdown-icon fe fe-check-square mr-2"></i>Confirm Receive</a>
                                                @endcan
                                                @can('edit' , $pos_machine )
                                                    <a href="/pos-transfer/{{ $pos_machine->id }}/edit" class="dropdown-item"><i class="dropdown-icon fe fe-edit-2 mr-2"></i>Edit</a>
                                                @endcan
                                                @can('delete' , $pos_machine )
                                                    <a href="/pos-transfer/{{ $pos_machine->id }}/delete" class="dropdown-item"><i class="dropdown-icon fe fe-trash-2 mr-2"></i>Delete</a>
                                                @endcan
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer row justify-content-center col-lg-12 border-0 bg-white pt-5 m-0">
                        {{ $pos_machines->appends(request()->query())->links()  }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
