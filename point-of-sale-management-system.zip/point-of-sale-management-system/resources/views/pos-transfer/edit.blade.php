@extends('layouts.dashboard' , [ 'title' => 'POS Transfer'  ,'active' => 'pos-transfer' ])
@section('content')
    <div class="container p-5">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <form method="POST" action="/pos-transfer/{{ $pos->id }}/edit" class="card rounded-0 border-0 shadow-lg">
                    @csrf
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-icon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="batch" class="">Batch ID</label>
                                    <input id="batch" type="text" class="form-control {{ $errors->has('batch') ? ' is-invalid' : '' }}" name="batch" value="{{ old('batch', $pos->batch_id ) }}" required autofocus>
                                    @if ($errors->has('batch'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('batch') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="terminal" class="">Terminal ID</label>
                                    <input id="terminal" type="text" class="form-control {{ $errors->has('terminal') ? ' is-invalid' : '' }}" name="terminal" value="{{ old('terminal', $pos->terminal ) }}" required autofocus>
                                    @if ($errors->has('terminal'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('terminal') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="serial_number" class="">Serial Number</label>
                                    <input id="serial_number" type="text" class="form-control {{ $errors->has('serial_number') ? ' is-invalid' : '' }}" name="serial_number" value="{{ old('serial_number', $pos->serial_number ) }}" required autofocus>
                                    @if ($errors->has('serial_number'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('serial_number') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="asset_code" class="">Asset Code</label>
                                    <input id="asset_code" type="text" class="form-control {{ $errors->has('asset_code') ? ' is-invalid' : '' }}" name="asset_code" value="{{ old('asset_code', $pos->asset_code) }}" required autofocus>
                                    @if ($errors->has('asset_code'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('asset_code') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-center">
                        <div class="col-lg-6">
                            <button type="submit" class="btn btn-primary btn-block">Update POS Transfer</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
