@extends('layouts.dashboard' , [ 'title' => 'Tellers '  ,'active' => 'tellers-create' ])
@section('content')
    <div class="container p-5">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <form method="POST" action="/tellers/store" class="card rounded-0 border-0 shadow-lg">
                    @csrf
                    <div class="card-body">
                        <h1 class="card-title">Add Teller</h1>
                    </div>
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-icon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="card" class="">Card Number</label>
                                    <input id="card" type="text" class="form-control {{ $errors->has('card') ? ' is-invalid' : '' }}" name="card" value="{{ old('card', request()->get('card')) }}" required autofocus>
                                    @if ($errors->has('card'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('card') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="name" class="">Teller Name</label>
                                    <input id="name" type="text" class="form-control {{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ old('name', request()->get('name')) }}" required autofocus>
                                    @if ($errors->has('name'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-center">
                        <div class="col-lg-6">
                            <button type="submit" class="btn btn-primary btn-block">Create Teller</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
