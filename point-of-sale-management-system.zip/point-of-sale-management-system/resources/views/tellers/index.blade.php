@extends('layouts.dashboard' , [ 'title' => 'Tellers'  ,'active' => 'tellers' ])
@section('content')
    <div class="container py-5">
        <div class="py-3">
            <h1 class="mb-0">Tellers</h1>
        </div>
        <form class="page-header row px-0" method="GET">
            {{--<div class="col-lg-2 pl-0">--}}
            {{--<a href="" class="btn btn-primary btn-block">View Statics</a>--}}
            {{--</div>--}}
            <div class="input-group col-lg-6 ml-auto">
                <input type="text" class="form-control" name="search" placeholder="Search" value="{{ old('search' , request('search')) }}">
                <span class="input-group-append">
                    <button class="btn btn-primary" type="submit">Search</button>
                </span>
            </div>
            @can('input' , \App\models\system\Input::class )
                <div class="col-lg-2 pr-0">
                    <a href="/tellers/add" class="btn btn-primary btn-block"><i class="fe fe-plus mr-2"></i> Add Teller </a>
                </div>
            @endcan
        </form>
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="card border-0 bg-transparent">
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-icon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    <div class="table-responsive">
                        <table style="border-collapse:separate; border-spacing:0 15px;"
                               class="table table-hover table-outline table-vcenter text-nowrap card-table table-borderless">
                            <thead class="text-dark">
                            <tr>
                                <th>Info</th>
                                <th>Info</th>
                                <th>Terminal</th>
                                @can('input' , \App\models\system\Input::class )
                                    <th class="text-center"><i class="fe fe-info"></i></th>
                                @endcan
                                <th class="text-center"><i class="fe fe-info"></i></th>
                                {{--<th class="text-center"><i class="fe fe-settings"></i></th>--}}
                            </tr>
                            </thead>
                            <tbody>

                            @foreach( $tellers as $teller )

                                <tr class="bg-white shadow-sm shadow-lg--hover">
                                    <td>
                                        <div><span class="text-muted">Card : </span>{{ $teller->card_number }}</div>
                                        <div><span class="text-muted">Name : </span>{{ $teller->name }}</div>
                                    </td>
                                    <td>
                                        <div><span class="text-muted">Created : </span>{{ $teller->created_at }}</div>
                                        <div><span class="text-muted">Last Update : </span>{{ $teller->updated_at->diffForHumans() }}</div>
                                    </td>
                                    <td>
                                        @if($teller->terminal)
                                            <div><span class="text-muted">Terminal:  </span> {{ $teller->terminal->terminal_id }} </div>
                                            <div><span class="text-muted">Name:  </span> {{ $teller->terminal->trade_name }} </div>
                                            <div><span class="text-muted">Account:  </span> {{ $teller->terminal->account_id }} </div>
                                        @else
                                            <div class="mb-1"><span class="px-2 border border-info text-info small">No Terminal Linked</span></div>
                                        @endif
                                    </td>
                                    @can('input' , \App\models\system\Input::class )
                                        <td class="text-center">
                                            <div class="mb-1"><a href="/teller/{{ $teller->id }}/reset" class="card-link"><i class="fe fe-refresh-cw mr-2"></i>Reset</a></div>
                                        </td>
                                    @endcan
                                    <td class="text-center">
                                        <div class="mb-1"><a href="/teller/{{ $teller->id }}/view" class="card-link"><i class="fe fe-eye mr-2"></i>View</a></div>
                                        @can('input' , \App\models\system\Input::class )
                                            <div class="mb-1"><a href="/teller/{{ $teller->id }}/edit" class="card-link"><i class="fe fe-edit-2 mr-2"></i>Edit</a></div>
                                            @if($teller->terminal)
                                                <div class="mb-1"><a href="/terminal/{{ $teller->terminal->id }}/view" class="card-link text-success"><i class="fe fe-git-pull-request mr-2"></i>View Terminal</a></div>
                                            @endif

                                            @can('auth' , \App\models\Teller::class )
                                                @if($teller->supervisor)
                                                    <div class="mb-1"><a href="/teller/{{ $teller->id }}/remove-supervisor" class="card-link text-danger"><i class="fe fe-trash-2 mr-2"></i>Remove supervisor</a></div>
                                                @else
                                                    <div class="mb-1"><a href="/teller/{{ $teller->id }}/make-supervisor" class="card-link text-success"><i class="fe fe-check mr-2"></i>Make supervisor</a></div>
                                                @endif
                                            @endcan
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer row justify-content-center col-lg-12 border-0 bg-white pt-5 m-0">
                        {{ $tellers->appends(request()->query())->links()  }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
