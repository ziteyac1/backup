@extends('layouts.dashboard' ,  [ 'title' => 'POS Transfer Batches '  ,'active' => 'pos-batches' ])
@section('content')
    <div class="container py-7">
        <div class="py-3">
            <h1 class="mb-0">POS Transfer Batches</h1>
        </div>
        <form class="page-header row px-0" method="GET">
            {{--<div class="col-lg-2 pl-0">--}}
            {{--<a href="" class="btn btn-primary btn-block">View Statics</a>--}}
            {{--</div>--}}
            <div class="input-group col-lg-6 ml-auto">
                <input type="text" class="form-control" name="search" placeholder="Search" value="{{ old('search' , request('search')) }}">
                <span class="input-group-append">
                    <button class="btn btn-primary" type="submit">Search</button>
                </span>
            </div>
            <div class="col-lg-2 pr-0">
                <a href="/pos-transfer-batches/add" class="btn btn-primary btn-block"><i class="fe fe-plus mr-2"></i> POS Transfer Batch </a>
            </div>
        </form>
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="card border-0 bg-transparent">
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-icon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    <div class="table-responsive">
                        <table style="border-collapse:separate; border-spacing:0 15px;"
                               class="table table-hover table-outline table-vcenter text-nowrap card-table table-borderless">
                            <thead class="text-dark">
                            <tr>
                                <th>Info</th>
                                <th>Sender</th>
                                <th>Receiver</th>
                                <th class="text-center">Info</th>
                                <th class="text-center"><i class="fe fe-info"></i></th>
                                <th class="text-center"><i class="fe fe-info"></i></th>
                            </tr>
                            </thead>
                            <tbody>

                            @foreach( $batches as $batch )

                                <tr class="bg-white shadow-sm shadow-lg--hover">
                                    <td class="border-left border-lg {{ $batch->complete  ? 'border-success' : 'border-warning' }} ">
                                        <div><span class="text-muted">Bath ID : </span>{{ $batch->id }}</div>
                                        <div><span class="text-muted">To : </span>{{ $batch->to }}</div>
                                        <div><span class="text-muted">Branch : </span>{{ $batch->branch->name }}</div>
                                        <div><span class="text-muted">Created : </span>{{ $batch->created_at }}</div>
                                    </td>
                                    <td>
                                        <div><span class="text-muted">Name : </span>{{ $batch->sender->name }}</div>
                                        <div><span class="text-muted">To : </span>{{ $batch->sender->email }}</div>
                                        <div><span class="text-muted">Branch : </span>{{ $batch->sender->branch_name->name }}</div>
                                    </td>
                                    <td>
                                        @if($batch->receiver)
                                            <div><span class="text-muted">Bath ID : </span>{{ $batch->receiver->name }}</div>
                                            <div><span class="text-muted">To : </span>{{ $batch->receiver->email }}</div>
                                            <div><span class="text-muted">Branch : </span>{{ $batch->receiver->branch_name->name }}</div>
                                        @else
                                            <div><span class="px-2 border border-info text-info small">Not received</span></div>
                                        @endif
                                    </td>
                                    <td class="text-center">
                                        <div class="mb-1"><span class="text-muted">Number of POS : </span>{{ $batch->terminals_count }}</div>@if($batch->checked)
                                            <div class="mb-1"><span class="px-2 border border-success text-success small">Checked</span></div>
                                        @else
                                            <div class="mb-1"><span class="px-2 border border-danger text-danger small">Not Checked</span></div>
                                        @endif

                                        @if($batch->sent)
                                            <div><span class="px-2 border border-success text-success small">Sent</span></div>
                                        @else
                                            <div><span class="px-2 border border-danger text-danger small">Not Sent</span></div>
                                        @endif
                                    </td>
                                    <td class="text-center">
                                        <div class="mb-1"><a href="/pos-transfer-batch/{{ $batch->id }}/view" class="card-link text-info"><i class="fe fe-eye mr-2"></i>View Batch</a></div>
                                        @can('terminal' , $batch )
                                            <div class="mb-1"><a href="/pos-transfers/add?batch={{ $batch->id }}" class="card-link text-info"><i class="fe fe-plus-circle mr-2"></i>Terminal</a></div>
                                        @endcan
                                    </td>
                                    <td class="text-center">

                                        @can('check', $batch)
                                            <div class="mb-1"><a href="/pos-transfer-batch/{{ $batch->id }}/check" class="card-link text-success"><i class="fe fe-check mr-2"></i>Check</a></div>
                                        @endcan
                                        @can('send', $batch)
                                            <div class="mb-1"><a href="/pos-transfer-batch/{{ $batch->id }}/send" class="card-link"><i class="fe fe-send mr-2"></i>Send</a></div>
                                        @endcan
                                        @can('receive', $batch)
                                            <div class="mb-1"><a href="/pos-transfer-batch/{{ $batch->id }}/receive" class="card-link text-success"><i class="fe fe-check-square mr-2"></i>Confirm Receive</a></div>
                                        @endcan
                                        @can('edit', $batch)
                                            <div class="mb-1"><a href="/pos-transfer-batch/{{ $batch->id }}/edit" class="card-link"><i class="fe fe-edit-2 mr-2"></i>Edit</a></div>
                                        @endcan
                                        @can('delete', $batch)
                                            <div class="mb-1"><a href="/pos-transfer-batch/{{ $batch->id }}/delete" class="card-link text-danger"><i class="fe fe-trash-2 mr-2"></i>Delete</a></div>
                                        @endcan

                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer row justify-content-center col-lg-12 border-0 bg-white pt-5 m-0">
                        {{ $batches->appends(request()->query())->links()  }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
