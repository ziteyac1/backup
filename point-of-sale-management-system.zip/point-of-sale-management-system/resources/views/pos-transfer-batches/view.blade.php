@extends('layouts.dashboard' ,  [ 'title' => 'POS Transfer Batches '  ,'active' => 'pos-batches' ])
@section('content')
    <div class="container">
        <div class="row justify-content-center py-5">
            <div class="col-lg-12">
                @if(session()->has('message'))
                    <div class="card-alert alert alert-icon alert-success">
                        <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                    </div>
                @endif
            </div>
            <div class="col-lg-4">
                <div class="card bg-transparent border-0 rounded-0 shadow-none">
                    <div class="card-header">
                        <h5 class="card-title">POS Batch Info</h5>
                        <div class="card-options">
                            <a href="/pos-transfer-batch/{{ $batch->id }}/history" class="btn btn-secondary btn-sm ml-2 ">History</a>
                            @can('edit' , $batch )
                                <a href="/pos-transfer-batch/{{ $batch->id }}/edit" class="btn btn-secondary btn-sm ml-2 ">Edit</a>
                            @endcan
                            @can('check' , $batch )
                                <a href="/pos-transfer-batch/{{ $batch->id }}/check" class="btn btn-secondary btn-sm ml-2">Check</a>
                            @endcan
                            @can('send', $batch )
                                <a href="/pos-transfer-batch/{{ $batch->id }}/send" class="btn btn-secondary btn-sm ml-2">Send</a>
                            @endcan
                            @can('receive' , $batch)
                                <a href="/pos-transfer-batch/{{ $batch->id }}/receive" class="btn btn-secondary btn-sm ml-2"></i>Confirm Receive</a>
                            @endcan
                        </div>
                    </div>
                    <table class="card-table table bg-white shadow-sm table-hover">
                        <tbody>
                        <tr>
                            <td class="small"><strong> Batch ID :</strong></td>
                            <td class="text-right">{{ $batch->id }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong> Number of Terminals :</strong></td>
                            <td class="text-right">{{ $batch->terminals_count }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong> To Role :</strong></td>
                            <td class="text-right">{{ $batch->to }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong> To Branch :</strong></td>
                            <td class="text-right">{{ $batch->to_branch }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Transport :</strong></td>
                            <td class="text-right">{{ $batch->transport }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Branch :</strong></td>
                            <td class="text-right">{{ $batch->branch->name }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Sender  :</strong></td>
                            <td class="text-right">
                                <div>{{ $batch->sender->name }}</div>
                                <div>{{ $batch->sender->email }}</div>
                                <div>{{ $batch->sender->branch_name->name }}</div>
                            </td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Receiver  :</strong></td>
                            <td class="text-right">
                                @if($batch->receiver)
                                    <div>{{ $batch->receiver->name }}</div>
                                    <div>{{ $batch->receiver->email }}</div>
                                    <div>{{ $batch->receiver->branch_name->name }}</div>
                                @else
                                    <div><span class="px-2 border border-info text-info small">Not received</span></div>
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Created :</strong></td>
                            <td class="text-right">{{ $batch->created_at }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Updated :</strong></td>
                            <td class="text-right">{{ $batch->updated_at->diffForHumans() }}</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card bg-transparent border-0 rounded-0 shadow-none">
                    <div class="card-header">
                        <h3 class="card-title">Terminals</h3>
                        <div class="card-options">
                            <form>
                                <div class="input-group">
                                    <input type="text" class="form-control form-control-sm" value="{{ old('search', request()->get('search') ) }}" placeholder="Search something..." name="search">
                                    <span class="input-group-btn ml-2">
                                    <button class="btn btn-sm btn-secondary px-4" type="submit">
                                      <span class="fe fe-search"></span>
                                    </button>
                                  </span>
                                </div>
                            </form>
                            @can('terminal' , $batch )
                                <a href="/pos-transfers/add?batch={{ $batch->id }}" class="btn btn-secondary btn-sm ml-2 px-4">Add Terminal To Batch</a>
                            @endcan
                        </div>
                    </div>
                    <table class="card-table table table-vcenter">
                        <thead>
                        <tr>
                            <th>Info</th>
                            <th>Info</th>
                            <th></th>
                            <th></th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody class="bg-white">
                        @foreach( $pos_machines as $pos_machine )

                            <tr class="">
                                <td>
                                    <div><span class="text-muted">Serial : </span>{{ $pos_machine->serial_number }}</div>
                                    <div><span class="text-muted">Terminal : </span>{{ $pos_machine->terminal }}</div>
                                    <div><span class="text-muted">Asset Code : </span>{{ $pos_machine->asset_code }}</div>
                                </td>
                                <td>
                                    @if($pos_machine->batch->receiver)
                                        <div><span class="text-muted">Bath ID : </span>{{ $pos_machine->batch->receiver->name }}</div>
                                        <div><span class="text-muted">To : </span>{{ $pos_machine->batch->receiver->email }}</div>
                                        <div><span class="text-muted">Branch : </span>{{ $batch->receiver->branch_name->name }}</div>
                                    @else
                                        <div><span class="px-2 border border-info text-info small">Not received</span></div>
                                    @endif
                                </td>
                                <td class="text-center">
                                    @if($pos_machine->checked)
                                        <div class="mb-1"><span class="px-2 border border-success text-success small">Checked</span></div>
                                    @else
                                        <div class="mb-1"><span class="px-2 border border-danger text-danger small">Not Checked</span></div>
                                    @endif

                                    @if($pos_machine->received)
                                        <div><span class="px-2 border border-success text-success small">Received</span></div>
                                    @else
                                        <div><span class="px-2 border border-danger text-danger small">Not Received</span></div>
                                    @endif
                                </td>
                                <td class="text-center">
                                    <a href="/pos-transfer/{{ $pos_machine->id }}/view" class="dropdown-item"><i class="dropdown-icon fe fe-eye mr-2"></i>View</a>
                                    @can('edit' , $pos_machine )
                                        <a href="/pos-transfer/{{ $pos_machine->id }}/edit" class="dropdown-item"><i class="dropdown-icon fe fe-edit-2 mr-2"></i>Edit</a>
                                    @endcan
                                    @can('delete' , $pos_machine )
                                        <a href="/pos-transfer/{{ $pos_machine->id }}/delete" class="dropdown-item"><i class="dropdown-icon fe fe-trash-2 mr-2"></i>Delete</a>
                                    @endcan
                                </td>
                                <td class="text-center">
                                    @can('check' , $pos_machine )
                                        <a href="/pos-transfer/{{ $pos_machine->id }}/check" class="dropdown-item"><i class="dropdown-icon fe fe-check mr-2"></i>Check</a>
                                    @endcan
                                    @can('send' , $pos_machine )
                                        <a href="/pos-transfer/{{ $pos_machine->id }}/send" class="dropdown-item"><i class="dropdown-icon fe fe-send mr-2"></i>Send</a>
                                    @endcan
                                    @can('receive' , $pos_machine )
                                        <a href="/pos-transfer/{{ $pos_machine->id }}/receive" class="dropdown-item"><i class="dropdown-icon fe fe-check-square mr-2"></i>Confirm Receive</a>
                                    @endcan
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
