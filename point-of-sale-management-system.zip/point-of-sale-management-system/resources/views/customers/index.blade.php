@extends('layouts.dashboard' , [ 'title' => 'Customers'  ,'active' => 'customers' ])
@section('content')
    <div class="container py-5">
        <div class="page-header">
            <h1 class="page-title">
                Customers
            </h1>
        </div>
        <form class="page-header row px-0" method="GET">
            {{--<div class="col-lg-2 pl-0">--}}
            {{--<a href="" class="btn btn-primary btn-block">View Statics</a>--}}
            {{--</div>--}}
            <div class="input-group col-lg-6 ml-auto">
                <input type="text" class="form-control" name="search" placeholder="Search" value="{{ old('search' , request('search')) }}">
                <span class="input-group-append">
                    <button class="btn btn-primary" type="submit">Search</button>
                </span>
            </div>
            @can('input' , \App\models\system\Input::class )
                <div class="col-lg-2 pr-0">
                    <a href="/customers/add" class="btn btn-primary btn-block"><i class="fe fe-plus mr-2"></i> Add Customer </a>
                </div>
            @endcan
        </form>
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="card border-0 bg-transparent">
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-icon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    <div class="table-responsive">
                        <table style=" min-height: 20rem;border-collapse:separate; border-spacing:0 15px;"
                               class="table table-hover table-outline table-vcenter text-nowrap card-table table-borderless">
                            <thead class="text-dark">
                            <tr>
                                <th>Info</th>
                                <th>Contact</th>
                                <th>Details</th>
                                <th class="text-center"><i class="fe fe-info"></i></th>
                                {{--<th class="text-center"><i class="fe fe-settings"></i></th>--}}
                            </tr>
                            </thead>
                            <tbody>

                            @foreach( $customers as $customer )

                                <tr class="bg-white shadow-sm shadow-lg--hover">
                                    <td>
                                        <div><span class="text-muted">ID : </span>{{ $customer->id }}</div>
                                        <div><span class="text-muted">Name : </span>{{ $customer->name }}</div>
                                        <div><span class="text-muted">Last name : </span>{{ $customer->last_name }}</div>
                                    </td>
                                    <td>
                                        <div><span class="text-muted">Phone : </span>{{ $customer->phone }}</div>
                                        <div><span class="text-muted">Email : </span>{{ $customer->email }}</div>
                                        <div><span class="text-muted">Address : </span>{{ $customer->address }}</div>
                                    </td>
                                    <td>
                                        <div><span class="text-muted">Created :  </span> {{ $customer->created_at }} </div>
                                        <div><span class="text-muted">Last Update :  </span> {{ $customer->updated_at->diffForHumans() }} </div>
                                    </td>

                                    <td class="text-center">

                                        <div class="mb-1"><a href="/customer/{{ $customer->id }}/view" class="card-link"><i class="fe fe-eye mr-2"></i>View</a></div>

                                        @can('input' , \App\models\system\Input::class )
                                            <div class="mb-1"><a href="/accounts/add?customer={{ $customer->id }}" class="card-link"><i class="fe fe-plus-circle mr-2"></i>Account</a></div>
                                            <div class="mb-1"><a href="/requests/pos-hire/create?customer={{ $customer->id }}" class="card-link"><i class="fe fe-plus-circle mr-2"></i>POS Hire </a></div>
                                            <div class="mb-1"><a href="/requests/change-customer/create?name={{ $customer->name }}&last_name={{ $customer->last_name }}&phone={{ $customer->phone }}&email={{ $customer->email }}&address={{ $customer->address }}&id={{ $customer->id }}" class="card-link text-success"><i class="fe fe-edit-2 mr-2"></i>Edit</a></div>
                                        @endcan

                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer row justify-content-center col-lg-12 border-0 bg-white pt-5 m-0">
                        {{ $customers->appends(request()->query())->links()  }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

