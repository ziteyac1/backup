@extends('layouts.dashboard' , [ 'title' => 'Customer - View'  ,'active' => 'customers' ])
@section('content')
    <div class="container">
        <div class="row py-5">
            <div class="col-lg-12">
                @if(session()->has('message'))
                    <div class="card-alert alert alert-icon alert-success">
                        <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                    </div>
                @endif
            </div>
            <div class="col-lg-4">
                @include('includes.customer-info' ,['customer' => $customer ])
            </div>
            <div class="col-lg-8">
                <div class="card bg-transparent border-0 rounded-0 shadow-none">
                    <div class="card-header">
                        <h3 class="card-title">Accounts</h3>
                        @can('input' , \App\models\system\Input::class)
                            <div class="card-options">
                                <a href="/accounts/add?customer={{ $customer->id }}" class="btn btn-secondary btn-sm ml-2 px-5"><i class="fe fe-plus mr-3"></i>Add account</a>
                            </div>
                        @endcan

                    </div>
                    <table class="card-table table table-vcenter table-hover">
                        <thead>
                        <tr>
                            <th>Account</th>
                            <th>Branch</th>
                            <th class="text-center">Terminals</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody class="bg-white shadow-sm">
                        @foreach($customer->accounts as $account)
                            <tr>
                                <td>
                                    <div><span class="text-muted">ID : </span>{{ $account->account }}</div>
                                    <div><span class="text-muted">Created : </span>{{ $account->created_at }}</div>
                                </td>
                                <td>
                                    <div><span class="text-muted">Short Name : </span>{{ $account->branch->short_name }}</div>
                                    <div><span class="text-muted">Name : </span>{{ $account->branch->name }}</div>
                                </td>
                                <td class="text-center">
                                    {{ $account->terminals_count }}
                                </td>
                                <td>
                                    <div class="item-action dropdown">
                                        <a href="javascript:void(0)" data-toggle="dropdown" class="icon" aria-expanded="false"><i class="fe fe-more-vertical"></i></a>
                                        <div class="dropdown-menu dropdown-menu-right text-center" x-placement="bottom-end" style="position: absolute; transform: translate3d(15px, 20px, 0px); top: 0px; left: 0px; will-change: transform;">
                                            <a href="/account/{{ $account->id }}/view" class="dropdown-item"><i class="dropdown-icon fe fe-eye mr-3"></i> View Account</a>
                                            @can('input' , \App\models\system\Input::class)
                                                <a href="/requests/change-account/create?old={{ $account->account }}" class="dropdown-item"><i class="dropdown-icon fe fe-link mr-3"></i> Change Account </a>
                                                <a href="/requests/new-terminal/create?account={{ $account->account }}" class="dropdown-item"><i class="dropdown-icon fe fe-git-pull-request mr-3"></i> Request Terminal </a>
                                            @endcan
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
                @include('includes.terminal-list' , [ 'terminals'=> $customer->terminals_limit , 'ref'=> $customer , 'name'=> 'customer'])
            </div>
        </div>
    </div>
@endsection
