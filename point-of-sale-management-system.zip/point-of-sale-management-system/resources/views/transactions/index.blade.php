@extends('layouts.dashboard' , [ 'title' => 'Transaction'  ,'active' => 'transactions' ])
@section('content')
    <div class="container py-5">

        <form class="page-header row px-0" method="GET">
            
            {{--<div class="col-lg-2 pl-0">--}}
                {{--<a href="" class="btn btn-primary btn-block"><i class="fe fe-cpu mr-2"></i>View Overview</a>--}}
            {{--</div>--}}
            {{--<div class="col-lg-2 pl-0">--}}
                {{--<a href="" class="btn btn-primary btn-block"><i class="fe fe-file-plus mr-2"></i>Extract Reports</a>--}}
            {{--</div>--}}
            <div class="input-group col-lg-6 ml-auto">
                <input type="text" class="form-control" name="search" placeholder="Search" value="{{ old('search' , request('search')) }}">
                <span class="input-group-append">
                    <button class="btn btn-primary" type="submit">Search</button>
                </span>
            </div>
        </form>
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="card border-0 bg-transparent">
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-icon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    <div class="table-responsive">
                        <table style="border-collapse:separate; border-spacing:0 15px;"
                               class="table table-hover table-outline table-vcenter text-nowrap card-table table-borderless">
                            <thead class="text-dark">
                            <tr>
                                <th>Info</th>
                                <th>Info</th>
                                <th>Info</th>
                                <th>Info</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>

                            @foreach( $transactions as $transaction )

                                <tr class="bg-white shadow-sm shadow-lg--hover">
                                    <td>
                                        <div><span class="text-muted">Tran Number : </span>{{ $transaction->tran_nr }}</div>
                                        <div><span class="text-muted">State : </span>{{ $transaction->state }}</div>
                                        <div><span class="text-muted">Source Node : </span>{{ $transaction->source_node }}</div>
                                        <div><span class="text-muted">Sink Node : </span>{{ $transaction->source_node }}</div>
                                    </td>
                                    <td>
                                        <div><span class="text-muted">Amount : </span>{{ $transaction->amount }}</div>
                                        <div><span class="text-muted">Pan : </span>{{ $transaction->pan }}</div>
                                        <div><span class="text-muted">Expiry Date : </span>{{ $transaction->expiry_date }}</div>
                                        <div><span class="text-muted">RRN : </span>{{ $transaction->ret_ref_no }}</div>
                                    </td>
                                    <td>
                                        <div><span class="text-muted">Terminal ID : </span>{{ $transaction->card_acceptor_id }}</div>
                                        <div><span class="text-muted">Location : </span>{{ $transaction->card_acceptor_name_loc }}</div>
                                        <div><span class="text-muted">Account From : </span>{{ $transaction->account_id_1 }}</div>
                                    </td>
                                    <td>
                                        <div><span class="text-muted">Sponsor Bank : </span>{{ $transaction->sponsor_bank }}</div>
                                        <div><span class="text-muted">Date : </span>{{ $transaction->in_req }}</div>
                                        <div><span class="text-muted">Tran Type : </span>{{ $transaction->tran_type }}</div>
                                        <div><span class="text-muted">Rsp Code : </span>{{ $transaction->response_code }}</div>
                                    </td>
                                    <td class="text-center">
                                        <div class="item-action dropdown">
                                            <a href="javascript:void(0)" data-toggle="dropdown" class="icon" aria-expanded="false"><i class="fe fe-more-vertical"></i></a>
                                            <div class="dropdown-menu dropdown-menu-right text-center text-dark" x-placement="bottom-end" style="position: absolute; transform: translate3d(15px, 20px, 0px); top: 0px; left: 0px; will-change: transform;">
                                                <a href="/transaction/{{ $transaction->id }}/view" class="dropdown-item"><i class="dropdown-icon fe fe-eye mr-3"></i> View Transaction</a>
                                                <a href="/terminal/{{ $transaction->terminal->id }}/view" class="dropdown-item"><i class="dropdown-icon fe fe-git-pull-request mr-3"></i> View Terminal</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer row justify-content-center col-lg-12 border-0 bg-white pt-5 m-0">
                        {{ $transactions->appends(request()->query())->links()  }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
