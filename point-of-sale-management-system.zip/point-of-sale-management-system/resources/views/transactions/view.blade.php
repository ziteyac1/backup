@extends('layouts.dashboard' , [ 'title' => 'Transaction'  ,'active' => 'transactions' ])
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-4">
            @include('includes.terminal-info' ,['terminal' => $transaction->terminal ])
            @include('includes.account-info' ,['account' => $transaction->terminal->account ])
            @include('includes.customer-info' ,['customer' => $transaction->terminal->account->customer ])
        </div>
        <div class="col-lg-6">
            <div class="card bg-transparent border-0 rounded-0 shadow-none">
                <div class="card-header">
                    <h5 class="card-title">Transaction Info</h5>
                </div>
                <table class="card-table table bg-white shadow-sm table-hover text-wrap">
                    <tbody>
                    <tr>
                        <td class="small"><strong>Transaction ID :</strong></td>
                        <td class="text-right">{{ $transaction->id }}</td>
                    </tr>
                    <tr>
                        <td class="small"><strong>Postlion reference :</strong></td>
                        <td class="text-right">{{ $transaction->tran_nr }}</td>
                    </tr>
                    <tr>
                        <td class="small"><strong>State :</strong></td>
                        <td class="text-right">{{ $transaction->state }}</td>
                    </tr>
                    <tr>
                        <td class="small"><strong>Source Node :</strong></td>
                        <td class="text-right">{{ $transaction->source_node }}</td>
                    </tr>
                    <tr>
                        <td class="small"><strong>Amount  :</strong></td>
                        <td class="text-right">{{ $transaction->amount }}</td>
                    </tr>
                    <tr>
                        <td class="small"><strong>Sink Node :</strong></td>
                        <td class="text-right">{{ $transaction->sink_node }}</td>
                    </tr>
                    <tr>
                        <td class="small"><strong>Pan :</strong></td>
                        <td class="text-right">{{ $transaction->pan }}</td>
                    </tr>
                    <tr>
                        <td class="small"><strong>RRN :</strong></td>
                        <td class="text-right">{{ $transaction->ret_ref_no }}</td>
                    </tr>
                    <tr>
                        <td class="small"><strong>Terminal :</strong></td>
                        <td class="text-right">{{ $transaction->card_acceptor_id }}</td>
                    </tr>
                    <tr>
                        <td class="small"><strong>Account  :</strong></td>
                        <td class="text-right">{{ $transaction->account_id_1 }}</td>
                    </tr>
                    <tr>
                        <td class="small"><strong>Bank :</strong></td>
                        <td class="text-right">{{ $transaction->sponsor_bank }}</td>
                    </tr>
                    <tr>
                        <td class="small"><strong>Date :</strong></td>
                        <td class="text-right">{{ $transaction->in_req }}</td>
                    </tr>
                    <tr>
                        <td class="small"><strong>Structured Data :</strong></td>
                        <td class="text-right">{{  str_limit($transaction->structured_data , '50' )  }}</td>
                    </tr>
                    <tr class="text-wrap">
                        <td class="small"><strong>Extended Data :</strong></td>
                        <td class="text-right">{{ $transaction->extended_data }}</td>
                    </tr>
                    <tr class="text-wrap">
                        <td class="small"><strong>Response Code :</strong></td>
                        <td class="text-right">{{ $transaction->response_code }}</td>
                    </tr>
                    <tr>
                        <td class="small"><strong>Date Retrieved :</strong></td>
                        <td class="text-right">{{ $transaction->created_at }}</td>
                    </tr>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
