@extends('layouts.dashboard' , [ 'title' => 'POS Machines'  ,'active' => 'pos-machines' ])
@section('content')
    <div class="container py-5">
        <div class="py-3">
            <h1 class="mb-0">POS Machines</h1>
        </div>
        <div class="page-header row px-0">
            @can('serial' , \App\models\system\Input::class)
                <form action="/pos-machines/add"  class="input-group col-lg-4" method="POST">
                    @csrf
                    <input type="text" class="form-control" name="serial" placeholder="Serial" value="{{ old('serial' , request('serial')) }}">
                    <span class="input-group-append">
                    <button class="btn btn-primary" type="submit">Add Serial</button>
                </span>
                </form>
            @endcan

            <form class="input-group col-lg-4 ml-auto" method="GET">
                <input type="text" class="form-control" name="search" placeholder="Search" value="{{ old('search' , request('search')) }}">
                <span class="input-group-append">
                    <button class="btn btn-primary" type="submit">Search</button>
                </span>
            </form>

            @can('input' , \App\models\system\Input::class )
                <div class="col-lg-2 pr-0">
                    <a href="/pos-machines/add-log" class="btn btn-primary btn-block"><i class="fe fe-plus mr-2"></i> Add POS Log </a>
                </div>
            @endcan
        </div>
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="card border-0 bg-transparent">
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-icon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    @if($errors->any())
                        <div class="card-alert alert alert-icon alert-danger">
                            <i class="fe fe- mr-2" aria-hidden="true"></i> {!!  implode('', $errors->all('<div>:message</div>')) !!}
                        </div>
                    @endif
                    <div class="table-responsive">
                        <table style="border-collapse:separate; border-spacing:0 15px;"
                               class="table table-hover table-outline table-vcenter text-nowrap card-table table-borderless">
                            <thead class="text-dark">
                            <tr>
                                <th>Info</th>
                                <th>Info</th>
                                <th>Terminal</th>
                                <th>System Terminal</th>
                                <th class="text-center"><i class="fe fe-info"></i></th>
                                {{--<th class="text-center"><i class="fe fe-settings"></i></th>--}}
                            </tr>
                            </thead>
                            <tbody>

                            @foreach( $pos as $machine )

                                <tr class="bg-white shadow-sm shadow-lg--hover">
                                    <td class="border-left border-lg {{ $machine->working_state  ? 'border-success' : 'border-danger' }} ">
                                        <div><span class="text-muted">Serial Number : </span>{{ $machine->serial_number }}</div>
                                        <div><span class="text-muted">Asset Code : </span>{{ $machine->asset_code }}</div>
                                        <div><span class="text-muted">Model : </span>{{ $machine->model }}</div>
                                        <div><span class="text-muted">Location : </span>{{ $machine->location }}</div>
                                    </td>
                                    <td>
                                        <div><span class="text-muted">Condition : </span>{{ $machine->condition }}</div>
                                        <div><span class="text-muted">Created : </span>{{ $machine->created_at }}</div>
                                        <div><span class="text-muted">Last Update : </span>{{ $machine->updated_at->diffForHumans() }}</div>
                                    </td>
                                    <td>
                                        @if($machine->terminal)
                                            <div><span class="text-muted">Terminal : </span>{{ $machine->terminal->terminal_id }}</div>
                                            <div><span class="text-muted">Account : </span>{{ $machine->terminal->account_id }}</div>
                                            <div><span class="text-muted">Trade Name : </span>{{ $machine->terminal->trade_name }}</div>
                                            <div><span class="text-muted">Location : </span>{{ $machine->terminal->location }}</div>
                                        @else
                                            <div class="mb-1"><span class="px-2 border border-danger text-danger small">Not Detected</span></div>
                                        @endif
                                    </td>
                                    <td>
                                        @if($machine->auto_terminal)
                                            <div><span class="text-muted">Terminal : </span>{{ $machine->auto_terminal->terminal_id }}</div>
                                            <div><span class="text-muted">Account : </span>{{ $machine->auto_terminal->account_id }}</div>
                                            <div><span class="text-muted">Trade Name : </span>{{ $machine->auto_terminal->trade_name }}</div>
                                            <div><span class="text-muted">Location : </span>{{ $machine->auto_terminal->location }}</div>
                                        @else
                                            <div class="mb-1"><span class="px-2 border border-danger text-danger small">Not Detected</span></div>
                                        @endif
                                    </td>
                                    <td class="text-center">
                                        <div class="mb-1"><a href="/pos-machines/{{ $machine->id }}/view" class="card-link"><i class="fe fe-eye mr-2"></i>View More</a></div>
                                        @can('input' , \App\models\system\Input::class )
                                            <div class="mb-1"><a href="/pos-machines/{{ $machine->id }}/edit" class="card-link text-success"><i class="fe fe-edit mr-2"></i>Edit</a></div>
                                            <div class="mb-1"><a href="/pos-machines/add-log?serial_number={{ $machine->serial_number }}&terminal=@if($machine->terminal){{ $machine->terminal->terminal_id }}@endif" class="card-link"><i class="fe fe-plus-circle mr-2"></i>Log</a></div>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer row justify-content-center col-lg-12 border-0 bg-white pt-5 m-0">
                        {{ $pos->appends(request()->query())->links()  }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
