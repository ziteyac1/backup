@extends('layouts.dashboard' , [ 'title' => 'POS Machine'  ,'active' => 'pos-machines' ])
@section('content')
    <div class="container">
        <div class="row justify-content-center py-5">
            <div class="col-lg-4">
                @include('includes.pos-info' , [ 'machine' => $machine ])
                @if($machine->terminal)
                    @include('includes.terminal-info' ,['terminal' => $machine->terminal  ])
                @endif
                @if($machine->auto_terminal)
                    @include('includes.terminal-info' ,['terminal' => $machine->auto_terminal , 'type' => 'System Detected' ])
                @endif
            </div>
            <div class="col-lg-8">
                <div class="card bg-transparent border-0 rounded-0 shadow-none">
                    <div class="card-header">
                        <h3 class="card-title">Logs</h3>
                    </div>
                    <table class="card-table table table-vcenter table-hover">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>LOG</th>
                            <th>LEVEL</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody class="bg-white shadow-sm">
                        @foreach( $machine->logs as $log )
                            <tr class="">
                                <td>
                                    <div><span class="text-muted">Log ID: </span>{{ $log->id }}</div>
                                </td>
                                <td>
                                   <div><span class="text-muted">Log : </span>{{ $log->log }}</div>
                                    <div><span class="text-muted">Created : </span>{{ $log->created_at }}</div>
                                </td>
                                <td>
                                    <div><span class="text-muted">Level : </span>{{ $log->level }}</div>
                                    <div><span class="text-muted">Updated : </span>{{ $log->updated_at->diffForHumans() }}</div>
                                </td>
                                <td class="text-center">
                                    <div class="mb-1"><a href="/pos-log/{{ $log->id }}/view" class="card-link"><i class="fe fe-eye mr-2"></i>View</a></div>
                                 </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
