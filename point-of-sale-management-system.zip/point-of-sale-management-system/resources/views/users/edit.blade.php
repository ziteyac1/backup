@extends('layouts.dashboard' , [ 'title' => 'Users - Edit '  ,'active' => 'users' ])
@section('content')
    <div class="container p-5">
        <div class="row justify-content-center">
            <div class="col-lg-4">
                <form method="POST" action="/user/{{ $user->id }}/edit" class="card rounded-0 border-0 shadow-lg">
                    @csrf
                    <div class="card-body">
                        <h1 class="card-title">Edit User</h1>
                    </div>
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-icon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <h6 class="text-muted">User Info</h6>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="name" class="">Name</label>
                                    <input id="name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ old('name' , $user->name ) }}" required autofocus>
                                    @if ($errors->has('name'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="branch_code" class="">Branch</label>
                                    <select id="branch_code" type="branch_code" class="form-control{{ $errors->has('branch_code') ? ' is-invalid' : '' }}" name="branch_code" value="{{ old('branch_code', $user->branch ) }}" required>
                                        <option value="">Choose Branch Name</option>
                                        @foreach( $branches as $branch )
                                            <option value="{{ $branch->branch_code }}" {{ old( 'branch_code', $user->branch ) === $branch->branch_code ? 'selected' : '' }}>{{ $branch->short_name }} - {{ $branch->name }}</option>
                                        @endforeach
                                    </select>
                                    @if ($errors->has('branch_code'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('branch_code') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            @can('role',\App\User::class)
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label for="role" class="">Role</label>
                                        <select id="role" type="role" class="form-control{{ $errors->has('role') ? ' is-invalid' : '' }}" name="role" value="{{ old( 'role' , $user->role ) }}" required>
                                            <option value="">Choose Role Name</option>
                                            @foreach( $roles as $role )
                                                <option value="{{ $role->id }}" {{ old('role' ,$user->role ) === $role->id ? 'selected' : '' }}>{{ $role->name }}</option>
                                            @endforeach
                                        </select>
                                        @if ($errors->has('role'))
                                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('role') }}</strong>
                                    </span>
                                        @endif
                                    </div>
                                </div>
                            @endcan
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-center">
                        <div class="col-lg-6">
                            <button type="submit" class="btn btn-primary btn-block">Update User</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
