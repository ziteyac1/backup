@extends('layouts.dashboard' , [ 'title' => 'Dashboard'  ,'active' => 'home' ])
@section('content')
    <div class="container">
        <div class="page-header">
            <h1 class="page-title">
                Dashboard
            </h1>
        </div>

        <div class="row row-cards">

            @foreach($stats  as $stat)

                <div class="col-lg-2">
                    <div class="card rounded-0">
                        <div class="card-body p-3 text-center">
                            <div class="h1 m-0">{{ number_format( (float)$stat['number'] , 0, ',', ' ') }}</div>
                            <div class="text-muted small">{{ $stat['name'] }}</div>
                        </div>
                    </div>
                </div>

            @endforeach

        </div>

        <div class="mb-4">
            <h1 class="page-title">
                Quick links
            </h1>
        </div>

        <div class="row m-0">
            @can('input' , \App\models\system\Input::class)
                <div class="col-lg-12 row p-0 m-0">
                    <div class="col-lg-2 pr-0 pl-0 mb-2">
                        <a href="/requests/new-terminal/create" class="btn btn-primary btn-block"><i class="fe fe-git-pull-request mr-2"></i> New Terminal </a>
                    </div>
                    <div class="col-lg-2 pr-0 mb-2">
                        <a href="/requests/re-allocation/create" class="btn btn-primary btn-block"><i class="fe fe-share-2 mr-2"></i> Reallocation </a>
                    </div>
                    <div class="col-lg-2 pr-0 mb-2">
                        <a href="/requests/change-details/create" class="btn btn-primary btn-block"><i class="fe fe-edit-3 mr-1"></i> Change of Details </a>
                    </div>
                    <div class="col-lg-2 pr-0 mb-2">
                        <a href="/requests/pos-repair/create" class="btn btn-primary btn-block"><i class="fe fe-git-merge mr-2"></i> POS Repair </a>
                    </div>
                    <div class="col-lg-2 pr-0 mb-2">
                        <a href="/requests/terminal-testing/create" class="btn btn-primary btn-block"><i class="fe fe-radio mr-2"></i> Terminal Testing </a>
                    </div>
                    <div class="col-lg-2 pr-0 mb-2">
                        <a href="/requests/pos-hire/create" class="btn btn-primary btn-block"><i class="fe fe-feather mr-2"></i>POS Hire</a>
                    </div>
                    <div class="col-lg-2 pr-0 mb-2 pl-0">
                        <a href="/requests/change-account/create" class="btn btn-primary btn-block"><i class="fe fe-edit-2 mr-2"></i>Change Account</a>
                    </div>
                    <div class="col-lg-2 pr-0 mb-2">
                        <a href="/requests/change-customer/create" class="btn btn-primary btn-block"><i class="fe fe-users mr-2"></i>Change Customer</a>
                    </div>
                    <div class="col-lg-2 pr-0 mb-2">
                        <a href="/customers/add" class="btn btn-primary btn-block"><i class="fe fe-plus-circle mr-2"></i>Add Customer</a>
                    </div>
                    <div class="col-lg-2 pr-0 mb-2">
                        <a href="/accounts/add" class="btn btn-primary btn-block"><i class="fe fe-plus-circle mr-2"></i>Add Account</a>
                    </div>
                    <div class="col-lg-2 pr-0 mb-2">
                        <a href="/terminals/give-customer" class="btn btn-primary btn-block"><i class="fe fe-arrow-up mr-2"></i>Issue Terminal</a>
                    </div>
                    <div class="col-lg-2 pr-0 mb-2">
                        <a href="/terminals/return-terminal" class="btn btn-primary btn-block"><i class="fe fe-arrow-down mr-2"></i>Return Terminal</a>
                    </div>
                    <div class="col-lg-2 pr-0 mb-2 pl-0">
                        <a href="/tellers/add" class="btn btn-primary btn-block"><i class="fe fe-plus-circle mr-2"></i>Add Teller</a>
                    </div>
                    <div class="col-lg-2 pr-0 mb-2">
                        <a href="/pos-logs/all" class="btn btn-primary btn-block"><i class="fe fe-plus-circle mr-2"></i>Add POS Log</a>
                    </div>
                    <div class="col-lg-2 pr-0 mb-2">
                        <a href="/pos-transfer-batches/all" class="btn btn-primary btn-block"><i class="fe fe-plus-circle mr-2"></i>Add POS Batch</a>
                    </div>
                    <div class="col-lg-2 pr-0 mb-2">
                        <a href="/pos-transfers/all" class="btn btn-primary btn-block"><i class="fe fe-plus-circle mr-2"></i>Add POS Transfer</a>
                    </div>
                    <div class="col-lg-2 pr-0 mb-2">
                        <a href="/reports/all" class="btn btn-primary btn-block"><i class="fe fe-bar-chart-2 mr-2"></i>Run Reports</a>
                    </div>
                </div>
            @endcan
        </div>

        <div class="mb-4 mt-2 row m-0 p-0">
            <h1 class="page-title">
                Summary
            </h1>
        </div>

        <form class="col-lg-12 row m-0 p-0 mt-3 border-top border-bottom py-5">
            <div class="col-lg-4 ml-auto">
                <input type="date" class="form-control" name="start_date"  value="{{ old('start_date' , request('start_date')) }}">
            </div>
            <div class="col-lg-4">
                <input type="date" class="form-control" name="end_date" value="{{ old('end_date' , request('end_date')) }}">
            </div>
            <div class="col-lg-2">
                <select class="form-control custom-select" name="branch_code" id="">
                    <option value="">Choose Branch</option>
                    <option value="">Choose Branch</option>
                    @foreach(\App\models\Branch::all()  as $branch )
                        <option value="{{ $branch->branch_code }}" {{ old('branch_code' , request('branch_code') === $branch->branch_code ? 'selected' : '' ) }}>{{ $branch->branch_code }} - {{ $branch->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-lg-2">
                <button class="btn btn-block btn-primary" type="submit"><i class="fe fe-filter mr-1"></i> Filter</button>
            </div>
        </form>

        @foreach($reports as $report )
            <div class="mb-4 mt-2 row m-0 p-0">
                <h1 class="page-title">
                    {{ $report['report']->name }}
                </h1>
            </div>
            <div class="row">
                @if (view()->exists('reports.'.$report['report']->views.'.overview'))
                    @include('reports.'.$report['report']->views.'.overview',  [ 'overview' => $report['overview'] , 'report' => false ])
                @endif
            </div>
        @endforeach

    </div>
@endsection

@section('scripts')

    <script src="{{ asset('js/Chart.min.js') }}"></script>

    @foreach($reports as $report )
        @if (view()->exists('reports.'.$report['report']->views.'.scripts'))
            @include('reports.'.$report['report']->views.'.scripts',[ 'overview' => $report['overview'] ])
        @endif
    @endforeach

@endsection
