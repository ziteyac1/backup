@extends('layouts.dashboard' , [ 'title' => 'History'  ,'active' => 'customers' ])
@section('content')
    <div class="container">
        <div class="page-header">
            <h1 class="page-title">
                Audit
            </h1>
        </div>
        <div class="row">
            <div class="col-lg-4">
                <div class="card bg-transparent border-0 rounded-0 shadow-none">
                    <div class="card-header">
                        <h5 class="card-title">Audit Info</h5>
                    </div>
                    <table class="card-table table bg-white shadow-sm table-hover">
                        <tbody>
                        <tr>
                            <td class="small"><strong>User Name :</strong></td>
                            <td class="text-right">{{ $audit->user->name }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>User Email:</strong></td>
                            <td class="text-right">{{ $audit->user->email  }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Role:</strong></td>
                            <td class="text-right">{{ $audit->user->role_name->name  }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Branch:</strong></td>
                            <td class="text-right">{{ $audit->user->branch_name->name }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>ID:</strong></td>
                            <td class="text-right">{{ $audit->id }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Event:</strong></td>
                            <td class="text-right">{{ $audit->event }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>URL:</strong></td>
                            <td class="text-right">{{ $audit->url }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>IP:</strong></td>
                            <td class="text-right">{{ $audit->ip_address }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Agent:</strong></td>
                            <td class="text-right">{{ $audit->user_agent }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Created:</strong></td>
                            <td class="text-right">{{ $audit->created_at }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Updated:</strong></td>
                            <td class="text-right">{{ $audit->updated_at->diffForHumans() }}</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card bg-transparent border-0 rounded-0 shadow-none">
                    <div class="card-header">
                        <h5 class="card-title">Changes</h5>
                    </div>
                    <table class="card-table table">
                        <thead>
                        <tr>
                            <th>Old</th>
                            <th>New</th>
                        </tr>
                        </thead>
                        <tbody class="bg-white shadow-sm">
                        <tr>
                            <td>
                                @foreach($audit->getModified() as $key => $item )
                                    @if(isset($item['old']))
                                        <div class=""><small style="font-weight: bolder">{{ ucwords($key) }}</small></div>
                                        @if(is_array($item['old']))
                                            @foreach( $item['old'] as $name => $value )
                                                <div class=""><small style="font-weight: bolder">{{ ucwords($name) }}</small></div>
                                                @if(is_array($value))
                                                    @foreach( $value as $i => $a )
                                                        <div class=""><small style="font-weight: bolder">{{ ucwords($i) }}</small></div>
                                                        <div> {{ $a }}</div>
                                                    @endforeach
                                                @else
                                                    <div> {{ $value }}</div>
                                                @endif
                                            @endforeach
                                        @else
                                            {{ $item['old'] }}
                                        @endif
                                    @endif
                                @endforeach
                            </td>
                            <td>
                                @foreach($audit->getModified() as $key => $item )
                                    @if(isset($item['new']))
                                        <div class=""><small style="font-weight: bolder">{{ ucwords($key) }}</small></div>
                                        @if(is_array($item['new']))
                                            @foreach( $item['new'] as $name => $value )
                                                <div class=""><small style="font-weight: bolder">{{ ucwords($name) }}</small></div>
                                                @if(is_array($value))
                                                    @foreach( $value as $i => $a )
                                                        <div class=""><small style="font-weight: bolder">{{ ucwords($i) }}</small></div>
                                                        <div> {{ $a }}</div>
                                                    @endforeach
                                                @else
                                                    <div> {{ $value }}</div>
                                                @endif
                                            @endforeach
                                        @else
                                            {{ $item['new'] }}
                                        @endif
                                    @endif
                                @endforeach
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
@endsection
