@extends('layouts.dashboard' , [ 'title' => 'POS Logs'  ,'active' => 'pos-logs' ])
@section('content')
    <div class="container">
        <div class="row justify-content-center py-5">

            <div class="col-lg-4">
                @include('includes.terminal-info' , [ 'terminal' => $log->terminal_linked ])
            </div>
            <div class="col-lg-4">
                <div class="card bg-transparent border-0 rounded-0 shadow-none">
                    <div class="card-header">
                        <h5 class="card-title">Log Info</h5>
                        <div class="card-options">
                            <a href="/pos-log/{{ $log->id }}/history" class="btn btn-secondary btn-sm ml-2 ">History</a>
                            <a href="/pos-log/{{ $log->id }}/edit" class="btn btn-secondary btn-sm ml-2 ">Edit</a>
                        </div>
                    </div>
                    <table class="card-table table bg-white shadow-sm table-hover">
                        <tbody>
                        <tr>
                            <td class="small"><strong>ID :</strong></td>
                            <td class="text-right">{{ $log->id }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Serial Number :</strong></td>
                            <td class="text-right">{{ $log->serial_number }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>POS :</strong></td>
                            <td class="text-right"><a href="/pos-machines/{{ $log->pos->id }}/view" class="btn btn-secondary btn-sm ml-2 ">View POS Machine</a></td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Log :</strong></td>
                            <td class="text-right">{{ $log->log }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Level :</strong></td>
                            <td class="text-right">{{ $log->level }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Terminal :</strong></td>
                            <td class="text-right">{{ $log->terminal }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Terminal :</strong></td>
                            <td class="text-right"><a href="/terminal/{{ $log->terminal_linked->id }}/view" class="btn btn-secondary btn-sm ml-2 ">View Terminal</a></td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Account :</strong></td>
                            <td class="text-right">{{ $log->account }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Created :</strong></td>
                            <td class="text-right">{{ $log->created_at }}</td>
                        </tr>
                        <tr>
                            <td class="small"><strong>Updated :</strong></td>
                            <td class="text-right">{{ $log->updated_at->diffForHumans() }}</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-lg-4">
                @include('includes.pos-info' , [ 'machine' => $log->pos ])
            </div>
        </div>
    </div>
@endsection
