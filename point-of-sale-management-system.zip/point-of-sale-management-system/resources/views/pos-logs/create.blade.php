@extends('layouts.dashboard' , [ 'title' => 'POS Machine Log - Add '  ,'active' => 'pos-logs' ])
@section('content')
    <div class="container p-5">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <form method="POST" action="/pos-machines/add-log" class="card rounded-0 border-0 shadow-lg">
                    @csrf
                    <div class="card-body">
                        <h1 class="card-title">POS Machine Log</h1>
                    </div>
                    @if(session()->has('message'))
                        <div class="card-alert alert alert-icon alert-success">
                            <i class="fe fe-check mr-2" aria-hidden="true"></i> {!! session()->get('message') !!}
                        </div>
                    @endif
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <h6 class="text-muted">POS Machine Info</h6>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="serial_number" class="">Serial Number</label>
                                    <input id="serial_number" type="text" class="form-control {{ $errors->has('serial_number') ? ' is-invalid' : '' }}" name="serial_number" value="{{ old('serial_number', request()->get('serial_number')) }}" required autofocus>
                                    @if ($errors->has('serial_number'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('serial_number') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="terminal" class="">Terminal ID</label>
                                    <input id="terminal" type="text" class="form-control {{ $errors->has('terminal') ? ' is-invalid' : '' }}" name="terminal" value="{{ old('terminal', request()->get('terminal')) }}" required autofocus>
                                    @if ($errors->has('terminal'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('terminal') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <h6 class="text-muted">Log Info</h6>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="log" class="">Log</label>
                                    <select id="log" type="log" class="form-control {{ $errors->has('log') ? ' is-invalid' : '' }}" name="log" value="{{ old('log', request()->get('log')) }}" required>
                                        <option value=""> Choose POS Log  </option>
                                        @foreach($logs as $log )
                                            <option value="{{ $log->id }}" {{ old('log', request()->get('log')) === $log->data_id ? 'selected' : '' }}> {{ $log->description }} </option>
                                        @endforeach
                                        <option value="other"> Other </option>
                                    </select>
                                    @if ($errors->has('log'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('log') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="other_log" class=""> Other </label>
                                    <span class="text-info small">Please Use this if only the log or error is not listed above </span>
                                    <textarea id="other_log" type="text" class="form-control {{ $errors->has('other_log') ? ' is-invalid' : '' }}" name="other_log"  autofocus>{{ old('other_log' , request()->get('other_log')) }}</textarea>
                                    @if ($errors->has('other_log'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('other_log') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-center">
                        <div class="col-lg-6">
                            <button type="submit" class="btn btn-primary btn-block">Create Log</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
