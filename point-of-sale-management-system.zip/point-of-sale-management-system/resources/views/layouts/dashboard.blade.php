<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Language" content="en" />
    <meta name="msapplication-TileColor" content="#2d89ef">
    <meta name="theme-color" content="#4188c9">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"/>
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="HandheldFriendly" content="True">
    <meta name="MobileOptimized" content="320">
    <link rel="icon" href="{{asset('favicon.ico')}}" type="image/x-icon"/>
    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />

    <title>{{ config('app.name', 'Laravel') .' | ' . $title  }}</title>

    <!-- Dashboard Core -->
    <link href="{{asset('css/argon-dash.css')}}" rel="stylesheet" />
    <link href="{{asset('/assets/css/dashboard.css')}}" rel="stylesheet" />

    @yield('css')

    <style>
        @media (min-width: 1000px){
            .container {
                max-width: 95%;
            }
        }
    </style>

</head>
<body class="">
<div  id="app">
    <div class="page">
        <div class="page-main">
            <div class="fixed-top">
                <div class="shadow-sm">
                    <div class="header py-4">
                        <div class="container">
                            <div class="d-flex">
                                <a class="header-brand" href="/home">
                                   {{ config('app.name', 'Dash') }}
                                </a>
                                <div class="d-flex order-lg-2 ml-auto">
                                    <div class="dropdown">
                                        <a href="#" class="nav-link pr-0 leading-none" data-toggle="dropdown">
                                            <span class="avatar avatar-green">{{ Auth::user()->short_name }}</span>
                                            <span class="ml-2 d-none d-lg-block">
                                        <span class="text-default"> {{ Auth::user()->name }} </span>
                                     <small class="text-muted d-block mt-1">{{ Auth::user()->role_name->name }}</small>
                                    </span>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                            <a class="dropdown-item" href="/users/my-profile">
                                                <i class="dropdown-icon fe fe-user"></i> Profile
                                            </a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="{{ route('logout') }}"
                                               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                                {{ __('Logout') }}
                                            </a>
                                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                                @csrf
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <a href="#" class="header-toggler d-lg-none ml-3 ml-lg-0" data-toggle="collapse" data-target="#headerMenuCollapse">
                                    <span class="header-toggler-icon"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="header collapse d-lg-flex p-0" id="headerMenuCollapse">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-lg order-lg-first">
                                    <ul class="nav nav-tabs border-0 flex-column flex-lg-row small">
                                        <li class="nav-item">
                                            <a href="/home?start_date={{ now()->subMonth(1)->format('Y-m-d') }}" class="nav-link {{ $active == 'home' ? 'active' : '' }}"><i class="fe fe-bar-chart mr-3"></i>Home</a>
                                        </li>
                                        <li class="nav-item dropdown">
                                            <a href="javascript:void(0)" class="nav-link {{ $active == 'customers' || $active == 'customers-create'  ? 'active' : '' }}" data-toggle="dropdown"><i class="fe fe-users mr-3"></i>Customers</a>
                                            <div class="dropdown-menu dropdown-menu-arrow">
                                                <a href="/customers/all" class="dropdown-item  {{ $active == 'customers' ? 'active' : '' }}"><i class="fe fe-users mr-3"></i>All Customers</a>
                                                @can('input' , \App\models\system\Input::class )
                                                    <a href="/customers/add" class="dropdown-item  {{ $active == 'customers-create' ? 'active' : '' }}"><i class="fe fe-plus-circle mr-3"></i>Add Customer</a>
                                                @endcan
                                            </div>
                                        </li>

                                        <li class="nav-item dropdown">
                                            <a href="javascript:void(0)" class="nav-link {{ $active == 'accounts' || $active == 'accounts-create'  ? 'active' : '' }}" data-toggle="dropdown"><i class="fe fe-link mr-3"></i>Accounts</a>
                                            <div class="dropdown-menu dropdown-menu-arrow">
                                                <a href="/accounts/all" class="dropdown-item  {{ $active == 'accounts' ? 'active' : '' }}"><i class="fe fe-link mr-3"></i>All Accounts</a>
                                                @can('input' , \App\models\system\Input::class )
                                                    <a href="/accounts/add" class="dropdown-item  {{ $active == 'accounts-create' ? 'active' : '' }}"><i class="fe fe-plus-circle mr-3"></i>Add Accounts</a>
                                                @endcan
                                            </div>
                                        </li>

                                        <li class="nav-item dropdown">
                                            <a href="javascript:void(0)" class="nav-link {{ $active == 'terminals' || $active == 'pos-hire'  ? 'active' : '' }}" data-toggle="dropdown"><i class="fe fe-git-pull-request mr-3"></i>Terminals</a>
                                            <div class="dropdown-menu dropdown-menu-arrow">
                                                <a href="/terminals/all" class="dropdown-item  {{ $active == 'terminals' ? 'active' : '' }}"><i class="fe fe-git-pull-request mr-3"></i>All Terminals</a>
                                                <a href="/terminals/issues" class="dropdown-item  {{ $active == 'issues' ? 'active' : '' }}"><i class="fe fe-arrow-up mr-3"></i>All Issues</a>
                                                <a href="/terminals/returns" class="dropdown-item  {{ $active == 'returns' ? 'active' : '' }}"><i class="fe fe-arrow-down mr-3"></i>All Returns</a>
                                                @can('create' , \App\models\POSHire::class )
                                                    <a href="/pos-hire/all" class="dropdown-item  {{ $active == 'pos-hire' ? 'active' : '' }}"><i class="fe fe-credit-card mr-3"></i>POS Hire</a>
                                                @endcan
                                            </div>
                                        </li>

                                        <li class="nav-item dropdown">
                                            <a href="javascript:void(0)" class="nav-link {{ $active == 'tellers' || $active == 'tellers-create'  ? 'active' : '' }}" data-toggle="dropdown"><i class="fe fe-smartphone mr-3"></i>Tellers</a>
                                            <div class="dropdown-menu dropdown-menu-arrow">
                                                <a href="/tellers/all" class="dropdown-item  {{ $active == 'tellers' ? 'active' : '' }}"><i class="fe fe-git-pull-request mr-3"></i>All Tellers</a>
                                                @can('input' , \App\models\system\Input::class )
                                                    <a href="/tellers/add" class="dropdown-item  {{ $active == 'tellers-create' ? 'active' : '' }}"><i class="fe fe-plus-circle mr-3"></i>Add Tellers</a>
                                                @endcan
                                            </div>
                                        </li>

                                        <li class="nav-item">
                                            <a href="/transactions/all" class="nav-link {{ $active == 'transactions' ? 'active' : '' }}"><i class="fe fe-activity"></i>Transactions</a>
                                        </li>

                                        <li class="nav-item dropdown">
                                            <a href="javascript:void(0)" class="nav-link {{ $active == 'pos-machines' || $active == 'pos-logs' || $active === 'pos-batches' ||  $active === 'pos-transfer' ? 'active' : '' }}" data-toggle="dropdown"><i class="fe fe-git-commit mr-3"></i>POS Machines</a>
                                            <div class="dropdown-menu dropdown-menu-arrow">

                                                <a href="/pos-machines/all" class="dropdown-item  {{ $active == 'pos-machines' ? 'active' : '' }}"><i class="fe fe-git-commit mr-3"></i>POS Machines</a>
                                                <a href="/pos-logs/all" class="dropdown-item  {{ $active === 'pos-logs' ? 'active' : '' }}"><i class="fe fe-alert-octagon mr-3"></i>Logs</a>
                                                @can('input' , \App\models\system\Input::class )
                                                    @can('all' ,\App\models\POSTrasnferBatch::class)
                                                        <a href="/pos-transfer-batches/all" class="dropdown-item"><i class="fe fe-layers mr-3"></i>Transfer Batches</a>
                                                    @endcan
                                                    <a href="/pos-transfer-batches/mine" class="dropdown-item"><i class="fe fe-user mr-3"></i>My Transfer Batches</a>
                                                    @can('all' ,\App\models\POSTrasnfer::class)
                                                        <a href="/pos-transfers/all" class="dropdown-item"><i class="fe fe-bookmark  mr-3"></i>POS Transfer</a>
                                                    @endcan
                                                    <!-- <a href="/pos-transfers/mine" class="dropdown-item"><i class="fe fe-user  mr-3"></i>My POS Transfer</a> -->
                                                @endcan
                                            </div>
                                        </li>
                                        <li class="nav-item dropdown">
                                            <a href="javascript:void(0)" class="nav-link {{ $active == 'requests' || $active == 'requests-my-requests'  ? 'active' : '' }}" data-toggle="dropdown"><i class="fe fe-calendar mr-3"></i>Requests</a>
                                            <div class="dropdown-menu dropdown-menu-arrow">
                                                <a href="/requests/all" class="dropdown-item  {{ $active == 'requests'  ? 'active' : '' }}"><i class="fe fe-calendar mr-3"></i>All Requests</a>
                                                <a href="/requests/my-requests" class="dropdown-item  {{ $active == 'requests-my-requests' ? 'active' : '' }}"><i class="fe fe-user mr-3"></i>My Requests</a>
                                            </div>
                                        </li>
                                        <li class="nav-item dropdown">
                                            <a href="javascript:void(0)" class="nav-link {{ $active == 'reports'  ? 'active' : '' }}" data-toggle="dropdown"><i class="fe fe-file-text mr-3"></i>Reports</a>
                                            <div class="dropdown-menu dropdown-menu-arrow">
                                                <a href="/reports/all" class="dropdown-item {{ $active == 'reports' ? 'active' : '' }}"><i class="fe fe-file-text"></i>Run Reports</a>
                                                <a href="/reports/reports-run/all?user={{ auth()->id() }}" class="dropdown-item  {{ $active == 'reports-my-requests' ? 'active' : '' }}"><i class="fe fe-user mr-3"></i>My Reports</a>
                                                <a href="/reports/reports-run/all" class="dropdown-item  {{ $active == 'reports-all' ? 'active' : '' }}"><i class="fe fe-folder mr-3"></i>All Reports</a>
                                            </div>
                                        </li>
                                        @can('view',\App\User::class)
                                            <li class="nav-item dropdown">
                                                <a href="javascript:void(0)" class="nav-link {{ $active == 'users' ? 'active' : '' }}" data-toggle="dropdown"><i class="fe fe-user mr-3"></i>Users</a>
                                                <div class="dropdown-menu dropdown-menu-arrow">
                                                    <a href="/users/all" class="dropdown-item  {{ $active == 'users' ? 'active' : '' }}"><i class="fe fe-users mr-3"></i>All Users</a>
                                                </div>
                                            </li>
                                        @endcan
                                        <li class="nav-item">
                                            <a href="/how-to/all" class="nav-link {{ $active == 'Documentation' ? 'active' : '' }}"><i class="fe fe-folder-plus"></i>Documentation</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="pt-9" style="min-height: 90vh;position: relative">
                <div class="pt-5">
                    @yield('content')
                </div>
            </div>
        </div>
        <footer class="footer">
            <div class="container">
                <div class="row align-items-center flex-row-reverse">
                    <div class="col-auto ml-lg-auto">
                        <div class="row align-items-center">
                            <div class="col-auto">
                                <ul class="list-inline list-inline-dots mb-0">
                                    <li class="list-inline-item"><a href="/how-to/all">Documentation and Guidlines </a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-auto mt-3 mt-lg-0 text-center">
                        Copyright © 2019 {{ config('app.name', 'Dash') }}  Portal Done By <strong>Prince Gurajena ICT E-Channels 2018 </strong>   All rights reserved.
                    </div>
                </div>
            </div>
        </footer>
    </div>
</div>
<script src="{{ asset('js/app.js') }}"></script>
<script src="{{ asset('assets/js/core.js') }}"></script>
@yield('scripts')
</body>
</html>


