<?php

use App\models\Account;
use App\models\POSMachineLog;
use App\models\Request;
use App\models\SystemValue;
use App\models\Terminal;
use App\Reports\Sections\Terminals\Active;
use App\Reports\Sections\Terminals\Commissions;
use App\Reports\Sections\Terminals\InActive;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{

    /**
     * Seed the application's database.
     *
     * @return void
     * @throws Exception
     */
    public function run()
    {

//        self::addTellers();
        self::add_pos_machines();
//        self::add_branches();
//        self::add_terminals();
//        self::add_users();
//        self::add_system_values();
////        self::add_pos_logs();
////       self::add_requests();
//         self::addother();
         self::addReports();


    }

    public static function addReports(){

        echo 'Adding  : Reports' . PHP_EOL;

        $data = [
            [
                'name' => 'Transactions Report',
                'description' => 'Shows a list of transaction based on given filters',
                'class' => App\Reports\Sections\Transactions\Transactions::class,
                'exportable' => \App\Exports\TransactionsExport::class,
                'filter' => \App\elastic\TransactionFilters::class,
                'model' => \App\models\Transaction::class,
                'views' => 'transactions',
                'type' => 'instant',
                'section' => 'Transactions',
            ],[
                'name' => 'Requests Report',
                'description' => 'Shows a list of requests based on given filters',
                'class' => App\Reports\Sections\Requests\Requests::class,
                'exportable' => \App\Exports\RequestsExport::class,
                'filter' => \App\core\Filters\RequestFilters::class,
                'model' => \App\models\Request::class,
                'views' => 'requests',
                'type' => 'instant',
                'section' => 'requests',
            ],[
                'name' => 'Terminals Report',
                'description' => 'Shows a list of terminals based on given filters',
                'class' => App\Reports\Sections\Terminals\Terminals::class,
                'exportable' => \App\Exports\TerminalsExport::class,
                'filter' => \App\core\Filters\TerminalFilters::class,
                'model' => \App\models\Terminal::class,
                'views' => 'terminals',
                'type' => 'instant',
                'section' => 'terminals',
            ],[
                'name' => 'POSMachines Report',
                'description' => 'Shows a list of pos machines based on given filters',
                'class' => App\Reports\Sections\POSMachines\POSMachines::class,
                'exportable' => \App\Exports\POSMachinesExport::class,
                'filter' => \App\core\Filters\POSMachineFilters::class,
                'model' => \App\models\POSMachine::class,
                'views' => 'pos-machines',
                'type' => 'instant',
                'section' => 'pos-machines',
            ],[
                'name' => 'Customer Report',
                'description' => 'Shows a list of customer based on given filters',
                'class' => App\Reports\Sections\Customers\Customers::class,
                'exportable' => \App\Exports\CustomersExport::class,
                'filter' => \App\core\Filters\CustomerFilters::class,
                'model' => \App\models\Customer::class,
                'views' => 'customers',
                'type' => 'instant',
                'section' => 'customers',
            ],[
                'name' => 'Accounts Report',
                'description' => 'Shows a list of accounts based on given filters',
                'class' => App\Reports\Sections\Accounts\Accounts::class,
                'exportable' => \App\Exports\AccountsExport::class,
                'filter' => \App\core\Filters\AccountFilters::class,
                'model' => \App\models\Account::class,
                'views' => 'accounts',
                'type' => 'instant',
                'section' => 'accounts',
            ],[
                'name' => 'Tellers Report',
                'description' => 'Shows a list of teller based on given filters',
                'class' => App\Reports\Sections\Tellers\Tellers::class,
                'exportable' => \App\Exports\TellersExport::class,
                'filter' => \App\core\Filters\TellerFilters::class,
                'model' => \App\models\Teller::class,
                'views' => 'tellers',
                'type' => 'instant',
                'section' => 'tellers',
            ],[
                'name' => 'POSLogs Report',
                'description' => 'Shows a list of POSLogs based on given filters',
                'class' => App\Reports\Sections\POSLogs\POSLogs::class,
                'exportable' => \App\Exports\POSLogsExport::class,
                'filter' => \App\core\Filters\POSlogsFilters::class,
                'model' => \App\models\POSMachineLog::class,
                'views' => 'pos-logs',
                'type' => 'instant',
                'section' => 'pos-logs',
            ],[
                'name' => 'POSBatches Report',
                'description' => 'Shows a list of POSBatches based on given filters',
                'class' => App\Reports\Sections\POSBatches\POSBatches::class,
                'exportable' => \App\Exports\POSBacthesExport::class,
                'filter' => \App\core\Filters\POSTransferBatchFilters::class,
                'model' => \App\models\POSTrasnferBatch::class,
                'views' => 'pos-batches',
                'type' => 'instant',
                'section' => 'pos-batches',
            ],[
                'name' => 'POSTransfers Report',
                'description' => 'Shows a list of POSTransfers based on given filters',
                'class' => App\Reports\Sections\POSTransfers\POSTransfers::class,
                'exportable' => \App\Exports\POSTransfersExport::class,
                'filter' => \App\core\Filters\POSTransferFilters::class,
                'model' => \App\models\POSTrasnfer::class,
                'views' => 'pos-transfers',
                'type' => 'instant',
                'section' => 'pos-transfers',
            ],[
                'name' => 'In-active Terminals Report',
                'description' => 'Show a list of all active terminal but they are not transacting',
                'class' => InActive::class,
                'exportable' => \App\Exports\TerminalInActiveExport::class,
                'filter' => \App\core\Filters\TerminalFilters::class,
                'model' => \App\models\Terminal::class,
                'views' => 'terminals-in-active',
                'type' => 'instant',
                'section' => 'terminals',
            ],[
                'name' => 'Active Terminals',
                'description' => 'Show a list of active terminals and transacting',
                'class' => Active::class,
                'exportable' => \App\Exports\TerminalActiveExport::class,
                'filter' => \App\core\Filters\TerminalFilters::class,
                'model' => \App\models\Terminal::class,
                'views' => 'terminals-active',
                'type' => 'instant',
                'section' => 'terminals',
            ],[
                'name' => 'Returns',
                'description' => 'Show a list of terminals Returned to the bank',
                'class' => \App\Reports\Sections\Terminals\Returns::class,
                'exportable' => \App\Exports\POSRetunrsExport::class,
                'filter' => \App\core\Filters\POSReturnFilters::class,
                'model' => \App\models\POSReturn::class,
                'views' => 'returns',
                'type' => 'instant',
                'section' => 'terminals',
            ],[
                'name' => 'Issues',
                'description' => 'Show a list of terminals Issues to customers',
                'class' => \App\Reports\Sections\Terminals\Issues::class,
                'exportable' => \App\Exports\POSIssueExport::class,
                'filter' => \App\core\Filters\POSIssueFilters::class,
                'model' => \App\models\POSIssue::class,
                'views' => 'issues',
                'type' => 'instant',
                'section' => 'terminals',
            ],[
                'name' => 'POSHires',
                'description' => 'Shows the list of POS Hires',
                'class' => App\Reports\Sections\POSHire\POSHires::class,
                'exportable' => \App\Exports\POSHireExport::class,
                'filter' => \App\core\Filters\POSHireFilters::class,
                'model' => \App\models\POSHire::class,
                'views' => 'pos-hire',
                'type' => 'instant',
                'section' => 'terminals',
            ],[
                'name' => 'Users',
                'description' => 'Shows lists of user based on the filters',
                'class' => App\Reports\Sections\Users\Users::class,
                'exportable' => \App\Exports\UsersExport::class,
                'filter' => \App\core\Filters\UserFilters::class,
                'model' => \App\User::class,
                'views' => 'users',
                'type' => 'instant',
                'section' => 'users',
            ],
        ];

        foreach ($data as $item)
        {

            \App\models\Report::query()->create([
                'name' => $item['name'],
                'description' => $item['description'],
                'class' => $item['class'],
                'views' => $item['views'],
                'type' => $item['type'],
                'section' => $item['section'],
                'exportable' => $item['exportable'],
                'filter' => $item['filter'],
                'model' => $item['model'],
            ]);

            echo "Added  : {$item['name']} - {$item['description']} - {$item['class']}" . PHP_EOL;

        }

    }

    public static function addother(){

        echo 'Adding  : Request Type Transactions' . PHP_EOL;

        $data = [
          [ 'name' => '00' , 'desc' => 'Goods and services' ],
          [ 'name' => '01' , 'desc' =>  'Cash withdrawal' ],
          [ 'name' => '02' , 'desc' =>  'Debit adjustment' ],
          [ 'name' => '03' , 'desc' =>  'Check cash/guarantee' ],
          [ 'name' => '04' , 'desc' =>  'Check verification' ],
          [ 'name' => '05' , 'desc' =>  'Eurocheque' ],
          [ 'name' => '06' , 'desc' =>  'Traveller check' ],
          [ 'name' => '07' , 'desc' =>  'Letter of credit' ],
          [ 'name' => '08' , 'desc' =>  'Giro (postal banking)' ],
          [ 'name' => '09' , 'desc' =>  'Goods and services with cash back' ],
          [ 'name' => '10' , 'desc' =>  'Non-cash e.g. wire transfer' ],
          [ 'name' => '11' , 'desc' =>  'Quasi-cash and scrip' ],
          [ 'name' => '12' , 'desc' =>  'General debit ' ],
          [ 'name' => '19' , 'desc' =>  'Fee collection' ],
          [ 'name' => '20' , 'desc' =>  'Returns ' ],
          [ 'name' => '21' , 'desc' =>  'Deposit' ],
          [ 'name' => '22' , 'desc' =>  'Credit adjustment' ],
          [ 'name' => '23' , 'desc' =>  'Check deposit guarantee' ],
          [ 'name' => '24' , 'desc' =>  'Check deposit' ],
          [ 'name' => '25' , 'desc' =>  'General credit ' ],
          [ 'name' => '28' , 'desc' =>  'Merchandise dispatch' ],
          [ 'name' => '29' , 'desc' =>  'Funds disbursement' ],
          [ 'name' => '30' , 'desc' =>  'Available funds inquiry' ],
          [ 'name' => '31' , 'desc' =>  'Balance inquiry' ],
          [ 'name' => '32' , 'desc' =>  'General inquiry ' ],
          [ 'name' => '35' , 'desc' =>  'Full-Statement inquiry' ],
          [ 'name' => '36' , 'desc' =>  'Merchandise inquiry' ],
          [ 'name' => '37' , 'desc' =>  'Card verification inquiry' ],
          [ 'name' => '38' , 'desc' =>  'Mini-statement inquiry' ],
          [ 'name' => '39' , 'desc' =>  'Linked account inquiry' ],
          [ 'name' => '40' , 'desc' =>  'Cardholder accounts transfer' ],
          [ 'name' => '42' , 'desc' =>  'General transfer ' ],
          [ 'name' => '50' , 'desc' =>  'Payment from account' ],
          [ 'name' => '51' , 'desc' =>  'Payment by deposit' ],
          [ 'name' => '52' , 'desc' =>  'General payment ' ],
          [ 'name' => '53' , 'desc' =>  'Payment to account' ],
          [ 'name' => '54' , 'desc' =>  'Payment from account to account' ],
          [ 'name' => '90' , 'desc' =>  'Place hold on card' ],
          [ 'name' => '91' , 'desc' =>  'General admin ' ],
          [ 'name' => '92' , 'desc' =>  'Change PIN' ],
          [ 'name' => '93' , 'desc' =>  'Dead-end general admin ' ],
        ];
        foreach ($data as $item) {

            \App\models\TransactionType::query()->create([
                'description' => $item['desc'],
                'code' => $item['name'],
            ]);

            echo "Added  : {$item['name']} - {$item['desc']}" . PHP_EOL;
        }

        echo 'Adding  : Request Type Transactions' . PHP_EOL;

        $data = [
            [ 'name' => '00' , 'desc' => 'Approved or completed successfully' ],
            [ 'name' => '01' , 'desc' => 'Refer to card issuer' ],
            [ 'name' => '02' , 'desc' => 'Refer to card issuer, special condition' ],
            [ 'name' => '03' , 'desc' => 'Invalid merchant' ],
            [ 'name' => '04' , 'desc' => 'Pick-up card' ],
            [ 'name' => '05' , 'desc' => 'Do not honor' ],
            [ 'name' => '06' , 'desc' => 'Error' ],
            [ 'name' => '07' , 'desc' => 'Pick-up card, special condition' ],
            [ 'name' => '08' , 'desc' => 'Honor with identification' ],
            [ 'name' => '09' , 'desc' => 'Request in progress' ],
            [ 'name' => '10' , 'desc' => 'Approved, partial' ],
            [ 'name' => '11' , 'desc' => 'Approved, VIP' ],
            [ 'name' => '12' , 'desc' => 'Invalid transaction' ],
            [ 'name' => '13' , 'desc' => 'Invalid amount' ],
            [ 'name' => '14' , 'desc' => 'Invalid card number' ],
            [ 'name' => '15' , 'desc' => 'No such issuer' ],
            [ 'name' => '16' , 'desc' => 'Approved, update track 3' ],
            [ 'name' => '17' , 'desc' => 'Customer cancellation' ],
            [ 'name' => '18' , 'desc' => 'Customer dispute' ],
            [ 'name' => '19' , 'desc' => 'Re-enter transaction' ],
            [ 'name' => '20' , 'desc' => 'Invalid response' ],
            [ 'name' => '21' , 'desc' => 'No action taken' ],
            [ 'name' => '22' , 'desc' => 'Suspected malfunction' ],
            [ 'name' => '23' , 'desc' => 'Unacceptable transaction fee' ],
            [ 'name' => '24' , 'desc' => 'File update not supported' ],
            [ 'name' => '25' , 'desc' => 'Unable to locate record' ],
            [ 'name' => '26' , 'desc' => 'Duplicate record' ],
            [ 'name' => '27' , 'desc' => 'File update field edit error' ],
            [ 'name' => '28' , 'desc' => 'File update file locked' ],
            [ 'name' => '29' , 'desc' => 'File update failed' ],
            [ 'name' => '30' , 'desc' => 'Format error' ],
            [ 'name' => '31' , 'desc' => 'Bank not supported' ],
            [ 'name' => '32' , 'desc' => 'Completed partially' ],
            [ 'name' => '33' , 'desc' => 'Expired card, pick-up' ],
            [ 'name' => '34' , 'desc' => 'Suspected fraud, pick-up' ],
            [ 'name' => '35' , 'desc' => 'Contact acquirer, pick-up' ],
            [ 'name' => '36' , 'desc' => 'Restricted card, pick-up' ],
            [ 'name' => '37' , 'desc' => 'Call acquirer security, pick-up' ],
            [ 'name' => '38' , 'desc' => 'PIN tries exceeded, pick-up' ],
            [ 'name' => '39' , 'desc' => 'No credit account' ],
            [ 'name' => '40' , 'desc' => 'Function not supported' ],
            [ 'name' => '41' , 'desc' => 'Lost card, pick-up' ],
            [ 'name' => '42' , 'desc' => 'No universal account' ],
            [ 'name' => '43' , 'desc' => 'Stolen card, pick-up' ],
            [ 'name' => '44' , 'desc' => 'No investment account' ],
            [ 'name' => '45' , 'desc' => 'Account closed' ],
            [ 'name' => '46' , 'desc' => 'Identification required' ],
            [ 'name' => '47' , 'desc' => 'Identification cross-check required' ],
            [ 'name' => '48' , 'desc' => 'No customer record' ],
            [ 'name' => '49' , 'desc' => 'Reserved for future Realtime use' ],
            [ 'name' => '50' , 'desc' => 'Reserved for future Realtime use' ],
            [ 'name' => '51' , 'desc' => 'Not sufficient funds' ],
            [ 'name' => '52' , 'desc' => 'No check account' ],
            [ 'name' => '53' , 'desc' => 'No savings account' ],
            [ 'name' => '54' , 'desc' => 'Expired card' ],
            [ 'name' => '55' , 'desc' => 'Incorrect PIN' ],
            [ 'name' => '56' , 'desc' => 'No card record' ],
            [ 'name' => '57' , 'desc' => 'Transaction not permitted to cardholder' ],
            [ 'name' => '58' , 'desc' => 'Transaction not permitted on terminal' ],
            [ 'name' => '59' , 'desc' => 'Suspected fraud' ],
            [ 'name' => '60' , 'desc' => 'Contact acquirer' ],
            [ 'name' => '61' , 'desc' => 'Exceeds withdrawal limit' ],
            [ 'name' => '62' , 'desc' => 'Restricted card' ],
            [ 'name' => '63' , 'desc' => 'Security violation' ],
            [ 'name' => '64' , 'desc' => 'Original amount incorrect' ],
            [ 'name' => '65' , 'desc' => 'Exceeds withdrawal frequency' ],
            [ 'name' => '66' , 'desc' => 'Call acquirer security' ],
            [ 'name' => '67' , 'desc' => 'Hard capture' ],
            [ 'name' => '68' , 'desc' => 'Response received too late' ],
            [ 'name' => '69' , 'desc' => 'Advice received too late' ],
            [ 'name' => '70' , 'desc' => 'Reserved for future Realtime use' ],
            [ 'name' => '71' , 'desc' => 'Reserved for future Realtime use' ],
            [ 'name' => '72' , 'desc' => 'Reserved for future Realtime use' ],
            [ 'name' => '73' , 'desc' => 'Reserved for future Realtime use' ],
            [ 'name' => '74' , 'desc' => 'Reserved for future Realtime use' ],
            [ 'name' => '75' , 'desc' => 'PIN tries exceeded' ],
            [ 'name' => '76' , 'desc' => 'Reserved for future Realtime use' ],
            [ 'name' => '77' , 'desc' => 'Intervene, bank approval required' ],
            [ 'name' => '78' , 'desc' => 'Intervene, bank approval required for partial amount' ],
            [ 'name' => '79' , 'desc' => 'Reserved for client-specific use (declined)' ],
            [ 'name' => '80' , 'desc' => 'Reserved for client-specific use (declined)' ],
            [ 'name' => '81' , 'desc' => 'Reserved for client-specific use (declined)' ],
            [ 'name' => '82' , 'desc' => 'Reserved for client-specific use (declined)' ],
            [ 'name' => '83' , 'desc' => 'Reserved for client-specific use (declined)' ],
            [ 'name' => '84' , 'desc' => 'Reserved for client-specific use (declined)' ],
            [ 'name' => '85' , 'desc' => 'Reserved for client-specific use (declined)' ],
            [ 'name' => '86' , 'desc' => 'Reserved for client-specific use (declined)' ],
            [ 'name' => '87' , 'desc' => 'Reserved for client-specific use (declined)' ],
            [ 'name' => '87' , 'desc' => 'Reserved for client-specific use (declined)' ],
            [ 'name' => '88' , 'desc' => 'Reserved for client-specific use (declined)' ],
            [ 'name' => '89' , 'desc' => 'Reserved for client-specific use (declined)' ],
            [ 'name' => '90' , 'desc' => 'Cut-off in progress' ],
            [ 'name' => '91' , 'desc' => 'Issuer or switch inoperative' ],
            [ 'name' => '92' , 'desc' => 'Routing error' ],
            [ 'name' => '93' , 'desc' => 'Violation of law' ],
            [ 'name' => '94' , 'desc' => 'Duplicate transaction' ],
            [ 'name' => '95' , 'desc' => 'Reconcile error' ],
            [ 'name' => '96' , 'desc' => 'System malfunction' ],
            [ 'name' => '97' , 'desc' => 'Reserved for future Realtime use' ],
            [ 'name' => '98' , 'desc' => 'Exceeds cash limit' ],
            [ 'name' => '99' , 'desc' => 'Reserved for future Realtime use' ],
        ];

        foreach ($data as $item) {

            \App\models\ResponseCode::query()->create([
                'description' => $item['desc'],
                'code' => $item['name'],
            ]);

            echo "Added  : {$item['name']} - {$item['desc']}" . PHP_EOL;
        }

    }


    public static function add_users(): void
    {
        echo 'Adding Users' . PHP_EOL;

        \App\User::query()->create([
            'name' => 'Root POS-System',
            'email' => 'root@pos-managment.system',
            'role' => 9 ,
            'password' => \Illuminate\Support\Facades\Hash::make('#Password#AgriBank#@1#')
        ]);

        echo 'Added Root User' . PHP_EOL;

        \App\User::query()->create([
            'name' => 'Root-Helper POS-System',
            'email' => 'root-helper@pos-managment.system',
            'role' => 10 ,
            'password' => \Illuminate\Support\Facades\Hash::make('#Password#AgriBank#@1#')
        ]);

        echo 'Added Root-Helper User' . PHP_EOL;

        echo 'Added Prince User' . PHP_EOL;

        \App\User::query()->create([
            'name' => 'Prince Gurajena',
            'email' => 'pgurajena@agribank.co.zw',
            'role' => 5 ,
            'password' => \Illuminate\Support\Facades\Hash::make('wapdam98')
        ]);

        echo 'Done Adding Users' . PHP_EOL;

    }

    public static function add_terminals(): void
    {
        echo 'Getting Terminals' . PHP_EOL;

        $terminals = self::getTable('eftc_t24_terminal_lookup')->where(function (\Illuminate\Database\Query\Builder $builder) {

            $builder->orWhere('terminal_id', 'like', '8001%');
            $builder->orWhere('terminal_id', 'like', 'MP0%');
            $builder->orWhere('terminal_id', 'like', 'AGY%');

        })->get();

        $terminals_count = self::getTable('eftc_t24_terminal_lookup')->where(function (\Illuminate\Database\Query\Builder $builder) {

            $builder->orWhere('terminal_id', 'like', '8001%');
            $builder->orWhere('terminal_id', 'like', 'MP0%');
            $builder->orWhere('terminal_id', 'like', 'AGY%');

        })->count();

        $current = 0;

        foreach ($terminals as $terminal) {
            $current++;

            echo "[ - {$current} / {$terminals_count} - ] Looking at {$terminal->terminal_id} " . PHP_EOL;

            if ($account = \App\models\Account::query()->where('account', $terminal->account)->first()) {

                echo "[ - {$current} / {$terminals_count} - ] Account Number Exists {$terminal->account} - {$terminal->terminal_id} " . PHP_EOL;

                if ($t = self::getTable('eftc_hyp_base_term')->where('id', $terminal->terminal_id)->first()) {

                    echo "[ - {$current} / {$terminals_count} - ] Looking at {$terminal->terminal_id} " . PHP_EOL;

                    $account->addTerminal([

                        'terminal_id' => $terminal->terminal_id,
                        'trade_name' => $terminal->description,
                        'location' => self::getValueOrNull($t->city),
                        'system_serial_number' => self::getValueOrNull($t->term_serial_nr),
                        'model' => self::getValueOrNull($t->term_model),
                        'override_term_type' => $t->override_terminal_type

                    ]);

                }

            } else {

                echo "[ - {$current} / {$terminals_count} - ] New Account Number : {$terminal->account} - {$terminal->terminal_id} " . PHP_EOL;

                $customer = \App\models\Customer::query()->create([
                    'name' => $terminal->description,
                ]);

                $account = $customer->addAccount([
                    'account' => $terminal->account,
                    'branch_code' => $terminal->branch_code
                ]);

                if ($t = self::getTable('eftc_hyp_base_term')->where('id', $terminal->terminal_id)->first()) {

                    echo "[ - {$current} / {$terminals_count} - ] Add Terminal : {$terminal->account} - {$terminal->terminal_id} - {$terminal->description} - {$t->term_model}" . PHP_EOL;

                    /** @noinspection PhpUndefinedMethodInspection */
                    /** @noinspection ReturnNullInspection */
                    $account->addTerminal([

                        'terminal_id' => $terminal->terminal_id,
                        'trade_name' => $terminal->description,
                        'location' => self::getValueOrNull($t->city),
                        'system_serial_number' => self::getValueOrNull($t->term_serial_nr),
                        'serial_number' => self::getValueOrNull($t->term_serial_nr),
                        'model' => self::getValueOrNull($t->term_model),
                        'override_term_type' => $t->override_terminal_type

                    ]);

                }

            }

        }
    }

    public static function add_pos_logs(): void
    {
        // Adding Logs

        echo 'Adding Logs' . PHP_EOL;

        $machines = \App\models\POSMachine::query()->limit(200)->get();

        foreach ($machines as $machine) {

            /** @noinspection CallableInLoopTerminationConditionInspection */
            for ($i = 0; $i < random_int(1, 6); $i++) {

                $id = random_int(1, 24);

                $system_value_log = \App\models\system\Log::query()->find($id);

                $log_id = $id;

                /** @noinspection NullPointerExceptionInspection */
                $log = $system_value_log->description;
                /** @noinspection NullPointerExceptionInspection */
                $level = $system_value_log->level;

                $rand = random_int(100, 990);

                $terminal_log = \App\models\Terminal::query()
                    ->where('id', '=', $rand)->first();

                /** @noinspection NullPointerExceptionInspection */
                $machine->addLog([
                    'terminal' => $terminal_log->terminal_id,
                    'account' => $terminal_log->account_id,
                    'log' => $log,
                    'log_id' => $log_id,
                    'level' => $level,
                ]);

                /** @noinspection NullPointerExceptionInspection */
                echo "Add Logs - {$machine->serial_number} - {$terminal_log->terminal_id} - {$level} - {$log} - {$log_id}" . PHP_EOL;

            }

        }
    }

    public static function add_requests(): void
    {
        echo 'Adding Requests' . PHP_EOL;

        for ($i = 1; $i <= 300; $i++) {

            echo "Creating Request : {$i}" . PHP_EOL;

            $request_type = random_int(1, 7);

            $data = [];

            switch ($request_type) {

                case 1:

                    // New Terminal

                    $rand = random_int(500, 2000);

                    echo "Using : {$rand}" . PHP_EOL;

                    $acc = self::getRandomAccount($rand);

                    $terminal_type = random_int(1, 4);
                    $number = random_int(1, 3);

                    $data = [
                        'account' => $acc,
                        'location' => 'Harare',
                        'terminal_type' => $terminal_type,
                        'number' => $number,
                        'trade_name' => 'Test Trade Name'
                    ];

                    echo "New Terminal Request : {$acc} : {$number} : {$terminal_type}" . PHP_EOL;

                    break;
                case 2:

                    // Reallocation

                    $rand = random_int(500, 2000);

                    /** @noinspection NullPointerExceptionInspection */
                    $terminal = self::getRandomTerminal($rand);

                    /** @noinspection NullPointerExceptionInspection */
                    $account = self::getRandomAccount($rand);


                    $data = [
                        'terminal' => $terminal,
                        'new' => [
                            'account' => $account,
                            'location' => 'Harare',
                            'trade_name' => 'Prince LTD'
                        ]
                    ];

                    echo "Reallocation : {$terminal} : to : {$account} " . PHP_EOL;

                    break;
                case 3:

                    // Change of details

                    $rand = random_int(500, 2000);

                    /** @noinspection NullPointerExceptionInspection */
                    $terminal = self::getRandomTerminal($rand);
                    /** @noinspection NullPointerExceptionInspection */
                    $account = self::getRandomAccount($rand);


                    $data = [
                        'terminal' => $terminal,
                        'new' => [
                            'account' => $account,
                            'location' => 'Harare',
                            'trade_name' => 'Prince LTD'
                        ]
                    ];

                    echo "Change of Details : {$terminal} : to : {$account} " . PHP_EOL;

                    break;
                case 4:

                    //POS Repair

                    $log_id = random_int(50, 250);

                    $rand = random_int(500, 2000);

                    /** @noinspection NullPointerExceptionInspection */
                    $terminal = self::getRandomTerminalWithInfo($rand);
                    $serial = '321-612-674';

                    if ($terminal->system_serial_number) {
                        $serial = $terminal->system_serial_number;
                    }

                    $data = [
                        'serial_number' => $serial,
                        'terminal' => $terminal->terminal_id,
                        'log' => $log_id
                    ];

                    /** @noinspection NullPointerExceptionInspection */
                    /** @noinspection PhpUndefinedFieldInspection */
                    $log = POSMachineLog::query()->find($log_id)->log;

                    echo "POS Repair : {$log_id} : {$serial} : to : {$log} " . PHP_EOL;

                    break;
                case 5:

//                    $rand = random_int(500, 2000);
//
//                    /** @noinspection NullPointerExceptionInspection */
//                    $terminal = self::getRandomTerminalWithInfo($rand);
//
//                    $serial = '321-612-674';
//
//                    if ($terminal->system_serial_number) {
//                        $serial = $terminal->system_serial_number;
//                    }
//
//                    $terminal_id = $terminal->terminal_id;
//                    $serial_number = $serial;
//
//                    $data = [
//                        'terminal' => $terminal_id,
//                        'serial_number' => $serial_number,
//                    ];
//
//                    echo "Terminal Testing : {$terminal_id} :  {$serial_number} " . PHP_EOL;

                    // Change of details

                    $rand = random_int(500, 2000);

                    /** @noinspection NullPointerExceptionInspection */
                    $terminal = self::getRandomTerminal($rand);
                    /** @noinspection NullPointerExceptionInspection */
                    $account = self::getRandomAccount($rand);


                    $data = [
                        'terminal' => $terminal,
                        'new' => [
                            'account' => $account,
                            'location' => 'Harare',
                            'trade_name' => 'Prince LTD'
                        ]
                    ];

                    echo "Change of Details : {$terminal} : to : {$account} " . PHP_EOL;

                    break;

                case 6:

                    // Replacement

                    $rand = random_int(500, 2000);

                    /** @noinspection NullPointerExceptionInspection */
                    $terminal = self::getRandomTerminalWithInfo($rand);

                    $serial = '321-612-674';

                    if ($terminal->system_serial_number) {
                        $serial = $terminal->system_serial_number;
                    }

                    $terminal_id = $terminal->terminal_id;
                    $serial_number = $serial;

                    $data = [
                        'terminal' => $terminal_id,
                        'serial_number' => $serial_number,
                    ];

                    echo "Terminal Testing : {$terminal_id} :  {$serial_number} " . PHP_EOL;
                    break;

                    case 7:

                    // Replacement

                        $data = [
                        'customer' => '24',
                        'account' => '040000291287',
                        'bank' => 'Agribank'
                    ];

                    echo "POS hire : {$data['customer']} :  {$data['account']} :  {$data['bank']} " . PHP_EOL;
                    break;

                default:

            }

            $state = \App\models\system\RequestType::query()->find($request_type)->name;

            echo 'Found : '.$state.PHP_EOL;

            $state = \App\models\system\RequestState::query()
                            ->where('name', $state )
                            ->orderBy('id','asc')
                            ->first();

            $request_type = \App\models\system\RequestType::query()->find($request_type);

            /** @noinspection NullPointerExceptionInspection */
            /** @noinspection PhpUndefinedFieldInspection */
            Request::query()->create([
                'requester_id' => 4,
                'role_assigned' => $state->role,
                'branch_code' => '001',
                'type' => $request_type->name ,
                'data' => $data,
                'state' => $state->id,
            ]);

        }
    }

    public static function addTellers(): void
    {
        echo 'Adding Tellers' . PHP_EOL;

        $tellers = self::getTable('eftc_teller')->get();

        foreach ($tellers as $teller) {

            echo "Adding Teller : {$teller->teller_card} - {$teller->current_terminal_id} - {$teller->teller_first_name}" . PHP_EOL;

            \App\models\Teller::query()->create([

                'card_number' => $teller->teller_card,
                'linked_terminal' => $teller->current_terminal_id,
                'supervisor' => $teller->supervisor,
                'name' => $teller->teller_first_name,

            ]);

        }
    }

    public static function add_branches(): void
    {
        echo 'Adding Branches' . PHP_EOL;

        $branches = self::getTable('eftc_t24_branch_lookup')->get();

        foreach ($branches as $branch) {

            echo "Adding branch : {$branch->branch_code} - {$branch->mnemonic} - {$branch->description}" . PHP_EOL;

            \App\models\Branch::query()->create([

                'branch_code' => $branch->branch_code,
                'name' => $branch->mnemonic,
                'short_name' => $branch->description,

            ]);

        }

        \App\models\Branch::query()->create([

            'branch_code' => 'eft',
            'name' => 'EFT',
            'short_name' => 'EFT',

        ]);

    }

    public static function add_pos_machines()
    {
        echo 'Adding POS Machines' . PHP_EOL;

        /** @noinspection ReturnFalseInspection */
        if (($handle = fopen("serial_numbers.csv", "r")) !== FALSE) {

            /** @noinspection ReturnFalseInspection */
            while (($data = fgetcsv($handle, null, ",")) !== FALSE) {

                if (isset($data[0])) {

                    echo 'POS - ' . $data[0] . PHP_EOL;

                    \App\models\POSMachine::query()->create([
                        'serial_number' => $data[0],
                    ]);

                }
            }

            fclose($handle);
        }

        echo 'Done POS Machines' . PHP_EOL;
    }

    /**
     * @param $rand
     * @return mixed
     */
    public static function getRandomAccount($rand)
    {
        /** @noinspection PhpUndefinedFieldInspection */
        return Account::query()->find($rand)->account;
    }
    /**
     * @param $rand
     * @return mixed
     */
    public static function getRandomTerminal($rand)
    {
        /** @noinspection PhpUndefinedFieldInspection */
        return Terminal::query()->find($rand)->terminal_id;
    }

    /**
     * @param $rand
     * @return mixed
     */
    public static function getRandomTerminalWithInfo($rand)
    {
        /** @noinspection PhpUndefinedFieldInspection */
        return Terminal::query()->find($rand);
    }



    public static function getTable($name): \Illuminate\Database\Query\Builder
    {
        return DB::connection('sqlsrv_live')->table($name);
    }

    public static function getConnection(): \Illuminate\Database\ConnectionInterface
    {
        return DB::connection('sqlsrv_live');
    }

    public static function getValueOrNull($i){

        if ( $i ){

            return $i;
        }

        return null;
    }


    public static function add_system_values()
    {
        echo 'Adding  : System Variables' . PHP_EOL;
        echo 'Adding  : Type of Requests' . PHP_EOL;

        $data = [
            ['id' => 1,
                'description' => 'New Terminal',
                'name'=>'new-terminal',
                'execution' => 'auth'
            ],
            ['id' => 2,
                'description' => 'Reallocation',
                'name'=>'re-allocation',
                'execution' => 'auth'
            ],
            ['id' => 3,
                'description' => 'Change of Details',
                'name'=>'change-of-details',
                'execution' => 'auth'

            ],
            ['id' => 4,
                'description' => 'POS Repair',
                'name'=>'pos-repair',
                'execution' => 'auth'
            ],
            ['id' => 5,
                'description' => 'Terminal Testing',
                'name'=>'terminal-testing',
                'execution' => 'instant'
            ],
            ['id' => 6,
                'description' => 'Replacement',
                'name'=>'replacement',
                'execution' => 'auth'
            ],
            ['id' => 6,
                'description' => 'POS Hire',
                'name'=>'pos-hire',
                'execution' => 'auth'
            ],
            ['id' => 6,
                'description' => 'Change Account',
                'name'=>'change-account',
                'execution' => 'auth'
            ],
            ['id' => 7,
                'description' => 'Change Customer',
                'name'=>'change-customer',
                'execution' => 'auth'
            ],
        ];
        foreach ($data as $item) {

            \App\models\system\RequestType::query()->create([
                'description' => $item['description'],
                'name' => $item['name'],
                'execution' => $item['execution']
            ]);

            echo "Added  : {$item['id']} - {$item['execution']} - {$item['description']} " . PHP_EOL;
        }


        echo 'Adding  : Type system values' . PHP_EOL;

        $data = [
            [
                'name'=>'pso-hire-account',
                'value' => '040000291287'
            ],[
                'name'=>'pso-hire-branch',
                'value' => '001'
            ],[
                'name'=>'daily-transactions-start',
                'value' => ''
            ],[
                'name'=>'daily-transactions-target',
                'value' => ''
            ],[
                'name'=>'daily-transactions-current',
                'value' => ''
            ],[
                'name'=>'bulk-transactions-start',
                'value' => ''
            ],[
                'name'=>'bulk-transactions-target',
                'value' => ''
            ],[
                'name'=>'bulk-transactions-current',
                'value' => ''
            ]

        ];
        foreach ($data as $item) {

            \App\models\system\SystemValue::query()->create([
                'name' => $item['name'],
                'value' => $item['value'],
            ]);

            echo "Added  : {$item['name']} - {$item['value']}" . PHP_EOL;
        }

        echo 'Adding  : Locks' . PHP_EOL;

        $data = [
            ['id' => 1,
                'description' => 'Terminal ID Generation'
            ],
        ];
        foreach ($data as $item) {

            \App\models\system\RecordLock::query()->create([
                'description' => $item['description'],
            ]);

            echo "Added  : {$item['id']} - {$item['description']}" . PHP_EOL;

        }

        echo 'Adding : Request States' . PHP_EOL;

        $data = [
            ['id' => 1,
                'description' => 'Open | Awaiting Branch Manager Auth'
            ],
            ['id' => 2,
                'description' => 'Open | Awaiting merchant-services Auth'
            ],
            ['id' => 3,
                'description' => 'Open | Awaiting merchant-services Manager Auth'
            ],
            ['id' => 4,
                'description' => 'Open | Awaiting E-channels Implementation'
            ],
            ['id' => 5,
                'description' => 'Open | Awaiting Root Implementation'
            ],
            ['id' => 6,
                'description' => 'Open | Awaiting merchant-services Confirmation'
            ],
            ['id' => 7,
                'description' => 'Open | Awaiting E-channels Confirmation'
            ],
            ['id' => 8,
                'description' => 'Closed | Request Completed'
            ],
            ['id' => 9,
                'description' => 'Open | Awaiting Branch Manager Confirmation'
            ]

        ];
        foreach ($data as $item) {

            \App\models\system\RequestDescription::query()->create([
                'description' => $item['description'],
            ]);

            echo "Added  : {$item['id']} - {$item['description']}" . PHP_EOL;

        }

        echo 'Adding : Roles' . PHP_EOL;

        $data = [
            ['id' => 1,
                'description' => 'branch'
            ],
            ['id' => 2,
                'description' => 'branch-manager'
            ],
            ['id' => 3,
                'description' => 'merchant-services'
            ],
            ['id' => 4,
                'description' => 'merchant-services-manager'
            ],
            ['id' => 5,
                'description' => 'e-channels'
            ],
            ['id' => 6,
                'description' => 'risk'
            ],
            ['id' => 7,
                'description' => 'audit'
            ],
            ['id' => 8,
                'description' => 'reports'
            ],
            ['id' => 9,
                'description' => 'root'
            ],
            ['id' => 10,
                'description' => 'root-helper'
            ],
        ];
        foreach ($data as $item) {

            \App\models\system\Role::query()->create([
                'name' => $item['description'],
                'level' => $item['id']
            ]);

            echo "Added  : {$item['id']} - {$item['description']}" . PHP_EOL;


        }

        echo 'Adding : POS Location' . PHP_EOL;

        $data = [
            ['id' => 1,
                'description' => 'customer'
            ],
            ['id' => 2,
                'description' => 'branch'
            ],
            ['id' => 3,
                'description' => 'branch-swift-ebanking'
            ],
            ['id' => 4,
                'description' => 'ebanking'
            ],
            ['id' => 5,
                'description' => 'ebanking-to-echannels'
            ],
            ['id' => 6,
                'description' => 'echannels'
            ],
            ['id' => 7,
                'description' => 'eft'
            ],
            ['id' => 8,
                'description' => 'echannels-to-ebanking'
            ],
            ['id' => 9,
                'description' => 'ebanking-swift-branch'
            ],
            ['id' => 10 ,
                'description' => 'unknown'
            ],
        ];
        foreach ($data as $item) {

            \App\models\system\POSLocation::query()->create([
                'description' => $item['description'],
            ]);

            echo "Added  : {$item['id']} - {$item['description']}" . PHP_EOL;


        }

        echo 'Adding : POS Logs' . PHP_EOL;

        $data = [
            ['id' => 1,
                'description' => 'Please try again  - CE - Connection Error',
                'level' => '1'
            ],
            ['id' => 2,
                'description' => 'Please try again  - NA - No Answer',
                'level' => '1'
            ],
            ['id' => 3,
                'description' => 'Please try again  - ND - No Data',
                'level' => '1'
            ],
            ['id' => 4,
                'description' => 'Temper Error - After Repair',
                'level' => '5'
            ],
            ['id' => 5,
                'description' => 'Tamper error',
                'level' => '4'
            ],
            ['id' => 6,
                'description' => 'White screen',
                'level' => '1'
            ],
            ['id' => 7,
                'description' => 'Not charging - faulty charging port ',
                'level' => '3'
            ],
            ['id' => 8,
                'description' => 'Keypads not responding',
                'level' => '3'
            ],
            ['id' => 9,
                'description' => 'Port not set',
                'level' => '3'
            ],
            ['id' => 10,
                'description' => 'Faulty ethernet port',
                'level' => '3'
            ],
            ['id' => 11,
                'description' => 'Printer error ',
                'level' => '1'
            ],
            ['id' => 12,
                'description' => 'Printer not pulling paper',
                'level' => '3'
            ],
            ['id' => 13,
                'description' => 'Printer printing faint',
                'level' => '3'
            ],
            ['id' => 14,
                'description' => 'Call customer service ',
                'level' => '4'
            ],
            ['id' => 15,
                'description' => 'Broken screen',
                'level' => '3'
            ],
            ['id' => 16,
                'description' => 'Not switching On',
                'level' => '3'
            ],
            ['id' => 17,
                'description' => 'Please remove card',
                'level' => '3'
            ],
            ['id' => 18,
                'description' => 'Not reading sim card ',
                'level' => '3'
            ],
            ['id' => 19,
                'description' => 'Not reading swipe card',
                'level' => '3'
            ],
            ['id' => 20,
                'description' => 'Teller already logged on',
                'level' => '1'
            ],
            ['id' => 21,
                'description' => 'Settlement Required',
                'level' => '1'
            ],
            ['id' => 22,
                'description' => 'Please Initialize',
                'level' => '1'
            ],
            ['id' => 23,
                'description' => 'Settlement Required - No batch Totals',
                'level' => '2'
            ],
            ['id' => 24,
                'description' => 'Beyond economic repair',
                'level' => '5'
            ],
            ['id' => 25,
                'description' => 'White screen - After Charging',
                'level' => '3'
            ],

            ['id' => 26,
                'description' => 'Printer Error - After Charging',
                'level' => '3'
            ],

            ['id' => 27,
                'description' => 'Refer To Card Issuer',
                'level' => '1'
            ],

        ];
        foreach ($data as $item) {

            \App\models\system\Log::query()->create([
                'description' => $item['description'],
                'level' => $item['level']
            ]);

            echo "Added : {$item['id']} - {$item['level']} - {$item['description']}" . PHP_EOL;

        }

        echo 'Adding : Request States Logs' . PHP_EOL;

        $data = [
            [
                'name' => 'new-terminal', 'description' => 1 , 'action' => 'authorize', 'role' => 'branch-manager',
            ],[
                'name' => 'new-terminal', 'description' => 2 , 'action' => 'authorize', 'role' => 'merchant-services',
            ],[
                'name' => 'new-terminal', 'description' => 3 , 'action' => 'authorize', 'role' => 'merchant-services-manager',
            ],[
                'name' => 'new-terminal', 'description' => 4 , 'action' => 'implement', 'role' => 'e-channels',
            ],[
                'name' => 'new-terminal', 'description' => 5 , 'action' => 'implement', 'role' => 'root',
            ],[
                'name' => 'new-terminal', 'description' => 7 , 'action' => 'confirm', 'role' => 'e-channels',
            ],[
                'name' => 'new-terminal', 'description' => 6 , 'action' => 'confirm', 'role' => 'merchant-services',
            ],[
                'name' => 'new-terminal', 'description' => 8 , 'action' => 'close', 'role' => 'root',
            ],[
                'name' => 're-allocation', 'description' => 2 , 'action' => 'authorize', 'role' => 'merchant-services',
            ],[
                'name' => 're-allocation', 'description' => 4 , 'action' => 'implement', 'role' => 'e-channels',
            ],[
                'name' => 're-allocation', 'description' => 5 , 'action' => 'implement', 'role' => 'root',
            ],[
                'name' => 're-allocation', 'description' => 7, 'action' => 'confirm', 'role' => 'e-channels',
            ],[
                'name' => 're-allocation', 'description' => 6 , 'action' => 'confirm', 'role' => 'merchant-services',
            ],[
                'name' => 're-allocation', 'description' => 8 , 'action' => 'close', 'role' => 'root',
            ],[
                'name' => 'change-of-details', 'description' => 2 , 'action' => 'authorize', 'role' => 'merchant-services',
            ],[
                'name' => 'change-of-details', 'description' => 4 , 'action' => 'implement', 'role' => 'e-channels',
            ],[
                'name' => 'change-of-details', 'description' => 5, 'action' => 'implement', 'role' => 'root',
            ],[
                'name' => 'change-of-details', 'description' => 7 , 'action' => 'confirm', 'role' => 'e-channels',
            ],[
                'name' => 'change-of-details', 'description' => 6 , 'action' => 'confirm', 'role' => 'merchant-services',
            ],[
                'name' => 'change-of-details', 'description' => 8 , 'action' => 'close', 'role' => 'root',
            ],[
                'name' => 'pos-repair', 'description' => 2 , 'action' => 'authorize', 'role' => 'merchant-services',
            ],[
                'name' => 'pos-repair', 'description' => 4 , 'action' => 'implement', 'role' => 'e-channels',
            ],[
                'name' => 'pos-repair', 'description' => 5, 'action' => 'implement', 'role' => 'root',
            ],[
                'name' => 'pos-repair', 'description' => 7 , 'action' => 'confirm', 'role' => 'e-channels',
            ],[
                'name' => 'pos-repair', 'description' => 6 , 'action' => 'confirm', 'role' => 'merchant-services',
            ],[
                'name' => 'pos-repair', 'description' => 8 , 'action' => 'close', 'role' => 'root',
            ],[
                'name' => 'terminal-testing', 'description' => 5 , 'action' => 'implement', 'role' => 'root',
            ],[
                'name' => 'terminal-testing', 'description' => 8 , 'action' => 'close', 'role' => 'root',
            ],[
                'name' => 'replacement', 'description' => 2 , 'action' => 'authorize', 'role' => 'merchant-services',
            ],[
                'name' => 'replacement', 'description' => 4 , 'action' => 'implement', 'role' => 'e-channels',
            ],[
                'name' => 'replacement', 'description' => 4 , 'action' => 'implement', 'role' => 'root',
            ],[
                'name' => 'replacement', 'description' => 7 , 'action' => 'confirm', 'role' => 'e-channels',
            ],[
                'name' => 'replacement', 'description' => 6 , 'action' => 'confirm', 'role' => 'merchant-services',
            ],[
                'name' => 'replacement', 'description' => 8 , 'action' => 'close', 'role' => 'root',
            ],[
                'name' => 'pos-hire', 'description' => 1 , 'action' => 'authorize', 'role' => 'branch-manager',
            ],[
                'name' => 'pos-hire', 'description' => 2 , 'action' => 'authorize', 'role' => 'merchant-services',
            ],[
                'name' => 'pos-hire', 'description' => 3 , 'action' => 'authorize', 'role' => 'merchant-services-manager',
            ],[
                'name' => 'pos-hire', 'description' => 4 , 'action' => 'implement', 'role' => 'e-channels',
            ],[
                'name' => 'pos-hire', 'description' => 5 , 'action' => 'implement', 'role' => 'root',
            ],[
                'name' => 'pos-hire', 'description' => 7 , 'action' => 'confirm', 'role' => 'e-channels',
            ],[
                'name' => 'pos-hire', 'description' => 6 , 'action' => 'confirm', 'role' => 'merchant-services',
            ],[
                'name' => 'pos-hire', 'description' => 8 , 'action' => 'close', 'role' => 'root',
            ],[
                'name' => 'change-account', 'description' => 2 , 'action' => 'implement', 'role' => 'merchant-services',
            ],[
                'name' => 'change-account', 'description' => 5 , 'action' => 'implement', 'role' => 'root',
            ],[
                'name' => 'change-account', 'description' => 6 , 'action' => 'confirm', 'role' => 'merchant-services',
            ],[
                'name' => 'change-account', 'description' => 8 , 'action' => 'close', 'role' => 'root',
            ],[
                'name' => 'change-customer', 'description' => 1 , 'action' => 'implement', 'role' => 'branch-manager',
            ],[
                'name' => 'change-customer', 'description' => 5 , 'action' => 'implement', 'role' => 'root',
            ],[
                'name' => 'change-customer', 'description' => 8 , 'action' => 'close', 'role' => 'root',
            ],
        ];

        foreach ($data as $item) {

            \App\models\system\RequestState::query()->create([
                'name' => $item['name'],
                'action' => $item['action'],
                'role' => $item['role'],
                'description' => $item['description'],
            ]);

            echo "Added : {$item['name']} - {$item['action']} - {$item['role']}" . PHP_EOL;

        }
    }
}
