<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTerminalsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('terminals', function (Blueprint $table) {

            $table->increments('id');
            $table->string('account_id');
            $table->string('terminal_id');
            $table->string('override_term_type')->nullable();
            $table->string('model')->nullable();
            $table->string('term_type')->nullable();
            $table->string('system_serial_number')->nullable();
            $table->string('serial_number')->nullable();
            $table->string('trade_name')->nullable();
            $table->string('location')->nullable();
            $table->boolean('active')->default(1);
            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('terminals');
    }
}
