<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePOSMachinesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('p_o_s_machines', function (Blueprint $table) {

            $table->increments('id');
            $table->string('serial_number');
            $table->string('asset_code')->nullable();
            $table->string('model')->nullable();
            $table->string('location')->nullable();
            $table->string('branch')->nullable();
            $table->boolean('working_state')->default(true);
            $table->string('pos_condition')->nullable();
            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p_o_s_machines');
    }
}
