<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateReportRequestsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('report_requests', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('requester_id');
            $table->text('params');
            $table->integer('report_id');
            $table->string('report_path')->nullable();
            $table->boolean('completed')->nullable();
            $table->boolean('canceled')->nullable();
            $table->boolean('excel_disabled')->nullable();
            $table->boolean('scheduled')->nullable();
            $table->string('state')->nullable();
            $table->string('number')->nullable();
            $table->string('size')->nullable();
            $table->text('receivers')->nullable();
            $table->string('frequency')->nullable();
            $table->string('progress')->nullable();
            $table->longText('data')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('report_requests');
    }
}
