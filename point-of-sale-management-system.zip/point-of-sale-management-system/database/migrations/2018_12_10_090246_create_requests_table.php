<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRequestsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('requests', function (Blueprint $table) {

            $table->increments('id');
            $table->integer('requester_id');
            $table->string('branch_code');
            $table->string('role_assigned')->nullable();
            $table->string('type');
            $table->integer('reference')->nullable();
            $table->json('suggestion')->nullable();
            $table->json('resolution')->nullable();
            $table->json('data');
            $table->integer('state');
            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('requests');
    }
}
