<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePOSReturnsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('p_o_s_returns', function (Blueprint $table) {
            $table->increments('id');
            $table->string('terminal');
            $table->string('serial_number');
            $table->integer('user');
            $table->integer('customer');
            $table->string('account');
            $table->string('branch');
            $table->string('state');
            $table->text('reason');
            $table->boolean('charger');
            $table->boolean('battery');
            $table->boolean('line');
            $table->boolean('card');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p_o_s_returns');
    }
}
