<?php

use App\models\Account;
use App\models\Branch;
use App\models\Customer;
use App\models\POSMachine;
use Faker\Generator as Faker;

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| This directory should contain each of the model factory definitions for
| your application. Factories provide a convenient way to generate new
| model instances for testing / seeding your application's database.
|
*/

$factory->define(App\User::class, function (Faker $faker) {

    return [
        'name' => $faker->name,
        'email' => $faker->unique()->safeEmail,
        'email_verified_at' => now(),
        'role' => 'default',
        'branch' => '001',
        'allowed' => 1,
        'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', // secret
        'remember_token' => str_random(10),
    ];

});


$factory->define(Customer::class, function (Faker $faker) {

    return [
        'name' => $faker->name,
        'last_name' => $faker->lastName,
        'email' => $faker->email,
        'phone' => $faker->phoneNumber,
        'address' => $faker->address,
    ];

});

$factory->define(Account::class, function (Faker $faker) {

    return [
        'account' => $faker->unique()->bankAccountNumber,
        'branch_code' => $faker->lastName,
        'customer_id' => $faker->randomNumber(2, true ),
    ];

});

$factory->define(Branch::class, function (Faker $faker) {

    return [

        'branch_code' => $faker->unique()->randomNumber(3, true),
        'name' => $faker->streetName,
        'short_name' => substr($faker->streetName ,0 ,3 ),

    ];

});

$factory->define(POSMachine::class, function (Faker $faker) {

    return [
        'serial_number' => 'XXX-XXX-XXX'
    ];

});
