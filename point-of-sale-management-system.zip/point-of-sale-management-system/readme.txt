# Requests #
1 - New Terminal
2 - Reallocation
3 - Change of Details
4 - POS Repair
5 - Terminal Testing
6 - Replacement
7 - POS Hire

// Details for Reallocation
1 - New Terminal => account , trade_name , location , terminal_type , number
2 - Reallocation => terminal , to - account  , trade_name , location
3 - Change of Details => terminal , account , trade_name , location
4 - POS Repair => log
5 - POS Hire  - name , location

#Locks
1 - Terminal ID Generation

# Terminal Types
1 - Merchant POS
2 - Agent POS
3 - MPOS Merchant
4 - Branch POS

# Requests Path Description
1 -  Open | Awaiting Branch Manager Auth
2 -  Open | Awaiting merchant-services Auth
3 -  Open | Awaiting merchant-services Manager Auth
4 -  Open | Awaiting E-channels Implementation
5 -  Open | Awaiting Root Implementation
6 -  Open | Awaiting E-channels Confirmation
7 -  Open | Awaiting merchant-services Confirmation
8 -  Closed | Request Completed

#Request States
@New Terminal
1 - branch-manager = 1 = authorize
2 - merchant-services  = 2 = authorize
3 - merchant-services-manager = 3 = authorize
4 - e-channels = 4 = implement
5 - root = 5 = implement
6 - e-channels = 4 = implement
7 - merchant-services = 6 = confirm
8 - root = 7 = close

@Reallocation
1 - branch-manager = 1 = authorize
2 - merchant-services  = 2 = authorize
3 - e-channels = 4 = implement
4 - root = 5 = implement
5 - e-channels = 4 = implement
6 - merchant-services = 6 = confirm
7 - root = 7 = close

@Change of Details
1 - merchant-services  = 2 = authorize
2 - e-channels = 4 = implement
3 - root = 5 = implement
4 - e-channels = 4 = implement
5 - merchant-services = 6 = confirm
6 - root = 7 = close

@POS Repair
1 - merchant-services  = 2 = authorize
2 - e-channels = 4 = implement
5 - merchant-services = 6 = confirm
6 - root = 7 = close

@POS Testing
1 - root = 5 = implement
2 - root = 7 = close

@POS Repair
1 - merchant-services  = 2 = authorize
2 - e-channels = 4 = implement
5 - merchant-services = 6 = confirm
6 - root = 7 = closed

@POS Hire
1 - merchant-services  = 2 = authorize
2 - e-channels = 4 = implement
3 - root = 5 = implement
4 - e-channels = 4 = implement
5 - merchant-services = 6 = confirm
6 - root = 7 = close

# Roles #
1 - branch
2 - branch-manager
3 - ebanking
4 - ebanking-manager
5 - echannels
6 - root
7 - root-helper


# POS Locations #
1 - customer
2 - branch
3 - branch-swift-ebanking
4 - ebanking
4 - ebanking-to-echannels
5 - echannels
6 - eft
7 - echannels-to-ebanking
8 - ebanking-swift-branch


# POS Issues #
1 - Please try again  - CE - Connection Error #level-1
2 - Please try again  - NA - No Answer #level-1
3 - Please try again  - ND - No Data #level-1
4 - Tamper error #level-4
5 - White screen #level-2
6 - Not charging - faulty charging port #level-3
7 - Keypads not responding #level-3
8 - Port not set #level-3
9 - Faulty ethernet port #level-3
10 - Printer error #level-2
11 - Printer not pulling paper #level-3
12 - Printer printing faint #level-3
13 - Call customer service #level-4
14 - Broken screen #level-4
15 - Not switching On #level-3
16 - Please remove card #level-3
17 - Not reading sim card #level-3
18 - Not reading swipe card #level-3
19 - Teller already logged on #level-1
20 - Settlement Required #level-1
21 - Please Initialize #level-1
22 - Settlement Required - No Batch Totals #level-2
23 - Beyond economic repair #level-5
24 - Temper repaired #level-5
25 - Please try again  - ND - No Data - After Sim Change #level-1
25 - Refer To Card Issuer #level-1

#Values and columns - POSTLION
@TermProfile
id - auto-increment - primary
profile_id - 2
terminal_id - $terminal_id

@HyperBaseTerm
id => $terminal_id
currency_code => 840
key_management_scheme => 1
override_terminal_type => 1006 / 1003 / 1001
location_information => $terminal_id.' '.$location
city => $location
state_region => '  '
country => ZW

@Term
id => $terminal_id
short_name => $short_name
term_type => 5
term_active => 1
worst_event_severity => 0
card_acceptor => $terminal_id
participant_id => 4 / 3 / 2 / 1
pos_geographic_data => '              263'
sponsor_bank => 504875,
pos_data_code => 010101210041201

@CardAcceptor
card_acceptor => $terminal_id
name_location => $card_acceptor_location - MP000008 Guruve        GadzikwaStore  ZW
currency_code => 840
default_lang => 0
card_set => DefaultCardSet
limits_class => DefaultLimitsClass
routing_group => DefaultRoutingGroup

@TerminalLookUp
merchant_id => $terminal_id
terminal_id => $terminal_id
branch_code => $branch_code
description => $name
account => $account


// Reports
// Terminals
Overview
// Number of terminals
// Number of terminals by terminal type
Complex
// Most Performing terminals using  - number of transactions
                                    - value of transactions
                                    - value / number ( average transactions )
                                    - max of transactions
// Low performing terminals - based on high performing
// Inactive terminals - no transactions at all
                      - no transaction value
// Commissions Report
// @Filters = date
            = keyword
            = terminal id
            = account
            = customer
            = branch
            = serial number
            = state
            = type of terminals
            = location
            = created
            = updated

// Requests
Overview
// number of requests
// number of requests by request type
// number by role assigned
// number by state
// number by open / closed
// number by my - requests
// number by description of request
// @filters = date
            = keyword
            = role
            = type
            = state
            = description


// Transactions
Overview
// number of transactions
// number of transactions by type
// number of transactions by response code
@ Filters  = tran_nr
           = terminal
           = date
           = sink_node
           = date
           = location
           = keyword

Tran Types

00 Goods and services
01 Cash withdrawal
02 Debit adjustment
03 Check cash/guarantee
04 Check verification
05 Eurocheque
06 Traveller check
07 Letter of credit
08 Giro (postal banking)
09 Goods and services with cash back
10 Non-cash e.g. wire transfer
11 Quasi-cash and scrip
12 General debit (see extended transaction type)
19 Fee collection
20 Returns (refund)
21 Deposit
22 Credit adjustment
23 Check deposit guarantee
24 Check deposit
25 General credit (see extended transaction type)
28 Merchandise dispatch
29 Funds disbursement
30 Available funds inquiry
31 Balance inquiry
32 General inquiry (see extended transaction type)
35 Full-Statement inquiry
36 Merchandise inquiry
37 Card verification inquiry
38 Mini-statement inquiry
39 Linked account inquiry
40 Cardholder accounts transfer
42 General transfer (see extended transaction type)
50 Payment from account
51 Payment by deposit
52 General payment (see extended transaction type)
53 Payment to account
54 Payment from account to account
90 Place hold on card
91 General admin (see extended transaction type)
92 Change PIN
93 Dead-end general admin (see extended transaction type).

Response Code
00 Approved or completed successfully
01 Refer to card issuer
02 Refer to card issuer, special condition
03 Invalid merchant
04 Pick-up card
05 Do not honor
06 Error
07 Pick-up card, special condition
08 Honor with identification
09 Request in progress
10 Approved, partial
11 Approved, VIP
12 Invalid transaction
13 Invalid amount
14 Invalid card number
15 No such issuer
16 Approved, update track 3
17 Customer cancellation
18 Customer dispute
19 Re-enter transaction
20 Invalid response
21 No action taken
22 Suspected malfunction
23 Unacceptable transaction fee
24 File update not supported
25 Unable to locate record
26 Duplicate record
27 File update field edit error
28 File update file locked
29 File update failed
30 Format error
31 Bank not supported
32 Completed partially
33 Expired card, pick-up
34 Suspected fraud, pick-up
35 Contact acquirer, pick-up
36 Restricted card, pick-up
37 Call acquirer security, pick-up
38 PIN tries exceeded, pick-up
39 No credit account
40 Function not supported
41 Lost card, pick-up
42 No universal account
43 Stolen card, pick-up
44 No investment account
45 Account closed
46 Identification required
47 Identification cross-check required
48 No customer record
49 Reserved for future Realtime use
50 Reserved for future Realtime use
51 Not sufficient funds
52 No check account
53 No savings account
54 Expired card
55 Incorrect PIN
56 No card record
57 Transaction not permitted to cardholder
58 Transaction not permitted on terminal
59 Suspected fraud
60 Contact acquirer
61 Exceeds withdrawal limit
62 Restricted card
63 Security violation
64 Original amount incorrect
65 Exceeds withdrawal frequency
66 Call acquirer security
67 Hard capture
68 Response received too late
69 Advice received too late
70  to 74 Reserved for future Realtime use
75 PIN tries exceeded
76 Reserved for future Realtime use
77 Intervene, bank approval required
78 Intervene, bank approval required for partial amount
79  to 89 Reserved for client-specific use (declined)
90 Cut-off in progress
91 Issuer or switch inoperative
92 Routing error
93 Violation of law
94 Duplicate transaction
95 Reconcile error
96 System malfunction
97 Reserved for future Realtime use
98 Exceeds cash limit
99 Reserved for future Realtime use






