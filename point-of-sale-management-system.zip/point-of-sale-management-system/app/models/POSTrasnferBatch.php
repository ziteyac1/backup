<?php

namespace App\models;

use App\core\Filters\HasFilter;
use App\models\system\Role;
use App\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;
use Spiritix\LadaCache\Database\LadaCacheTrait;

/** @noinspection SpellCheckingInspection */

/**
 * @property mixed id
 * @property mixed sender_id
 * @property User sender
 * @property mixed sent
 * @property int terminals_checked_count
 * @property int terminals_count
 * @property int terminals_count_received
 * @property mixed checked
 * @property Collection terminals
 * @property mixed to
 * @property mixed to_branch
 * @property Role role_name_to
 * @property mixed terminals_received_count
 * @property mixed transport
 * @property mixed received
 * @property mixed created_at
 * @property mixed updated_at
 */
class POSTrasnferBatch extends Model implements Auditable
{
    use HasFilter , \OwenIt\Auditing\Auditable , LadaCacheTrait;

    protected static function boot()
    {
        parent::boot();

        static::addGlobalScope('terminals_count' , function (Builder $builder){
            $builder->withCount('terminals');
        });

        static::addGlobalScope('terminals_count_received' , function (Builder $builder){
            $builder->withCount('terminalsReceived');
        });

        static::addGlobalScope('terminals_count_checked' , function (Builder $builder){
            $builder->withCount('terminalsChecked');
        });
    }

    protected /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $guarded = [];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function role_name_to(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(Role::class , 'name' ,'to');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function branch(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Branch::class , 'to_branch' ,'branch_code');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function sender(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {

       return $this->belongsTo(User::class , 'sender_id' ,'id');

    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function receiver(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {

       return $this->belongsTo(User::class , 'receiver_id' ,'id');

    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function terminals(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(POSTrasnfer::class , 'batch_id' ,'id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function terminalsChecked(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->terminals()->whereNotNull('checked');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function terminalsReceived(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->terminals()->whereNotNull('received');
    }

    /**
     * @param $data
     * @return Model
     */
    public function addTerminal($data): Model
    {

        return $this->terminals()->create([
           'serial_number' => $data['serial_number'],
           'terminal' => $data['terminal'],
           'asset_code' => $data['asset_code'],
        ]);

    }
}
