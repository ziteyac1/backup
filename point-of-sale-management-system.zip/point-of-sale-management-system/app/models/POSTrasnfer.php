<?php

namespace App\models;

use App\core\Filters\HasFilter;
use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;

/** @noinspection SpellCheckingInspection */

/**
 * @property POSTrasnferBatch batch
 * @property mixed terminal
 * @property mixed serial_number
 * @property mixed checked
 * @property mixed received
 * @property mixed id
 * @property mixed asset_code
 * @property mixed sent
 * @property mixed created_at
 * @property mixed updated_at
 */
class POSTrasnfer extends Model implements Auditable
{
    use HasFilter  , \OwenIt\Auditing\Auditable, \Spiritix\LadaCache\Database\LadaCacheTrait;
    protected $guarded = [];

    public function batch(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(POSTrasnferBatch::class ,'batch_id' , 'id');
    }

    public function pos(){

        return $this->hasOne(POSMachine::class , 'serial_number' , 'serial_number');
    }

}
