<?php

namespace App\models;

use App\core\Filters\HasFilter;
use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;
use Spiritix\LadaCache\Database\LadaCacheTrait;
use Staudenmeir\EloquentParamLimitFix\ParamLimitFix;


/**
 * @property mixed terminal_id
 * @property mixed trade_name
 * @property mixed account_id
 * @property Account account
 * @property mixed system_serial_number
 * @property mixed serial_number
 * @property mixed trade_name
 * @property mixed location
 * @property mixed|null term_model
 * @property null model
 * @property null override_term_type
 * @property mixed term_type
 * @property mixed active
 * @property mixed created_at
 */
class Terminal extends Model implements Auditable
{
    use HasFilter , \OwenIt\Auditing\Auditable , ParamLimitFix;//LadaCacheTrait


    protected /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $guarded = [];


    public function account(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Account::class ,'account_id','account');
    }



}
