<?php

namespace App\models;

use App\core\Filters\HasFilter;
use App\User;
use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;

/**
 * @property mixed updated_at
 * @property mixed created_at
 * @property mixed id
 * @property mixed terminal
 * @property mixed serial_number
 * @property User input
 * @property mixed account
 * @property mixed branch
 * @property mixed state
 * @property mixed reason
 * @property mixed charger
 * @property mixed battery
 * @property mixed line
 * @property mixed card
 */
class POSReturn extends Model implements Auditable
{
    use \OwenIt\Auditing\Auditable , HasFilter, \Spiritix\LadaCache\Database\LadaCacheTrait;
    protected $guarded = [];

    public function account_name(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Account::class ,'account','account');
    }

    public function input(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(User::class ,'user','id');
    }

}
