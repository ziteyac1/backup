<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property mixed name
 */
class Branch extends Model
{
    use \Spiritix\LadaCache\Database\LadaCacheTrait;
}
