<?php

namespace App\models;

use App\core\Filters\HasFilter;
use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;

/**
 * @property mixed updated_at
 * @property mixed created_at
 * @property mixed customer_id
 * @property mixed serial_number
 * @property mixed terminal
 * @property mixed id
 */
class POSHire extends Model implements Auditable
{
    use HasFilter , \OwenIt\Auditing\Auditable, \Spiritix\LadaCache\Database\LadaCacheTrait;
    protected $guarded = [];

    public function terminal_name(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(Terminal::class , 'terminal_id','terminal');
    }

    public function customer(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(Customer::class , 'id','customer_id');
    }

}
