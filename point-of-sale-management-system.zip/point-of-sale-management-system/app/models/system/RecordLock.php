<?php

namespace App\models\system;

use Illuminate\Database\Eloquent\Model;

class RecordLock extends Model
{
    protected /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $guarded = [];
}
