<?php

namespace App\models\system;

use Illuminate\Database\Eloquent\Model;

class Input extends Model
{
    //
}
