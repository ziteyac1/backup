<?php

namespace App\models\system;

use Illuminate\Database\Eloquent\Model;

class POSLocation extends Model
{
    use \Spiritix\LadaCache\Database\LadaCacheTrait;

    protected /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $guarded = [];
}
