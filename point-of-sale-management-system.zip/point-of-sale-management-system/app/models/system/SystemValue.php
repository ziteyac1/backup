<?php

namespace App\models\system;

use Illuminate\Database\Eloquent\Model;

/**
 * @property mixed value
 */
class SystemValue extends Model
{
    use \Spiritix\LadaCache\Database\LadaCacheTrait;

    protected $guarded = [];
}
