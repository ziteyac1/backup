<?php

namespace App\models\system;

use Illuminate\Database\Eloquent\Model;

/**
 * @property mixed name
 * @property mixed id
 */
class Role extends Model
{
    use \Spiritix\LadaCache\Database\LadaCacheTrait;

    protected /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $guarded = [];
}
