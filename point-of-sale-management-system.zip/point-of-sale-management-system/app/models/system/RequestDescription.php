<?php

namespace App\models\system;

use Illuminate\Database\Eloquent\Model;
/**
 * @property mixed id
 * @property mixed description
 */

class RequestDescription extends Model
{
    use \Spiritix\LadaCache\Database\LadaCacheTrait;

    protected /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $guarded = [];
}
