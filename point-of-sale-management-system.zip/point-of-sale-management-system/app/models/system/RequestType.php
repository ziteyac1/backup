<?php

namespace App\models\system;

use Illuminate\Database\Eloquent\Model;

class RequestType extends Model
{
    use \Spiritix\LadaCache\Database\LadaCacheTrait;

    protected /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $guarded = [];
}
