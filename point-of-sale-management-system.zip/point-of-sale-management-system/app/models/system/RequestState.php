<?php

namespace App\models\system;

use Illuminate\Database\Eloquent\Model;

/**
 * @property mixed id
 * @property mixed role
 * @property mixed action
 * @property mixed description
 * @property RequestDescription description_name
 */
class RequestState extends Model
{
    use \Spiritix\LadaCache\Database\LadaCacheTrait;

    protected /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $guarded = [];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function description_name(): \Illuminate\Database\Eloquent\Relations\BelongsTo
        {
            return $this->belongsTo(RequestDescription::class , 'description' ,'id');
        }


}
