<?php

namespace App\models;

use App\core\Filters\HasFilter;
use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;

/**
 * @property mixed serial_number
 * @property Terminal terminal
 * @property Terminal auto_terminal
 * @property mixed asset_code
 * @property mixed location
 * @property mixed branch
 * @property mixed updated_at
 */
class POSMachine extends Model implements Auditable
{
    use HasFilter  , \OwenIt\Auditing\Auditable, \Spiritix\LadaCache\Database\LadaCacheTrait;

    protected $guarded = [];

    public function terminal(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(Terminal::class,'serial_number','serial_number');
    }

    public function auto_terminal(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(Terminal::class,'system_serial_number','serial_number');
    }

    public function logs(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(POSMachineLog::class , 'serial_number','serial_number');
    }

    /**
     * @param $data
     * @return Model
     */
    public function addLog($data): Model
    {
        return $this->logs()->create($data);
    }
}
