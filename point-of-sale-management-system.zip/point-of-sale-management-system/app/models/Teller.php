<?php

namespace App\models;

use App\core\Filters\HasFilter;
use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;
use Spiritix\LadaCache\Database\LadaCacheTrait;

/**
 * @property mixed terminal
 * @property mixed card_number
 * @property mixed linked_terminal
 * @property mixed updated_at
 * @property mixed created_at
 * @property mixed name
 * @property mixed supervisor
 */
class Teller extends Model implements Auditable
{
    use HasFilter , \OwenIt\Auditing\Auditable , LadaCacheTrait;
    protected /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $guarded = [];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function terminal(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Terminal::class , 'linked_terminal' , 'terminal_id');
    }
}
