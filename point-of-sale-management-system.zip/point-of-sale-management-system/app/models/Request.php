<?php

namespace App\models;

use App\core\Filters\HasFilter;
use App\models\system\RequestState;
use App\models\system\RequestType;
use App\models\system\Role;
use App\User;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;
use Spiritix\LadaCache\Database\LadaCacheTrait;

/**
 * @property array data
 * @property RequestState state_name
 * @property mixed type
 * @property mixed branch_code
 * @property mixed requester_id
 * @property mixed role_assigned
 * @property mixed state
 * @property array resolution
 * @property User requester
 * @property mixed id
 * @property Carbon created_at
 * @property Role role_name
 * @property mixed updated_at
 */
class Request extends Model implements Auditable
{
    use HasFilter , \OwenIt\Auditing\Auditable ;// LadaCacheTrait;
    protected /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $guarded = [];

    protected $casts = [
        'data' => 'array',
        'suggestion' => 'array',
        'resolution' => 'array',
    ];



    protected $auditExclude = [
        'suggestion',
        'resolution',
        'requester_id',
        'branch_code',
        'type',
        'reference',
        'suggestion',
        'id'
    ];

    protected $auditEvents = [
        'updated'
    ];

    /**
     * @param $value
     * @return array|mixed
     */
    public function getDataAttribute($value)
    {
        /** @noinspection ReturnNullInspection */
        return \is_array($value) ? $value : (array)json_decode($value, true);
    }

    /**
     * @param $value
     * @return array|mixed
     */
    public function getSuggestionAttribute($value)
    {
        /** @noinspection ReturnNullInspection */
        return \is_array($value) ? $value : (array)json_decode($value, true);
    }

    /**
     * @param $value
     * @return array|mixed
     */
    public function getResolutionAttribute($value)
    {
        /** @noinspection ReturnNullInspection */
        return \is_array($value) ? $value : (array)json_decode($value, true);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function state_name(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(RequestState::class , 'state','id');
    }


    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function role_name(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Role::class , 'role_assigned' ,'name');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function name(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(RequestType::class , 'type' ,'name');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function requester(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(User::class , 'requester_id','id');
    }


}
