<?php

namespace App\models;

use App\core\Filters\HasFilter;
use App\User;
use Illuminate\Database\Eloquent\Model;
use Spiritix\LadaCache\Database\LadaCacheTrait;

/**
 * @property Report report
 * @property User user
 * @property mixed params
 * @property array receivers
 * @property mixed name
 * @property mixed id
 * @property mixed data
 * @property mixed exportable
 * @property mixed canceled
 * @property mixed excel
 * @property mixed excel_disabled
 * @property mixed scheduled
 * @property mixed completed
 * @property mixed requester_id
 * @property mixed report_path
 */
class ReportRequest extends Model
{
    use HasFilter , LadaCacheTrait;

    protected $guarded = [];

    protected $casts = [
        'params' => 'array',
        'receivers' => 'array',
        'data' => 'array'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function report(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Report::class , 'report_id' , 'id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(User::class , 'requester_id' , 'id');
    }
}
