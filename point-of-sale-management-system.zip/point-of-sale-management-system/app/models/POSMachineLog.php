<?php

namespace App\models;

use App\core\Filters\HasFilter;
use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;

/**
 * @property mixed id
 * @property mixed serial_number
 * @property mixed log
 * @property mixed level
 * @property mixed terminal
 * @property mixed account
 * @property mixed created_at
 * @property mixed updated_at
 */
class POSMachineLog extends Model implements Auditable
{
    use HasFilter , \OwenIt\Auditing\Auditable, \Spiritix\LadaCache\Database\LadaCacheTrait;

    protected /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $guarded = [];

    public function pos(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
      return $this->belongsTo(POSMachine::class ,'serial_number','serial_number');
    }

    public function terminal_linked(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
      return  $this->belongsTo(Terminal::class ,'terminal','terminal_id');
    }

    public function account(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
      return $this->belongsTo(Account::class ,'account','account');
    }
}
