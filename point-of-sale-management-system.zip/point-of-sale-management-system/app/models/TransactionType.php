<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;
use Spiritix\LadaCache\Database\LadaCacheTrait;

class TransactionType extends Model
{
    use LadaCacheTrait;
    protected $guarded = [];
}
