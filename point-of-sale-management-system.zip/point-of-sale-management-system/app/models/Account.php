<?php

namespace App\models;

use App\core\Filters\HasFilter;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;

/**
 * @property mixed account
 * @property Branch branch
 * @property mixed customer_id
 * @property mixed branch_code
 * @property Customer customer
 * @property mixed created_at
 * @property mixed updated_at
 */
class Account extends Model implements Auditable
{
    use HasFilter , \OwenIt\Auditing\Auditable , \Spiritix\LadaCache\Database\LadaCacheTrait;

    protected /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $guarded = [];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */

    public function branch(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
       return $this->belongsTo(Branch::class , 'branch_code' , 'branch_code');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function customer(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Customer::class , 'customer_id' , 'id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function terminals(): \Illuminate\Database\Eloquent\Relations\HasMany
    {

        return $this->hasMany(Terminal::class ,'account_id' ,'account');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function terminals_limit(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->terminals()->limit(30);
    }

    /**
     * @param  array $data
     * @return Model
     */
    public function addTerminal( array $data): Model
    {
        return $this->terminals()->create($data);
    }

}
