<?php

namespace App\models;

use App\core\Filters\Filters;
use App\core\Filters\HasFilter;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Spiritix\LadaCache\Database\LadaCacheTrait;

/**
 * @property mixed class
 * @property mixed id
 * @property mixed name
 * @property mixed exportable
 * @property mixed report_path
 * @property Filters filter
 * @property mixed model
 */
class Report extends Model
{
    use HasFilter , LadaCacheTrait;
    protected $guarded = [];

    protected static function boot()
    {
        parent::boot();

//        static::addGlobalScope('id', function (Builder $builder) {
//            $builder->whereNotIn('id', [ 11 , 12 ]);
//        });
    }
}
