<?php

namespace App\Notifications;

use App\models\ReportRequest;
use App\models\Request;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

class ReportCompleted extends Notification implements ShouldQueue
{
    use Queueable;

    /**
     * @var ReportRequest $report
     */

    public $report;

    /**
     * Create a new notification instance.
     * @param $report
     * @param $overview
     */
    public function __construct($report)
    {
        $this->report = $report;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail','database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {

        $line = $this->report->report->name.' completed please click on the link to view report';
        $url = '/reports/completed-reports/'.$this->report->id;

        return (new MailMessage)
            ->subject($this->report->report->name.' completed #'. $this->report->id )
            ->greeting('Good Day')
            ->line($line)
            ->action('View Report', url($url))
            ->line('Thank you for using POS Management');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'request' => $this->report->toArray(),
            'report' => $this->report->report->toArray(),
        ];
    }
}