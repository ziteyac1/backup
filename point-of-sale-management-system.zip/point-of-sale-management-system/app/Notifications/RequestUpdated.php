<?php

namespace App\Notifications;

use App\models\Request;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

class RequestUpdated extends Notification implements ShouldQueue
{
    use Queueable;

    /**
     * Request $request
     */

    public $request;


    /**
     * Create a new notification instance.
     * @param  Request $request;
     * @return void
     */
    public function __construct($request)
    {
        $this->request = $request;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail','database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {

        $line = 'Your '.ucwords( str_replace_first( '-', ' ', $this->request->type ) ).' Request has being Updated';
        $url = '/request/'.$this->request->id.'/view';

        return (new MailMessage)
            ->subject('Request Updated #'. $this->request->id .' '.
                ucwords(
                    str_replace_first(
                        '-',
                        ' ',
                        $this->request->type
                    )
                )
            )
            ->greeting('Good Day')
            ->line($line)
            ->action('View Request', url($url))
            ->line('Thank you for using POS Management');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [

            'id' => $this->request->id,
            'type' => $this->request->type,
            'role' => $this->request->role_assigned,
            'branch' => $this->request->branch_code,
            'action' => $this->request->state_name->action,
            'state' => $this->request->state_name->description_name->description,
            'created' => $this->request->created_at->toDayDateTimeString(),
            'ago' => $this->request->created_at->diffForHumans(),

        ];
    }
}