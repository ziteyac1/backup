<?php

namespace App\Http\Middleware;

use Closure;

class UserMustBeAllouwedToProcced
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $user = auth()->user();

        if ($user && !$user->allowed) {

           auth()->logout();
           return redirect('/login')->with('message' , 'You are not allowed on this portal contact ICT to be added');

        }

        return $next($request);
    }
}
