<?php

namespace App\Http\Controllers;

use App\core\Filters\TellerFilters;
use App\models\Teller;
use App\models\Transaction;
use App\services\integration\PostlionService;
use Illuminate\Http\Request;
use Illuminate\View\View;

class TellerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(TellerFilters $filters)
    {
        $tellers  = Teller::filter($filters)->with(['terminal'])->latest()->paginate(30);
        return view('tellers.index' , compact('tellers'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('tellers.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        $this->validate($request , [

            'name' => ['required'],
            'card' => ['required', 'unique:tellers,card_number', 'max:16' ,'min:16'],

        ]);

        Teller::query()->create([

            'card_number' => $request['card'],
            'name' => $request['name'],
            'supervisor' => false ,
            'linked_terminal' => null ,

        ]);

        $service = new PostlionService([]);
        $service->addTeller([
            'name' => $request['name'],
            'card' => $request['card'],
        ]);
        return back()->with('message',
            'Teller Created <br> '.
            'Name : '.$request['name'].'<br>'.
            'Card : '.$request['card'].'<br>'
        );
    }


    /**
 * Show the form for editing the specified resource.
 *
 * @param  \App\Teller  $teller
 * @return \Illuminate\Http\Response
 */
    public function edit(Teller $teller)
    {
        return view('tellers.edit' , compact('teller') );
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Teller  $teller
     * @return \Illuminate\Http\Response
     */
    public function show(Teller $teller)
    {

        $transactions = [];

        if ($teller->terminal) {

            $transactions = Transaction::search('*')
                ->with('terminal')
                ->where('card_acceptor_id', $teller->terminal->terminal_id)
                ->orderBy('in_req', 'desc')
                ->paginate(50);

        }

        return view('tellers.view' , compact(['teller','transactions']) );
    }

    /**
     * @param Teller $teller
     * @return \Illuminate\Contracts\View\Factory|View
     */
    public function history(Teller $teller)
    {

        $audits =  $teller->audits()->latest()->paginate(50);
        return view('history' , compact(['teller','audits']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Teller $teller
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, Teller $teller)
    {
        $this->validate($request , [

            'name' => ['required'],
            'card' => ['required','max:16' ,'min:16'],

        ]);

        $teller->update([

            'card_number' => $request['card'],
            'name' => $request['name'],

        ]);

        $service = new PostlionService([]);
        $service->updateTeller([
            'name' => $request['name'],
            'card' => $request['card'],
        ]);

        return back()->with('message',
            'Teller Updated <br> '.
            'Name : '.$request['name'].'<br>'.
            'Card : '.$request['card'].'<br>'
        );
    }


    public function reset(Teller $teller)
    {
        $teller->update([
          'linked_terminal' => null
        ]);

        $service = new PostlionService([]);
        $service->reset($teller->card_number);

        return back()->with('message',
            'Card Reset was successful <br>'
        );
    }
    public function authorizeTeller(Teller $teller)
    {
        $teller->update([
            'supervisor' => true ,
        ]);

        $service = new PostlionService([]);
        $service->makeSupervisor($teller->card_number);

        return back()->with('message',
            'Teller Authorized <br> '
        );

    }

    public function remove(Teller $teller)
    {
        $teller->update([
            'supervisor' => false ,
        ]);

        $service = new PostlionService([]);
        $service->removeSupervisor($teller->card_number);

        return back()->with('message',
            'Teller Removed <br>'
        );

    }
}
