<?php

namespace App\Http\Controllers;

use App\core\Filters\POSTransferBatchFilters;
use App\Events\POSBatchTrasnferReceived;
use App\Events\POSBatchTrasnferSent;
use App\models\Branch;
use App\models\POSTrasnfer;
use App\models\POSTrasnferBatch;
use App\models\system\Role;
use App\services\local\POSService;
use Carbon\Carbon;
use Illuminate\Database\Query\Builder;
use Illuminate\Http\Request;

class POSTransferBatchController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param POSTransferBatchFilters $filters
     * @return \Illuminate\Http\Response
     */
    public function index(POSTransferBatchFilters $filters)
    {
        /** @noinspection PhpUndefinedMethodInspection */
        $batches = POSTrasnferBatch::filter($filters)->with(['sender.branch_name','receiver.branch_name','branch'])->latest()->paginate(30);
        return view('pos-transfer-batches.index' , compact('batches'));

    }

    /**
     * Display a listing of the resource.
     *
     * @param POSTransferBatchFilters $filters
     * @return \Illuminate\Http\Response
     */
    public function mine(POSTransferBatchFilters $filters)
    {
        $extra = [
            'mine' => ''
        ];

        /** @noinspection PhpUndefinedMethodInspection */
        $batches = POSTrasnferBatch::filter($filters , $extra , $extra )->latest()->paginate(30);
        return view('pos-transfer-batches.index' , compact('batches'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $branches = Branch::all();
        $roles = Role::query()->where('level', '<' , '6')->get();
        $transports = [];
        return view('pos-transfer-batches.create' , compact(['branches' ,'roles' , 'transports']) );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request): \Illuminate\Http\RedirectResponse
    {
        $this->validate($request , [

            'role' => ['required'],
            'branch_code' => ['required','string', 'max:255'],
            'transport' => ['required', 'string', 'max:255'],

        ]);

        $batch = POSTrasnferBatch::query()->create([
           'to' => $request['role'],
           'to_branch' =>  $request['branch_code'],
           'transport' =>  $request['transport'],
           'sender_id' =>  auth()->id(),
        ]);

        return back()->with('message',
            'Batch Created <br> '.
            'Role : '.$request['role'].'<br>'.
            'Branch : '.$request['branch_code'].'<br>'.
            'Transport : '.$request['transport'].'<br>'
        );

    }

    public function edit(POSTrasnferBatch $batch){

        $branches = Branch::all();
        $roles = Role::query()->where('level', '<' , '6')->get();
        $transports = [];

        return view('pos-transfer-batches.edit' , compact(['branches' ,'roles' , 'transports','batch']));

    }

    public function show(POSTrasnferBatch $batch){

        $value = \request()->get('search');
        $pos_machines = $batch->terminals();

        if ($value){

            $pos_machines = $batch->terminals()->where(function ( \Illuminate\Database\Eloquent\Builder $builder) use ($value){

                    $builder->orWhere('terminal' ,'like', "%{$value}%");
                    $builder->orWhere('serial_number' ,'like', "%{$value}%");
                    $builder->orWhere('asset_code' ,'like', "%{$value}%");

            });

        }

        $pos_machines = $pos_machines->get();

        return view('pos-transfer-batches.view' , compact(['pos_machines' ,'batch']));

    }

    /**
     * @param Request $request
     * @param POSTrasnferBatch $batch
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request , POSTrasnferBatch $batch ){

        $this->validate($request , [

            'role' => ['required'],
            'branch_code' => ['required','exists:branches', 'string', 'max:255'],
            'transport' => ['required', 'string', 'max:255'],

        ]);

        $batch->update([
            'to' => $request['role'],
            'to_branch' =>  $request['branch_code'],
            'transport' =>  $request['transport'],
            'sender_id' =>  auth()->id(),
        ]);

        return back()->with('message',
            'Batch Updated <br> '.
            'Role : '.$request['role'].'<br>'.
            'Branch : '.$request['branch_code'].'<br>'.
            'Transport : '.$request['transport'].'<br>'
        );
    }

    public function check(POSTrasnferBatch $batch){

        $batch->update([
            'checked' => Carbon::now()
        ]);

        return back()->with('message',
            'Batch Checked <br> '
        );

    }

    public function send(POSTrasnferBatch $batch){

        $batch->update([
            'sent' => Carbon::now()
        ]);

        event(new POSBatchTrasnferSent($batch));

        return back()->with('message',
            'Batch Sent <br>'
        );

    }

    public function receive(POSTrasnferBatch $batch){

        if ( $batch->terminals_count !== $batch->terminals_received_count )
        {
            return back()->with('message',
                'Please Confirm Receive All Machines in the batch<br>'
            );
        }

        $batch->update([
            'received' => Carbon::now(),
            'receiver_id' => auth()->id()
        ]);

        event(new POSBatchTrasnferReceived($batch));

        return back()->with('message',
            'Batch Received<br>'
        );

    }

    /**
     * @param POSTrasnferBatch $batch
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function delete(POSTrasnferBatch $batch): \Illuminate\Http\RedirectResponse
    {
        $batch->delete();
        return back()->with('message',
            'Batch Deleted<br>'
        );
    }

    public function history(POSTrasnferBatch $batch)
    {
        $audits =  $batch->audits()->latest()->paginate(50);
        return view('history' , compact(['batch','audits']));
    }
}
