<?php

namespace App\Http\Controllers;

use App\core\Filters\POSReturnFilters;
use App\models\POSIssue;
use App\models\POSReturn;
use App\models\Terminal;
use App\services\local\POSService;
use Illuminate\Http\Request;
use App\services\integration\PostlionService;

class POSReturnController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param POSReturnFilters $filters
     */
    public function index(POSReturnFilters $filters)
    {
        /** @noinspection PhpUndefinedMethodInspection */
        $terminals = POSReturn::filter($filters)->with(['account_name.customer' ,'account_name.branch'])->latest()->paginate(30);
//        dd($terminals);
        return view('terminals.return.index' , compact('terminals'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('terminals.return.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        $this->validate($request , [

            'terminal' => ['required','exists:terminals,terminal_id'],
            'serial_number' => ['required', 'exists:p_o_s_machines'],
            'reason' => ['required'],
            'state' => ['required'],

        ]);

        /** @var Terminal $terminal */
        $terminal = Terminal::query()->where('terminal_id' ,$request['terminal'] )->first();


        POSReturn::query()->create([

            'terminal' => $request['terminal'],
            'serial_number' => $request['serial_number'],
            'reason' => $request['reason'],
            'state' => $request['state'],
            'user' => auth()->id() ,
            'customer' => $terminal->account->customer_id ,
            'branch' => $terminal->account->branch_code ,
            'account' => $terminal->account_id,
            'charger' => \request()->get('charger') ?: false ,
            'battery' => \request()->get('battery') ?: false ,
            'line' => \request()->get('line') ?: false ,
            'card' => \request()->get('card') ?: false ,

        ]);

        $role = auth()->user()->role_name->name;
        $location =  $role === 'branch' || $role === 'branch-manager' ? 'branch' : $role;

        $service = new POSService();
        $service->setLocation($request['terminal'], $request['serial_number'], $location , auth()->user()->branch );
		
		/*    part to deactivate the returned pos machine */
		
		$pservice = new PostlionService([
            'terminal' => $terminal->terminal_id
        ]);

        $pservice->deactivate();

        $terminal->update([
            'active' => false
        ]);
		/*         ending here */

        if (!$this->checkIfWorking($request))
        {
            return redirect("/pos-machines/add-log?serial_number={$request['serial_number']}&terminal={$request['terminal']}")->with('message','Terminal Deactivated and Updated <br> Add the Log');
        }

        return  back()->with('message','Terminal Deactivated and Updated');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\POSReturn  $pOSReturn
     * @return \Illuminate\Http\Response
     */
    public function show(POSReturn $pOSReturn)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\POSReturn  $pOSReturn
     * @return \Illuminate\Http\Response
     */
    public function edit(POSReturn $pOSReturn)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\POSReturn  $pOSReturn
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, POSReturn $pOSReturn)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\POSReturn  $pOSReturn
     * @return \Illuminate\Http\Response
     */
    public function destroy(POSReturn $pOSReturn)
    {
        //
    }

    /**
     * @param Request $request
     * @return bool
     */
    public function checkIfWorking(Request $request): bool
    {
        return $request['state'] === 'working';
    }
}
