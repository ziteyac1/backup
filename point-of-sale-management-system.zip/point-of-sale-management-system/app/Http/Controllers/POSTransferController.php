<?php

namespace App\Http\Controllers;

use App\core\Filters\POSTransferBatchFilters;
use App\core\Filters\POSTransferFilters;
use App\models\POSMachine;
use App\models\POSTrasnfer;
use App\models\POSTrasnferBatch;
use App\services\local\POSService;
use Carbon\Carbon;
use Illuminate\Http\Request;

class POSTransferController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param POSTransferFilters $filters
     * @return \Illuminate\Http\Response
     */
    public function index(POSTransferFilters $filters)
    {
        /** @noinspection PhpUndefinedMethodInspection */
        $pos_machines = POSTrasnfer::filter($filters)->with(['batch.sender.branch_name','batch.receiver.branch_name','batch.branch'])->latest()->paginate(100);
        return view('pos-transfer.index' , compact('pos_machines'));

    }

    /**
     * Display a listing of the resource.
     *
     * @param POSTransferFilters $filters
     * @return \Illuminate\Http\Response
     */
    public function mine(POSTransferFilters $filters)
    {
        $extra = [
            'mine' => ''
        ];

        /** @noinspection PhpUndefinedMethodInspection */
        $pos_machines = POSTrasnfer::filter( $filters , $extra , $extra )->latest()->paginate(100);
        return view('pos-transfer.index' , compact('pos_machines'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('pos-transfer.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request): \Illuminate\Http\RedirectResponse
    {
        $this->validate($request , [

            'batch' => ['required','exists:p_o_s_trasnfer_batches,id'],
            'terminal' => ['required','exists:terminals,terminal_id'],
            'serial_number' => ['required','exists:p_o_s_machines', 'string', 'max:255'],
            'asset_code' => ['required', 'string', 'max:255'],

        ]);

        $pos = POSTrasnfer::query()->create([
            'terminal' => $request['terminal'],
            'serial_number' =>  $request['serial_number'],
            'batch_id' =>  $request['batch'],
            'asset_code' =>  $request['asset_code'],
        ]);

        $service = new POSService();
        $service->addAssetCode($request['serial_number'], $request['asset_code'] );

        return back()->with('message',
            'POS Transfer Created <br> '.
            'Batch ID: '.$request['batch'].'<br>'.
            'Terminal : '.$request['terminal'].'<br>'.
            'Serial Number : '.$request['serial_number'].'<br>'.
            'Asset Code : '.$request['asset_code'].'<br>'
        );

    }

    public function show(POSTrasnfer $pos){

        return view('pos-transfer.view' , compact('pos'));

    }

    public function history(POSTrasnfer $pos)
    {
        $audits =  $pos->audits()->latest()->paginate(50);
        return view('history' , compact(['pos','audits']));
    }

    public function edit(POSTrasnfer $pos){

        return view('pos-transfer.edit' , compact('pos'));

    }

    /**
     * @param Request $request
     * @param POSTrasnfer $pos
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request , POSTrasnfer $pos ){

        $this->validate($request , [

            'batch' => ['required','exists:p_o_s_trasnfer_batches,id'],
            'terminal' => ['required','exists:terminals,terminal_id'],
            'serial_number' => ['required','exists:p_o_s_machines', 'string', 'max:255'],
            'asset_code' => ['required', 'string', 'max:255'],

        ]);

        $pos->update([
            'terminal' => $request['terminal'],
            'serial_number' =>  $request['serial_number'],
            'batch_id' =>  $request['batch'],
            'asset_code' =>  $request['asset_code'],
        ]);

        $service = new POSService();
        $service->addAssetCode($request['serial_number'], $request['asset_code'] );

        return back()->with('message',
            'POS Transfer Updated <br> '.
            'Batch ID: '.$request['batch'].'<br>'.
            'Terminal : '.$request['terminal'].'<br>'.
            'Serial Number : '.$request['serial_number'].'<br>'.
            'Asset Code : '.$request['asset_code'].'<br>'
        );
    }

    public function check(POSTrasnfer $pos){

        $pos->update([
            'checked' => Carbon::now()
        ]);

        return back()->with('message',
            'POS Checked <br> '
        );

    }


    public function receive(POSTrasnfer $pos){

        $pos->update([
            'received' => Carbon::now()
        ]);

        $service = new POSService();
        $service->setLocation($pos->terminal, $pos->serial_number , $pos->batch->to , $pos->batch->to_branch );

        return back()->with('message',
            'POS Received<br>'
        );

    }

    /**
     * @param POSTrasnfer $pos
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function delete(POSTrasnfer $pos): \Illuminate\Http\RedirectResponse
    {

        $pos->delete();

        return back()->with('message',
            'POS Deleted<br>'
        );

    }
}
