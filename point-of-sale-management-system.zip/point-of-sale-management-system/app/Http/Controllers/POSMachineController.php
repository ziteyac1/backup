<?php

namespace App\Http\Controllers;

use App\core\Filters\POSMachineFilters;
use App\models\POSHire;
use App\models\POSMachine;
use App\models\Terminal;
use Illuminate\Http\Request;

class POSMachineController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param POSMachineFilters $filters
     * @return \Illuminate\Http\Response
     */
    public function index(POSMachineFilters  $filters)
    {
        /** @noinspection PhpUndefinedMethodInspection */
        $pos = POSMachine::filter($filters)->with(['terminal','auto_terminal'])->latest()->paginate(30);
        return view('pos.index' , compact('pos'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        $this->validate($request ,[
            'serial' => [ 'required' , 'unique:p_o_s_machines,serial_number'],
        ]);

        POSMachine::query()->create([
            'serial_number' => $request->serial
        ]);

        return back()->with('message' ,  'POS Added ');
    }

    /**
     * Display the specified resource.
     *
     * @param POSMachine $machine
     * @return \Illuminate\Http\Response
     */
    public function show(POSMachine $machine)
    {
        return view('pos.view' , compact('machine') );
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param POSMachine $machine
     * @return \Illuminate\Http\Response
     */
    public function edit(POSMachine $machine)
    {
       return view('pos.edit' , compact('machine'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param POSMachine $machine
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, POSMachine $machine)
    {

        $this->validate($request ,[

           'terminal' => [ 'required' , 'exists:terminals,terminal_id'],
           'asset_code' => [ 'required' , 'min:6' , 'max:6' ],
           'location' => [ 'required' , 'exists:p_o_s_locations,description'],

        ]);

        // updated terminals

        Terminal::query()->where('terminal_id' , $request['terminal'])->update([
            'serial_number' => $machine->serial_number
        ]);

        $machine->update([
            'asset_code' => $request['asset_code'],
            'location' => $request['location'],
        ]);

        return back()->with('message',
            'POS Update <br> '.
            'Terminal : '.$request['terminal'].'<br>'.
            'Location : '.$request['location'].'<br>'.
            'Asset Code : '.$request['asset_code'].'<br>'
        );

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\POSMachine  $pOSMachine
     * @return \Illuminate\Http\Response
     */
    public function destroy(POSMachine $pOSMachine)
    {
        //
    }

    /**
     * @param POSMachine $machine
     * @return \Illuminate\Contracts\View\Factory|View
     */
    public function history(POSMachine $machine)
    {

        $audits =  $machine->audits()->latest()->paginate(50);
        return view('history' , compact(['machine','audits']));
    }
}
