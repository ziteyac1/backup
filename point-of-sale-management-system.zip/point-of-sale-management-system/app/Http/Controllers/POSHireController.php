<?php

namespace App\Http\Controllers;

use App\core\Filters\POSHireFilters;
use App\models\POSHire;
use App\models\system\SystemValue;
use App\models\Terminal;
use App\models\Transaction;
use Illuminate\Http\Request;
use Illuminate\View\View;

class POSHireController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param TerminalFilters $filters
     * @return \Illuminate\Http\Response
     */
    public function index(POSHireFilters $filters)
    {
        /** @noinspection PhpUndefinedMethodInspection */
        $terminals = POSHire::filter($filters)->latest()->paginate(30);
        return view('pos-hire.index' , compact('terminals'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('pos-hire.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     * @throws \Exception
     */
    public function store(Request $request)
    {
        $this->validate($request , [

            'terminal' => ['required','exists:terminals,terminal_id','unique:p_o_s_hires,terminal'],
            'serial_number' => ['required', 'exists:p_o_s_machines'],
        ]);

       POSHire::query()->create([
           'terminal' => $request['terminal'],
           'serial_number' => $request['serial_number'],
       ]);

       $posHireAccount = SystemValue::query()->where('name','pos-hire-account')->first();

        /** @noinspection NullPointerExceptionInspection */
        $link = '/requests/re-allocation/create?' .
            "terminal={$request['terminal']}" .
            "&account={$posHireAccount->value}".
            '&trade_name=POS Hire'.
            '&location=Harare';

        return redirect($link)->with('message',
            'POS Hire Created <br> Please Send Reallocation Request To complete POS Hire'.
            'Terminal : '.$request['terminal'].'<br>'.
            'Serial Number : '.$request['serial_number'].'<br>'
        );

    }

    public function history(POSHire $terminal)
    {
        $audits =  $terminal->audits()->latest()->paginate(50);
        return view('history' , compact(['terminal','audits']));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Terminal  $terminal
     * @return \Illuminate\Contracts\View\Factory|View
     */
    public function show(POSHire $terminal)
    {
        /** @noinspection PhpUndefinedFieldInspection */
        $transactions = Transaction::search('*')
            ->with('terminal')
            ->where('card_acceptor_id' , $terminal->terminal )
            ->orderBy('in_req' , 'desc')
            ->paginate(50);

        return \view('pos-hire.view' , compact(['terminal','transactions']));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Terminal  $terminal
     * @return \Illuminate\Http\Response
     */
    public function edit(POSHire $terminal)
    {
        return view('pos-hire.edit',compact('terminal'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Terminal $terminal
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, POSHire $terminal)
    {
        $this->validate($request , [
            'terminal' => ['required','exists:terminals,terminal_id'],
            'serial_number' => ['required', 'exists:p_o_s_machines'],
            'customer' => ['string', 'exists:customers,id'],
        ]);

        $terminal->update([
            'terminal' => $request['terminal'],
            'serial_number' => $request['serial_number'],
            'customer_id' => $request['customer']
        ]);

        /** @noinspection NullPointerExceptionInspection */
        return back()->with('message',
            'POS Hire Updated <br> '.
            'Terminal : '.$request['terminal'].'<br>'.
            'Serial Number : '.$request['serial_number'].'<br>'.
            'Customer ID : '.$request['customer_id'].'<br>'
        );
    }

    public function remove(POSHire $terminal)
    {

        $terminal->update([
            'customer_id' =>null
        ]);

        return back()->with('message' , 'Customer Removed');
    }

    /**
     * @param POSHire $terminal
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function delete(POSHire $terminal): \Illuminate\Http\RedirectResponse
    {
        $terminal->delete();
        return back()->with('message' , 'POS Hire Removed');
    }

}
