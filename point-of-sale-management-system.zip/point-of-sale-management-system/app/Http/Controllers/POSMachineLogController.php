<?php

namespace App\Http\Controllers;

use App\core\Filters\POSlogsFilters;
use App\core\Filters\POSMachineFilters;
use App\core\Filters\SystemValueFilters;
use App\models\POSMachine;
use App\models\POSMachineLog;
use App\models\system\Log;
use App\models\SystemValue;
use App\models\Terminal;
use App\services\local\POSService;
use Illuminate\Http\Request;

class POSMachineLogController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @param POSMachineFilters $filters
     * @return \Illuminate\Http\Response
     */
    public function index(POSlogsFilters $filters)
    {
        /** @noinspection PhpUndefinedMethodInspection */
        $logs = POSMachineLog::filter($filters)->with(['pos','terminal_linked','account'])->latest()->paginate(30);
        return view('pos-logs.index' , compact('logs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @param SystemValueFilters $filters
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        /** @noinspection PhpUndefinedMethodInspection */
        $logs = Log::all();
        return view('pos-logs.create',compact('logs'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        $this->validate($request , [
            'serial_number' => ['required','string','exists:p_o_s_machines'],
            'terminal' => ['required', 'string', 'max:8','min:8','exists:terminals,terminal_id'],
            'log' => ['required','string','max:255'],
            'other_log' => ['required_if:log,other']
        ]);

        // Add Log To the POS machines

        $pos = POSMachine::query()->where('serial_number', $request['serial_number'])->first();
        $terminal = Terminal::query()->where('terminal_id', $request['terminal'])->first();

        if ($request['other_log'] === 'other' ){

            $log_id = 0;
            $log = $request['other_log'];
            $level = 6;

        } else {

            $system_value_log = Log::query()->find($request['log']);
            $log_id = $request['log'];

            /** @noinspection NullPointerExceptionInspection */
            /** @noinspection PhpUndefinedFieldInspection */
            $log = $system_value_log->description;

            /** @noinspection NullPointerExceptionInspection */
            /** @noinspection PhpUndefinedFieldInspection */
            $level = $system_value_log->level;

        }


        /** @noinspection NullPointerExceptionInspection */
        /** @var POSMachineLog $id */
        $id = $pos->addLog([
            'terminal' => $request['terminal'],
            'account' => $terminal->account_id,
            'log' => $log,
            'log_id' => $log_id,
            'level' => $level,
        ]);

        $role = auth()->user()->role_name->name;
        $location =  $role === 'branch' || $role === 'branch-manager' ? 'branch' : $role;

        $posService = new POSService();
        $posService->setLocation($request['terminal'], $request['serial_number'], $location, auth()->user()->branch );

        // TODO : Redirect Depending on the Level of the Log
        // TODO : add pos repair link on table

        if ($level > 2 ){

            return redirect("/requests/pos-repair/create?log={$id->id}&terminal={$request['terminal']}&serial_number={$request['serial_number']}")->with('message',
                'Log Created <br> '.
                'Serial Number : '.$request['serial_number'].'<br>'.
                'Account : '.$terminal->account_id.'<br>'.
                'Terminal : '.$request['terminal'].'<br>'.
                'Log : '.$log.'<br>'.
                'Level : '.$level.'<br>'
            );
        }

        /** @noinspection NullPointerExceptionInspection */
        return back()->with('message',
            'Log Created : Refer to documentation for assistance <br> '.
            'Serial Number : '.$request['serial_number'].'<br>'.
            'Account : '.$terminal->account_id.'<br>'.
            'Terminal : '.$request['terminal'].'<br>'.
            'Log : '.$log.'<br>'.
            'Level : '.$level.'<br>'
        );

    }

    /**
     * Display the specified resource.
     *
     * @param POSMachineLog $log
     * @return \Illuminate\Http\Response
     */
    public function show(POSMachineLog $log)
    {
       return view('pos-logs.view' , compact('log'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param POSMachineLog $log
     * @return \Illuminate\Http\Response
     */
    public function edit(POSMachineLog $log)
    {
        return view('pos-logs.edit' , compact('log'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param POSMachineLog $log
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, POSMachineLog $log)
    {
        $update = $log;

        $this->validate($request , [
            'serial_number' => ['required','string','exists:p_o_s_machines'],
            'terminal' => ['required', 'string', 'max:8','min:8','exists:terminals,terminal_id'],
            'log' => ['required','string','max:255'],
            'other_log' => ['required_if:log,other']
        ]);

        // Add Log To the POS machines

        $pos = POSMachine::query()->where('serial_number', $request['serial_number'])->first();
        $terminal = Terminal::query()->where('terminal_id', $request['terminal'])->first();

        if ($request['other_log'] === 'other' ){

            $log_id = 0;
            $log = $request['other_log'];
            $level = 6;

        } else {

            $system_value_log = Log::query()->find($request['log']);
            $log_id = $request['log'];

            /** @noinspection NullPointerExceptionInspection */
            /** @noinspection PhpUndefinedFieldInspection */
            $log = $system_value_log->description;

            /** @noinspection NullPointerExceptionInspection */
            /** @noinspection PhpUndefinedFieldInspection */
            $level = $system_value_log->level;

        }


        /** @noinspection NullPointerExceptionInspection */
        $update->update([
            'terminal' => $request['terminal'],
            'account' => $terminal->account_id,
            'log' => $log,
            'log_id' => $log_id,
            'level' => $level,
        ]);

        $role = auth()->user()->role_name->name;
        $location =  $role === 'branch' || $role === 'branch-manager' ? 'branch' : $role;

        $service = new POSService();
        $service->setLocation($request['terminal'], $request['serial_number'], $location , auth()->user()->branch );

        /** @noinspection NullPointerExceptionInspection */
        return back()->with('message',
            'Log Updated <br> '.
            'Serial Number : '.$request['serial_number'].'<br>'.
            'Account : '.$terminal->account_id.'<br>'.
            'Terminal : '.$request['terminal'].'<br>'.
            'Log : '.$log.'<br>'.
            'Level : '.$level.'<br>'
        );
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param POSMachineLog $log
     * @return \Illuminate\Http\Response
     * @throws \Exception
     */
    public function destroy(POSMachineLog $log)
    {
        $log->delete();
        return back()->with('message','Log Deleted');
    }

    public function history(POSMachineLog $log)
    {
        $audits =  $log->audits()->latest()->paginate(50);
        return view('history' , compact(['terminal','audits']));
    }
}
