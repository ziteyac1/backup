<?php

namespace App\Http\Controllers;

use App\core\Filters\RequestFilters;
use App\Events\RequestCreated;
use App\Events\RequestUpdated;
use App\models\Request;
use App\models\system\RequestState;
use App\models\system\RequestType;
use App\services\requests\RequestActionService;
use App\services\requests\RequestCreateService;
use Illuminate\Http\Request as Req;

class RequestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param RequestFilters $filters
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index(RequestFilters $filters)
    {
        /** @noinspection PhpUndefinedMethodInspection */
        $requests = Request::filter($filters)->with(['requester.branch_name','state_name.description_name','name'])->latest()->paginate(30);
        return view('requests.index' , compact('requests'));

    }

    /**
     * Display a listing of the resource.
     *
     * @param RequestFilters $filters
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function mine(RequestFilters $filters)
    {
        $extra = [
            'mine' => '',
        ];
        /** @noinspection PhpUndefinedMethodInspection */
        $requests = Request::filter( $filters , $extra , $extra )->with(['requester.branch_name','state_name.description_name','name'])->latest()->paginate(30);
        return view('requests.mine' , compact('requests'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @param string $type
     * @return mixed
     */
    public function create(string $type)
    {
        if ($this->viewExits($type)){

            if (!session()->has('_fallback')) {

                session(['_fallback' => session()->previousUrl()]);

            }

            return view("requests.create.{$type}");
        }

        return abort(404, 'Page Not found');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param RequestCreateService $requestService
     * @param RequestActionService $actionService
     * @param $type
     * @return mixed
     */
    public function store(RequestCreateService $requestService , RequestActionService $actionService , $type )
    {

        $request = $requestService->create( $this , $type );

        event(new RequestCreated($request));

        /** @noinspection ReturnNullInspection */
        $action = $this->getAction($type);

        if ( $request->role_assigned === 'root' || $this->needsInstantExecution($action) ){

            $message = $actionService->action( $this , $request );

            if (session()->has('_fallback')){

                $url = session()->get('_fallback');
                session()->remove('_fallback');

                return redirect($url)->with( 'message', $message );

            }

            return back()->with( 'message' , $message );

        }

        return back()->with('message',
            "Role Assigned : {$request->role_assigned} <br>" .
            "Branch Requested : {$request->branch_code} <br>" .
            "Request Type : {$request->type} <br>"
        );

    }


    /**
     * @param RequestActionService $actionService
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function action(RequestActionService $actionService , Request $request ): \Illuminate\Http\RedirectResponse
    {

        $this->authorize( $request->state_name->action , $request );
        $message = $actionService->action( $this , $request );

        if (session()->has('_fallback')){

            $url = session()->get('_fallback');

            session()->remove('_fallback');

            return redirect($url)->with( 'message', $message );

        }

        return back()->with( 'message' , $message );

    }

    /**
     * Display the specified resource.
     *
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function show(Request $request)
    {
        $audits = $request->audits()->latest()->paginate(30);
        return view("requests.view.{$request->type}" , compact(['request','audits']));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Request $request
     * @return mixed
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function edit(Request $request)
    {
        $this->authorize('edit', $request );

        if (!session()->has('_fallback')) {

            session(['_fallback' => session()->previousUrl()]);

        }

        if ($this->viewExits($request->type ,'edit')){

            return view("requests.edit.{$request->type}" , compact('request') );
        }

        return abort(404, 'Page Not found');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param RequestCreateService $requestService
     * @param Request $request
     * @return mixed
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function update(RequestCreateService $requestService , Request $request)
    {
        $this->authorize('edit', $request );

        $request = $requestService->update($this,$request);

        event(new RequestUpdated($request));

        return back()->with('message',
            'Request Updated<br>' .
            "Request Type : {$request->type} <br>"
        );

    }

    public function proof(Request $request)
    {
        if (isset($request->data['proof']))
        {
            return response()->download(storage_path('app/public/'.$request->data['proof']));
        }

        return back()->with('message' , 'There is no Proof of payment');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function close(Request $request): \Illuminate\Http\RedirectResponse
    {

        $this->authorize('close', $request );

        $state = RequestState::query()
            ->where('name', $request->type )
            ->orderBy('id','desc')
            ->first();

        /** @var RequestState $state */
        /** @noinspection NullPointerExceptionInspection */
        $request->update([
            'state' => $state->id,
            'role_assigned' => $state->role
        ]);

        if (session()->has('_fallback')){

            $url = session()->get('_fallback');

            session()->remove('_fallback');

            return redirect($url)->with('message','Request was closed successfully');

        }

        return back()->with('message','Request was closed successfully');
    }

    /**
     * @param $action
     * @return bool
     */
    public function needsInstantExecution($action): bool
    {
        return $action->execution === 'instant';
    }

    /**
     * @param string $type
     * @param string $method
     * @return bool
     */
    public function viewExits(string $type , string  $method = 'create' ): bool
    {
        return view()->exists("requests.{$method}.{$type}");
    }

    /**
     * @param $type
     * @return \Illuminate\Database\Eloquent\Builder|\Illuminate\Database\Eloquent\Model|null|object
     */
    public function getAction($type)
    {
        return RequestType::query()->where('name', $type)->first();
    }

}
