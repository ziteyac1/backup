<?php

namespace App\Http\Controllers;

use App\models\Transaction;
use Illuminate\Http\Request;

class TransactionController extends Controller
{
    public function index(){

        $transactions = Transaction::search('*');

        if (\request()->get('search'))
        {
            $transactions = Transaction::search(request()->get('search'));
        }

        $transactions = $transactions->with(['terminal'])->orderBy('in_req','desc')->paginate(100);

        return view('transactions.index' , compact(['transactions','stats']));

    }

    public function show(Transaction $transaction)
    {
        return view('transactions.view' , compact('transaction'));
    }
}
