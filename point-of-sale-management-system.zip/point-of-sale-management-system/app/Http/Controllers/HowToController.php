<?php

namespace App\Http\Controllers;

use App\core\Filters\HowToFilters;
use App\HowTo;
use DOMElement;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class HowToController extends Controller
{
    public function index(HowToFilters $filters)
    {
        /** @noinspection PhpUndefinedMethodInspection */
        $guides = HowTo::filter($filters)->paginate(30);
        return view('how-to.index' , compact('guides'));
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function create()
    {
        return view('how-to.create');
    }

    /**
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {

        $this->validate($request, [
            'name' => ['required'],
            'type' => ['required'],
            'description' => ['required'],
            'section' => ['required'],
            'content' => ['required'],
        ]);

        $detail = $request->input('content');

        $dom = new \DomDocument();
        $dom->loadHTML($detail, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        $images = $dom->getElementsByTagName('img');

        /** @var \DOMElement $img */

        foreach($images as $k => $img)
        {
            $data = $img->getAttribute('src');
            list($type, $data) = explode(';', $data);
            list(, $data)      = explode(',', $data);

            /** @noinspection ReturnFalseInspection */
            $data = base64_decode($data);
            $image_name= auth()->user()->email.time().$k.'.png';
            $path = storage_path('app/public/how-to-uploads/') . $image_name;

            /** @noinspection ReturnFalseInspection */
            file_put_contents($path, $data);
            $img->removeAttribute('src');
            $img->setAttribute('src', '/storage/how-to-uploads/'.$image_name );

        }

        $detail = $dom->saveHTML();

        /** @noinspection PhpUndefinedFieldInspection */
        $howto = HowTo::query()->create([
            'name' => $request->name,
            'content' => $detail,
            'type' => $request->type,
            'section' => $request->section,
            'description' => $request->description,
        ]);

        return back()->with('message','Documentation Added');

    }

    public function view(HowTo $howto )
    {

        return view('how-to.view' , compact('howto') );
    }

    public function edit(HowTo $howto ){

        return view('how-to.edit' , compact('howto') );
    }

    /**
     * @param Request $request
     * @param HowTo $howto
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request , HowTo $howto ){

        $this->validate($request, [
            'name' => ['required'],
            'type' => ['required'],
            'description' => ['required'],
            'section' => ['required'],
            'content' => ['required'],
        ]);

        $oldList = $this->getImagesList($howto->content);

        $detail = $request->input('content');

        $dom = new \DomDocument();
        $dom->loadHTML($detail, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        $images = $dom->getElementsByTagName('img');

        /** @var \DOMElement $img */

        foreach($images as $k => $img)
        {
            $data = $img->getAttribute('src');

            if (!str_contains($data, '/storage/how-to-uploads/')) {

                [$type, $data] = explode(';', $data);
                [, $data] = explode(',', $data);

                /** @noinspection ReturnFalseInspection */
                $data = base64_decode($data);
                $image_name = auth()->user()->email . time() . $k . '.png';
                $path = storage_path('app/public/how-to-uploads/') . $image_name;

                /** @noinspection ReturnFalseInspection */
                file_put_contents($path, $data);
                $img->removeAttribute('src');
                $img->setAttribute('src', '/storage/how-to-uploads/' . $image_name);

            }
        }

        $detail = $dom->saveHTML();

        $newList  = $this->getImagesList($detail);
        $remove = array_diff($oldList, $newList );

        foreach ($remove as $item )
        {
            $path = '/public'.str_replace_first('/storage', '', $item);
            Storage::delete($path);
        }

        /** @noinspection PhpUndefinedFieldInspection */
        $howto->update([
            'name' => $request->name,
            'content' => $detail,
            'type' => $request->type,
            'section' => $request->section,
            'description' => $request->description,
        ]);

        return back()->with('message','Documentation Updated');

    }

    /**
     * @param HowTo $howto
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function delete(HowTo $howto ){

        $howto->delete();
        return back()->with('message','Documentation Deleted');

    }

    /**
     * @param $old
     * @return array
     */
    public function getImagesList($old): array
    {
        $oldDom = new \DOMDocument();
        $oldDom->loadHTML($old, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        $list = $oldDom->getElementsByTagName('img');

        return  collect($list)->map(function ($value) {
            /** @var \DOMElement $value */
            return $value->getAttribute('src');
        })->toArray();
    }
}
