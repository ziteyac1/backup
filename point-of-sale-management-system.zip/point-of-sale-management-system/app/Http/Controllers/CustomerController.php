<?php

namespace App\Http\Controllers;

use App\models\Branch;
use App\core\Filters\CustomerFilters;
use App\models\Customer;
use App\models\Transaction;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param CustomerFilters $filters
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */

    public function index(CustomerFilters $filters)
    {
        /** @noinspection PhpUndefinedMethodInspection */
        $customers = Customer::filter($filters)->latest()->paginate(30);
        return view('customers.index' , compact('customers') );
    }

    /**
     * Show the form for creating a new resource.
     *
     */
    public function create()
    {
        $branches = Branch::all();
        return view('customers.create' , compact('branches') );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request): \Illuminate\Http\RedirectResponse
    {
        $this->validate($request , [
            'name' => ['required', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'phone' => ['required', 'string', 'max:255','regex:/(^2637)/'],
            'address' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email'],
        ]);

        /** @noinspection PhpUndefinedMethodInspection */
        $customer  = Customer::create([
            'name' => $request['name'],
            'last_name' => $request['last_name'],
            'address' => $request['address'],
            'email' => $request['email'],
            'phone' => $request['phone']
        ]);


        if ($request->get('account')){

            $this->validate($request , [
                'branch_code' => ['required', 'string', 'max:255' ,'exists:branches'],
                'account' => ['required','string','max:255','max:12|min:12' ,'unique:accounts'],
            ]);

            /** @noinspection PhpUndefinedMethodInspection */
            $customer->addAccount([
                'account' => $request['account'],
                'branch_code' => $request['branch_code']
            ]);

        }

        return back()->with( 'message' ,
        'Customer Created Success Fully <br>'.
        'ID : '.$customer->id .'<br>'.
        'Name : '.$request['name'] .'<br>'.
        'Last Name : '.$request['last_name'].'<br>'.
        'Email : '.$request['email'].'<br>'.
        'Phone : '.$request['phone'].'<br>'.
        'Address : '.$request['address'].'<br>'.
        'IF you wish to do a pos hire <a href="/requests/pos-hire/create?customer='.$customer->id.'">( Click Here )</a>'
    );
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function show(Customer $customer)
    {
        $customer->load(['accounts','terminals_limit.account']);
        return view('customers.view' , compact(['customer']));
    }

    public function history(Customer $customer)
    {
        $audits =  $customer->audits()->latest()->paginate(50);
        return view('history' , compact(['customer','audits']));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Customer $customer
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function edit(Customer $customer)
    {
        $customer->load('accounts.branch');
        return view('customers.edit',compact('customer'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Customer $customer
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, Customer $customer)
    {
        $this->validate($request , [
            'name' => ['required', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'phone' => ['required', 'string', 'max:255','regex:/(^2637)/'],
            'address' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email'],
        ]);


        $customer->update([
            'name' => $request['name'],
            'last_name' => $request['last_name'],
            'address' => $request['address'],
            'email' => $request['email'],
            'phone' => $request['phone']
        ]);

        return back()->with( 'message-customer' ,
            'Customer Updated Successfully <br>'.
            'Name : '.$request['name'] .'<br>'.
            'Last Name : '.$request['last_name'].'<br>'.
            'Email : '.$request['email'].'<br>'.
            'Phone : '.$request['phone'].'<br>'.
            'Address : '.$request['address'].'<br>'
        );

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Customer $customer
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy(Customer $customer): \Illuminate\Http\RedirectResponse
    {
        if($customer->terminals()->count())
        {
            return back()->with('message' , 'Cannot Complete action :  customer linked to terminals');
        }

        $customer->delete();
        return back()->with('message' , 'Customer was Deleted Successfully');
    }
}
