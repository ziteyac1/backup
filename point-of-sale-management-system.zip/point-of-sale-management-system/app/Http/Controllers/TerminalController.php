<?php

namespace App\Http\Controllers;

use App\elastic\TransactionFilters;
use App\elastic\TransactionsConfigurator;
use App\models\Account;
use App\core\Filters\TerminalFilters;
use App\models\POSIssue;
use App\models\Terminal;
use App\models\Transaction;
use App\services\integration\PostlionService;
use App\services\local\POSService;
use App\services\local\TerminalsService;
use Illuminate\Http\Request;

class TerminalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param TerminalFilters $filters
     * @return \Illuminate\Http\Response
     */
    public function index(TerminalFilters $filters)
    {
        /** @noinspection PhpUndefinedMethodInspection */
        $terminals = Terminal::filter($filters)->with(['account.customer' ,'account.branch'])->latest()->paginate(30);
        return view('terminals.index' , compact('terminals'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('terminals.create');
    }

    public function history(Terminal $terminal)
    {
        $audits =  $terminal->audits()->latest()->paginate(50);
        return view('history' , compact(['terminal','audits']));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     * @throws \Exception
     */
    public function store(Request $request)
    {
        $this->validate($request , [

            'account' => ['required','exists:accounts'],
            'trade_name' => ['required', 'string', 'max:255'],
            'location' => ['required', 'string', 'max:20'],
            'term_type' => ['required', 'string', 'max:255'],
            'number' => ['required', 'integer', 'min:0','max:20'],

        ]);


        $account = Account::query()->where('account', $request['account'])->first();

        /** @noinspection NullPointerExceptionInspection */
        $account->addTerminal([

            'terminal_id' => '800T'.random_int(100,999) ,
            'trade_name' => $request['trade_name'],
            'location' => $request['location'] ,
            'override_term_type' => '1003' //

        ]);

        /** @noinspection NullPointerExceptionInspection */
        return back()->with('message',
            'Terminal Created <br> '.
            'Trade Name : '.$request['trade_name'].'<br>'.
            'Location : '.$request['location'].'<br>'.
            'Number : '.$request['number'].'<br>'.
            'Account : '.$account->account.'<br>'
        );

    }

    /**
     * Display the specified resource.
     *
     * @param Terminal $terminal
     * @param TransactionFilters $filters
     * @return \Illuminate\Http\Response
     */
    public function show(Terminal $terminal , TransactionFilters $filters )
    {


        $transactions = $filters->apply(
            Transaction::search('*') ,
            [
                'terminal' => $terminal->terminal_id,
                'latest' => ''
        ]);

        $transactions =  $transactions->paginate(30);

        return view('terminals.view' , compact('terminal', 'transactions'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Terminal  $terminal
     * @return \Illuminate\Http\Response
     */
    public function edit(Terminal $terminal)
    {
        $terminal->load(['account']);
        return view('terminals.edit',compact('terminal'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Terminal $terminal
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, Terminal $terminal)
    {

        $this->validate($request , [
            'account' => ['required','exists:accounts'],
            'trade_name' => ['required', 'string', 'max:255'],
            'location' => ['required', 'string', 'max:255'],
            'serial_number' => ['required', 'string', 'max:11','regex:/\d{3}-\d{3}-\d{3}/',
//                 'exists:p_o_s_machines'
            ],
        ]);

        $terminal->update([
            'account_id' => $request['account'],
            'trade_name' => $request['trade_name'],
            'location' => $request['location'],
            'serial_number' => $request['serial_number'],
        ]);

        return back()->with( 'message' ,
            'Terminal Updated Successfully <br>'.
            'Name : '.$request['trade_name'] .'<br>'.
            'Account: '.$request['account'].'<br>'.
            'Location : '.$request['location'].'<br>'.
            'Serial Number : '.$request['serial_number'].'<br>'
        );

    }

    public function activate(Terminal $terminal)
    {
        $service = new PostlionService([
            'terminal' => $terminal->terminal_id
        ]);

        $service->activate();

        $terminal->update([
            'active' => true
        ]);

        return back()->with('message' , "Terminal {$terminal->terminal_id} : {$terminal->trade_name} : activated");
    }

    public function deactivate(Terminal $terminal)
    {
        $service = new PostlionService([
            'terminal' => $terminal->terminal_id
        ]);

        $service->deactivate();

        $terminal->update([
            'active' => false
        ]);

        return back()->with('message' , "Terminal {$terminal->terminal_id} : {$terminal->trade_name} : deactivated");
    }

}
