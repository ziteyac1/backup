<?php

namespace App\Http\Controllers;

use App\core\Filters\POSIssueFilters;
use App\models\POSIssue;
use App\models\Terminal;
use App\services\local\POSService;
use Illuminate\Http\Request;
use App\services\integration\PostlionService;

class POSIssueController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param POSIssueFilters $filters
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index(POSIssueFilters $filters)
    {
        /** @noinspection PhpUndefinedMethodInspection */
        $terminals = POSIssue::filter($filters)->with(['account_name.customer' ,'account_name.branch'])->latest()->paginate(30);
        return view('terminals.issue.index' , compact('terminals'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('terminals.issue.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        $this->validate($request , [
            'terminal' => ['required','exists:terminals,terminal_id'],
            'serial_number' => ['required', 'exists:p_o_s_machines'],
        ]);

        /** @var Terminal $terminal */
        $terminal = Terminal::query()->where('terminal_id' ,$request['terminal'] )->first();

        POSIssue::query()->create([
            'terminal' => $request['terminal'],
            'serial_number' => $request['serial_number'],
            'user' => auth()->id() ,
            'customer' => $terminal->account->customer_id ,
            'branch' => $terminal->account->branch_code ,
            'account' => $terminal->account_id,
            'charger' => \request()->get('charger') ?: false ,
            'battery' => \request()->get('battery') ?: false ,
            'line' => \request()->get('line') ?: false ,
            'card' => \request()->get('card') ?: false ,
        ]);

        $service = new POSService();
        $service->setLocation($request['terminal'], $request['serial_number'], 'customer' , auth()->user()->branch);
        /* Part to activate a pos machine*/
		
		        $service = new PostlionService([
            'terminal' => $terminal->terminal_id
        ]);

        $service->activate();

        $terminal->update([
            'active' => true
        ]);
		/* ending here*/
        return  back()->with('message','Terminal Activated and Updated');
    }

    /**
     * Display the specified resource.
     *
     * @param POSIssue $pOSIssue
     * @return void
     */
    public function show(POSIssue $pOSIssue)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\POSIssue  $pOSIssue
     * @return \Illuminate\Http\Response
     */
    public function edit(POSIssue $pOSIssue)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\POSIssue  $pOSIssue
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, POSIssue $pOSIssue)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\POSIssue  $pOSIssue
     * @return \Illuminate\Http\Response
     */
    public function destroy(POSIssue $pOSIssue)
    {
        //
    }
}
