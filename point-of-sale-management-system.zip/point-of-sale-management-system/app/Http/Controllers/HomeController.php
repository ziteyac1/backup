<?php

namespace App\Http\Controllers;

use App\Charts\SampleChart;
use App\core\Filters\Filters;
use App\models\Account;
use App\models\Customer;
use App\models\POSMachine;
use App\models\Report;
use App\models\Teller;
use App\models\Terminal;
use App\Reports\Sections\Requests\Requests;
use App\Reports\Sections\Transactions\Transactions;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     * @throws \Exception
     */
    public function index()
    {
        $stats = [
            [
                'name' => 'Customers',
                'number' => Customer::query()->count()
            ],[
                'name' => 'Accounts',
                'number' => Account::query()->count()
            ],[
                'name' => 'Terminals',
                'number' => Terminal::query()->count()
            ],[
                'name' => 'Tellers',
                'number' => Teller::query()->count()
            ],[
                'name' => 'POS Machines',
                'number' => POSMachine::query()->count()
            ],[
                'name' => 'Requests',
                'number' => \App\models\Request::query()->count()
            ]
        ];

        $reports = [];

        $ids = [
          1 , 2 , 11 , 12 
        ];

        $list = Report::query()->whereIn('id', $ids)->get();

        foreach ($list as $item ){

            $compiled['report'] = $item;

            /** @var Report $item */
            $class = app()->make($item->class);

            /** @var \App\Reports\Core\Report|Transactions|Requests $class */
            $class->filters(\request()->all());

            if ( app()->make($item->filter) instanceof Filters )
            {
                $class->request($item);
            }

            $class->runResponse($class->getResponse());
            $compiled['overview'] = $class->getOverViewData();
            $reports[] = $compiled;
            $class = null;

        }

        return view('home' , compact('stats' , 'reports') );
    }

    public function panel(){


        $values = [];
        $values2 = [];
        $values3 = [];
        $values4 = [];
        $values5 = [];
        $labels = 'a';

        for ($i  = 1 ; $i <= 5 ; $i++ ){

            $values[] = random_int(0,100);
            $values2[] = random_int(0,100);
            $values4[] = random_int(0,100);
            $values5[] = random_int(0,100);
            $labels++;
            $values3[] = $labels;

        }

        $chart = new SampleChart;
        $chart->labels($values3);

        $dataset = $chart->dataset('My dataset', 'bar', $values );
        $dataset->backgroundColor(collect(['transparent']));
        $dataset->color(collect(['RED']));

        $dataset = $chart->dataset('My dataset', 'bar', $values2 );
        $dataset->backgroundColor(collect(['transparent']));
        $dataset->color(collect(['Green']));

        $dataset = $chart->dataset('My dataset', 'bar', $values4 );
        $dataset->backgroundColor(collect(['transparent']));
        $dataset->color(collect(['blue']));

        $dataset = $chart->dataset('My dataset', 'bar', $values5 );
        $dataset->backgroundColor(collect(['transparent']));
        $dataset->color(collect(['yellow']));

        $chart->displayLegend(true);
        $chart->displayAxes(true);


//        $chart = new SampleChart;
//        $chart->labels(['One', 'Two', 'Three']);
////        $chart->displayLegend(false);
//        $chart->displayAxes(false);
//
//        $dataset = $chart->dataset('My dataset', 'line', array('10','80','10'));
//        $dataset->backgroundColor(collect(['#7158e2','#3ae374', '#ff3838']));
//        $dataset->color(collect(['#7d5fff','#32ff7e', '#ff4d4d']));
//
//        $dataset = $chart->dataset('My dataset', 'line', array('10','80','10'));
//        $dataset->backgroundColor(collect(['#7158e2','#3ae374', '#ff3838']));
//        $dataset->color(collect(['#7d5fff','#32ff7e', '#ff4d4d']));

        return view('quick-panel' , compact('chart'));

    }
}
