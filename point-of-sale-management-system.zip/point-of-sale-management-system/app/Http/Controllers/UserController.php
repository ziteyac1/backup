<?php

namespace App\Http\Controllers;

use App\core\Filters\UserFilters;
use App\models\Branch;
use App\models\system\Role;
use App\Notifications\UserAllowed;
use App\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function index(UserFilters $filters){

        /** @noinspection PhpUndefinedMethodInspection */
        $users = User::filter($filters)->with(['role_name','branch_name'])->latest()->paginate(30);
        return view('users.index', compact('users'));

    }

    public function edit(User $user){

        $roles = Role::all();
        $branches = Branch::all();
        return view('users.edit' ,compact('roles','branches','user'));

    }

    public function profile(){

        $user = auth()->user();
        $roles = Role::all();
        $branches = Branch::all();
        return view('users.edit' ,compact('roles','branches','user'));


    }

    /**
     * @param Request $request
     * @param User $user
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request , User $user){

        $this->validate($request , [
            'name' => ['required', 'string', 'max:255'],
            'branch_code' => ['required', 'string', 'max:255' ,'exists:branches'],
        ]);

        $user->update([
           'name' => $request['name'],
           'branch' => $request['branch_code'],
           'role' => $request['role'],
        ]);

        if ($user->can('role',User::class)){

            $this->validate($request , [
                'role' => ['required','exists:roles,id']
            ]);

            $user->update([
                'role' => $request['role'],
            ]);

        }

        /** @noinspection NullPointerExceptionInspection */
        return back()->with('message',
            'User Updated <br> '.
            'Name : '.$request['name'].'<br>'.
            'Branch : '.$request['branch_code'].'<br>'
        );

    }

    public function remove(User $user){

        $user->update([
            'allowed' => false
        ]);

        return back()->with('message',
            "User Removed  : {$user->email} <br> "
        );
    }

    public function allow(User $user){

        $user->update([
            'allowed' => true
        ]);

        $user->notify(new UserAllowed());

        return back()->with('message',
            "User Allowed  : {$user->email} <br> "
        );
    }




}
