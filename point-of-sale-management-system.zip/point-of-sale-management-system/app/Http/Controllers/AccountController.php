<?php

namespace App\Http\Controllers;

use App\models\Account;
use App\models\Branch;
use App\core\Filters\AccountFilters;
use App\models\Customer;
use App\services\integration\PostlionService;
use Illuminate\Http\Request;

class AccountController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param AccountFilters $filters
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index(AccountFilters $filters)
    {
        /** @noinspection PhpUndefinedMethodInspection */
        $accounts = Account::filter($filters)->with(['customer','branch'])->latest()->paginate(30);
        return view('accounts.index' , compact('accounts'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $branches = Branch::all();
        return view('accounts.create',compact('branches'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request): \Illuminate\Http\RedirectResponse
    {
        $this->validate($request , [
            'customer_id' => ['required','exists:customers,id'],
            'branch_code' => ['required', 'string', 'max:255' ,'exists:branches'],
            'account' => ['required','string','max:255','max:12|min:12' ,'unique:accounts'],
        ]);

        /** @noinspection PhpUndefinedMethodInspection */
        $customer  = Customer::find($request['customer_id']);

        /** @noinspection PhpUndefinedMethodInspection */
        $customer->addAccount([
            'account' => $request['account'],
            'branch_code' => $request['branch_code']
        ]);

        return back()->with( 'message' ,
            'Account Number Added  <br>'.
            'ID : '.$customer['id'] .'<br>'.
            'Name : '.$customer['name'] .'<br>'.
            'Last Name : '.$customer['last_name'].'<br>'.
            'Email : '.$customer['email'].'<br>'.
            'Account : '.$request['account'].'<br>'.
            'Branch Code : '.$request['branch_code'].'<br>'
        );
    }

    /**
     * Display the specified resource.
     *
     * @param Account $account
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function show(Account $account)
    {
        return view('accounts.view' , compact('account') );
    }

    public function history(Account $account)
    {
        $audits =  $account->audits()->latest()->paginate(50);
        return view('history' , compact(['account','audits']));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Account  $account
     * @return \Illuminate\Http\Response
     */
    public function edit(Account $account)
    {
        $account->load(['branch','customer']);
        $branches = Branch::all();
        return view('accounts.edit',compact('account','branches'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param Account $account
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update( Request $request, Account $account )
    {

        $this->validate( $request , [
            'branch_code' => ['required', 'string', 'max:3' ,'exists:branches'],
        ]);

        if( $account->account !== $request['account'] ){

            $this->validate( $request , [
                'account' => ['required','string','max:12','min:12' ,'unique:accounts'],
            ]);

        }

        $account->update([
            'account' => $request['account'],
            'branch_code' => $request['branch_code'],
        ]);

        $account->load('branch');

        return back()->with( 'message' ,
            'Account Updated Successfully <br>'.
            'Account : '.$request['account'] .'<br>'.
            'Branch Code : '.$request['branch_code'] .'<br>'.
            'Branch Name : '.$account->branch->name .'<br>'
        );
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Account $account
     * @return \Illuminate\Http\Response
     * @throws \Exception
     */
    public function destroy(Account $account)
    {
        if ($account->terminals()->count()){

            return back()->with('message' , 'Action cannot be completed : Account is linked to terminal(s)');

        }

        $account->delete();

        return back()->with('message' , 'Account was Deleted Successfully');
    }
}
