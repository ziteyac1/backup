<?php

namespace App\Http\Controllers;
use App\core\Filters\Filters;
use App\core\Filters\ReportFilters;
use App\core\Filters\ReportRequestsFilters;
use App\models\Report;
use App\models\ReportRequest;
use App\Reports\Core\PreExtracted;
use App\Reports\Core\ReportsService;
use App\Reports\Sections\Requests\Requests;
use App\Reports\Sections\Transactions\Transactions;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;


class ReportsController extends Controller
{

    public function index(ReportFilters $filters)
    {

        /** @noinspection PhpUndefinedMethodInspection */
        $reports = Report::filter($filters)->paginate(30);
        return view('reports.index' , compact('reports'));
    }

    /**
     * @param Request $request
     * @param Report $report
     * @return mixed
     * @throws \Exception
     */
    public function view(Report $report){

        if (\request()->has('request'))
        {

            /**
             * Create a Report Request - and send Report Job
             */
            $service = new ReportsService();

            /** @var ReportRequest $request */
            $service->register(
                $report,
                \request()->all(),
                auth()->id()
            );

            return redirect('/reports/reports-run/all?user='.auth()->id())
                ->with('message' , 'Your Report has being sent to the reports <a href="/reports/reports-run/all">queue</a>  kindly refresh to check progress');

        }

        $class = app()->make($report->class);

        /** @var \App\Reports\Core\Report|Transactions|Requests $class */
        $class->filters(\request()->all());

        if ( app()->make($report->filter) instanceof Filters )
        {
             $class->request($report);
        }

        $class->runResponse($class->getResponse());

        $overview = $class->getOverViewData();

        /** @var Builder $builder */
        $builder = $class->getBuilderCollection();

        if ($class instanceof PreExtracted ){

            $results = $class->getList()->take(50);

        } else {

            $results = $builder->paginate(50);

        }


        return view('reports.view' ,compact('report' ,'overview','results'));

    }

    public function run(ReportRequestsFilters $filters)
    {
        /** @noinspection PhpUndefinedMethodInspection */
        $reports  = ReportRequest::filter($filters)->with(['report','user'])->latest('id')->paginate(50);
        return view('reports.run' , compact('reports'));
    }

    public function report(ReportRequest $request)
    {

        $report = $request->report;
        $class = app()->make($report->class);
        $class->runResponse($request->data);
        $overview = $class->getOverViewData();

        return view('reports.summary' ,compact('report' ,'overview'));

    }

   public function download(ReportRequest $request)
    {
        return response()->download('C:\\Users\\Administrator\\Documents\\Portals\\Final\\POSClone\\storage\\app\\'.$request->report_path);
    }

    public function cancel(ReportRequest $request)
    {
        $request->update([
            'progress' => '1',
            'state'=> 'Report Cancelled By User',
            'canceled' => true,

        ]);

        return back()->with('message' , 'Report Cancelled By User');
    }

}
