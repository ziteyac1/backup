<?php

namespace App\core\Filters;

use App\core\Essentials\HasEssentials;
use App\User;
use Illuminate\Database\Eloquent\Builder;

class PropertyFilters extends Filters
{

    Use HasEssentials , LocationFilters;
    /**
     * Registered filters to operate upon.
     *
     * @var array
     */
    protected $filters = [

        'type', 'rating', 'latest' ,
        'updated','confirmed' ,'essentials',
        'city','province','suburb',
        'gender','min_occupants','max_occupants',
        'room_title','must_have_rooms',
        'room_type','min_price','max_price',
        'room_description','institution',
        'search','state','owner','agent' ,
        'manager','order_created'

    ];

    /**
     * Filter the query by the manager of the Properties
     *
     * @param $choice
     * @return Builder
     */
    protected function order_created( $choice ): Builder
    {
        return $this->builder->orderBy('created_at' , $choice );
    }

    /**
     * Filter the query by the manager of the Properties
     *
     * @param $id
     * @return Builder
     */
    protected function manager($id): Builder
    {
        return $this->builder->where(function (Builder $builder) use ($id){

            $builder->orWhere('agent_id' , $id );
            $builder->orWhere('owner_id' , $id );

        });
    }

    /**
     * Filter the query by if a property has rooms
     *
     * @return Builder
     */
    protected function must_have_rooms(): Builder
    {
        return $this->builder->where('rooms_count' , '>' ,0 );
    }


    /**
     * Filter the query by the owner of the Properties
     *
     * @param $id
     * @return Builder
     */
    protected function owner($id): Builder
    {
        return $this->builder->where('owner_id' , $id );
    }

    /**
     * Filter the query by the agent of the Properties
     *
     * @param $id
     * @return Builder
     */
    protected function agent($id): Builder
    {
        return $this->builder->where('agent_id' , $id );
    }

    /**
     * Filter the query by search of Property
     *
     * @param $value
     * @return Builder
     */

    protected function search($value): Builder
    {
        return $this->builder->where(function (Builder $builder) use ($value){

            $builder->orWhere('address','like',"%{$value}%");
            $builder->orWhere('id','=',$value);
            $builder->orWhere('description','like',"%{$value}%");

            $builder->orWhereHas('location', function (Builder $builder) use ($value){

                $builder->where(function (Builder $builder) use ($value){

                    $builder->orWhere('city','like',"%{$value}%");
                    $builder->orWhere('suburb','like',"%{$value}%");
                    $builder->orWhere('province','like',"%{$value}%");

                });

            });

            $builder->orWhereHas('owner',function (Builder $builder) use ($value) {

                $builder->where(function (Builder $builder) use ($value) {

                    $builder->orWhere('name','like',"%{$value}%");
                    $builder->orWhere('last_name','like',"%{$value}%");
                    $builder->orWhere('phone','like',"%{$value}%");
                    $builder->orWhere('email','like',"%{$value}%");

                });
            });

            $builder->orWhereHas('agent',function (Builder $builder) use ($value) {

                $builder->where(function (Builder $builder) use ($value) {

                    $builder->orWhere('name','like',"%{$value}%");
                    $builder->orWhere('last_name','like',"%{$value}%");
                    $builder->orWhere('phone','like',"%{$value}%");
                    $builder->orWhere('email','like',"%{$value}%");

                });
            });

            $builder->orWhereHas('rooms', function (Builder $builder) use ($value){

                $builder->where(function (Builder $builder) use ($value) {

                    $builder->orWhere('room_type','like',"%{$value}%");
                    $builder->orWhere('description','like',"%{$value}%");

                });

            });

        });
    }

    /**
     * Filter the query by the description of Property Rooms
     *
     * @param $description
     * @return Builder
     */
    protected function room_description($description): Builder
    {
        return $this->builder->whereHas('rooms', function (Builder $builder) use ($description){

            $builder->where('description','like',"%{$description}%");

        });
    }

    /**
     * Filter the query by the max price of Property Rooms
     *
     * @param $price
     * @return Builder
     */
    protected function max_price($price): Builder
    {
        return $this->builder->whereHas('rooms', function (Builder $builder) use ($price){

            $builder->where('price','<=',$price);

        });
    }


    /**
     * Filter the query by the min price of Property Rooms
     *
     * @param $price
     * @return Builder
     */
    protected function min_price($price): Builder
    {
        return $this->builder->whereHas('rooms', function (Builder $builder) use ($price){

            $builder->where('price','>=',$price);

        });
    }

    /**
     * Filter the query by the room type of Property Rooms
     *
     * @param $room_type
     * @return Builder
     */
    protected function room_type($room_type): Builder
    {
        return $this->builder->whereHas('rooms', function (Builder $builder) use ($room_type){

            $builder->where('room_type','like',"%{$room_type}%");

        });
    }

    /**
     * Filter the query by the room title of Property Rooms
     *
     * @param $room_title
     * @return Builder
     */
    protected function room_title($room_title): Builder
    {
        return $this->builder->whereHas('rooms', function (Builder $builder) use ($room_title){

            $builder->where('room_title','like',"%{$room_title}%");

        });
    }

    /**
     * Filter the query by the min occupants of Property Rooms
     *
     * @param $occupants
     * @return Builder
     */
    protected function max_occupants($occupants): Builder
    {
        return $this->builder->whereHas('rooms', function (Builder $builder) use ($occupants){

            $builder->where('number_of_occupants','<=',$occupants);

        });
    }


    /**
     * Filter the query by the min occupants of Property Rooms
     *
     * @param $occupants
     * @return Builder
     */
    protected function min_occupants($occupants): Builder
    {
        return $this->builder->whereHas('rooms', function (Builder $builder) use ($occupants){

            $builder->where('number_of_occupants','>=',$occupants);

        });
    }

    /**
     * Filter the query by the gender of Property Rooms
     *
     * @param $gender
     * @return Builder
     */
    protected function gender($gender): Builder
    {
        return $this->builder->whereHas('rooms', function (Builder $builder) use ($gender){

            $builder->where('gender',$gender);

        });
    }

    /**
     * Filter the query by the type of Property
     *
     * @param $type
     * @return Builder
     */
    protected function type($type): Builder
    {
        return $this->builder->where('type', $type);
    }

    /**
     * Filter the query by the type of Property
     *
     * @return Builder
     */
    protected function confirmed(): Builder
    {
        return $this->builder->where('state', 1 );
    }

    /**
     * Filter the query by the type of Property
     *
     * @param $value
     * @return Builder
     */
    protected function state($value): Builder
    {
        if ($value === '0-0') {

            $value = 0;

        }
        return $this->builder->where('state', $value );
    }

    /**
     * Filter the query by the institution of Property Rooms
     *
     * @param $institution
     * @return Builder
     */
    protected function institution($institution): Builder
    {
        return $this->builder->where('preferred_institution', $institution );
    }


}
