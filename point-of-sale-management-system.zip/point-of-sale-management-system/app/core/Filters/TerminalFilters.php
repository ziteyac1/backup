<?php

namespace App\core\Filters;

use App\User;
use Illuminate\Database\Eloquent\Builder;

class TerminalFilters extends Filters
{

    /**
     * Registered filters to operate upon.
     *
     * @var array
     */
    protected $filters = [
        'search','customer','account_id',
        'start_date','end_date','branch_code',
        'term_type','active','model'
    ];

    protected function term_type($value)
    {
        return $this->builder->where('term_type', $value );
    }

    protected function active($value)
    {
        $value = (boolean)$value;
        return $this->builder->where('active', $value );
    }

    protected function model($value)
    {
        return $this->builder->where('model', $value );
    }



    /**
     * Filter the query by search of Customers
     *
     * @param $value
     * @return Builder
     */
    protected function search($value): Builder
    {
        return $this->builder->where(function (Builder $builder) use ($value){

           SearchFilters::terminalSearch($builder , $value);

        });
    }

    protected function customer($value){

        return $this->builder->whereHas('account.customer' ,function (Builder $builder) use ($value){

            $builder->where('id', $value);

        });
    }

    protected function account_id($value){

        return $this->builder->whereHas('account' ,function (Builder $builder) use ($value){

            $builder->where('account_id', $value);

        });
    }

    protected function branch_code($value){

        return $this->builder->whereHas('account' ,function (Builder $builder) use ($value){

            $builder->where('branch_code', $value);

        });
    }


    protected function start_date($value): Builder
    {
        return $this->builder->where('terminals.created_at', '>=',$value.' 00:00:00.000');
    }

    protected function end_date($value): Builder
    {
        return $this->builder->where('terminals.created_at','<=', $value.' 23:59:59.000');
    }

}
