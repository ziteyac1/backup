<?php

namespace App\core\Filters;

use App\User;
use Illuminate\Database\Eloquent\Builder;

class TellerFilters extends Filters
{

    /**
     * Registered filters to operate upon.
     *
     * @var array
     */
    protected $filters = [
        'search','terminal','supervisor'
    ];

    protected function terminal($value): Builder
    {
        return $this->builder->where('linked_terminal' , $value );
    }

    protected function supervisor($value): Builder
    {
        return $this->builder->where('supervisor' , $value );
    }

    /**
     * Filter the query by search of Customers
     *
     * @param $value
     * @return Builder
     */
    protected function search($value): Builder
    {
        return $this->builder->where(function (Builder $builder) use ($value){

           SearchFilters::tellerSearch($builder , $value);

        });
    }


}
