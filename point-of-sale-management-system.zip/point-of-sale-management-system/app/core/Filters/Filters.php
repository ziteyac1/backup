<?php

namespace App\core\Filters;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

abstract class Filters
{
    /**
     * @var Request
     */
    protected $request;

    /**
     * The Eloquent builder.
     *
     * @var \Illuminate\Database\Eloquent\Builder
     */
    protected $builder;

    /**
     * Registered filters to operate upon.
     *
     * @var array
     */
    protected  $filters = [];

    /**
     * Create a new ThreadFilters instance.
     *
     * @param Request $request
     */
    public function __construct(Request $request = null)
    {
        if ($request)
        {
            $this->request = $request;
        }
    }

    /**
     * Apply the filters.
     *
     * @param  \Illuminate\Database\Eloquent\Builder $builder
     * @param array $extra
     * @param array|null $exclude
     * @param bool $considerRequest
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function apply( $builder , array $extra = [] , array $exclude = []  , bool $considerRequest = true ): \Illuminate\Database\Eloquent\Builder
    {

        $this->builder = $builder;

        $temp = [];

        $ex = [
            'supervisor',
            'active'
        ];

        foreach ($ex as $item )
        {
            if (isset($extra[$item]))
            {
                $temp[$item] = $extra[$item];
            }

        }

        $filters = array_filter($extra);
        $filters = array_merge($filters , $temp );

        if ( $considerRequest && $this->request ){

            $filters = $this->getFilters();
            $filters = array_diff_key( $filters , $exclude );
            $filters = array_merge( $extra , $filters);

        }

        foreach ($filters as $filter => $value) {
            if (method_exists($this, $filter)) {
                $this->$filter($value);
            }
        }

        return $this->builder;
    }

    /**
     * Fetch all relevant filters from the request.
     *
     * @return array
     */
    public function getFilters(): array
    {
        return array_filter($this->request->only($this->filters));
    }

    protected function created( $value = 'desc' ) : Builder
    {
        return $this->builder->orderBy('created_at' , $value );
    }

    protected function updated(  $value = 'desc' ) : Builder
    {
        return $this->builder->orderBy('updated_at' , $value );
    }


    protected function start_date($value): Builder
    {
        return $this->builder->where('created_at', '>=',$value.' 00:00:00.000');
    }

    protected function end_date($value): Builder
    {
        return $this->builder->where('created_at','<=', $value.' 23:59:59.000');
    }

}
