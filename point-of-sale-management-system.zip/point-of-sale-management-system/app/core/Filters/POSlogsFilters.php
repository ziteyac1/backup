<?php

namespace App\core\Filters;

use App\User;
use Illuminate\Database\Eloquent\Builder;

class POSlogsFilters extends Filters
{

    /**
     * Registered filters to operate upon.
     *
     * @var array
     */
    protected $filters = [
        'search','serial_number','level','terminal','account','log_id'
    ];

    protected function log_id($value): Builder
    {
        return $this->builder->where('log_id', $value );
    }

    protected function account($value): Builder
    {
        return $this->builder->where('account', $value );
    }

    protected function serial_number($value): Builder
    {
        return $this->builder->where('serial_number', $value );
    }

    protected function level($value): Builder
    {
        return $this->builder->where('level', $value );
    }

    protected function terminal($value): Builder
    {
        return $this->builder->where('terminal', $value );
    }

    /**
     * Filter the query by search of Customers
     *
     * @param $value
     * @return Builder
     */

    protected function search($value): Builder
    {
        return $this->builder->where(function (Builder $builder) use ($value){

            SearchFilters::posLog( $builder , $value );

        });
    }


}
