<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 11/22/2018
 * Time: 9:18 AM
 */

namespace App\core\Filters;


use Illuminate\Database\Eloquent\Builder;

trait LocationFilters
{

    /**
     * Filter the query by the Suburb of the Property
     *
     * @param $suburb
     * @return Builder
     */
    protected function suburb($suburb): Builder
    {
        return $this->builder->whereHas('location', function (Builder $builder) use ($suburb) {

            $builder->where('suburb', 'like', "%{$suburb}%");

        });
    }

    /**
     * Filter the query by the Province of the Property
     *
     * @param $province
     * @return Builder
     */
    protected function province($province): Builder
    {
        return $this->builder->whereHas('location', function (Builder $builder) use ($province) {

            $builder->where('province', 'like', "%{$province}%");

        });
    }

    /**
     * Filter the query by the City of the Property
     *
     * @param $city
     * @return Builder
     */
    protected function city($city): Builder
    {
        return $this->builder->whereHas('location', function (Builder $builder) use ($city) {

            $builder->where('city', 'like', "%{$city}%");

        });
    }
}