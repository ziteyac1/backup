<?php

namespace App\core\Filters;

use App\User;
use Illuminate\Database\Eloquent\Builder;

class POSMachineFilters extends Filters
{

    /**
     * Registered filters to operate upon.
     *
     * @var array
     */
    protected $filters = [
        'search','branch','location','start_date','end_date'
    ];

    public function branch($value)
    {
        return $this->builder->where('branch' , $value );
    }

    public function location($value)
    {
        return $this->builder->where('location' , $value );
    }

    /**
     * Filter the query by search of Customers
     *
     * @param $value
     * @return Builder
     */
    protected function search($value): Builder
    {
        return $this->builder->where(function (Builder $builder) use ($value){

           SearchFilters::posSearch($builder , $value);

        });
    }


}
