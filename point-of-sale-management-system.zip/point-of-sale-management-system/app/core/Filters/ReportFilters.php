<?php

namespace App\core\Filters;

use App\User;
use Illuminate\Database\Eloquent\Builder;

class ReportFilters extends Filters
{

    /**
     * Registered filters to operate upon.
     *
     * @var array
     */
    protected $filters = [
        'search',
    ];


    /**
     * Filter the query by search of Customers
     *
     * @param $value
     * @return Builder
     */
    protected function search($value): Builder
    {
        return $this->builder->where(function (Builder $builder) use ($value){

           SearchFilters::reportsSearch($builder , $value);

        });
    }


}
