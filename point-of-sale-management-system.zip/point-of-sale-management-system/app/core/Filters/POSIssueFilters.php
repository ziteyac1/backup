<?php

namespace App\core\Filters;

use App\User;
use Illuminate\Database\Eloquent\Builder;

class POSIssueFilters extends Filters
{

    /**
     * Registered filters to operate upon.
     *
     * @var array
     */
    protected $filters = [
        'search','branch_code'
    ];

    protected function branch_code($value): Builder
    {
        return $this->builder->where('branch' , $value );
    }

    /**
     * Filter the query by search of Customers
     *
     * @param $value
     * @return Builder
     */

    protected function search($value): Builder
    {
        return $this->builder->where(function (Builder $builder) use ($value){

            SearchFilters::posIssueSearch( $builder , $value );

        });
    }


}
