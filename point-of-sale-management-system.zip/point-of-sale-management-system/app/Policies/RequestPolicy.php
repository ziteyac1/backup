<?php

namespace App\Policies;

use App\models\Request;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;



class RequestPolicy
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * @param User $user
     * @param $ability
     * @return mixed
     */
    public function all(User $user)
    {
        return $user->role_name->name === 'e-channels';
    }

    /**
     * @param User $user
     * @param $ability
     * @return mixed
     */
    public function before(User $user, $ability)
    {
        if ( $user->role_name->name === 'root' ) {

            return true;
        }

        return null;

    }


    /**
     * @param User $user
     * @param Request $request
     * @return bool
     */
    public function authorize(User $user , Request $request ): bool
    {

        if ( $this->methodActionIsNot($request, 'authorize' ) || $this->isWithRoot($request)){
            return false;
        }

        if ( $request->role_assigned === 'branch-manager' ){
            return  $request->branch_code === $user->branch && $request->state_name->role === $user->role_name->name;
        }

        return $request->state_name->role === $user->role_name->name;

    }

    /**
     * @param User $user
     * @param Request $request
     * @return bool
     */
    public function confirm(User $user , Request $request): bool
    {
        if ( $this->methodActionIsNot($request, 'confirm' ) || $this->isWithRoot($request) ){
            return false;
        }
        return $request->state_name->role === $user->role_name->name;
    }

    /**
     * @param User $user
     * @param Request $request
     * @return bool
     */
    public function implement(User $user , Request $request): bool
    {
        if ( $this->methodActionIsNot($request, 'implement' ) || $this->isWithRoot($request) ){
            return false;
        }
        return $request->state_name->role === $user->role_name->name;
    }


    /**
     * @param User $user
     * @param Request $request
     * @return bool
     */
    public function edit(User $user , Request $request): bool
    {
        if ($request->resolution || $this->isWithRoot($request)  ){
            return false;
        }

        if ( $request->role_assigned === 'branch-manager' ){
            return  $user->id === $request->requester_id || $request->branch_code === $user->branch;
        }

        return $request->state_name->role === $user->role_name->name;
    }

    /**
     * @param User $user
     * @param Request $request
     * @return bool
     */
    public function close(User $user , Request $request): bool
    {

        if ($request->resolution || $this->isWithRoot($request)  ){
            return false;
        }

        if ( $user->id === $request->requester_id ){
            return true;
        }
        if ($request->role_assigned === 'branch-manager'){
            return   $request->branch_code === $user->branch;
        }
        return $request->state_name->role === $user->role_name->name;
    }

    /**
     * @param Request $request
     * @return bool
     */
    public function isWithRoot(Request $request): bool
    {
        return $request->role_assigned === 'root';
    }

    /**
     * @param Request $request
     * @param $type
     * @return bool
     */
    public function methodActionIsNot(Request $request, $type): bool
    {
        return $request->state_name->action !== $type;
    }


}
