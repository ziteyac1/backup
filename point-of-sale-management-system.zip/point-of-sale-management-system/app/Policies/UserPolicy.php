<?php

namespace App\Policies;

use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class UserPolicy
{
    use HandlesAuthorization;

    /**
     * @param User $user
     * @return bool
     */

    public function view(User $user): bool
    {

        return $user->role > 2;

    }


    /**
     * @param User $user
     * @param User $profile
     * @return bool
     */
    public function edit(User $user , User $profile ): bool
    {
        return $user->role > 2 || $user->id === $profile->id;
    }


    /**
     * @param User $user
     * @return bool
     */
    public function role(User $user ): bool
    {

      return $user->role > 2;

    }
}
