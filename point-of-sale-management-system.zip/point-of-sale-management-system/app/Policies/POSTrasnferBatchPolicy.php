<?php

namespace App\Policies;

use App\models\POSTrasnferBatch;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class POSTrasnferBatchPolicy
{
    use HandlesAuthorization;

    /**
     * @param User $user
     * @return bool
     */
    public function all(User $user): bool
    {
        return $user->role_name->name === 'e-channels';
    }

    /**
     * @param User $user
     * @param POSTrasnferBatch $batch
     * @return bool
     */
    public function edit(User $user, POSTrasnferBatch $batch): bool
    {
        if ($batch->sent)
        {
            return false;
        }

        return (int)$batch->sender_id === (int)$user->id;
    }

    public function terminal(User $user, POSTrasnferBatch $batch): bool
    {
        if ($batch->sent)
        {
            return false;
        }

        return (int)$batch->sender_id === (int)$user->id;
    }

    /**
     * @param User $user
     * @param POSTrasnferBatch $batch
     * @return bool
     */
    public function delete(User $user, POSTrasnferBatch $batch): bool
    {
        if ( $batch->sent )
        {
            return false;
        }

        return (int)$batch->sender_id === (int)$user->id;

    }

    /**
     * @param User $user
     * @param POSTrasnferBatch $batch
     * @return bool
     */
    public function check(User $user, POSTrasnferBatch $batch): bool
    {
        if ($batch->checked)
        {
           return false;
        }

        if ( $batch->terminals_checked_count !== $batch->terminals_count )
        {
            return false;
        }

        return (int)$batch->sender_id === (int)$user->id;

    }

    /**
     * @param User $user
     * @param POSTrasnferBatch $batch
     * @return bool
     */
    public function send(User $user, POSTrasnferBatch $batch): bool
    {
        if ( $batch->sent )
        {
            return false;
        }

        if (!$batch->checked)
        {
            return false;
        }

        return (int)$batch->sender_id === (int)$user->id && $batch->checked;
    }



    /**
     * @param User $user
     * @param POSTrasnferBatch $batch
     * @return bool
     */
    public function receive(User $user, POSTrasnferBatch $batch): bool
    {

        if (!$batch->sent || $batch->received )
        {
            return false;
        }

        $accepted = [
            'branch',
            'branch-manager'
        ];

        if (\in_array($batch->to, $accepted, true))
        {
            return $batch->to_branch === $user->branch;
        }

        return $batch->to === $user->role_name->name;

    }

}
