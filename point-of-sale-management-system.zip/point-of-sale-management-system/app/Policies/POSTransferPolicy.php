<?php

namespace App\Policies;

use App\models\POSTrasnfer;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class POSTransferPolicy
{
    use HandlesAuthorization;

    /**
     * @param User $user
     * @return bool
     */
    public function all(User $user): bool
    {
        return $user->role_name->name === 'e-channels';
    }

    /**
     * @param User $user
     * @param POSTrasnfer $transfer
     * @return bool
     */
    public function edit(User $user, POSTrasnfer $transfer): bool
    {
        return (int)$transfer->batch->sender_id === (int)$user->id;
    }

    /**
     * @param User $user
     * @param POSTrasnfer $transfer
     * @return bool
     */
    public function delete(User $user, POSTrasnfer $transfer): bool
    {
       if ( $transfer->batch->sent )
        {
            return false;
        }

        return (int)$transfer->batch->sender_id === (int)$user->id;
    }

    /**
     * @param User $user
     * @param POSTrasnfer $transfer
     * @return bool
     */
    public function check(User $user, POSTrasnfer $transfer): bool
    {
        // return true;

        if ($transfer->checked)
        {
            return false;
        }

        return (int)$transfer->batch->sender_id === (int)$user->id;
    }

    /**
     * @param User $user
     * @param POSTrasnfer $transfer
     * @return bool
     */
    public function receive(User $user, POSTrasnfer $transfer): bool
    {
        if (!$transfer->batch->sent || $transfer->received )
        {
            return false;
        }

        $accepted = [
            'branch',
            'branch-manager'
        ];

        if ( \in_array($transfer->batch->to, $accepted, true))
        {
            return $transfer->batch->to_branch === $user->branch;
        }

        return $transfer->batch->to === $user->role_name->name;

    }

}
