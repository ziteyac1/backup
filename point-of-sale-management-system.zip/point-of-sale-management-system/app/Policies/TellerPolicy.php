<?php

namespace App\Policies;

use App\User;
use App\models\Teller;
use Illuminate\Auth\Access\HandlesAuthorization;

class TellerPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view the teller.
     *
     * @param  \App\User  $user
     * @param  \App\models\Teller  $teller
     * @return mixed
     */
    public function view(User $user, Teller $teller)
    {
        //
    }

    /**
     * Determine whether the user can create tellers.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function auth(User $user)
    {
        return $user->role_name->name === 'e-channels'
            || $user->role_name->name === 'merchant-services'
            || $user->role_name->name === 'merchant-services-manager';
    }

    /**
     * Determine whether the user can update the teller.
     *
     * @param  \App\User  $user
     * @param  \App\models\Teller  $teller
     * @return mixed
     */
    public function update(User $user, Teller $teller)
    {
        //
    }

    /**
     * Determine whether the user can delete the teller.
     *
     * @param  \App\User  $user
     * @param  \App\models\Teller  $teller
     * @return mixed
     */
    public function delete(User $user, Teller $teller)
    {
        //
    }

    /**
     * Determine whether the user can restore the teller.
     *
     * @param  \App\User  $user
     * @param  \App\models\Teller  $teller
     * @return mixed
     */
    public function restore(User $user, Teller $teller)
    {
        //
    }

    /**
     * Determine whether the user can permanently delete the teller.
     *
     * @param  \App\User  $user
     * @param  \App\models\Teller  $teller
     * @return mixed
     */
    public function forceDelete(User $user, Teller $teller)
    {
        //
    }
}
