<?php

namespace App\Policies;

use App\User;
use App\models\Terminal;
use Illuminate\Auth\Access\HandlesAuthorization;

class TerminalPolicy
{
    use HandlesAuthorization;

    /**
     * @param User $user
     * @param Terminal $terminal
     * @return bool
     */
    public function deactivate(User $user, Terminal $terminal ): bool
    {

        return $user->role_name->name === 'e-channels'
            || $user->role_name->name === 'merchant-services'
            || $user->role_name->name === 'merchant-services-manager';
    }

    /**
     * Determine whether the user can view the terminal.
     *
     * @param  \App\User  $user
     * @param  \App\models\Terminal  $terminal
     * @return mixed
     */
    public function view(User $user, Terminal $terminal)
    {
        //
    }

    /**
     * Determine whether the user can create terminals.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function create(User $user)
    {
        //
    }

    /**
     * Determine whether the user can update the terminal.
     *
     * @param  \App\User  $user
     * @param  \App\models\Terminal  $terminal
     * @return mixed
     */
    public function update(User $user, Terminal $terminal)
    {
        //
    }

    /**
     * Determine whether the user can delete the terminal.
     *
     * @param  \App\User  $user
     * @param  \App\models\Terminal  $terminal
     * @return mixed
     */
    public function delete(User $user, Terminal $terminal)
    {
        //
    }

    /**
     * Determine whether the user can restore the terminal.
     *
     * @param  \App\User  $user
     * @param  \App\models\Terminal  $terminal
     * @return mixed
     */
    public function restore(User $user, Terminal $terminal)
    {
        //
    }

    /**
     * Determine whether the user can permanently delete the terminal.
     *
     * @param  \App\User  $user
     * @param  \App\models\Terminal  $terminal
     * @return mixed
     */
    public function forceDelete(User $user, Terminal $terminal)
    {
        //
    }
}
