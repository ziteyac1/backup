<?php

namespace App\Policies;

use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class InputPolicy
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * @param User $user
     * @return bool
     */
    public function input(User $user): bool
    {

        $accepted  = [

            'branch',
            'branch-manager',
            'merchant-services',
            'merchant-services-manager',
            'e-channels',

        ];

        return \in_array($user->role_name->name , $accepted , true );
    }
    public function serial(User $user): bool
    {

        $accepted  = [

            'merchant-services',
            'merchant-services-manager',
            'e-channels',

        ];

        return \in_array($user->role_name->name , $accepted , true );
    }
}
