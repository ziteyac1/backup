<?php

namespace App\Policies;

use App\models\ReportRequest;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class ReportsRequestPolicy
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function cancel(User $user , ReportRequest $request): bool
    {

        if ($request->completed || $request->canceled )
        {
            return false;
        }

        if ($user->role_name->name === 'e-channels')
        {
            return true;
        }

        return $user->id === $request->requester_id;

    }

    public function download( User $user , ReportRequest $request)
    {
        return $request->report_path;
    }

    public function view( User $user , ReportRequest $request)
    {
        if ($request->canceled)
        {
            return false;
        }

        return $request->data;
    }

}
