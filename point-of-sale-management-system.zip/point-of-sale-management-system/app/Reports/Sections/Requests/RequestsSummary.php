<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 2/14/2019
 * Time: 7:09 PM
 */

namespace App\Reports\Sections\Requests;


class RequestsSummary
{

}