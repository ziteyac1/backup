<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 2/14/2019
 * Time: 3:55 PM
 */

namespace App\Reports\Sections\Requests;


use App\Charts\SampleChart;
use App\Reports\Core\Report;
use App\Reports\Core\ReportComponents;
use Illuminate\Support\Facades\DB;

class Requests implements Report
{
    use ReportComponents;

    /**
     * @param $response
     * @throws \Exception
     */
    public function runResponse($response) : void
    {

        $response['chart'] = $this->makeChartData($response);
        $this->overview = $response;
    }

    public function getResponse()
    {

        $response['total'] = $this->makeBuilder()->count();
        $response['role_assigned'] = $this->groupBy('role_assigned');
        $response['request_types'] = $this->groupBy('type');
        $response['branches'] = $this->groupBy('branch_code');

        $response['states'] = $this->makeBuilder()->join('request_states', 'requests.state','=','request_states.id')
            ->join('request_descriptions', 'request_descriptions.id','=','request_states.description')
            ->groupBy('request_descriptions.description')
            ->get([ 'request_descriptions.description', DB::raw('count(*) as state_count') ])->toArray();

        $response['chart'] = $this->groupByTypeChart('type' , 'created_at');

        $this->builder = $this->makeBuilder()->with(['state_name.description_name']);
        return $response;

    }


}