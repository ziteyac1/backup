<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 2/14/2019
 * Time: 7:24 PM
 */

namespace App\Reports\Sections\Transactions;


class TransactionAnalysis
{

}