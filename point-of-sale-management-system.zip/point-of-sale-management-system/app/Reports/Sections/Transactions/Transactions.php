<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 2/14/2019
 * Time: 1:37 PM
 */

namespace App\Reports\Sections\Transactions;


use App\Charts\SampleChart;
use App\elastic\TransactionFilters;
use App\elastic\TransactionsService;
use App\models\Transaction;
use App\Reports\Core\Report;
use App\Reports\Core\ReportComponents;
use ConsoleTVs\Charts\Classes\Chartjs\Dataset;

class Transactions implements Report
{
    use ReportComponents;

    /**
     * @throws \Exception
     * @return mixed
     */
    public function getResponse()
    {
        /**
         *  Extracting Filters for the transactions
         */


        $filters =  new TransactionFilters();
        $this->builder  = $filters->apply(
            Transaction::search('*'),
            $this->params,
            $this->params,
            false
        );

        /**
         *  Adding Addition Aggregations for stats
         */

        $extra = [
            'size' => 0,
            'aggs' => [
                'tran_intervals' => [
                    'date_histogram' => [
                        'field' => 'in_req',
                        'interval' => 'day',
                        'format' => 'yyyy-MM-dd',
                        'min_doc_count' => 1
                    ],
                    'aggs' => [
                        'source_node_group' => [
                            'terms' => [
                                'field' => 'source_node'
                            ]
                        ],
                        'tran_type_group' => [
                            'terms' => [
                                'field' => 'tran_type',
                                'missing' => 'Unknown',
                            ]
                        ],
                        'response_code_group' => [
                            'terms' => [
                                'field' => 'response_code'
                            ]
                        ],
                    ]
                ],
                'groups_stats' => [
                    'terms' => [
                        'field' => 'source_node'
                    ]
                ],
                'tran_type_stats' => [
                    'terms' => [
                        'field' => 'tran_type',
                        'missing' => 'X',
                    ]
                ],
                'response_code_stats' => [
                    'terms' => [
                        'field' => 'response_code',
                        'missing' => 'X',
                    ]
                ],
                'summary_amounts' => [
                    'stats' => [
                        'field' => 'amount'
                    ]
                ]
            ]
        ];

        /**
         * Extracting Stats From Elastic
         *
         */

        $service  =  new TransactionsService(
            array_merge($filters->params() , $extra )
        );

        $filters = null;
        return $service->search();
    }


    /**
     * @throws \Exception
     */

    public function runResponse($response)
    {


        $this->overview['total']  = number_format( $response['hits']['total']  , 0, ',', ' ');

        $this->overview['amount_stats'] = collect($response['aggregations']['summary_amounts'])->map(function ($value) {
            return number_format( $value , 0, ',', ' ');
        })->toArray();

        /**
         * POS Types Groups
         *
         */
        foreach ($response['aggregations']['groups_stats']['buckets'] as $key => $item)
        {
            $this->overview['groups'][] = [
                'name' => \App\core\Helper::getSourceNodeName($item['key']) ,
                'code' => $item['key'] ,
                'value' => number_format( $item['doc_count'] , 0, ',', ' '),
            ];
        }

        /**
         * Tran Types Groups
         *
         */

        foreach ($response['aggregations']['tran_type_stats']['buckets'] as $key => $item)
        {
            $this->overview['tran_types'][] = [
                'name' => \App\core\Helper::getTranTypeName($item['key']) ,
                'code' => $item['key'],
                'value' => number_format( $item['doc_count'] , 0, ',', ' '),
            ];
        }


        /**
         * Reponce Code Groups
         *
         */
        foreach ($response['aggregations']['response_code_stats']['buckets'] as $key => $item)
        {
            $this->overview['response_codes'][] = [
                'name' => \App\core\Helper::getResponseCodeName($item['key']) ,
                'code' => $item['key'],
                'value' => number_format( $item['doc_count'] , 0, ',', ' '),
            ];
        }


        /**
         * Generating Charts
         */

        $labels = [];
        $datasets = [];

        foreach ( $response['aggregations']['tran_intervals']['buckets'] as $item )
        {
            $labels[] = $item['key_as_string'];
            foreach ($item as $i => $a )
            {
                if (\is_array($a) && isset($a['buckets'])) {

                    foreach ($a['buckets'] as $b => $c )
                    {
                        $datasets[$i][$c['key']][] = $c['doc_count'];
                    }
                }
            }
        }

        $charts = [];
        $chart = null;

        foreach ($datasets as $key => $item )
        {
            $chart = new SampleChart;
            $chart->labels($labels);

            /** @var Dataset $dataset */
            foreach ($item as $a => $b )
            {
                $dataset = $chart->dataset($a , 'line', $b );
                $dataset->backgroundColor($this->getTransparentColor());
                $dataset->color($this->getRandomColor($this->getColors()));
            }

            $charts[$key] = $chart;

        }

        $this->overview['charts'] = $charts;
        $response = null;
        $datasets = null;

    }
}