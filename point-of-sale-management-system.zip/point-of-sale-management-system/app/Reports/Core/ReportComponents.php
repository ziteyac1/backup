<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 2/14/2019
 * Time: 8:42 PM
 */

namespace App\Reports\Core;


use App\Charts\SampleChart;
use App\core\Filters\Filters;
use App\models\ReportRequest;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

trait ReportComponents
{
    public $params;
    public $overview;
    public $builder;
    public $response;
    /**
     * @var \App\models\Report $request
     */
    public $report;

    /**
     * @param array $params
     * @return void
     */
    public function filters(array $params) : void
    {
        $this->params =  $params;
    }

    /**
     * @param $request
     * @return void
     */
    public function request($request) : void
    {
        $this->report =  $request;
    }

    public function getOverViewData()
    {
        return $this->overview;
    }

    public function getBuilderCollection()
    {
        return $this->builder;
    }

    /**
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function makeBuilder(): \Illuminate\Database\Eloquent\Builder
    {
        /** @var Filters $filter */
        $filter = app()->make($this->report->filter);

        /** @var Model $model */
        $model = app()->make($this->report->model);

        $filters = $filter->apply(
            $model::query(),
            $this->params,
            $this->params,
            false
        );

        return $filters;
    }

    /**
     * @return array
     */
    public function getColors(): array
    {
        $string = '#AA5959,#AC5A61,#AD5C69,#AC5E71,#AB6179,#A96582,#A56889,#A16D91,#9B7198,#95769E,#8D7BA3,#857FA8,#7B84AC,#7289AE,#678DB0,#5D91B0,#5295AF,#4899AE,#3F9DAB,#38A0A7,#33A3A2,#32A69D,#35A996,#3CAB8F,#44AD88,#4EAF81,#59B079,#65B171,#70B26A,#7CB363,#88B35C,#95B356,#A1B251,#ADB24D,#B9B14B,#C6AF4A,#D2AD4A,#DDAB4D,#E9A951,#F3A757';
        return explode(',', $string);
    }

    /**
     * @param $colors
     * @return \Illuminate\Support\Collection
     * @throws \Exception
     */
    public function getRandomColor($colors): \Illuminate\Support\Collection
    {
        return collect([$colors[random_int(0, \count($colors) - 1)]]);
    }

    /**
     * @return \Illuminate\Support\Collection
     */
    public function getTransparentColor(): \Illuminate\Support\Collection
    {
        return collect(['transparent']);
    }

    /**
     * @param $name
     * @return mixed
     */
    public function groupBy($name)
    {
        return $this->makeBuilder()->groupBy($name)
            ->get([$name, DB::raw('count(*) as ' . $name . '_count')])->toArray();
    }

    /**
     * @param $column
     * @param $date
     * @return array
     */
    public function groupByTypeChart($column, $date): array
    {

        return $this->makeBuilder()
            ->withoutGlobalScopes()
            ->groupBy([ DB::raw("FORMAT({$date}, 'yyyy-MM-dd')") , $column ])
            ->orderBy(DB::raw("FORMAT({$date}, 'yyyy-MM-dd')"))
            ->get([ DB::raw("FORMAT({$date}, 'yyyy-MM-dd') as day ") ,
                $column , DB::raw('count(' . $column . ') as ' . $column . '_count') ])->toArray();

    }

    public function groupByChart($column, $date ): array
    {

        return $this->makeBuilder()->withoutGlobalScopes()
            ->groupBy(DB::raw("FORMAT({$date}, 'yyyy-MM-dd')"))
            ->orderBy(DB::raw("FORMAT({$date}, 'yyyy-MM-dd')"), 'asc')
             ->get([ DB::raw("FORMAT({$date}, 'yyyy-MM-dd') as day ") ,
                 DB::raw("count({$column}) as {$column}_count") ])->toArray();

        // return $this->makeBuilder()->withoutGlobalScopes()
        //     ->groupBy(DB::raw('DATE(' . $date . ')'))
        //     ->orderBy(DB::raw('DATE(' . $date . ')'), 'asc')
        //     ->get([ DB::raw('DATE(' . $date . ') as day '),
        //         DB::raw('count(' . $column . ') as ' . $column . '_count')])
        //     ->toArray();


    }

    /**
     * @param $response
     * @param $key
     * @param $column
     * @return SampleChart
     * @throws \Exception
     */
    public function makeChartData($response , $key_name = 'chart' , $column = 'type' ): SampleChart
    {

        $unique = collect($response[$key_name])->unique($column)
            ->map(function ($value) use ($column) {
                return $value[$column];
            })->toArray();

        $data = collect($response[$key_name])->groupBy(function ($value) {
            return $value['day'];
        })->toArray();


        $labels = [];
        $datasets = [];

        foreach ($data as $key => $item )
        {
            $labels[] = $key;
            foreach ( $item as $c => $a )
            {
                foreach ($unique as $i )
                {
                    /** @noinspection UnSafeIsSetOverArrayInspection */
                    if (!isset($datasets[$i][$key.$i])){

                        $datasets[$i][$key.$i] = 0;
                    }
                }

                $datasets[$a[$column]][$key.$a[$column]] = $a[$column.'_count'];
            }

        }

        $chart = new SampleChart;
        $chart->labels($labels);

        foreach ($datasets as $key => $item)
        {
            $dataset = $chart->dataset($key, 'line', array_values($item));
            $dataset->backgroundColor($this->getTransparentColor());
            $dataset->color($this->getRandomColor($this->getColors()));
        }

        return $chart;

    }

    /**
     * @param $response
     * @param string $key_name
     * @param string $column
     * @param string $name
     * @return SampleChart
     * @throws \Exception
     */
    public function makeChart($response , $key_name = 'chart' , $column = 'type'  , $name = 'default' , $type = 'line' ): SampleChart
    {


        $data = collect($response[$key_name])->groupBy(function ($value) {
            return $value['day'];
        })->toArray();


        $labels = [];
        $datasets = [];

        foreach ($data as $key => $item )
        {
            $labels[] = $key;

            foreach ( $item as $c => $a )
            {
                $datasets[] = $a[$column.'_count'];
            }

        }

        $chart = new SampleChart;
        $chart->labels($labels);

        $dataset = $chart->dataset($name, $type, array_values($datasets));
        $dataset->backgroundColor($this->getTransparentColor());
        $dataset->color($this->getRandomColor($this->getColors()));

        return $chart;

    }
}