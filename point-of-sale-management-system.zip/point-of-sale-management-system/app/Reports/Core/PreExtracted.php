<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 2/26/2019
 * Time: 12:14 AM
 */

namespace App\Reports\Core;


use Illuminate\Database\Eloquent\Collection;

interface PreExtracted
{
    /**
     * @return Collection
     */
    public function getList();
}