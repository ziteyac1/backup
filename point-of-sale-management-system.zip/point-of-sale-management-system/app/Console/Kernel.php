<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        //
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {

        $dateTime = now()->format('Ymd');
        // Queues Terminating

        $queues = [
            'requests-action',
            'requests-notifications',
            'batch',
        ];

        foreach ($queues as $queue)
        {
            $schedule->command("queue:work --queue={$queue} --stop-when-empty --tries=2")
                ->withoutOverlapping()
                ->appendOutputTo("C:\\test\\{$queue}.txt")
                ->everyMinute();
        }

        $schedule->command('queue:retry all --quiet')
            ->hourly()->withoutOverlapping();

        $schedule->command('integration:update-system')
            ->dailyAt('01:00')
            ->sendOutputTo('C:\test\update-system.txt')
            ->emailOutputTo(['pgurajena@agribank.co.zw','fzihove@agribank.co.zw','sndindana@agribank.co.zw']);


        $schedule->command('integration:update-postlion')
            ->dailyAt('01:30')
            ->sendOutputTo('C:\test\update-postlion.txt')
            ->emailOutputTo(['pgurajena@agribank.co.zw','fzihove@agribank.co.zw','sndindana@agribank.co.zw']);
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
