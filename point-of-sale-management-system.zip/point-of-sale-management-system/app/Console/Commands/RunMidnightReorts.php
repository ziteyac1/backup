<?php

namespace App\Console\Commands;

use App\Jobs\RunReportJob;
use App\models\ReportRequest;
use Illuminate\Console\Command;

class RunMidnightReorts extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'reports:midnight-run';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Runs Reports Scheduled for midnight';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function log($message): void
    {

        echo  '[ '.now().' ]' . $message .PHP_EOL;

    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->log('Starting Reports');
        
        $requests  = ReportRequest::query()
            ->where('scheduled' , true)->where('completed' , false )->get();

        foreach ($requests as $request){

            $this->log('Dispatching Report ' . $request->id );
            RunReportJob::dispatch($request)->onConnection('redis');

        }

        $this->log('End Reports');

    }
}
