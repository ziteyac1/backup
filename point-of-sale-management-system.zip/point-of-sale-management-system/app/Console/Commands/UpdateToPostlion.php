<?php

namespace App\Console\Commands;

use App\models\Terminal;
use App\services\integration\models\Term;
use App\services\integration\models\TerminalLookup;
use Illuminate\Console\Command;

class UpdateToPostlion extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'integration:update-postlion';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update Information from Portal to Postlion';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        // Get Terminals from postlion - new updates - override term type

        echo 'Init Terminals: '.now()->toDayDateTimeString().PHP_EOL;

        $count = 0 ;

        try {

            Terminal::query()->chunk(500 , function ($terminals) use ($count) {

                foreach ($terminals as $terminal ){

                    /** @var TerminalLookup $terminal */
                    $terminalLookUp = TerminalLookup::query()
                        ->where('terminal_id' ,'=' , $terminal->terminal_id )->first();

                    if ($terminalLookUp)
                    {
                        $terminalLookUp->account = $terminal->account_id  ?: '0000000';
                        $terminalLookUp->description = $terminal->trade_name  ?: '0000000';

                        if ($terminal->isDirty())
                        {
                            $count++;
                            echo "Updated : {$terminal->terminal_id} : {$terminal->account_id} : {$terminal->trade_name}".PHP_EOL;
                        }

                        $terminalLookUp->save();
                    }
                }
            });

        } catch (\Exception $exception){

            echo $exception->getMessage() .PHP_EOL;

        }

        echo 'End Terminals: '.now()->toDayDateTimeString().PHP_EOL;

        echo 'Init activations / De-activations: '.now()->toDayDateTimeString().PHP_EOL;

        try {

            Terminal::query()->chunk(500 , function ($terminals) use ($count) {

                foreach ($terminals as $terminal ){

                    /** @var TerminalLookup $terminal */
                    $term = Term::query()
                        ->where('id' ,'=' , $terminal->terminal_id )->first();

                    if ($term)
                    {
                        $term->term_active = $terminal->active;

                        if ($term->isDirty())
                        {
                            echo "Updated : {$terminal->terminal_id} : {$term->term_active}".PHP_EOL;
                        }

                        $term->save();
                    }
                }
            });

        } catch (\Exception $exception)
        {
            echo $exception->getMessage() .PHP_EOL;
        }

        echo 'End activations / De-activations: '.now()->toDayDateTimeString().PHP_EOL;

    }
}
