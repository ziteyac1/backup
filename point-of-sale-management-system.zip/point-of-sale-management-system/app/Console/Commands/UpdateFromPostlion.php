<?php

namespace App\Console\Commands;

use App\models\Terminal;
use App\services\integration\models\HypBaseTerm;
use App\services\integration\models\Teller;
use Illuminate\Console\Command;

class UpdateFromPostlion extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'integration:update-system';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Get From Postlion';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        // Get Terminals from postlion - new updates - override term type

        echo 'Init Terminals : '.now()->toDayDateTimeString().PHP_EOL;

        try {

            HypBaseTerm::query()->chunk(500 , function ($postlionTerminals)  {

                foreach ( $postlionTerminals as $postlionTerminal ){

                    /** @var Terminal $terminal */
                    $terminal = Terminal::query()
                        ->where('terminal_id' ,'=' , $postlionTerminal->id )->first();

                    if ($terminal)
                    {
                        $terminal->system_serial_number = $postlionTerminal->term_serial_nr  ?: null;
                        $terminal->model = $postlionTerminal->term_model  ?: null;
                        $terminal->override_term_type = $postlionTerminal->override_terminal_type  ?: null;

                        if ($terminal->isDirty())
                        {
                            if (\is_string($terminal->system_serial_number)){
                                $terminal->system_serial_number =  str_replace( '', '\u0000', $terminal->system_serial_number );
                            }

                            echo "Updated : {$postlionTerminal->id} : {$terminal->system_serial_number} : {$terminal->term_model}".PHP_EOL;
                        }

                        $terminal->save();
                    }
                }
            });

        } catch (\Exception $exception){

            echo $exception->getMessage() .PHP_EOL;

        }

        echo 'End Terminals: '.now()->toDayDateTimeString().PHP_EOL;

        echo 'Init Tellers : '.now()->toDayDateTimeString().PHP_EOL;

        try {

            Teller::query()->chunk(500 , function ($postlionTellers)
            {
                foreach ($postlionTellers as $postlionTeller )
                {
                    /** @var Terminal $terminal */
                    $teller = \App\models\Teller::query()
                        ->where('card_number' ,'=' , $postlionTeller->teller_card )->first();

                    if ($teller)
                    {
                        $teller->linked_terminal = $postlionTeller->current_terminal_id  ?: null;

                        if ($teller->isDirty())
                        {
                            echo "Updated : {$postlionTeller->teller_card} : {$teller->linked_terminal}".PHP_EOL;
                        }
                        $teller->save();
                    }
                }
            });

        } catch (\Exception $exception)
        {
            echo $exception->getMessage() .PHP_EOL;
        }

        echo 'End Tellers : '.now()->toDayDateTimeString().PHP_EOL;

    }
}
