<?php

namespace App\Console\Commands;

use App\models\Transaction;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class GetTransactions extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'transactions:import';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import Transactions From Postlion';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->info('Starting Getting Transactions !');

        $this->info('Clearing cache');

        Cache::tags('terminal-transaction')->flush();

        $this->info('Cache cleared');

        $target ='66000001';
        $current = '';

        while ( $current !== $target ){

            try {

                $this->getTable('tm_trans')->select(
                    [
                        'tran_nr',
                        'state',
                        'source_node',
                        'srcnode_amount_final',
                        'sink_node',
                        'pan',
                        'expiry_date',
                        'ret_ref_no',
                        'card_acceptor_term_id',
                        'card_acceptor_name_loc',
                        'account_id_1',
                        'account_id_2',
                        'sponsor_bank',
                        'in_req',
                        'structured_data_req',
                        'extended_data',
                        'tran_type',
                        'rsp_code_req_rsp',
                    ]
                   )->where('tran_nr' ,'<' , '69087242')
                    ->whereIn('source_node', [
                        'AgriPosSrc',
                        'AgriMerchSrc',
                        'AgriMPOSSrc',
                        'AgriTellSrc',
                    ])->orderBy('tran_nr', 'desc')
                    ->chunk(1000 , function ($items){
                        foreach ($items as $item)
                        {
                            if ((int)Transaction::search($item->tran_nr )->count() === 0 )
                            {
                                Transaction::query()->create([

                                    'tran_nr'=> $item->tran_nr,
                                    'state'=> $item->state,
                                    'source_node'=> $item->source_node,
                                    'amount'=> $item->srcnode_amount_final / 100 ,
                                    'sink_node'=> $item->sink_node,
                                    'pan'=> $item->pan,
                                    'expiry_date'=> $item->expiry_date,
                                    'ret_ref_no'=> $item->ret_ref_no,
                                    'card_acceptor_id'=> $item->card_acceptor_term_id,
                                    'card_acceptor_name_loc'=> $item->card_acceptor_name_loc,
                                    'account_id_1'=> $item->account_id_1,
                                    'account_id_2'=> $item->account_id_2,
                                    'sponsor_bank'=> $item->sponsor_bank,
                                    'in_req'=> $item->in_req,
                                    'structured_data'=> $item->structured_data_req,
                                    'extended_data'=> $item->extended_data,
                                    'tran_type'=> $item->tran_type,
                                    'response_code'=> $item->rsp_code_req_rsp,

                                ]);
                                $this->info("Getting : {$item->tran_nr} : {$item->state} : {$item->source_node} : {$item->card_acceptor_term_id}");
                            }

                        }

                    });

            }  catch (\Exception $exception){

                echo $exception.PHP_EOL;
                return;

            }

        }

    }

    /**
     * @param $sheet
     * @param $column_index
     * @param $row_index
     * @param $value
     */
    public function writeValue(Worksheet $sheet, $column_index, $row_index, $value): void
    {
        $sheet->setCellValueByColumnAndRow($column_index, $row_index, $value);
    }

    public  function getTable($name): \Illuminate\Database\Query\Builder
    {
        return DB::connection('sqlsrv_trans')->table($name);
    }
}
