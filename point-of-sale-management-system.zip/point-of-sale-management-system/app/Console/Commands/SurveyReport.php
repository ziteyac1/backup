<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class SurveyReport extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'survey:report';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generates Survey Report';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     * @throws \PhpOffice\PhpSpreadsheet\Exception
     */
    public function handle()
    {
        $this->info('Starting Building Report!');

        $this->info('Response Rate!');

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $row_index = 1;
        $column_index = 1;

        $this->writeValue($sheet, $column_index, $row_index, 'Response Rate');
        $row_index += 2;

        $this->writeValue($sheet, $column_index, $row_index, 'Overall Response Rate');
        $row_index++;

        $this->writeValue($sheet, $column_index, $row_index, 'Overall');
        $column_index++;
        $this->writeValue($sheet, $column_index, $row_index, 'Number');
        $column_index++;
        $this->writeValue($sheet, $column_index, $row_index, 'Total');
        $column_index++;
        $this->writeValue($sheet, $column_index, $row_index, '%');
        $column_index = 1;

        // Overall

        $total_number_of_responses = $this->getTable('responses')->count();

        $row_index++;
        $this->writeValue($sheet, $column_index, $row_index, 'Overall');
        $column_index++;
        $this->writeValue($sheet, $column_index, $row_index, $total_number_of_responses);
        $column_index++;
        $this->writeValue($sheet, $column_index, $row_index, 508);
        $column_index++;
        $this->writeValue($sheet, $column_index, $row_index, round( $total_number_of_responses / 508 *100 ,2).'%');
        $column_index = 1;

        $row_index += 2;

        $data = [
            [
                'title' => 'Gender',
                'question' => 'question-3-1',
            ],
            [
                'title' => 'Age',
                'question' => 'question-3-2',
            ],
            [
                'title' => 'Length Of Service',
                'question' => 'question-3-3',
            ],
            [
                'title' => 'Employment Level',
                'question' => 'question-3-4',
            ],
            [
                'title' => 'Work Area',
                'question' => 'question-3-5',
            ],
        ];

        foreach ( $data as $item ){

            $this->writeValue($sheet, $column_index, $row_index, 'By '.$item['title']);
            $row_index++;

            $column_index++;
            $this->writeValue($sheet, $column_index, $row_index, 'Number');
            $column_index++;
            $this->writeValue($sheet, $column_index, $row_index, 'Total');
            $column_index++;
            $this->writeValue($sheet, $column_index, $row_index, '%');
            $column_index = 1;

            foreach ( $this->getTable('answers')
                         ->where('question_name',$item['question'])
                         ->groupBy('answer')
                         ->get(['answer']) as $answer ){

                $number = $this->getTable('answers')
                    ->where('question_name',$item['question'])->where('answer',$answer->answer)->count();

                $this->writeValue($sheet, $column_index, $row_index, $answer->answer);
                $column_index++;
                $this->writeValue($sheet, $column_index, $row_index,$number);
                $column_index++;
                $this->writeValue($sheet, $column_index, $row_index, $total_number_of_responses);
                $column_index++;
                $this->writeValue($sheet, $column_index, $row_index, round($number / $total_number_of_responses  * 100, 2 ).'%');
                $column_index = 1;

                $row_index++;

            }

            $row_index++;

        }



//        $this->writeValue($sheet, $column_index, $row_index, 'By Employment Level');
//        $column_index++;
//        $this->writeValue($sheet, $column_index, $row_index, $total_number_of_responses);
//        $column_index++;
//        $this->writeValue($sheet, $column_index, $row_index, 508);
//        $column_index++;
//        $this->writeValue($sheet, $column_index, $row_index,  ($total_number_of_responses / 508 *100 ).'%' );
//        $column_index = 1;

        //Responses

        $column_index = 1;

        $this->writeValue($sheet, $column_index, $row_index, 'Part 2');
        $row_index += 2;

        foreach ($this->getTable('answers')
                      ->where('question_name','like' ,'question-5%')
                      ->groupBy('question_name')
                      ->orderBy('question_name','asc')
                      ->get(['question_name']) as $question_name
        ){

            echo $question_name->question_name .PHP_EOL;

            $row_index++;
            $column_index = 1;
            $this->writeValue($sheet, $column_index, $row_index, $question_name->question_name);
            $column_index++;

            foreach ($this->getTable('answers')
                         ->where('question_name', '=' , $question_name->question_name )
                         ->get(['answer']) as $answer ){

                echo  $answer->answer .PHP_EOL;
                $this->writeValue( $sheet , $column_index , $row_index , $answer->answer );
                $column_index++;

            }

        }

        $column_index = 1;

        $row_index += 2;
        $this->writeValue($sheet, $column_index, $row_index, 'Part 3');
        $row_index += 2;

        foreach ($this->getTable('answers')
                     ->where('question_name','like' ,'question-6%')
                     ->groupBy('question_name')
                     ->orderBy('question_name','asc')
                     ->get(['question_name']) as $question_name
        ){

            echo $question_name->question_name .PHP_EOL;

            $row_index++;
            $column_index = 1;
            $this->writeValue($sheet, $column_index, $row_index, $question_name->question_name);
            $column_index++;

            foreach ($this->getTable('answers')
                         ->where('question_name', '=' , $question_name->question_name )
                         ->get(['answer']) as $answer ){

                echo  $answer->answer .PHP_EOL;
                $this->writeValue( $sheet , $column_index , $row_index , $answer->answer );
                $column_index++;

            }

        }


        for ($i = 'A'; $i !=  $sheet->getHighestColumn(); $i++) {
            $sheet->getColumnDimension($i)->setAutoSize(TRUE);
        }
        $writer = new Xlsx($spreadsheet);
        $writer->save('Survey-Report.xlsx');


    }

    /**
     * @param $sheet
     * @param $column_index
     * @param $row_index
     * @param $value
     */
    public function writeValue(Worksheet $sheet, $column_index, $row_index, $value): void
    {
        $sheet->setCellValueByColumnAndRow($column_index, $row_index, $value);
    }

    public  function getTable($name): \Illuminate\Database\Query\Builder
    {
        return DB::connection('sqlsrv_survey')->table($name);
    }
}
