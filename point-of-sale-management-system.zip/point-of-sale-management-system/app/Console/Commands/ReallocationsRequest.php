<?php

namespace App\Console\Commands;

use App\models\Request;
use Illuminate\Console\Command;

class ReallocationsRequest extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'reports:re-allocations';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $requests = Request::query()
            ->whereNotNull('resolution')
            ->where('type' , '=' , 're-allocation')->latest()->with('requester.branch_name')->get();

        // Create files

        $file = fopen("Re-allocations.txt","w+");

        //requester

        foreach ($requests as $key => $request)
        {
            $output = "{$request->id},{$request->created_at},{$request->data['terminal']},{$request->resolution['old']['account_id']},{$request->resolution['new']['account_id']}".PHP_EOL;
            fwrite($file,$output);
            echo $output;
        }

        fclose($file);
    }
}
