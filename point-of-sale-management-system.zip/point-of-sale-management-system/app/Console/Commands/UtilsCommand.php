<?php

namespace App\Console\Commands;

use App\models\Request;
use App\models\system\RequestState;
use App\models\Terminal;
use Illuminate\Console\Command;

class UtilsCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'utils:corrector';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Runs System Corrections';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        echo 'Adding : Request States Logs' . PHP_EOL;

        $data = [
            [
                'name' => 'new-terminal', 'description' => 1 , 'action' => 'authorize', 'role' => 'branch-manager',
            ],[
                'name' => 'new-terminal', 'description' => 2 , 'action' => 'authorize', 'role' => 'merchant-services',
            ],[
                'name' => 'new-terminal', 'description' => 3 , 'action' => 'authorize', 'role' => 'merchant-services-manager',
            ],[
                'name' => 'new-terminal', 'description' => 4 , 'action' => 'implement', 'role' => 'e-channels',
            ],[
                'name' => 'new-terminal', 'description' => 5 , 'action' => 'implement', 'role' => 'root',
            ],[
                'name' => 'new-terminal', 'description' => 7 , 'action' => 'confirm', 'role' => 'e-channels',
            ],[
                'name' => 'new-terminal', 'description' => 6 , 'action' => 'confirm', 'role' => 'merchant-services',
            ],[
                'name' => 'new-terminal', 'description' => 8 , 'action' => 'close', 'role' => 'root', // re-allocation
            ],[
                'name' => 're-allocation', 'description' => 1 , 'action' => 'authorize', 'role' => 'branch-manager',
            ],[
                'name' => 're-allocation', 'description' => 2 , 'action' => 'authorize', 'role' => 'merchant-services',
            ],[
                'name' => 're-allocation', 'description' => 3 , 'action' => 'authorize', 'role' => 'merchant-services-manager',
            ],[
                'name' => 're-allocation', 'description' => 4 , 'action' => 'implement', 'role' => 'e-channels',
            ],[
                'name' => 're-allocation', 'description' => 5 , 'action' => 'implement', 'role' => 'root',
            ],[
                'name' => 're-allocation', 'description' => 7 , 'action' => 'confirm', 'role' => 'e-channels',
            ],[
                'name' => 're-allocation', 'description' => 6 , 'action' => 'confirm', 'role' => 'merchant-services',
            ],[
                'name' => 're-allocation', 'description' => 8 , 'action' => 'close', 'role' => 'root', // change-of-details
            ],[
                'name' => 'change-of-details', 'description' => 1 , 'action' => 'authorize', 'role' => 'branch-manager',
            ],[
                'name' => 'change-of-details', 'description' => 2 , 'action' => 'authorize', 'role' => 'merchant-services',
            ],[
                'name' => 'change-of-details', 'description' => 3 , 'action' => 'authorize', 'role' => 'merchant-services-manager',
            ],[
                'name' => 'change-of-details', 'description' => 4 , 'action' => 'implement', 'role' => 'e-channels',
            ],[
                'name' => 'change-of-details', 'description' => 5 , 'action' => 'implement', 'role' => 'root',
            ],[
                'name' => 'change-of-details', 'description' => 7 , 'action' => 'confirm', 'role' => 'e-channels',
            ],[
                'name' => 'change-of-details', 'description' => 6 , 'action' => 'confirm', 'role' => 'merchant-services',
            ],[
                'name' => 'change-of-details', 'description' => 8 , 'action' => 'close', 'role' => 'root', // change-of-details
            ],[
                'name' => 'pos-repair', 'description' => 2 , 'action' => 'authorize', 'role' => 'merchant-services',
            ],[
                'name' => 'pos-repair', 'description' => 4 , 'action' => 'implement', 'role' => 'e-channels',
            ],[
                'name' => 'pos-repair', 'description' => 5, 'action' => 'implement', 'role' => 'root',
            ],[
                'name' => 'pos-repair', 'description' => 7 , 'action' => 'confirm', 'role' => 'e-channels',
            ],[
                'name' => 'pos-repair', 'description' => 6 , 'action' => 'confirm', 'role' => 'merchant-services',
            ],[
                'name' => 'pos-repair', 'description' => 8 , 'action' => 'close', 'role' => 'root',
            ],[
                'name' => 'terminal-testing', 'description' => 5 , 'action' => 'implement', 'role' => 'root',
            ],[
                'name' => 'terminal-testing', 'description' => 8 , 'action' => 'close', 'role' => 'root',
            ],[
                'name' => 'replacement', 'description' => 2 , 'action' => 'authorize', 'role' => 'merchant-services',
            ],[
                'name' => 'replacement', 'description' => 4 , 'action' => 'implement', 'role' => 'e-channels',
            ],[
                'name' => 'replacement', 'description' => 4 , 'action' => 'implement', 'role' => 'root',
            ],[
                'name' => 'replacement', 'description' => 7 , 'action' => 'confirm', 'role' => 'e-channels',
            ],[
                'name' => 'replacement', 'description' => 6 , 'action' => 'confirm', 'role' => 'merchant-services',
            ],[
                'name' => 'replacement', 'description' => 8 , 'action' => 'close', 'role' => 'root',
            ],[
                'name' => 'pos-hire', 'description' => 1 , 'action' => 'authorize', 'role' => 'branch-manager',
            ],[
                'name' => 'pos-hire', 'description' => 2 , 'action' => 'authorize', 'role' => 'merchant-services',
            ],[
                'name' => 'pos-hire', 'description' => 3 , 'action' => 'authorize', 'role' => 'merchant-services-manager',
            ],[
                'name' => 'pos-hire', 'description' => 4 , 'action' => 'implement', 'role' => 'e-channels',
            ],[
                'name' => 'pos-hire', 'description' => 5 , 'action' => 'implement', 'role' => 'root',
            ],[
                'name' => 'pos-hire', 'description' => 7 , 'action' => 'confirm', 'role' => 'e-channels',
            ],[
                'name' => 'pos-hire', 'description' => 6 , 'action' => 'confirm', 'role' => 'merchant-services',
            ],[
                'name' => 'pos-hire', 'description' => 8 , 'action' => 'close', 'role' => 'root', //change-account
            ],[
                'name' => 'change-account', 'description' => 1 , 'action' => 'authorize', 'role' => 'branch-manager',
            ],[
                'name' => 'change-account', 'description' => 2 , 'action' => 'authorize', 'role' => 'merchant-services',
            ],[
                'name' => 'change-account', 'description' => 3 , 'action' => 'authorize', 'role' => 'merchant-services-manager',
            ],[
                'name' => 'change-account', 'description' => 4 , 'action' => 'implement', 'role' => 'e-channels',
            ],[
                'name' => 'change-account', 'description' => 5 , 'action' => 'implement', 'role' => 'root',
            ],[
                'name' => 'change-account', 'description' => 7 , 'action' => 'confirm', 'role' => 'e-channels',
            ],[
                'name' => 'change-account', 'description' => 6 , 'action' => 'confirm', 'role' => 'merchant-services',
            ],[
                'name' => 'change-account', 'description' => 8 , 'action' => 'close', 'role' => 'root', //change-account
            ],[
                'name' => 'change-customer', 'description' => 1 , 'action' => 'implement', 'role' => 'branch-manager',
            ],[
                'name' => 'change-customer', 'description' => 5 , 'action' => 'implement', 'role' => 'root',
            ],[
                'name' => 'change-customer', 'description' => 8 , 'action' => 'close', 'role' => 'root',
            ],
        ];

        foreach ($data as $item) {

            RequestState::query()->create([
                'name' => $item['name'],
                'action' => $item['action'],
                'role' => $item['role'],
                'description' => $item['description'],
            ]);

            echo "Added : {$item['name']} - {$item['action']} - {$item['role']}" . PHP_EOL;

        }

        foreach (Request::all() as $request ){

            $state = RequestState::query()
                ->where('name', $request->type )
                ->orderBy('id','desc')
                ->first();

            /** @var RequestState $state */
            /** @noinspection NullPointerExceptionInspection */
            $request->update([
                'state' => $state->id,
                'role_assigned' => $state->role
            ]);

            echo 'Corrected : ' .$request->id.PHP_EOL;

        }
        
    }
}
