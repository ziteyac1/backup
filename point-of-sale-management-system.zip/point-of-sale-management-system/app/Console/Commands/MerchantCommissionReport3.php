<?php

namespace App\Console\Commands;

use Elasticsearch\ClientBuilder;
use Illuminate\Console\Command;

class MerchantCommissionReport3 extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'report:commissions';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $terminals = [];
        $trans = [];

        $client = ClientBuilder::create();
        $client->setHosts(["192.168.0.124:9200"]);
        $client = $client->build();

        $params = [
            'index' => 'pos_transactions_index',
            'type' => 'transactions',
            "scroll" => "30s",
            'body' => [
                'query' => [
                    'range' => [
                        'in_req' => [
                            "gte" => "2020-07-01 00:00:00.000",
                            "lte" => "2020-07-31 23:59:59.999",
                        ]
                    ],
                ],
                "sort" => [
                  "in_req" => [
                      "order" => "asc"
                  ]
                ],
                'size' => 1000 ,
            ]
        ];

        $response = $client->search($params);

        echo "Total  = " .$response['hits']['total'] .PHP_EOL;

        while (isset($response['hits']['hits']) && count($response['hits']['hits']) > 0) {

            // **
            // Do your work here, on the $response['hits']['hits'] array
            // **

            foreach ($response['hits']['hits'] as $item ){

                if (isset($trans[$item['_source']['tran_nr']])){

                } else {

                    if (isset($item['_source']['account'])){
                        $trans[$item['_source']['tran_nr']] = 0;
                        $id = $item['_source']['account']."-".$item['_source']['card_acceptor_id'];
                        echo "{$id} - " .$item['_source']['tran_nr']."-".$item['_source']['in_req'].PHP_EOL;

                        if (isset($terminals[$id]))
                        {
                            if ($item['_source']['response_code'] === "00")
                            {
                                $terminals[$id] = [
                                    "Sum" =>  $item['_source']['tran_type'] === "0420" ? $terminals[$id]['Sum'] - $item['_source']['amount'] :  $terminals[$id]['Sum'] + $item['_source']['amount'],
                                    "Count" =>  $item['_source']['tran_type'] === "0420" ? $terminals[$id]['Count'] - 1 : $terminals[$id]['Count']  + 1,
                                    "Terminal" => $item['_source']['card_acceptor_id'],
                                    "Location" => $item['_source']['card_acceptor_name_loc'],
                                    "Account" => $item['_source']['account'],
                                    "Trade Name" => $item['_source']['trade_name'],
                                    "Serial Number" => $item['_source']['serial_number'],
                                ];
                            }

                        }  else {
                            if ($item['_source']['response_code'] === "00") {
                                $terminals[$id] = [
                                    "Sum" => $item['_source']['amount'],
                                    "Count" => 1,
                                    "Terminal" => $item['_source']['card_acceptor_id'],
                                    "Location" => $item['_source']['card_acceptor_name_loc'],
                                    "Account" => $item['_source']['account'],
                                    "Trade Name" => $item['_source']['trade_name'],
                                    "Serial Number" => $item['_source']['serial_number'],
                                ];
                            }
                        }
                    }


                }
            }

            // When done, get the new scroll_id
            // You must always refresh your _scroll_id!  It can change sometimes
            $scroll_id = $response['_scroll_id'];

            // Execute a Scroll request and repeat
            $response = $client->scroll([
                    "scroll_id" => $scroll_id,  //...using our previously obtained _scroll_id
                    "scroll" => "30s"           // and the same timeout window
                ]
            );

        }

        // loop terminals

        $file = fopen("Report-Terminal-Commissions-all-july.txt","w+");

        foreach ($terminals as $key => $terminal)
        {
            $output = "{$key},{$terminal['Terminal']},{$terminal['Location']},{$terminal['Account']},{$terminal['Trade Name']},{$terminal['Count']},{$terminal['Sum']}".PHP_EOL;
            fwrite($file,$output);
            echo $output;
        }

        fclose($file);
    }
}
