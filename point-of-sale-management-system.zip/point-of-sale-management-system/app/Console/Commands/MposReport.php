<?php

namespace App\Console\Commands;

use App\models\Request;
use Illuminate\Console\Command;

class MposReport extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'report:mpos';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'MPOS Requests MPOS';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $requests = Request::query()
            ->whereNotNull('resolution')
            ->where('resolution' , 'like' , '%MPOS%')
            ->where('type' , '=' , 'new-terminal')->latest()->with('requester.branch_name')->get();

        // Create files

        $file = fopen("All MPos Requests.txt","w+");

        //requester

        foreach ($requests as $key => $request)
        {

            $proof = "";

            if (isset($request->data['proof'])){
                $proof = "http://192.168.0.124:8080/download/proof/{$request->id}";
            }

            $output = "{$request->id},{$request->created_at},{$request->requester->name},{$request->requester->branch_name->name},{$proof}".PHP_EOL;

            fwrite($file,$output);
            echo $output;
        }

        fclose($file);

        // Write and save files

    }
}
