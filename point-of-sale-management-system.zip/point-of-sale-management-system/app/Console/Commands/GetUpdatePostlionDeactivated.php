<?php

namespace App\Console\Commands;

use App\models\Terminal;
use App\services\integration\models\Term;
use Illuminate\Console\Command;

class GetUpdatePostlionDeactivated extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'pos:deactivate';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $terminals = Term::query()->where('term_active' , 0 )->get();

        foreach ($terminals as $terminal){

            echo "Terminal : ".$terminal->id.PHP_EOL;

            Terminal::query()->where('terminal_id' , $terminal->id )->update([
               'active' => 0
            ]);

        }

    }
}
