<?php

namespace App\Console\Commands;

use App\models\Transaction;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class DailyTransactions extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'integration:daily-transactions-import';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Get Daily Transaction';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        $this->log('Starting Daily Transactions Import');

        $this->log('Clearing cache');

        Cache::tags('terminal-transaction')->flush();

        $this->log('Cache cleared');

        $this->log('Fetching Last Transaction in POS Management');

        /** @var Transaction $start */
        $start = Transaction::search('*')
            ->orderBy('tran_nr' , 'desc')->first();

        $start = 1547;//(int)$start->tran_nr;
        $this->log('Last Transaction : '. $start );

        $this->log('Fetching Last Transaction in Postlion');

        $end  = $this->getTable('tm_trans')->select( [ 'tran_nr' ])
            ->whereIn('source_node', [
                'AgriPosSrc',
                'AgriMerchSrc',
                'AgriMPOSSrc',
                'AgriTellSrc',
            ])->orderBy('tran_nr', 'desc')->first();

        /** @noinspection NullPointerExceptionInspection */
        $end = (int)$end->tran_nr;

        $this->log('Last Transaction : '. $end );

        $this->log('Number to be imported  (estimated): '. ( $end - $start ) );

        $this->log('Starting Import');

        // Run Chuck

        try {

            $this->getTable('tm_trans')->select(
                [
                    'tran_nr',
                    'state',
                    'source_node',
                    'srcnode_amount_final',
                    'sink_node',
                    'pan',
                    'expiry_date',
                    'ret_ref_no',
                    'card_acceptor_term_id',
                    'card_acceptor_name_loc',
                    'account_id_1',
                    'account_id_2',
                    'sponsor_bank',
                    'in_req',
                    'structured_data_req',
                    'extended_data',
                    'tran_type',
                    'rsp_code_req_rsp',
                ]
                )
                ->whereBetween('tran_nr' , [ $start , $end ])
                ->whereIn('source_node', [
                    'AgriPosSrc',
                    'AgriMerchSrc',
                    'AgriMPOSSrc',
                    'AgriTellSrc',
                ])
                ->orderBy('tran_nr', 'asc')
                ->chunk(1000 , function ($items){

                    foreach ($items as $item)
                    {
                        if ((int)Transaction::search($item->tran_nr )->count() === 0 )
                        {
                            Transaction::query()->create([

                                'tran_nr'=> $item->tran_nr,
                                'state'=> $item->state,
                                'source_node'=> $item->source_node,
                                'amount'=> $item->srcnode_amount_final / 100 ,
                                'sink_node'=> $item->sink_node,
                                'pan'=> $item->pan,
                                'expiry_date'=> $item->expiry_date,
                                'ret_ref_no'=> $item->ret_ref_no,
                                'card_acceptor_id'=> $item->card_acceptor_term_id,
                                'card_acceptor_name_loc'=> $item->card_acceptor_name_loc,
                                'account_id_1'=> $item->account_id_1,
                                'account_id_2'=> $item->account_id_2,
                                'sponsor_bank'=> $item->sponsor_bank,
                                'in_req'=> $item->in_req,
                                'structured_data'=> $item->structured_data_req,
                                'extended_data'=> $item->extended_data,
                                'tran_type'=> $item->tran_type,
                                'response_code'=> $item->rsp_code_req_rsp,

                            ]);

                        }

                        /*if ( now()->format('H:i') > '05:00' )
                        {
                            throw new \Exception('Exceeded Time Will Continue Import Next Day');
                        }*/
                    }
                });

        }  catch (\Exception $exception){

            $this->log('Error : Start =========================================== ');
            $this->log($exception->getMessage());
            $this->log('Error : End ============================================= ');
        }

        $this->log('Done Import');
        $this->log('Generating Summary');

        /** @var Transaction $latest */
        $latest = Transaction::search('*')
            ->orderBy('tran_nr' , 'desc')->first();

        $latest = (int)$latest->tran_nr;

        $this->log('Latest in POS Management : '. $latest );
        $this->log('Number Imported  (estimated): '. ( $latest - $start ) );
        $this->log('Number Left  (estimated): '.  ( $end - $latest ) );
        $this->log('End of import');

    }

    public function log($message): void
    {

        echo  '[ '.now().' ]' . $message .PHP_EOL;

    }

    public  function getTable($name): \Illuminate\Database\Query\Builder
    {
        return DB::connection('sqlsrv_live')->table($name);
    }

}
