<?php

namespace App\Jobs;

use App\models\ReportRequest;
use App\Reports\Core\ReportsService;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class RunReportJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    /**
     * @var ReportRequest $request
     */

    public $request;

    /**
     * Create a new job instance.
     *
     * @param ReportRequest $request
     */
    public function __construct(ReportRequest $request)
    {
        $this->request = $request;
        $this->request->update([
           'progress' => '0.1',
           'state' => 'Queued For Processing'
        ]);
    }

    /**
     * Execute the job.
     *
     * @return void
     * @throws \Exception
     */
    public function handle()
    {
        $service = new ReportsService();
        $this->request->update([
            'progress' => '0.15',
            'state' => 'Init Running Report'
        ]);

        $service->run($this->request);

    }
}
