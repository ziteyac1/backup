<?php

namespace App\Jobs;

use App\models\Terminal;
use App\services\integration\PostlionService;
use App\services\local\TerminalsService;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class DeactivateTerminal implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */

    public $terminal;

    public function __construct($terminal)
    {
        $this->terminal = $terminal;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $service  = new PostlionService([
           'terminal' => $this->terminal
        ]);
        $service->deactivate();

        $localService = new TerminalsService();
        $localService->deactivate($this->terminal);

    }
}
