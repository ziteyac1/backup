<?php

namespace App\elastic;

use ScoutElastic\IndexConfigurator;
use ScoutElastic\Migratable;

class TransactionsConfigurator extends IndexConfigurator
{
    use Migratable;

    protected $name = 'pos_transactions_index';

    /**
     * @var array
     */
    protected $settings = [
        'number_of_replicas' => 2,
        'analysis' => [
            'analyzer' => [
                'es_std' => [
                    'type' => 'standard',
                    'stopwords' => '_spanish_'
                ]
            ]
        ]
    ];
}