<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 2/11/2019
 * Time: 10:08 AM
 */

namespace App\elastic;


class TransactionsService
{

    private $params;

    /**
     * TransactionsService constructor.
     * @param $params
     */
    public function __construct($params)
    {
        $this->params = $params;
    }

    /**
     * @return array
     */
    public function search(): array
    {
        $client = $this->makeClient();

        $params = [
            'index' => 'pos_transactions_index',
            'type' => 'transactions',
            'body' => $this->params
        ];

        return $client->search($params);
    }

    /**
     * @param $params
     * @return TransactionsService
     */
    public function setParameters($params): TransactionsService
    {
        $this->params = $params;
        return $this;
    }

    /**
     * @return \Elasticsearch\Client
     */
    public function makeClient(): \Elasticsearch\Client
    {
        return \Elasticsearch\ClientBuilder::create()->build();
    }
}