<?php

namespace App\Providers;

use App\Events\RequestUpdated;
use App\Listeners\AuditedListener;
use App\Listeners\RequestAuthorizedAction;
use App\Listeners\RequestUpdatedAction;
use Illuminate\Support\Facades\Event;
use Illuminate\Auth\Events\Registered;
use Illuminate\Auth\Listeners\SendEmailVerificationNotification;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use App\Events\RequestCreated;
use App\Listeners\RequestCreatedAction;
use App\Events\RequestAuthorized;
use App\Events\RequestImplemented;
use App\Listeners\RequestImplementedAction;
use App\Events\RequestConfirmed;
use App\Listeners\RequestConfirmedAction;
use App\Events\RequestClosed;
use App\Listeners\RequestClosedAction;
use App\Events\POSBatchTrasnferSent;
use App\Listeners\POSBatchTrasnferSentAction;
use App\Events\POSBatchTrasnferReceived;
use App\Listeners\POSBatchTrasnferReceivedAction;
use OwenIt\Auditing\Events\Audited;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event listener mappings for the application.
     *
     * @var array
     */
    protected $listen = [
        Registered::class => [
            SendEmailVerificationNotification::class,
        ],
        RequestCreated::class => [
            RequestCreatedAction::class,
        ],
        RequestUpdated::class => [
            RequestUpdatedAction::class,
        ],
        RequestAuthorized::class => [
            RequestAuthorizedAction::class,
        ],
        RequestImplemented::class => [
            RequestImplementedAction::class,
        ],
        RequestConfirmed::class => [
            RequestConfirmedAction::class,
        ],
        RequestClosed::class => [
            RequestClosedAction::class,
        ],
        POSBatchTrasnferReceived::class => [
            POSBatchTrasnferReceivedAction::class,
        ],
        POSBatchTrasnferSent::class => [
            POSBatchTrasnferSentAction::class,
        ],
        Audited::class => [
            AuditedListener::class
        ]
    ];

    /**
     * Register any events for your application.
     *
     * @return void
     */
    public function boot()
    {
        parent::boot();

        //
    }
}
