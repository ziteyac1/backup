<?php

namespace App\Providers;

use App\models\POSHire;
use App\models\POSTrasnfer;
use App\models\POSTrasnferBatch;
use App\models\ReportRequest;
use App\models\Request;
use App\models\system\Input;
use App\models\Teller;
use App\models\Terminal;
use App\Policies\InputPolicy;
use App\Policies\POSHirePolicy;
use App\Policies\POSTransfer;
use App\Policies\POSTransferPolicy;
use App\Policies\POSTrasnferBatchPolicy;
use App\Policies\ReportsRequestPolicy;
use App\Policies\RequestPolicy;
use App\Policies\TellerPolicy;
use App\Policies\TerminalPolicy;
use App\Policies\UserPolicy;
use App\User;
use Illuminate\Support\Facades\Gate;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
        Request::class => RequestPolicy::class ,
        POSTrasnferBatch::class => POSTrasnferBatchPolicy::class ,
        User::class => UserPolicy::class,
        Terminal::class => TerminalPolicy::class,
        POSHire::class => POSHirePolicy::class,
        Teller::class => TellerPolicy::class,
        POSTrasnfer::class => POSTransferPolicy::class,
        Input::class => InputPolicy::class,
        ReportRequest::class => ReportsRequestPolicy::class,
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();
    }
}
