<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 1/7/2019
 * Time: 2:12 PM
 */

namespace App\services\requests;


use App\Http\Controllers\Controller;
use App\models\Terminal;
use App\services\local\POSTrasnferBatchService;
use App\User;
use Illuminate\Database\Query\Builder;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

trait RequestMethodsCreation
{
    /**
     * @var Request
     */
    protected $request;

    /**
     * @param Controller $controller
     * @return mixed
     * @throws \Illuminate\Validation\ValidationException
     */
    public function new_terminal(Controller $controller)
    {

        $controller->validate($this->request, [
            'account' => ['required', 'exists:accounts'],
            'trade_name' => ['required', 'string', 'max:255'],
            'location' => ['required', 'string', 'max:255'],
            'term_type' => ['required', 'string', 'max:255'],
            'number' => ['required', 'integer', 'min:0'],
            'reason' => ['required', 'string', 'min:10'],
            'proof' => ['required_if:term_type,==,mpos'],
        ]);

        $path = null;

        if ($this->request->file('proof'))
        {
            $path = $this->request->file('proof')->store('proof-of-payments','public');
        }

        return [
            'account' => $this->request['account'],
            'location' => $this->request['location'],
            'terminal_type' => $this->request['term_type'],
            'number' => $this->request['number'],
            'trade_name' => $this->request['trade_name'],
            'reason' => $this->request['reason'],
            'proof' => $path
        ];

    }

    /**
     * @param Controller $controller
     * @return mixed
     * @throws \Illuminate\Validation\ValidationException
     */
    public function pos_repair(Controller $controller)
    {

        $req = $this->request;

        $controller->validate($req, [
            'log' => ['required', 'exists:p_o_s_machine_logs,id'],
            'serial_number' => ['required', 'string', 'exists:p_o_s_machines'],
            'terminal' => ['required', 'exists:terminals,terminal_id', 'string'],
            'asset_code' => ['required','max:6','min:6'],
        ]);

        $user  =  auth()->user();

        $decision = [
            'branch' => [
                'to' => 'merchant-services',
                'to_branch' => '001',
                'transport' => 'swift'
            ],
            'merchant-services' => [
                'to' => 'e-channels',
                'to_branch' => '001',
                'transport' => 'internal'
            ],
            'merchant-services-manager' => [
                'to' => 'e-channels',
                'to_branch' => '001',
                'transport' => 'internal'
            ]

        ];

        if ($user){

            /** @var User $user */
            $role = $user->role_name->name;

            if (isset($decision[$role])){

                $batchService = new POSTrasnferBatchService();
                $batch = $batchService->getBatch($decision[$role]['to'] ,$decision[$role]['to_branch'] , $decision[$role]['transport']);
                $batchService->transfer($batch , $req['terminal'] , $req['serial_number'] );

            }

        }


        return [
            'serial_number' => $req['serial_number'],
            'terminal' => $req['terminal'],
            'log' => $req['log'],
            'asset_code' => $req['asset_code'],
        ];

    }

    /**
     * @param Controller $controller
     * @return mixed
     * @throws \Illuminate\Validation\ValidationException
     */
    public function change_of_details(Controller $controller)
    {

        $req = $this->request;

        $controller->validate($req, [
            'terminal' => ['required', 'exists:terminals,terminal_id', 'string'],
            'account' => [
                'required',

                Rule::exists('accounts')->where(function (Builder $query) use ($req) {

                    $terminal = Terminal::query()->where('terminal_id', $req['terminal'])->first();
                    /** @noinspection NullPointerExceptionInspection */
                    $query->whereIn('account', $terminal->account->customer->accounts->pluck('account') );

                }),],

            'trade_name' => ['required', 'string', 'max:255'],
            'location' => ['required', 'string', 'max:255'],
        ]);

        return [
            'terminal' => $this->request['terminal'],
            'new' => [
                'account' => $this->request['account'],
                'location' => $this->request['location'],
                'trade_name' => $this->request['trade_name']
            ]
        ];
    }

    /**
     * @param Controller $controller
     * @return mixed
     * @throws \Illuminate\Validation\ValidationException
     */
    public function re_allocation(Controller $controller)
    {

        $req = $this->request;

        $controller->validate($req, [
            'account' => ['required', 'exists:accounts'],
            'trade_name' => ['required', 'string', 'max:255'],
            'location' => ['required', 'string', 'max:255'],
            'terminal' => ['required', 'exists:terminals,terminal_id', 'string'],
        ]);

        return [
            'terminal' => $req['terminal'],
            'new' => [
                'account' => $req['account'],
                'location' => $req['location'],
                'trade_name' => $req['trade_name']
            ]
        ];
    }

    /**
     * @param Controller $controller
     * @return mixed
     * @throws \Illuminate\Validation\ValidationException
     */
    public function terminal_testing(Controller $controller)
    {

        $req = $this->request;

        $controller->validate($req, [
            'serial_number' => ['required', 'string', 'exists:p_o_s_machines'],
            'terminal' => ['required', 'exists:terminals,terminal_id', 'string'],
        ]);

        return [
            'serial_number' => $req['serial_number'],
            'terminal' => $req['terminal'],
        ];
    }

    /**
     * @param Controller $controller
     * @return mixed
     * @throws \Illuminate\Validation\ValidationException
     */
    public function replacement(Controller $controller)
    {

        $req = $this->request;

        $controller->validate($req, [
            'serial_number' => ['required', 'string', 'exists:p_o_s_machines'],
            'to_serial_number' => ['required', 'string', 'exists:p_o_s_machines,serial_number'],
            'terminal' => ['required', 'exists:terminals,terminal_id', 'string'],
        ]);

        return [
            'serial_number' => $req['serial_number'],
            'terminal' => $req['terminal'],
            'to_serial_number' => $req['to_serial_number'],
        ];
    }

    /**
     * @param Controller $controller
     * @return mixed
     * @throws \Illuminate\Validation\ValidationException
     */
    public function pos_hire(Controller $controller)
    {

        $req = $this->request;

        $controller->validate($req, [
            'customer' => ['required', 'string', 'exists:customers,id'],
            'account' => ['required', 'string'],
            'bank' => ['required', 'string'],
			'terminal' => ['string']
        ]);


        $path = null;

        if ($this->request->file('proof'))
        {
            $path = $this->request->file('proof')->store('proof-of-payments','public');
        }

        return [
            'customer' => $req['customer'],
            'account' => $req['account'],
            'bank' => $req['bank'],
            'proof' => $path,
			'terminal' => $req['terminal']
        ];
    }

    /**
     * @param Controller $controller
     * @return mixed
     * @throws \Illuminate\Validation\ValidationException
     */
    public function change_account(Controller $controller)
    {

        $req = $this->request;

        $controller->validate($req, [
            'old' => ['required', 'string', 'exists:accounts,account'],
            'account' => ['required', 'string','min:12','max:12'],
            'branch_code' => ['required', 'string','exists:branches,branch_code'],
        ]);

        return [
            'old' => $req['old'],
            'account' => $req['account'],
            'branch_code' => $req['branch_code'],
        ];
    }
    /**
     * @param Controller $controller
     * @return mixed
     * @throws \Illuminate\Validation\ValidationException
     */
    public function change_customer(Controller $controller)
    {
        $request = $this->request;

        $controller->validate($request , [
            'name' => ['required', 'string', 'max:255'],
            'id' => ['required', 'string', 'exists:customers'],
            'last_name' => ['required', 'string', 'max:255'],
            'phone' => ['required', 'string', 'max:255','regex:/(^2637)/'],
            'address' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email'],
        ]);


        return [
            'id' => $request['id'],
            'new' => [
                'name' => $request['name'],
                'last_name' => $request['last_name'],
                'address' => $request['address'],
                'email' => $request['email'],
                'phone' => $request['phone']
            ]
        ];

    }
}