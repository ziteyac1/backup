<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 1/3/2019
 * Time: 8:44 AM
 */

namespace App\services\requests;


use App\Http\Controllers\Controller;
use App\models\system\RequestState;
use App\models\system\Role;
use App\models\Terminal;
use App\User;
use Illuminate\Database\Query\Builder;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class RequestCreateService
{
    use RequestMethodsCreation;

    /**
     * @var array
     */
    protected $request_types = [
                        'new-terminal',
                        're-allocation',
                        'change-of-details',
                        'pos-repair',
                        'terminal-testing',
                        'replacement',
                        'pos-hire',
                        'change-account',
                        'change-customer'
                     ];

    /**
     * @var string
     */

    protected $current_request;

    /**
     * @var User
     */
    protected $user;


    /**
     * Create a new ThreadFilters instance.
     *
     * @param Request $request
     */
    public function __construct(Request $request)
    {
        $this->request = $request;
        $this->user = auth()->user();
    }

    /**
     * @param Controller $controller
     * @param string $type
     * @return mixed
     */
    public function create( Controller $controller , string $type ){

        $this->current_request = $type;
        $method = $this->make_method($type);




        /** @noinspection TypeUnsafeArraySearchInspection */
        if ( $this->checkRequestTypeDefined() && method_exists( $this , $method )){

            $data =  $this->$method($controller);
            /** @noinspection ReturnNullInspection */
            /** @var RequestState $state */
            $state =  $this->getState($this->user);

            if($state) {

                return \App\models\Request::query()->create([
                    'requester_id' => $this->user->id,
                    'role_assigned' => $state->role,
                    'branch_code' => $this->user->branch,
                    'type' => $this->current_request,
                    'data' => $data,
                    'state' => $state->id,
                ]);

            }

            abort(422 , 'There was an error in processing your entity');

        }

        return abort(404, 'Request type not found');

    }

    /**
     * @param Controller $controller
     * @param \App\models\Request $req
     * @return \App\models\Request
     */
    public function update(Controller $controller , \App\models\Request $req){

        $this->current_request =  $req->type;
        $method = $this->make_method($req->type);

        if ( $this->checkRequestTypeDefined() && method_exists( $this , $method )){

            $data =  $this->$method($controller);

            $req->update([
                'data' => $data
            ]);

            return $req;

        }

        return abort(404, 'Request type not found');
    }

    /**
     * @param string $type
     * @return mixed|string
     */
    public function make_method(string $type)
    {
        return  str_replace('-', '_', $type);
    }


    /**
     * @param $user
     * @return \Illuminate\Database\Eloquent\Builder|\Illuminate\Database\Eloquent\Model|null
     */
    protected function getState($user){

        $state = null;
        $level = $user->role;

        do {

            $level++;
            $role = Role::query()->find($level);

            /** @noinspection PhpUndefinedFieldInspection */
            $state =  RequestState::query()
                ->where('name', $this->current_request)
                ->where('role', $role->name)
                ->orderBy('id','asc')
                ->first();

        } while ( $state === null );

        return $state;

    }

    /**
     * @return array
     */
    public function getRequestTypes(): array
    {
        return $this->request_types;
    }

    /**
     * @return bool
     */
    public function checkRequestTypeDefined(): bool
    {
        /** @noinspection TypeUnsafeArraySearchInspection */
        return \in_array($this->current_request, $this->getRequestTypes() );
    }


}