<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 1/4/2019
 * Time: 3:10 PM
 */

namespace App\services\requests;


use App\Events\RequestAuthorized;
use App\Events\RequestClosed;
use App\Events\RequestConfirmed;
use App\Events\RequestImplemented;
use App\Http\Controllers\Controller;
use App\Listeners\RequestAuthorizedAction;
use App\models\Request;
use App\services\requests\action\Authorize;
use App\services\requests\action\Confirm;
use App\services\requests\action\Implement;

class RequestActionService
{

    /**
     * @param Controller $controller
     * @param Request $request
     * @return mixed
     */
    public function action( Controller $controller , Request $request ){

        $request->load('state_name');
        $class  = $this->makeClass( $request->state_name->action );
        $method = $this->makeMethod( $request->type );

        $service = app()->make( $class );

        if ( $service && method_exists( $service , $method ) ){

            $data = $service::$method( $controller , $request );

            switch ($class){

                case Authorize::class :
                    event(new RequestAuthorized($request));
                    break;
                case Implement::class :

                    event(new RequestImplemented($request));

                    if ($request->state_name->action === 'close'){
                        event(new RequestClosed($request));
                    }

                    break;
                case Confirm::class :

                    event(new RequestConfirmed($request));

                    if ($request->state_name->action === 'close'){
                        event(new RequestClosed($request));
                    }
                    break;

                default :

            }

            return $data;

        }

        return abort(404 , 'Method Not Found');

    }

    /**
     * @param $action
     * @return string
     */
    public function makeClass($action): string
    {

        $action = ucwords($action);
        return "App\\services\\requests\\action\\{$action}";

    }

    /**
     * @param $type
     * @return string
     */
    public function makeMethod($type): string
    {

        return str_replace('-','_' , $type);

    }

}