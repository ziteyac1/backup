<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 1/4/2019
 * Time: 3:41 PM
 */

namespace App\services\requests\action;


use App\Http\Controllers\Controller;
use App\Jobs\DeactivateTerminal;
use App\models\Account;
use App\models\Customer;
use App\models\POSHire;
use App\models\Request;
use App\models\system\SystemValue;
use App\models\Terminal;
use App\services\integration\PostlionService;
use App\services\local\POSTrasnferBatchService;
use App\services\local\TerminalsService;

class Implement implements RequestAction
{
    use DefaultRequestAction;

    /**
     * @param Controller $controller
     * @param Request $request
     * @return string
     */
    public static function new_terminal(Controller $controller, Request $request) : string
    {

        self::checkIFExecutedInstantly($request);

        $data = [];

        $defaultBranch = '040';

        $account = Account::query()->where( 'account' ,  $request->data['account'] )->first();

        $service  = new PostlionService([
            'name' =>  $request->data['trade_name'] ,
            'account' =>  $request->data['account'] ,
            'location' =>  $request->data['location'],
            'type' =>  $request->data['terminal_type'],
            'branch' => $account ? $account->branch_code : $defaultBranch ,
        ]);

        $resolution = $request->resolution;

        for ($i = 1 ; $i <= $request->data['number'] ; $i++ ){

            $terminal = $service->create();

            $data[] = Terminal::query()->create([
                'terminal_id' => $terminal['terminal'],
                'account_id' => $request->data['account'],
                'override_term_type' => $terminal['override_term_type'],
                'term_type' => $request->data['terminal_type'],
                'trade_name' => $request->data['trade_name'],
                'location' => $request->data['location'],
                'active' => true,
            ]);

            $resolution['terminals'][] = [
                'terminal_id' => $terminal['terminal'],
                'account_id' => $request->data['account'],
                'terminal_type' => $request->data['terminal_type'],
                'trade_name' => $request->data['trade_name'],
                'location' => $request->data['location'],
            ];

        }

        $request->resolution = $resolution;
        $request->save();

        self::defaultAction($request);

        $message =  'Created '. \count($data) .' '.str_plural('terminal' , $data ) .'<br>';

        foreach ( $data as $item ){
            $message .= "{$item->terminal_id} : {$item->account_id}  : {$item->trade_name} <br>";
        }

        return $message;

    }

    /**
     * @param Controller $controller
     * @param Request $request
     * @return string
     */
    public static function re_allocation(Controller $controller, Request $request) : string
    {
        return self::changeDetails($request);
    }

    /**
     * @param Controller $controller
     * @param Request $request
     * @return string
     */
    public static function change_of_details(Controller $controller, Request $request) : string
    {
        return self::changeDetails($request);
    }

    /**
     * @param Controller $controller
     * @param Request $request
     * @return string
     */
    public static function pos_repair(Controller $controller, Request $request)
    {

        $resolution = $request->resolution;

        $batchService = new POSTrasnferBatchService();
        $batch = $batchService->getBatch('eft' ,'eft' , 'drivers');
        $batchService->transfer($batch ,$request->data['terminal'],$request->data['serial_number']);

        $resolution['echannels'] = [
            'type' => 'sent',
            'to' => 'eft',
            'to_branch' =>  'eft',
            'transport' =>  'drivers',
            'sender_id' =>  auth()->id(),
            'terminal' => $request->data['terminal'],
            'serial_number' =>  $request->data['serial_number'],
            'batch_id' =>  $batch->id,
            'asset_code' =>  $request->data['asset_code'],
        ];

        $request->resolution = $resolution;
        $request->save();

        self::defaultAction($request);

        return "POS Repair Sent to Batch : {$batch->id} <br> "
            .  'To :  eft <br> '
            .  'Branch : eft <br>';
    }

    /**
     * @param Controller $controller
     * @param Request $request
     * @return mixed
     */
    public static function terminal_testing(Controller $controller, Request $request)
    {
        self::checkIFExecutedInstantly($request);

        $service = new PostlionService([
            'terminal' => $request->data['terminal'],
        ]);
        $service->activate();

        $terminalService = new TerminalsService();
        $terminalService->activate( $request->data['terminal'] );
        $terminalService->updateSerial( $request->data['terminal'] , $request->data['serial_number'] );

        DeactivateTerminal::dispatch( $request->data['terminal'])
            ->delay( now()->addMinute(20) );

        $resolution = [
            'serial_number' => $request->data['serial_number'],
            'terminal' => $request->data['terminal'],
        ];

        $request->resolution = $resolution;
        $request->save();

        self::defaultAction($request);

        return "Terminal Activated : {$request->data['terminal']} : Temporarily for 20 minutes <br> "
            . "Serial Number :  {$request->data['serial_number']} <br> ";
    }

    /**
     * @param Controller $controller
     * @param Request $request
     * @return string
     */
    public static function replacement(Controller $controller, Request $request)
    {
        self::checkIFExecutedInstantly($request);

        $terminalService = new TerminalsService();
        $terminalService->updateSerial( $request->data['terminal'] , $request->data['to_serial_number'] );

        $resolution = [
            'serial_number' => $request->data['serial_number'],
            'terminal' => $request->data['terminal'],
            'to_serial_number' => $request->data['to_serial_number'],
        ];

        $request->resolution = $resolution;
        $request->save();

        self::defaultAction($request);

        return "Terminal Updated : {$request->data['terminal']} <br> "
            . "Serial Number :  {$request->data['serial_number']} <br> "
            . "To Serial Number : {$request->data['to_serial_number']} <br>";

    }

    /**
     * @param Controller $controller
     * @param Request $request
     * @return string
     */
    public static function pos_hire(Controller $controller, Request $request)
    {
        self::checkIFExecutedInstantly($request);

        $resolution = $request->data;
		
		$customer = \App\models\Customer::find($request->data['customer']);
		
		\App\models\POSHire::query()->where( 'terminal' , $request->data['terminal'] )->update([
		  'customer_id' =>  $request->data['customer']
		]);
		
        $resolution['terminal'] = $request->data['terminal'];
        $resolution['account'] = $request->data['account'];
        $resolution['bank'] = $request->data['bank'];

        /** @noinspection NullPointerExceptionInspection */
        $resolution['customer'] = $customer->toArray(); 
	   // $resolution['customer'] = $request->data['customer'];
        $request->resolution = $resolution;
        $request->save();

        self::defaultAction($request);

        /** @noinspection NullPointerExceptionInspection */
		//"POS hire Implemented : {$hire->terminal} <br>"
        return "POS hire Implemented :<br>"
            ."Customer :  {$customer->name} - {$customer->last_name} - {$customer->email} <br> ";

    }

    /**
     * @param Request $request
     * @return string
     */

    public static function changeDetails(Request $request): string
    {
        self::checkIFExecutedInstantly($request);

        $account = Account::query()->where('account', $request->data['new']['account'])->first();

        $resolution = $request->resolution;

        /** @noinspection NullPointerExceptionInspection */
        $service = new PostlionService([
            'terminal' => $request->data['terminal'],
            'name' => $request->data['new']['trade_name'],
            'account' => $request->data['new']['account'],
            'location' => $request->data['new']['location'],
            'branch' => $account->branch_code,
        ]);

        $service->update();

        $terminal = Terminal::query()->where('terminal_id', $request->data['terminal'])->first();

        /** @noinspection NullPointerExceptionInspection */
        $resolution['old'] = [
            'account_id' => $terminal->account_id,
            'trade_name' => $terminal->trade_name,
            'location' => $terminal->location,
        ];

        /** @noinspection NullPointerExceptionInspection */
        $terminal->update([
            'account_id' => $request->data['new']['account'],
            'trade_name' => $request->data['new']['trade_name'],
            'location' => $request->data['new']['location'],
        ]);

        $resolution['new'] = [
            'account_id' => $request->data['new']['account'],
            'trade_name' => $request->data['new']['trade_name'],
            'location' => $request->data['new']['location'],
        ];

        $request->resolution = $resolution;
        $request->save();

        self::defaultAction($request);

        return "Terminal Updated : {$request->data['terminal']} <br> "
            . "Location :  {$request->data['new']['location']} <br> "
            . "Account : {$request->data['new']['account']} <br>"
            . "Trade Name :  {$request->data['new']['trade_name']}";
    }

    /**
     * @param Controller $controller
     * @param Request $request
     * @return string
     */

    public static function change_account(Controller $controller, Request $request): string
    {
        self::checkIFExecutedInstantly($request);

        /** @noinspection NullPointerExceptionInspection */
        $service = new PostlionService([]);
        $service->updateAccount(
            $request->data['old'],
            $request->data['account'],
            $request->data['branch_code']
        );

        Terminal::query()->where('account_id' , $request->data['old'] )->update([
            'account_id' => $request->data['account']
        ]);

        if (!Account::query()->where('account' , $request->data['account'] )->exists()){

            Account::query()->where('account' , $request->data['old'] )->update([
                'branch_code' => $request->data['branch_code'],
                'account' => $request->data['account']
            ]);

        }

        /** @noinspection NullPointerExceptionInspection */
        $resolution  = $request->data;

        $request->resolution = $resolution;
        $request->save();

        self::defaultAction($request);

        return  "Account Updated : {$request->data['old']} <br> "
            .   "Account :  {$request->data['account']} <br> "
            .   "Branch : {$request->data['branch_code']} <br>";
    }

    public static function change_customer(Controller $controller, Request $request): string
    {
        self::checkIFExecutedInstantly($request);

        $customer = Customer::query()->where('id' , $request->data['id'] )->first();

        if ($customer){

            $customer->update( $request->data['new'] );

        }

        /** @noinspection NullPointerExceptionInspection */
        $resolution  = $request->data['new'];

        $request->resolution = $resolution;
        $request->save();

        self::defaultAction($request);

        return  "Customer Updated ID: {$request->data['id']} <br> ";

    }

    /**
     * @param Request $request
     */
    public static function checkIFExecutedInstantly(Request $request): void
    {
        if (self::checkIsRootAssigned($request)) {

            self::defaultAction($request);

        }
    }

    /**
     * @param Request $request
     * @return bool
     */
    public static function checkIsRootAssigned(Request $request): bool
    {
        return $request->role_assigned !== 'root';
    }
}