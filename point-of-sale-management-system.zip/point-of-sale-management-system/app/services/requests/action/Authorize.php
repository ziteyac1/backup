<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 1/4/2019
 * Time: 3:40 PM
 */

namespace App\services\requests\action;


use App\Http\Controllers\Controller;
use App\models\Request;

class Authorize implements RequestAction
{
    use DefaultRequestAction;

}