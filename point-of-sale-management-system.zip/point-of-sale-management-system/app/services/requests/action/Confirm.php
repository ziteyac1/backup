<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 1/4/2019
 * Time: 3:41 PM
 */

namespace App\services\requests\action;


use App\Http\Controllers\Controller;
use App\models\Request;
use App\services\local\POSTrasnferBatchService;
use App\User;

class Confirm implements RequestAction
{

    use DefaultRequestAction;

    /**
     * @param Controller $controller
     * @param Request $request
     * @return mixed
     */
    public static function new_terminal(Controller $controller, Request $request)
    {
        $user  =  auth()->user();

        $decision = [

            'e-channels' => [
                'to' => 'merchant-services',
                'to_branch' => '001',
                'transport' => 'internal'
            ],
            'merchant-services' => [
                'to' => 'branch',
                'to_branch' => $request->requester->branch,
                'transport' => 'swift'
            ]

        ];

        if ($user){

            /** @var User $user */
            $role = $user->role_name->name;

            if (isset($decision[$role])){

                $batchService = new POSTrasnferBatchService();
                $batch = $batchService->getBatch($decision[$role]['to'] ,$decision[$role]['to_branch'] , $decision[$role]['transport']);

                foreach ($request->resolution['terminals'] as  $terminal)
                {
                    $batchService->transfer($batch , $terminal['terminal_id'] );
                }

            }

        }

        return self::defaultAction($request);
    }

    /**
     * @param Controller $controller
     * @param Request $request
     * @return mixed
     */
    public static function pos_repair(Controller $controller, Request $request)
    {
        $user  =  auth()->user();

        $decision = [

            'e-channels' => [
                'to' => 'merchant-services',
                'to_branch' => '001',
                'transport' => 'internal'
            ],
            'merchant-services' => [
                'to' => 'branch',
                'to_branch' => $request->requester->branch,
                'transport' => 'swift'
            ]

        ];

        if ($user){

            /** @var User $user */
            $role = $user->role_name->name;

            if (isset($decision[$role])){

                $batchService = new POSTrasnferBatchService();
                $batch = $batchService->getBatch($decision[$role]['to'] ,$decision[$role]['to_branch'] , $decision[$role]['transport']);
                $batchService->transfer($batch , $request->data['terminal'] ,$request->data['serial_number'] );

            }

        }

        return self::defaultAction($request);
    }

    /**
     * @param Controller $controller
     * @param Request $request
     * @return mixed
     */
    public static function replacement(Controller $controller, Request $request)
    {
        $user  =  auth()->user();

        $decision = [
            'e-channels' => [
                'to' => 'merchant-services',
                'to_branch' => '001',
                'transport' => 'internal'
            ],
            'merchant-services' => [
                'to' => 'branch',
                'to_branch' => $request->requester->branch,
                'transport' => 'swift'
            ]

        ];

        if ($user){

            /** @var User $user */
            $role = $user->role_name->name;

            if (isset($decision[$role])){

                $batchService = new POSTrasnferBatchService();
                $batch = $batchService->getBatch($decision[$role]['to'] ,$decision[$role]['to_branch'] , $decision[$role]['transport']);
                $batchService->transfer($batch , $request->data['terminal'] ,$request->data['to_serial_number'] );

            }

        }

        return self::defaultAction($request);
    }


}