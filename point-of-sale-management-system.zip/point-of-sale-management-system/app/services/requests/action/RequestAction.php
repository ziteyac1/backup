<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 1/4/2019
 * Time: 3:42 PM
 */

namespace App\services\requests\action;

use App\Http\Controllers\Controller;
use App\models\Request;

interface RequestAction
{
   public static function new_terminal( Controller $controller , Request $request );
   public static function re_allocation( Controller $controller , Request $request );
   public static function change_of_details( Controller $controller , Request $request );
   public static function pos_repair( Controller $controller , Request $request );
   public static function terminal_testing( Controller $controller , Request $request );
   public static function replacement( Controller $controller , Request $request );
   public static function pos_hire( Controller $controller , Request $request );
   public static function change_account( Controller $controller , Request $request );
}