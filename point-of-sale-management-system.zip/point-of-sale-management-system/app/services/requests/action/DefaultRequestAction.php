<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 1/6/2019
 * Time: 1:52 AM
 */

namespace App\services\requests\action;


use App\Http\Controllers\Controller;
use App\models\Request;
use App\models\system\RequestState;

trait DefaultRequestAction
{

    /**
     * @param Request $request
     * @return Request
     */
    public static function defaultAction(Request $request) : string
    {
        $id = $request->state;
        $role = RequestState::query()->find(++$id);

        /** @noinspection PhpUndefinedFieldInspection */
        $request->update([
            'role_assigned' => $role->role,
            'state' => $id
        ]);

        return  "Request {$request->state_name->action} successfully <br>" .
                "Role Assigned : {$request->role_assigned} <br>" .
                "Branch Requested : {$request->branch_code} <br>" .
                "Request Type : {$request->type} <br>";

    }

    /**
     * @param Controller $controller
     * @param Request $request
     * @return mixed
     */
    public static function new_terminal(Controller $controller, Request $request)
    {
        return self::defaultAction($request);
    }

    /**
     * @param Controller $controller
     * @param Request $request
     * @return mixed
     */
    public static function re_allocation(Controller $controller, Request $request)
    {
        return self::defaultAction($request);
    }

    /**
     * @param Controller $controller
     * @param Request $request
     * @return mixed
     */
    public static function change_of_details(Controller $controller, Request $request)
    {
        return self::defaultAction($request);
    }

    /**
     * @param Controller $controller
     * @param Request $request
     * @return mixed
     */
    public static function pos_repair(Controller $controller, Request $request)
    {
        return self::defaultAction($request);
    }

    /**
     * @param Controller $controller
     * @param Request $request
     * @return mixed
     */
    public static function terminal_testing(Controller $controller, Request $request)
    {
        return self::defaultAction($request);
    }

    /**
     * @param Controller $controller
     * @param Request $request
     * @return mixed
     */
    public static function replacement(Controller $controller, Request $request)
    {
        return self::defaultAction($request);
    }

    /**
     * @param Controller $controller
     * @param Request $request
     * @return mixed
     */
    public static function pos_hire(Controller $controller, Request $request)
    {
        return self::defaultAction($request);
    }

    public static function change_account(Controller $controller, Request $request)
    {
        return self::defaultAction($request);
    }
}