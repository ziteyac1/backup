<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 1/3/2019
 * Time: 8:47 AM
 */

namespace App\services\integration;


use App\services\integration\models\CardAcceptor;
use App\services\integration\models\HypBaseTerm;
use App\services\integration\models\Teller;
use App\services\integration\models\Term;
use App\services\integration\models\TerminalLookup;
use App\services\integration\models\TermProfile;

class PostlionService
{

    protected $helper = [

        'merchant' => [
            'search' => '80015',
            'override_term_type' => '1003',
            'trans_profile' => false,
            'participant_id' => 2,
            'first_terminal' => '80010001',
        ],

        'agency' => [
            'search' => 'AGY0',
            'override_term_type' => '1001',
            'trans_profile' => true,
            'participant_id' => 3,
            'first_terminal' => 'AGY00001',
        ],

        'mpos' => [
            'search' => 'MP0',
            'override_term_type' => '1006',
            'trans_profile' => false,
            'participant_id' => 4,
            'first_terminal' => 'MP000001',
        ]
        ,
        'branch' => [
            'search' => '80015',
            'override_term_type' => '1001',
            'trans_profile' => true,
            'participant_id' => 3,
            'first_terminal' => '80010001',
        ],

    ];

    protected $terminal;
    protected $name;
    protected $location;
    protected $account;
    protected $type;
    protected $branch;

    /**
     * PostlionService constructor.
     * @param array $data
     */
    public function __construct( array $data = [] )
    {

        $this->terminal = $data['terminal'] ?? null;
        $this->name = $data['name'] ?? null;
        $this->account = $data['account'] ?? null;
        $this->location = $data['location'] ?? null;
        $this->type = $data['type'] ?? null;
        $this->branch = $data['branch'] ?? null;

    }

    /**
     * @return array
     */
    public function create(): array
    {

        $this->terminal = $this->generateTerminal();

        $this->createCardAcceptor();
        $this->createTerm();
        $this->createHypBase();
        $this->createTerminalLookUp();

        if( $this->helper[$this->type]['trans_profile'] )
        {
            $this->createTermProfile();
        }

        return [
            'terminal' => $this->terminal ,
            'override_term_type' => $this->helper[$this->type]['override_term_type']
        ];

    }

    /**
     * For Updating terminals
     */
    public function update(): void
    {

        TerminalLookup::query()
            ->where('terminal_id' , $this->terminal )->update([
                'branch_code' => $this->branch,
                'description' => $this->name,
                'account' => $this->account,
            ]);

        HypBaseTerm::query()->where('id' , $this->terminal )->update([
            'location_information' => $this->makeHypBaseLocation(),
            'city' => $this->location
        ]);

        $term = Term::query()->where('id' , $this->terminal )->first();

        if ($term){

            $term->update([
                'short_name' => $this->makeShortName(),
            ]);

            CardAcceptor::query()->where('card_acceptor' , $term->card_acceptor )->update([
                'name_location' => $this->makeCardAcceptorLocation(),
            ]);
        }

    }

    /**
     * @param $old
     * @param $new
     * @param $branch
     */
    public function updateAccount($old , $new , $branch): void
    {

        TerminalLookup::query()->where('account' , $old )->update([
            'branch_code' => $branch ,
            'account' => $new
        ]);

    }

    /**
     * Activates a POS Terminal
     */
    public function activate(): void
    {
        Term::query()->where('id' , $this->terminal )->update([
            'term_active' => 1 ,
        ]);
    }

    /**
     * De-activates a POS Terminal
     */
    public function deactivate(): void
    {
        Term::query()->where('id' , $this->terminal )->update([
            'term_active' => 0 ,
        ]);
    }

    /**
     * @param $card
     */
    public function reset($card): void
    {
        Teller::query()->where('teller_card' , $card )->update([
            'current_terminal_id' => null
        ]);
    }

    /**
     * @param array $data
     * @return \Illuminate\Database\Eloquent\Builder|\Illuminate\Database\Eloquent\Model
     */

    public function addTeller(array $data ){

        return Teller::query()->create([
            'teller_first_name' => $data['name'],
            'teller_last_name' => 'Teller',
            'teller_card' => $data['card'],
            'teller_pin' => '3DC18B0BFB193935A8B4654D33205017B918B16F',
            'active' => true,
            'supervisor' => false ,
            'current_terminal_id' => null ,
            'tran_linked_id' => 1 ,
            'msg_linked_id' => 1 ,
            'ext_tran_linked_id' => 1 ,
            'term_linked_id' => 2 ,
            'current_cash_draw_id' => null ,
        ]);

    }

    /**
     * @param $data
     */

    public function updateTeller($data): void
    {

        Teller::query()->where('teller_card' , $data['card'] )->update([
            'teller_first_name' => $data['name'],
        ]);
    }

    /**
     * @param $card
     */
    public function makeSupervisor($card): void
    {
        $this->setCardSupervisorState($card, true);
    }

    /**
     * @param $card
     */
    public function removeSupervisor($card): void
    {
        $this->setCardSupervisorState($card, false);
    }

    /**
     * @return string
     */
    protected function generateTerminal(): string
    {
        $last =   CardAcceptor::query()
            ->where(
                'card_acceptor',
                'like',
                $this->helper[$this->type]['search'].'%'
            )->orderBy('card_acceptor', 'desc')
            ->pluck('card_acceptor')
            ->first();

        $last = $last ? trim($last) : null;
        return $last ? ++$last : $this->helper[$this->type]['first_terminal'];
    }

    /**
     * @param $string
     * @param $limit
     * @return string
     */
    protected function fill( $string, $limit ): string
    {
        return \strlen($string) > $limit ? substr($string, 0, $limit) : $string . str_repeat(' ', $limit - \strlen($string));
    }

    /**
     * @return string
     */
    protected function makeCardAcceptorLocation(): string
    {
        return $this->terminal.' '
            .$this->fill( $this->location , 14 ).' '.
            $this->fill( $this->name , 13).' ZW';
    }

    /**
     * @return string
     */
    protected function makeShortName(): string
    {
        return $this->fill(str_slug( $this->fill( $this->name , 12 ) ). ' ' .substr( $this->terminal , 4 , 4 ) , 18 );
    }

    /**
     * @return string
     */
    protected function makeHypBaseLocation(): string
    {
        return $this->fill($this->terminal.' '.$this->location , 21 ) ;
    }

    /**
     * @return array
     */
    public function getHelper(): array
    {
        return $this->helper;
    }

    /**
     * @param $card
     * @param $state
     */
    public function setCardSupervisorState($card, $state): void
    {
        Teller::query()->where('teller_card', $card)->update([
            'supervisor' => $state,
        ]);
    }

    public function createCardAcceptor(): void
    {
        CardAcceptor::query()->create([

            'card_acceptor' => $this->terminal,
            'name_location' => $this->makeCardAcceptorLocation(),
            'currency_code' => '840',
            'default_lang' => 0,
            'card_set' => 'DefaultCardSet',
            'limits_class' => 'DefaultLimitsClass',
            'routing_group' => 'DefaultRoutingGroup',

        ]);
    }

    public function createTerm(): void
    {
        Term::query()->create([

            'id' => $this->terminal,
            'short_name' => $this->makeShortName(),
            'term_type' => 5,
            'term_active' => 1,
            'worst_event_severity' => 0,
            'card_acceptor' => $this->terminal,
            'participant_id' => $this->helper[$this->type]['participant_id'],
            'pos_geographic_data' => '              263',
            'sponsor_bank' => '504875',
            'pos_data_code' => '010101210041201',

        ]);
    }

    public function createHypBase(): void
    {
        HypBaseTerm::query()->create([

            'id' => $this->terminal,
            'currency_code' => '840',
            'key_management_scheme' => 1,
            'override_terminal_type' => $this->helper[$this->type]['override_term_type'],
            'location_information' => $this->makeHypBaseLocation(),
            'city' =>  $this->fill( $this->location , 11 ) ,
            'state_region' => '  ',
            'country' => 'ZW'

        ]);
    }

    public function createTerminalLookUp(): void
    {
        TerminalLookup::query()->create([

            'merchant_id' => $this->terminal,
            'terminal_id' => $this->terminal,
            'branch_code' => $this->branch,
            'description' => $this->name,
            'account' => $this->account,
        ]);
    }

    public function createTermProfile(): void
    {
        TermProfile::query()->create([
            'profile_id' => 2,
            'terminal_id' => $this->terminal
        ]);
    }

}