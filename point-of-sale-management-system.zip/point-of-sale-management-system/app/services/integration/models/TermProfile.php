<?php

namespace App\services\integration\models;


class TermProfile extends PostilionDBConfig
{
    protected
        /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $table = 'eftc_teller_term_profile';

    protected
        /** @noinspection SpellCheckingInspection */
        /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $fillable = [
        'profile_id',
        'terminal_id',
    ];
}
