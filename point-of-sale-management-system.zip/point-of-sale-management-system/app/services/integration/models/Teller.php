<?php

namespace App\services\integration\models;

class Teller extends PostilionDBConfig
{
    protected
        /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $table = 'eftc_teller';

        protected
            /** @noinspection SpellCheckingInspection */
            /** @noinspection ClassOverridesFieldOfSuperClassInspection */
            $fillable = [
              'teller_first_name',
              'teller_last_name',
              'teller_card',
              'teller_pin',
              'active',
              'supervisor',
              'current_terminal_id',
              'tran_linked_id',
              'msg_linked_id',
              'ext_tran_linked_id',
              'term_linked_id',
              'current_cash_draw_id',
        ];
}
