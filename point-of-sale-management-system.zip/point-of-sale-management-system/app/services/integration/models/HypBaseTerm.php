<?php

namespace App\services\integration\models;


class HypBaseTerm extends PostilionDBConfig
{
    protected
        /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $table = 'eftc_hyp_base_term';

    protected
        /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $fillable = [
        'id',
        'currency_code',
        'key_management_scheme',
        'override_terminal_type',
        'location_information' ,
        'city',
        'state_region',
        'country'
    ];
}
