<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 8/22/2018
 * Time: 9:51 AM
 */

namespace App\services\integration\models;


use Illuminate\Database\Eloquent\Model;

class PostilionDBConfig extends Model
{
    public $incrementing = false;
    protected $keyType = 'string';
    public $timestamps = false;
    protected $connection = 'sqlsrv_live';

}