<?php

namespace App\services\integration\models;


/**
 * @property mixed account_id
 * @property mixed trade_name
 * @property mixed terminal_id
 * @property mixed active
 */
class TerminalLookup extends PostilionDBConfig
{
    protected
        /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $table = 'eftc_t24_terminal_lookup';

    protected
        /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $primaryKey  = 'terminal_id';

    protected
        /** @noinspection SpellCheckingInspection */
        /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $fillable = [
        'merchant_id' ,
        'terminal_id' ,
        'branch_code' ,
        'account' ,
        'description'
    ];
}
