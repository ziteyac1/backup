<?php

namespace App\services\integration\models;



class Term extends PostilionDBConfig
{
    protected
        /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $table = 'term';

    protected
        /** @noinspection SpellCheckingInspection */
        /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $fillable = [
        'id' ,
        'short_name' ,
        'term_type',
        'term_active',
        'worst_event_severity',
        'card_acceptor' ,
        'participant_id',
        'pos_geographic_data',
        'sponsor_bank',
        'pos_data_code',
    ];
}
