<?php

namespace App\services\integration\models;


class CardAcceptor extends PostilionDBConfig
{
    protected
        /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $table = 'tm_card_acceptor';

    protected
        /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $primaryKey  = 'card_acceptor';

    protected
        /** @noinspection SpellCheckingInspection */
        /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $fillable = [
        'card_acceptor' ,
        'name_location' ,
        'currency_code',
        'default_lang',
        'card_set',
        'limits_class',
        'routing_group',
    ];
}
