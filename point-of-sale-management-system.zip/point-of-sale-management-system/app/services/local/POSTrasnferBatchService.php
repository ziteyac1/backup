<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 1/19/2019
 * Time: 2:00 PM
 */

namespace App\services\local;


use App\models\POSTrasnfer;
use App\models\POSTrasnferBatch;

class POSTrasnferBatchService
{

    /**
     * @param $to
     * @param $to_branch
     * @return \Illuminate\Database\Eloquent\Builder|\Illuminate\Database\Eloquent\Model
     */
    protected function checkBatch($to , $to_branch )
    {
        return POSTrasnferBatch::query()
            ->where('to',$to)
            ->where('to_branch',$to_branch )
            ->where('sender_id', auth()->id() )
            ->where('sent', null )
            ->first();
    }

    /**
     * @param $to
     * @param $to_branch
     * @param $transport
     * @return POSTrasnferBatch|\Illuminate\Database\Eloquent\Builder|\Illuminate\Database\Eloquent\Model
     */
    public function getBatch( $to , $to_branch , $transport ){

        $batch = $this->checkBatch( $to , $to_branch);

        if ($batch){

            return $batch;
        }

        return POSTrasnferBatch::query()->create([
            'to' => $to ,
            'to_branch' =>  $to_branch ,
            'transport' =>  $transport,
            'sender_id' =>  auth()->id(),
        ]);

    }

    /**
     * @param POSTrasnferBatch $batch
     * @param $terminal
     * @param $serial_number
     */
    public function transfer( $batch , $terminal , $serial_number = null  ): void
    {
        POSTrasnfer::query()->create([
            'batch_id' => $batch->id ,
            'serial_number' => $serial_number,
            'terminal' => $terminal,
        ]);
    }

}