<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 1/18/2019
 * Time: 5:47 AM
 */

namespace App\services\local;


use App\models\POSMachine;
use App\models\Terminal;
use App\services\integration\PostlionService;

class POSService
{

    /**
     * @param $serial
     * @return \Illuminate\Database\Eloquent\Builder[]|\Illuminate\Database\Eloquent\Collection
     */
    protected function getPOSMachines($serial){

        return POSMachine::query()->where('serial_number',$serial )->get();

    }

    public function addAssetCode( $serial , $code ): void
    {

        $machines = $this->getPOSMachines( $serial );
        $this->assetUpdate( $machines,$code);

    }

    public function assetUpdate($machines , $code ): void
    {

        foreach ( $machines as $item ){

            /** @noinspection PhpUndefinedMethodInspection */
            $item->update([
                'asset_code' => $code,
            ]);

        }
    }


    /**
     * @param $machines
     * @param $location
     * @param $branch
     */
    protected function locationUpdate( $machines , $location  , $branch ): void
    {

        foreach ( $machines as $item ){

            /** @noinspection PhpUndefinedMethodInspection */
            $item->update([
                'location' => $location,
                'branch' => $branch
            ]);

        }

    }


    /**
     * @param $terminal
     * @param $pos
     * @param $location
     * @param $branch
     */
    public function setLocation( $terminal ,  $pos , $location , $branch ): void
    {
        $machines = $this->getPOSMachines( $pos );
        $this->locationUpdate( $machines, $location  , $branch );

        $terminalService = new TerminalsService();
        $service  = new PostlionService([
            'terminal' => $terminal
        ]);

        $terminalService->updateSerial( $terminal , $pos );

//        if ( $location === 'customer' ) TODO : Remove stub
//        {
//            $service->activate();
//            $terminalService->activate( $terminal );
//            return;
//        }
//
//        $service->deactivate();
//        $terminalService->deactivate( $terminal );

    }


}