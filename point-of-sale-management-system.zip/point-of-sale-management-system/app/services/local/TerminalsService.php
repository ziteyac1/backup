<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 1/18/2019
 * Time: 5:47 AM
 */

namespace App\services\local;


use App\models\Terminal;

class TerminalsService
{

    /**
     * @param $terminal
     * @return \Illuminate\Database\Eloquent\Builder[]|\Illuminate\Database\Eloquent\Collection
     */
    protected function getTerminals($terminal){

        return Terminal::query()->where('terminal_id',$terminal)->get();

    }

    /**
     * @param $terminals
     * @param $state
     */
    protected function stateUpdate($terminals , $state ): void
    {

        foreach ( $terminals as $item ){

            /** @noinspection PhpUndefinedMethodInspection */
            $item->update([
                'active' => $state
            ]);

        }

    }


    /**
     * @param $terminals
     * @param $serial
     */
    protected function serialUpdate( $terminals , $serial ): void
    {

        foreach ( $terminals as $item ){

            /** @noinspection PhpUndefinedMethodInspection */
            $item->update([
                'serial_number' => $serial
            ]);

        }

    }

    /**
     * @param $terminal
     */
    public function activate($terminal): void
    {
        $this->setState($terminal, true);
    }

    public function deactivate($terminal): void
    {
        $this->setState($terminal, false);
    }

    /**
     * @param $terminal
     * @param $state
     */
    public function setState($terminal, $state): void
    {
        $terminals = $this->getTerminals($terminal);
        $this->stateUpdate($terminals, $state);
    }

    /**
     * @param $terminal
     * @param $serial
     */
    public function updateSerial($terminal , $serial ): void
    {

        $terminals = $this->getTerminals($terminal);
        $this->serialUpdate($terminals, $serial );

    }

}