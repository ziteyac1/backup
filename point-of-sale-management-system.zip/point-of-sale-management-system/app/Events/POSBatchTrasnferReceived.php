<?php

namespace App\Events;

use App\models\POSTrasnferBatch;
use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;

class POSBatchTrasnferReceived
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /**
     * @var POSTrasnferBatch $batch
     *
     */

    public $batch;

    /**
     * Create a new event instance.
     *
     * @param POSTrasnferBatch $batch
     */

    public function __construct(POSTrasnferBatch $batch)
    {
        $this->batch = $batch;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new Channel('batch');
    }

}
