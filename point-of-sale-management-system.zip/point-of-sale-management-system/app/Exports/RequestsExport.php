<?php

namespace App\Exports;

use App\models\Request;
use Illuminate\Database\Eloquent\Builder;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Events\AfterSheet;

class RequestsExport implements FromCollection , WithHeadings , WithMapping , WithEvents , ShouldAutoSize
{
    /**
     * @param Builder $model
     */
    public $model;

    public $params;
    /**
     * @param Builder $builder
     * @param null $params
     */

    public function __construct(Builder $builder , $params  = null )
    {
        $this->model = $builder;
        $this->params =  $params;
    }

    public function collection()
    {
        return $this->model->get();
    }

    /**
     * @return array
     */
    public function headings(): array
    {
        return [
            'Request #',
            'User',
            'Role Assigned',
            'Type',
            'Created',
            'Updated',
            'State',
        ];
    }


    /**
     * @param mixed $row
     *
     * @return array
     */public function map($row): array
{
    /** @var Request $row */
    return [
        $row->id,
        $row->requester->name,
        $row->role_assigned,
        $row->type,
        $row->created_at,
        $row->updated_at,
        $row->state_name->description_name->description  ,
    ];
}

    /**
     * @return array
     */
    public function registerEvents(): array
    {
        return [

            AfterSheet::class => function(AfterSheet $event)
            {
                $sheet = $event->getSheet();
                $sheet->autoSize();
            }

        ];
    }
}
