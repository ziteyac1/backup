<?php

namespace App\Exports;

use App\core\Helper;
use App\models\Terminal;
use Illuminate\Database\Eloquent\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Events\AfterSheet;

class TerminalActiveExport implements FromCollection , WithHeadings , WithMapping , WithEvents , ShouldAutoSize
{


    /**
     * @var Collection
     */
    public $data;

    public function __construct($data)
    {
        $this->data = $data;
    }

    public function collection()
    {
        return $this->data;
    }

    /**
     * @return array
     */
    public function headings(): array
    {
        return [
            'Terminal ID',
            'Last Know Transaction',
            'Account',
            'Type',
            'Override',
            'Model',
            'State',
            'Location',
            'Serial Number',
            'Auto Serial Number',
            'Created',
        ];
    }

    /**
     * @param mixed $row
     *
     * @return array
     */
    public function map($row): array
    {
        /** @var Terminal $row */
        return [
            $row->terminal_id,
            Helper::getLastTransaction($row->terminal_id),
            $row->account_id,
            $row->override_term_type,
            $row->model,
            $row->term_type,
            $row->active,
            $row->location,
            $row->serial_number,
            $row->system_serial_number,
            $row->created_at,
        ];
    }

    /**
     * @return array
     */
    public function registerEvents(): array
    {
        return [

            AfterSheet::class => function(AfterSheet $event)
            {
                $sheet = $event->getSheet();
                $sheet->autoSize();
            }

        ];
    }
}
