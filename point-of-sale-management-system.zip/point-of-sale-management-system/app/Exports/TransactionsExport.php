<?php

namespace App\Exports;

use App\elastic\TransactionFilters;
use App\models\Transaction;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Events\AfterSheet;
use ScoutElastic\Builders\FilterBuilder;

class TransactionsExport implements FromCollection , WithHeadings , WithMapping , WithEvents , ShouldAutoSize
{
    /**
     * @param FilterBuilder $transactions
     */
    public $transactions;

    public $params;

    /**
     * @param FilterBuilder $builder
     * @param null $params
     */

    public function __construct(FilterBuilder $builder , $params = null )
    {
        $this->params = $params;
        $count = $builder->count();
        $this->transactions = $builder->take($count);
    }

    public function collection()
    {
        return $this->transactions->get();
    }

    /**
     * @return array
     */
    public function headings(): array
    {
        return [
            'Tran #',
            'Pan',
            'Rrn',
            'Terminal',
            'Location',
            'Amount',
            'Tran Type',
            'Response Code',
            'Date',
        ];
    }


    /**
     * @param mixed $row
     *
     * @return array
     */public function map($row): array
{
    return [
        $row->tran_nr,
        $row->pan,
        $row->ret_ref_no,
        $row->card_acceptor_id,
        $row->card_acceptor_name_loc,
        $row->amount,
        $row->tran_type,
        $row->response_code,
        $row->in_req,
    ];
}

    /**
     * @return array
     */
    public function registerEvents(): array
    {
        return [

            AfterSheet::class => function(AfterSheet $event)
            {
                $sheet = $event->getSheet();
                $sheet->autoSize();
            }

        ];
    }
}
