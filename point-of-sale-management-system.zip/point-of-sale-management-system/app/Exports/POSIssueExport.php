<?php

namespace App\Exports;

use App\models\POSIssue;
use Illuminate\Database\Eloquent\Builder;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class POSIssueExport implements FromCollection , WithHeadings , WithMapping , WithEvents , ShouldAutoSize
{
    /**
     * @param Builder $model
     */
    public $model;

    public $params;
    /**
     * @param Builder $builder
     * @param null $params
     */

    public function __construct(Builder $builder , $params  = null )
    {
        $this->model = $builder;
        $this->params =  $params;
    }

    public function collection()
    {
        return $this->model->get();
    }

    /**
     * @return array
     */
    public function headings(): array
    {
        return [
            '#',
            'Terminal',
            'Serial Number',
            'User',
            'Account',
            'Branch',
            'Charger',
            'Battery',
            'Line',
            'Card',
            'Created',
            'Updated',
        ];
    }


    /**
     * @param mixed $row
     *
     * @return array
     */public function map($row): array
{
    /** @var POSIssue $row */
    return [
        $row->id,
        $row->terminal,
        $row->serial_number,
        $row->input->email,
        $row->account,
        $row->branch,
        $row->charger,
        $row->battery,
        $row->line,
        $row->card,
        $row->created_at,
        $row->updated_at,
    ];
}

    /**
     * @return array
     */
    public function registerEvents(): array
    {
        return [

            AfterSheet::class => function(AfterSheet $event)
            {
                $sheet = $event->getSheet();
                $sheet->autoSize();
            }

        ];
    }
}
