<?php

namespace App\Exports;

use App\models\POSTrasnferBatch;
use Illuminate\Database\Eloquent\Builder;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Events\AfterSheet;

class POSBacthesExport implements FromCollection , WithHeadings , WithMapping , WithEvents , ShouldAutoSize
{
    /**
     * @param Builder $model
     */
    public $model;

    public $params;
    /**
     * @param Builder $builder
     * @param null $params
     */

    public function __construct(Builder $builder , $params  = null )
    {
        $this->model = $builder;
        $this->params =  $params;
    }

    public function collection()
    {
        return $this->model->get();
    }

    /**
     * @return array
     */
    public function headings(): array
    {
        return [
            'Batch #',
            'To',
            'Batch',
            'Transport',
            'Sender',
            'Sent',
            'Received',
            'Checked',
            'Created',
            'Updated',
        ];
    }


    /**
     * @param mixed $row
     *
     * @return array
     */
    public function map($row): array
    {
        /** @var POSTrasnferBatch $row */
        return [
            $row->id,
            $row->to,
            $row->to_branch,
            $row->transport,
            $row->sender->email,
            $row->sent,
            $row->received,
            $row->checked,
            $row->created_at,
            $row->updated_at,
        ];
    }

    /**
     * @return array
     */
    public function registerEvents(): array
    {
        return [

            AfterSheet::class => function(AfterSheet $event)
            {
                $sheet = $event->getSheet();
                $sheet->autoSize();
            }

        ];
    }
}