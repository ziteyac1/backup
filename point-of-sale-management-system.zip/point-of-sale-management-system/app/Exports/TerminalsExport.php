<?php

namespace App\Exports;

use App\models\Terminal;
use Illuminate\Database\Eloquent\Builder;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Events\AfterSheet;

class TerminalsExport implements FromCollection , WithHeadings , WithMapping , WithEvents , ShouldAutoSize
{
    /**
     * @param Builder $model
     */
    public $model;

    public $params;
    /**
     * @param Builder $builder
     * @param null $params
     */

    public function __construct(Builder $builder , $params  = null )
    {
        $this->model = $builder;
        $this->params =  $params;
    }

    public function collection()
    {
        return $this->model->get();
    }

    /**
     * @return array
     */
    public function headings(): array
    {
        return [
            'Terminal ID',
            'Account',
            'Type',
            'Override',
            'Model',
            'State',
            'Location',
            'Serial Number',
            'Auto Serial Number',
            'Created',
        ];
    }

    /**
     * @param mixed $row
     *
     * @return array
     */
    public function map($row): array
    {
    /** @var Terminal $row */
    return [
        $row->terminal_id,
        $row->account_id,
        $row->override_term_type,
        $row->model,
        $row->term_type,
        $row->active,
        $row->location,
        $row->serial_number,
        $row->system_serial_number,
        $row->created_at,
    ];
}

    /**
     * @return array
     */
    public function registerEvents(): array
    {
        return [

            AfterSheet::class => function(AfterSheet $event)
            {
                $sheet = $event->getSheet();
                $sheet->autoSize();
            }

        ];
    }
}
