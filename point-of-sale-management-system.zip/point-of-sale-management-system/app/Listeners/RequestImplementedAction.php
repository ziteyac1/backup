<?php

namespace App\Listeners;

use App\Events\RequestImplemented;
use App\models\Request;
use App\User;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class RequestImplementedAction implements ShouldQueue
{
    /**
     * Create the event listener.
     *
     * @return void
     */

    /**
     * @var Request $request
     */

    public $request;

    public $queue = 'requests-action';

    /**
     * Handle the event.
     *
     * @param RequestImplemented $event
     * @return void
     */
    public function handle(RequestImplemented $event): void
    {
        $this->request  = $event->request;
        $this->request->requester->notify(new \App\Notifications\RequestImplemented( $this->request));

        $users = User::query();

        if ( $this->request->role_assigned === 'branch-manager' )
        {
            $users = $users->where('branch'  , $this->request->branch_code );
        }

        $users = $users->where('role' ,'=' , $this->request->role_name->id );

        /** @var User $user */
        foreach ($users->get() as $user )
        {
            echo 'Sending to Notification to : '.$user->email .PHP_EOL;

            $notAllowed = [
               'root','root-helper'
            ];

            if (!\in_array($user->role_name->name , $notAllowed , true)){

                $user->notify(new \App\Notifications\RequestReminder( $this->request , 'Implemented'));

            }

        }

    }
}