<?php

namespace App\Listeners;

use App\Events\POSBatchTrasnferSent;
use App\models\POSTrasnfer;
use App\models\POSTrasnferBatch;
use App\services\local\POSService;
use App\User;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class POSBatchTrasnferSentAction implements ShouldQueue
{
    /**
     * Create the event listener.
     *
     * @return void
     */

    /**
     * @var POSTrasnferBatch $batch
     */
    public $batch;

    /**
     * Handle the event.
     *
     * @param POSBatchTrasnferSent $event
     * @return void
     */
    public function handle(POSBatchTrasnferSent $event): void
    {
        $this->batch  = $event->batch;



        if ( $this->batch->role_name_to ){

            $users = User::query();

            $accepted = [
                'branch',
                'branch-manager'
            ];

            if ( \in_array($event->batch->to, $accepted, true))
            {
                $users = $users->where('branch','=',$this->batch->to_branch );

            } else {

                $users = $users->where('role','=',$this->batch->role_name_to->id )
                    ->where('branch','=',$this->batch->to_branch );
            }

            foreach ($users->get() as $user)
            {
                /** @var User $user */
                $user->notify(new \App\Notifications\POSBatchTrasnferSent($this->batch));
            }

        }

        $service = new POSService();
        foreach ( $this->batch->terminals as $terminal )
        {

            /** @var POSTrasnfer $terminal */
            $service->setLocation(
                $terminal->terminal,
                $terminal->serial_number,
                $this->batch->sender->role_name->name .'-to-'. $this->batch->to ,
                $this->batch->to_branch
            );

        }

    }
}
