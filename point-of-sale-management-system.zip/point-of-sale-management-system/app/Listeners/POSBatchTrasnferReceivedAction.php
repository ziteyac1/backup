<?php

namespace App\Listeners;

use App\Events\POSBatchTrasnferReceived;
use App\models\POSTrasnfer;
use App\models\POSTrasnferBatch;
use App\services\local\POSService;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class POSBatchTrasnferReceivedAction implements ShouldQueue
{
    /**
     * Create the event listener.
     *
     * @return void
     */

    /**
     * @var POSTrasnferBatch $batch
     */

    public $batch;

    /**
     * Handle the event.
     *
     * @param POSBatchTrasnferReceived $event
     * @return void
     */
    public function handle(POSBatchTrasnferReceived $event): void
    {
        $this->batch  = $event->batch;
        $this->batch->sender->notify(new \App\Notifications\POSBatchTrasnferReceived( $this->batch ));

        $service = new POSService();

        foreach ( $this->batch->terminals as $terminal )
        {
            /** @var POSTrasnfer $terminal */
            $service->setLocation(
                $terminal->terminal,
                $terminal->serial_number ,
                $this->batch->to ,
                $this->batch->to_branch
            );

        }

    }
}

