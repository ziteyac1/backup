<?php

namespace App\Listeners;

use App\Events\RequestAuthorized;
use App\Events\RequestUpdated;
use App\models\Request;
use App\User;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class RequestUpdatedAction implements ShouldQueue
{
    /**
     * Create the event listener.
     *
     * @return void
     */

    /**
     * @var Request $request
     */

    public $request;

    public $queue = 'requests-action';

    /**
     * Handle the event.
     *
     * @param RequestUpdated $event
     * @return void
     */
    public function handle(RequestUpdated $event): void
    {
        $this->request  = $event->request;
        $this->request->requester->notify(new \App\Notifications\RequestUpdated( $this->request));

    }
}
