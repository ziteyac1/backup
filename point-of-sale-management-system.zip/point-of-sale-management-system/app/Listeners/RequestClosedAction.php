<?php

namespace App\Listeners;

use App\Events\RequestClosed;
use App\models\Request;
use App\User;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class RequestClosedAction implements ShouldQueue
{
    /**
     * Create the event listener.
     *
     * @return void
     */

    /**
     * @var Request $request
     */

    public $request;

    public $queue = 'requests-action';

    /**
     * Handle the event.
     *
     * @param RequestClosed $event
     * @return void
     */
    public function handle(RequestClosed $event): void
    {
        $this->request  = $event->request;
        $this->request->requester->notify(new \App\Notifications\RequestClosed( $this->request));
    }
}
