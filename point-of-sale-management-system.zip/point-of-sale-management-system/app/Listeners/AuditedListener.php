<?php

namespace App\Listeners;

use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use OwenIt\Auditing\Events\Audited;
use OwenIt\Auditing\Models\Audit;

class AuditedListener
{

    /**
     * Handle the event.
     *
     * @param Audited $event
     * @return void
     */
    public function handle(Audited $event)
    {
        Audit::query()->where('user_id' , null )
                     ->orWhere('user_type' , null)
            ->update([
                'user_id' => 1 ,
                'user_type' => 'App\User'
            ]);
    }
}
