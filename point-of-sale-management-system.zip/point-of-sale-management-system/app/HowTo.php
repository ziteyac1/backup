<?php

namespace App;

use App\core\Filters\HasFilter;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * @property mixed content
 */
class HowTo extends Model
{
    use HasFilter , SoftDeletes;
    protected $guarded = [];

}
