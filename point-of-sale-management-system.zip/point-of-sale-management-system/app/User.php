<?php

namespace App;

use App\core\Filters\HasFilter;
use App\models\Branch;
use App\models\system\Role;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

/**
 * @property mixed name
 * @property mixed email
 * @property mixed role
 * @property mixed branch
 * @property Role role_name
 * @property mixed id
 * @property Branch branch_name
 * @property mixed allowed
 * @property mixed created_at
 * @property mixed updated_at
 * @property mixed email_verified_at
 */

class User extends Authenticatable implements MustVerifyEmail
{
    use Notifiable , HasFilter , \Spiritix\LadaCache\Database\LadaCacheTrait;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected  $fillable = [
        'name', 'email', 'password','role','allowed','branch'
    ];


    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    protected /** @noinspection ClassOverridesFieldOfSuperClassInspection */
        $with = [
        'role_name'
    ];


    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function role_name(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Role::class , 'role' ,'id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function branch_name(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Branch::class , 'branch' , 'branch_code');
    }

    public function getShortNameAttribute(){
        return strtoupper($this->name[0]);
    }

}
