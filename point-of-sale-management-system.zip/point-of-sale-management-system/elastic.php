<?php
/**
 * Created by PhpStorm.
 * User: pgurajena
 * Date: 2/9/2019
 * Time: 5:53 PM
 */

$params = [
    'query' => [
        'range' => [
            'in_req' => [
                'gte' => '2018-01-01',
                'lte' => '2019-12-31'
            ]
        ]
    ],
    'size' => 200,
    'aggs' => [
        'tran_intervals' => [
            'date_histogram' => [
                'field' => 'in_req',
                'interval' => 'day',
                'format' => 'yyyy-MM-dd',
                'min_doc_count' => 100
            ],
            'aggs' => [
                'source_node_group' => [
                    'terms' => [
                        'field' => 'source_node'
                    ]
                ],
                'tran_type_group' => [
                    'terms' => [
                        'field' => 'tran_type'
                    ]
                ],
                'response_code_group' => [
                    'terms' => [
                        'field' => 'response_code'
                    ]
                ]
            ]
        ]
    ]
];

/**
 * Aggregation Basics Bucket
 * Adjacency Matrix
 */

$params = [
    'index' => 'pos_transactions_index',
    'type' => 'transactions',
    'body' => [
        'aggs' => [
            'interactions' => [
                'adjacency_matrix' => [
                    'filters' => [
                        'Merchant' => [
                            'terms' => [
                                'source_node' => [ 'AgriMerchSrc' ]
                            ]
                        ],
                        'MPOS' => [
                            'terms' => [
                                'source_node' => [ 'AgriMPOSSrc' ]
                            ]
                        ]
                    ]
                ]
            ]

        ]
    ]
];


/**
 * Aggregation Basics Bucket
 * Auto-interval Date Histogram
 */

$params = [
    'index' => 'pos_transactions_index',
    'type' => 'transactions',
    'body' => [
        'aggs' => [
            'sales_over_time' => [
                'date_histogram' => [
                    'field' => 'in_req',
                    'interval' => 'day', // h , d  , w , m , q  , y
                    'format' => 'Y-m-d',
                    'ranges' => [
                        'to' => '',
                        'from' => '',
                    ]
                ]
            ]
        ]
    ]
];


/**
 * Aggregation Basics Bucket
 * Auto-interval Date Histogram
 */

$params = [
    'index' => 'pos_transactions_index',
    'type' => 'transactions',
    'body' => [
        'aggs' => [
            'amounts' => [
                'histogram' => [
                    'field' => 'amount',
                    'interval' => '50',
                ]
            ]
        ]
    ]
];

/**
 * Aggregation Basics
 * cardinality
 * - metrics aggregation that calculates an approximate count of distinct values
 */

$params = [
    'index' => 'pos_transactions_index',
    'type' => 'transactions',
    'body' => [
        'aggs' => [
            'source_node_count' => [
                'cardinality' => [
                    'field' => 'source_node',
                ]
            ]
        ]
    ]
];


/**
 * Aggregation Basics (Metric)
 * Extended Stats Aggregation
 * - sum_of_squares, variance, std_deviation and std_deviation_bounds.
 */

$params = [
    'index' => 'pos_transactions_index',
    'type' => 'transactions',
    'body' => [
        'aggs' => [
            'extended_stats' => [
                'extended_stats' => [ // other include min, max , value_count
                    'field' => 'amount',
                ]
            ]
        ]
    ]
];


/**
 * Basic Search Query
 * time = ['took'] in ms
 * total = ['hits']['total']
 * items = ['hits']['hits']
 * values = ['hits']['hits'][0]['_source']
 */

$params = [
    'index' => 'pos_transactions_index',
    'type' => 'transactions',
    'body' => [
        '_source' =>[
            'card_acceptor_id' , 'tran_nr'
        ],
        'query' => [
            'term' => [
                'card_acceptor_id' => 'AGY00446'
            ]
        ],
        'docvalue_fields' => [
            [
                'field' => 'in_req',
                'format' => 'epoch_millis',
            ]
        ],
        'sort' => [
            'in_req' => [
                'order' => 'asc',
                'mode' => 'avg',
                'missing' => '_last' // it can be first
            ],
        ],
        'from' => 0,
        'size' => 20,
    ]
];

/**
 *  OLD
 */



$params = [
    'index' => 'pos_transactions_index',
    'type' => 'transactions',
    'body' => [
        'query' => [
            'match_all' => (object)[] ,
            'match' => [
                'card_acceptor_id' => 'AGY00254'
            ]
        ],
        '_source' => ['card_acceptor_id','amount'],
        'size' => 10 ,
        'from' => 20 ,
        'sort' => [
            'in_req' => [
                'order' => 'desc'
            ]
        ]
    ]
];

/*************************
 * Group Aggregation
 **/

$params = [
    'index' => 'pos_transactions_index',
    'type' => 'transactions',
    'body' => [
        'size' => 0 ,
        'aggs' => [
            'group_by' => [
                'terms' => [
                    'field' => 'card_acceptor_id'
                ]
            ]
        ]
    ]
];

/*************************
 * Average Aggregation
 *
 */

$params = [
    'index' => 'pos_transactions_index',
    'type' => 'transactions',
    'body' => [
        'size' => 0 ,
        'aggs' => [
            'avg_for_grade' => [
                'avg' => [
                    'field' => 'amount',
                    'missing' => 10 // For documents with missing values
                ]
            ]
        ]
    ]
];

/*************************
 * Cardinality Aggregation ( Distinct values number )
 *
 */

$params = [
    'index' => 'pos_transactions_index',
    'type' => 'transactions',
    'body' => [
        'size' => 0 ,
        'aggs' => [
            'number_of_source_nodes' => [
                'cardinality' => [
                    'field' => 'source_node',
                ]
            ]
        ]
    ]
];

/*************************
 * Extended Stats ( comes with )
 *
 * count
 * min
 * max
 * avg
 * sum
 * sum_of_squares
 * variance
 * std_deviation
 * std_deviation_bounds - upper , lower
 *
 */

$params = [
    'index' => 'pos_transactions_index',
    'type' => 'transactions',
    'body' => [
        'size' => 0 ,
        'aggs' => [
            'amount_stats' => [
                'extended_stats' => [ // or stats , value_count
                    'field' => 'amount',
                ]
            ]
        ]
    ]
];

/*************************
 * Sum Aggregation
 *
 */

$params = [
    'index' => 'pos_transactions_index',
    'type' => 'transactions',
    'body' => [
        'size' => 0 ,
        'aggs' => [
            'max_amount' => [
                'percentiles' => [ // or use of  // min , percentiles ( stats of allocation of values ) ,
                    'field' => 'amount',
                ]
            ]
        ]
    ]
];

/*************************
 * Percentile Aggregation
 *
 */

$params = [
    'index' => 'pos_transactions_index',
    'type' => 'transactions',
    'body' => [
        'size' => 0 ,
        'aggs' => [
            'max_amount' => [
                'percentile_ranks' => [
                    'field' => 'amount',
                    'values' => [ 100 ,  300 ]

                ]
            ]
        ]
    ]
];


/*************************
 * Auto-interval Date Histogram  Aggregation
 *
 */

$params = [
    'index' => 'pos_transactions_index',
    'type' => 'transactions',
    'body' => [
        'aggs' => [
            'filter' => [
                'term' => [
                    'type' => 't-shirt'
                ]
            ],
            'trans_over_time' => [
                'auto_date_histogram' => [
                    'field' => 'in_req',
                    'bucket' => 10,
//                        'format' => 'yyyy-MM-dd'
                ]
            ]
        ]
    ]
];