<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Events\TestEvent;
use App\Http\Controllers\AppController;
use App\Http\Controllers\BalancesController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\SAFController;
use App\Http\Controllers\SAFReportController;
use App\Http\Controllers\SAFRequestController;
use App\Http\Controllers\SSOController;
use App\Http\Controllers\UserController;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

// Authentication Routes
Auth::routes([
    'register' => false,
    'verify' => false,
    "reset" => false,
]);


// SSO Routes
Route::get('/auth/redirect' ,[SSOController::class , 'auth']);
Route::get('/auth/sync/{id}/user' ,[SSOController::class , 'syncUser']);
Route::get('/auth/sync/{id}/role' ,[SSOController::class , 'syncRole']);

/*Route::get('test' , function (){
    return [
    ];
});

Route::get('/online' , function (){
       return [
           'online' => true
       ];
});*/

// Landing Page
Route::get('/', [HomeController::class , 'landing']);

// Auth Guard
Route::middleware('auth')->group(function (){

    // Reports CRUD
    Route::get('/transactions/reports', [SAFReportController::class , 'index']);
    Route::post('/transactions/reports/create', [SAFReportController::class , 'store']);
    Route::get('/transactions/reports/{report}/view', [SAFReportController::class , 'view']);
    Route::get('/transactions/reports/{report}/run', [SAFReportController::class , 'run']);
    Route::get('/transactions/reports/{report}/request', [SAFReportController::class , 'request']);
    Route::post('/transactions/reports/{report}/edit', [SAFReportController::class , 'update']);

    // Requests
    Route::get('/transactions/requests', [SAFRequestController::class , 'index']);
    Route::get('/transactions/requests/{request}/view', [SAFRequestController::class , 'view']);
    Route::get('/transactions/requests/{request}/abort', [SAFRequestController::class , 'abort']);
    Route::get('/transactions/requests/{request}/download', [SAFRequestController::class , 'download']);

    Route::get('/transactions/dashboard' , [ SAFController::class , 'index']);
    Route::get('/transactions/saf' , [ SAFController::class , 'saf']);
    Route::get('/transactions/generate' , [ SAFController::class , 'generate']);
    Route::get('/transactions/abort/{tran}' , [ SAFController::class , 'abort']);
    Route::get('/transactions/{report}/download' , [ SAFController::class , 'download']);

    // Home
    Route::get('/home', [HomeController::class , 'home']);

    // Applications
    Route::prefix('/apps')->group( function (){
        Route::get('/users' , [AppController::class , 'users'])->name('apps.users');
        Route::get('/profile' , [AppController::class , 'profile'])->name('apps.profile');
        Route::get('/postilion' , [AppController::class , 'postilion'])->name('apps.postilion');
    });

    // Users
    Route::prefix('/users')->group( function (){
        Route::get('/' , [UserController::class , 'index']);
        Route::get('/create' , [UserController::class , 'create']);
        Route::post('/create' , [UserController::class , 'store']);
        Route::get('/{user}/edit' , [UserController::class , 'edit']);
        Route::post('/{user}/edit' , [UserController::class , 'update']);
        Route::get('/{user}/view' , [UserController::class , 'view']);
        Route::get('/{user}/activity' , [UserController::class , 'activity']);
        Route::get('/{user}/roles' , [UserController::class , 'roles']);
        Route::get('/{user}/permissions' , [UserController::class , 'permissions']);
        Route::get('/{user}/timeline' , [UserController::class , 'timeline']);
        Route::get('/{user}/activate' , [UserController::class , 'activate']);
        Route::get('/{user}/deactivate' , [UserController::class , 'deactivate']);
    });

    // Roles
    Route::prefix('/roles')->group(function (){
        Route::get('/' , [RoleController::class , 'index']);
        Route::get('/create' , [RoleController::class , 'create']);
        Route::post('/create' , [RoleController::class , 'store']);
//        /roles/{role}/view
        Route::get('/{role}/view' , [RoleController::class , 'view']);
        Route::get('/{role}/edit' , [RoleController::class , 'edit']);
        Route::post('/{role}/edit' , [RoleController::class , 'update']);
        Route::get('/{role}/timeline' , [RoleController::class , 'timeline']);
        Route::get('/{role}/permissions' , [RoleController::class , 'permissions']);
    });

    // Permissions
    Route::prefix('/permissions')->group(function (){
        Route::get('/' , [PermissionController::class , 'index']);
    });

    // Permissions
    Route::prefix('/balances')->group(function (){
        Route::get('/' , [ BalancesController::class , 'index']);
        Route::get('/{account}/view' , [ BalancesController::class , 'view']);
        Route::post('/{account}/edit' , [ BalancesController::class , 'edit']);
    });

    // Profile
    Route::prefix('/profile')->group(function (){
        Route::get('/view', [ProfileController::class , 'view']);
        Route::post('/edit', [ProfileController::class , 'edit']);
        Route::post('/password', [ProfileController::class , 'password']);
        Route::get('/activity', [ProfileController::class , 'activity']);
        Route::get('/notifications-mini', [ProfileController::class , 'notificationsMini']);
        Route::get('/notifications', [ProfileController::class , 'notifications']);
    });

});

Route::get('partial/edit/{account}/{ledgerBalance}/{availableBalance}', 'PartialRefreshController@edit');
Route::get('/balances/partial/sendftp', 'PartialRefreshController@sendTCPRequest');
Route::get('/partial/log/{message}/{type}', 'PartialRefreshController@partialRefreshLogs');


