@extends('layouts.dashboard' , [
    'bread' => [
        [ 'name' => 'Home' , 'link' => url('/home') ],
        [ 'name' => 'Dashboard' , 'link' => url('/home') ],
    ]
])
@section('content')

@endsection
