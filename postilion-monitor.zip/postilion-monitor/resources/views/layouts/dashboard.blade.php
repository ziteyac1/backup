@extends('layouts.app')
@section('main')
    <div class="content content-fixed content-auth">
        <div class="container">
            @yield('content')
        </div>
    </div>
@endsection
