@extends('layouts.auth')
@section('content')
    <register></register>
@endsection
