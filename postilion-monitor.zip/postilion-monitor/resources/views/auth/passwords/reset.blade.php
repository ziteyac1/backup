@extends('layouts.auth')
@section('content')
    <reset token="{{ $token }}" email="{{ request('email') }}"></reset>
@endsection
