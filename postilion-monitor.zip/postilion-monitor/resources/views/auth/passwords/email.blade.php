@extends('layouts.auth')
@section('content')
    <email></email>
@endsection
