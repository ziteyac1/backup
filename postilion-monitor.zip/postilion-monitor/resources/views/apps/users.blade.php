@extends('layouts.app')
@section('css')
    <link rel="stylesheet" href="{{ asset('assets/css/dashforge.filemgr.css') }}">
@endsection
@section('main')
    <div class="filemgr-wrapper">
        <div class="filemgr-sidebar">
            <div class="filemgr-sidebar-body">
                <div class="pd-t-20 pd-b-10 pd-x-10">
                    <label class="tx-sans tx-uppercase tx-medium tx-10 tx-spacing-1 tx-color-03 pd-l-10">Users</label>
                    <nav class="nav nav-sidebar tx-13">
                        @can('create user')
                            <router-link class="nav-link" active-class="active" to="/users/create" exact> <plus-circle-icon size="24"></plus-circle-icon> New User </router-link>
                        @endcan()
                        @can('list user')
                            <router-link class="nav-link" active-class="active" to="/users" exact> <users-icon size="24"></users-icon>Users </router-link>
                        @endcan
                    </nav>
                </div>
                @can('manage roles')
                    <div class="pd-t-20 pd-b-10 pd-x-10">
                        <label class="tx-sans tx-uppercase tx-medium tx-10 tx-spacing-1 tx-color-03 pd-l-10">Authority</label>
                        <nav class="nav nav-sidebar tx-13">
                            <router-link class="nav-link" active-class="active" to="/roles/create" exact> <plus-circle-icon size="24"></plus-circle-icon> New Role </router-link>
                            <router-link class="nav-link" active-class="active" to="/roles" exact> <user-plus-icon size="24"></user-plus-icon>Roles </router-link>
                            <router-link class="nav-link" active-class="active" to="/permissions" exact> <user-check-icon size="24"></user-check-icon>Permissions </router-link>
                        </nav>
                    </div>
                 @endcan
            </div>
        </div>
        <transition name="slide-in-left">
            <router-view></router-view>
        </transition>
    </div>
@endsection

