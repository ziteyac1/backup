@extends('layouts.app')
@section('css')
    <link rel="stylesheet" href="{{ asset('assets/css/dashforge.filemgr.css') }}">
@endsection
@section('main')
    <div style="overflow-x: scroll" class="filemgr-wrapper">
        <div class="container py-4 px-4 border-bottom d-flex justify-content-between align-items-center">
            <div class="avatar avatar-lg">
                <span class="avatar-initial rounded-circle">{{ auth()->user()->avatar_name }}</span>
            </div>
            <h4 class="text-center">Profile</h4>
        </div>
        <div class="container py-3 mt-4">
            <div class="row">
                <div class="col-lg-3">
                    <nav class="nav nav-sidebar tx-13 pr-3">
                        <router-link class="nav-link" active-class="active" to="/profile/view" exact> <user-icon size="24"></user-icon> View Profile </router-link>
                        <router-link class="nav-link" active-class="active" to="/profile/notifications" exact> <bell-icon size="24"></bell-icon> Notifications </router-link>
                        <router-link class="nav-link" active-class="active" to="/profile/activity" exact> <clock-icon size="24"></clock-icon> Activity </router-link>
                        <router-link class="nav-link" active-class="active" to="/profile/edit" exact> <edit-icon size="24"></edit-icon>Edit Profile </router-link>
                        <router-link class="nav-link" active-class="active" to="/profile/password" exact> <lock-icon size="24"></lock-icon>Change Password </router-link>
                    </nav>
                </div>
                <div id="profile-container" style="height: 100%;" class="col-lg-9  border-left">
                    <transition name="slide-in-left">
                        <router-view></router-view>
                    </transition>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
@endsection
