// Buildings

import Index from "../components/saf-requests/index";
import Create from "../components/saf-requests/create";
import Open from "../components/saf-requests/open";
import View from "../components/saf-requests/view";
import Edit from "../components/saf-requests/edit";
import Run from "../components/saf-requests/run";


const routes = [

    {
        path : '/transactions/requests',
        component : Index
    },
    {
        path : '/transactions/requests/create',
        component : Create
    },

    {
            path : '/transactions/requests/:id/view',
            component : Open,
            children : [
                {
                    path : '/transactions/requests/:id/view',
                    component : View,
                },
                {
                    path : '/transactions/requests/:id/run',
                    component : Run,
                }
            ]
    }
];

export default routes;
