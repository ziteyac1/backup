
// Profile Components
import ProfileView  from  "../components/profile/view";
import ProfileEdit  from  "../components/profile/edit";
import ProfilePassword  from  "../components/profile/password";
import ProfileActivity  from  "../components/profile/activity";
import ProfileNotifications  from  "../components/profile/notifications";



const routes = [

// Profile
    {
        path : '/profile/view',
        component : ProfileView
    },
    {
        path : '/profile/activity',
        component : ProfileActivity
    },
    {
        path : '/profile/password',
        component : ProfilePassword
    },
    {
        path : '/profile/edit',
        component : ProfileEdit
    },
    {
        path : '/profile/notifications',
        component : ProfileNotifications
    },

];


export default routes;
