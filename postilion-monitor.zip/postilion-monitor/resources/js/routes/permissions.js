
// Permissions Components
import PermissionIndex from "../components/permissions/index";


const routes = [
    // Permissions
    {
        path : '/permissions',
        component : PermissionIndex
    },
];


export default routes;
