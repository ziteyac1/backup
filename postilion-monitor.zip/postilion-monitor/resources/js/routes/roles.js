

// Role Components
import RoleIndex from "../components/roles/index";
import RoleCreate from "../components/roles/create";
import RoleOpen  from "../components/roles/open";
import RoleView  from "../components/roles/view";
import RoleEdit from  "../components/roles/edit";
import RoleTimeline from  "../components/roles/timeline";
import RolePermissions from   "../components/roles/permissions";


const routes = [
    // Roles
    {
        path : '/roles',
        component : RoleIndex
    },
    {
        path : '/roles/create',
        component : RoleCreate
    },
    {
        path : '/roles/:id/view',
        component : RoleOpen ,
        children : [
            {
                path : '/roles/:id/view',
                component : RoleView
            },
            {
                path : '/roles/:id/edit',
                component : RoleEdit
            },
            {
                path : '/roles/:id/timeline',
                component : RoleTimeline
            },
            {
                path : '/roles/:id/permissions',
                component : RolePermissions
            }
        ]
    },
];


export default routes;
