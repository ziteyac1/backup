// Router
import VueRouter from "vue-router";
import Vue from "vue";

import Dash from '../components/saf/dashboard';
import SAF from '../components/saf/saf';
import BalancesIndex from '../components/balances/index';
import BalancesView from '../components/balances/view';

Vue.use(VueRouter);

let routes = [
    {
        path : '/transactions/dashboard',
        component : Dash
    },
    {
        path : '/transactions/saf',
        component : SAF
    },
    {
        path : '/balances',
        component : BalancesIndex
    },
    {
        path : '/balances/:id/view',
        component : BalancesView
    },

];

import users from "./users";
routes = routes.concat(users);

import roles from "./roles";
routes = routes.concat(roles);

import permissions from "./permissions";
routes = routes.concat(permissions);

import profile from "./profile";
routes = routes.concat(profile);

import saf_reports from "./saf_reports";
routes = routes.concat(saf_reports);

import saf_request from "./saf_requests";
routes = routes.concat(saf_request);



const router = new VueRouter({
    routes :  routes,
    activeClass : 'active',
});

let apps = [
    {
        path : "/apps/users",
        to : "/users"
    },
    {
        path : "/apps/profile",
        to : "/profile/view"
    },
    {
        path : "/apps/postilion",
        to : "/transactions/dashboard"
    }
];

router.beforeEach((to, from, next) => {
    if (to.path === "/") {
        apps.forEach((value) => {
            if ( window.location.pathname === value.path){
                next(value.to);
            }
        });
    }
    next();
});

export default router;
