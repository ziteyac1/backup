// User Components
import UserIndex from "../components/users/index";
import UserCreate from  "../components/users/create";
import UserOpen  from  "../components/users/open";
import UserView from "../components/users/view";
import UserEdit from  "../components/users/edit";
import UserTimeline from  "../components/users/timeline";
import UserActivity from  "../components/users/activity";
import UserRoles from  "../components/users/roles";
import UserPermissions from  "../components/users/permissions";


const routes = [

    // Users
    {
        path : '/users/create',
        component : UserCreate
    },
    {
        path : '/users/:id/view',
        component : UserOpen,
        children : [
            {
                path : '/users/:id/view',
                component : UserView,
            },
            {
                path : '/users/:id/edit',
                component : UserEdit,
            },
            {
                path : '/users/:id/activity',
                component : UserActivity,
            },
            {
                path : '/users/:id/timeline',
                component : UserTimeline,
            },
            {
                path : '/users/:id/roles',
                component : UserRoles,
            },
            {
                path : '/users/:id/permissions',
                component : UserPermissions,
            }
        ]
    },
    {
        path : '/users',
        component : UserIndex
    },

];


export default routes;
