// Buildings

import Index from "../components/saf-reports/index";
import Create from "../components/saf-reports/create";
import Open from "../components/saf-reports/open";
import View from "../components/saf-reports/view";
import Edit from "../components/saf-reports/edit";
import Run from "../components/saf-reports/run";


const routes = [

    {
        path : '/transactions/reports',
        component : Index
    },
    {
        path : '/transactions/reports/create',
        component : Create
    },

    {
            path : '/transactions/reports/:id/view',
            component : Open,
            children : [
                {
                    path : '/transactions/reports/:id/edit',
                    component : Edit,
                },
                {
                    path : '/transactions/reports/:id/view',
                    component : View,
                },
                {
                    path : '/transactions/reports/:id/run',
                    component : Run,
                }
            ]
    }
];

export default routes;
