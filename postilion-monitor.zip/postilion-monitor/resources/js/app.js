import Vue from "vue";
import router from "./routes/routes";
import {
    PlusCircleIcon , UsersIcon , UserPlusIcon ,
    UserCheckIcon, UserIcon , EditIcon , LockIcon ,
    ClockIcon , BellIcon , ColumnsIcon , CommandIcon , TagIcon , InfoIcon ,
    FolderIcon , ActivityIcon , BarChart2Icon , ZapIcon , SettingsIcon
} from "vue-feather-icons";
import { Plugin } from 'vue-fragment';

import Echo from 'laravel-echo';
// window.io = require('socket.io-client');

const Login  = () => import(/* webpackChunkName: "js/auth" */"./components/auth/Login");
const Register  = () => import(/* webpackChunkName: "js/auth" */"./components/auth/Register");
const Reset  = () => import(/* webpackChunkName: "js/auth" */"./components/auth/passwords/Reset");
const Email  = () => import(/* webpackChunkName: "js/auth" */"./components/auth/passwords/Email");
const NotificationsSmall  = () => import(/* webpackChunkName: "js/profile" */"./components/profile/notifications-small");

import Swal from 'sweetalert2';
window.Swal  = Swal;

let alerts = {
    success: function (response) {
        return new Promise((resolve, reject) => {
            window.Swal.fire({
                icon: 'success',
                title: response.data.message,
                showConfirmButton: false,
                padding: '20px',
                timer: 2000
            }).then((e) => {
                resolve(response);
            });
        });
    },
    warning: function (response) {
        return new Promise((resolve, reject) => {
            window.Swal.fire({
                icon: 'warning',
                title: response.data.message,
                showConfirmButton: false,
                padding: '20px',
                timer: 2000
            }).then((e) => {
                resolve(response);
            });
        });
    },
    error: function (response) {
        return new Promise((resolve, reject) => {
            window.Swal.fire({
                icon: 'error',
                title: response.data.message,
                showConfirmButton: false,
                padding: '20px',
                timer: 2000
            }).then((e) => {
                resolve(response);
            });
        });
    }
};

window.action = function (action , name , url ) {
    return new Promise((resolve, reject) => {
        window.Swal.fire({
            title: 'Are you sure?',
            text: `You want to ${action} this ${name}!`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: `Yes, ${action}!`
        }).then((result) => {
            if (result.value) {
                window.axios.get(url).then((response) => {
                    window.alerts.success(response).then((response) => {
                        resolve(response);
                    });
                }).catch((error) => {
                    reject(error);
                });
            }
        });

    });
};


window.alerts = alerts;

// Configure Axios for all ajax requests
window.axios = require('axios');
window.axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
window.axios.defaults.headers.common['Accept'] = 'application/json';
let token = document.head.querySelector('meta[name="csrf-token"]');
if (token) {
    window.axios.defaults.headers.common['X-CSRF-TOKEN'] = token.content;
} else {
    console.error('CSRF token not found , this is required for this web application');
}

// Configure laravel echo
// noinspection JSUnresolvedVariable

// window.Echo = new Echo({
//     broadcaster: 'socket.io',
//     host: window.location.hostname + ":" + window.laravel_echo_port
// });
//
// window.Echo.private('test-channel')
//     .listen('TestEvent', (e) => {
//         console.log(new Date());
//         console.log(e);
//     });

// Filters or pipes

Vue.filter('string_limit', function (value , limit = 20   , preceding = '...' ) {
    return value.length > limit ? value.substr( 0 ,  limit ) + preceding : value;
});

Vue.use(Plugin);

// Vue instance

window.vue = new Vue({
    router : router,
    components : {
        Login , Email , Reset , PlusCircleIcon , Register ,
        UsersIcon , UserPlusIcon , UserCheckIcon ,
        EditIcon , UserIcon , LockIcon , ClockIcon , FolderIcon ,
        BellIcon  , NotificationsSmall , ColumnsIcon , CommandIcon ,
        TagIcon , ActivityIcon , BarChart2Icon , ZapIcon , SettingsIcon , InfoIcon

    },
    el: '#app',
    methods : {
        logout : function () {
            document.getElementById('logout-form').submit();
        }
    }
});

