<template>
    <div>
        <div :class="['dimmer' , initLoading ? 'active' : '']">
            <div class="loader"></div>
            <div class="dimmer-content px-5">
                <h6 class="mg-b-25">Personal Details</h6>
                <div class="row">
                    <div class="col-4">
                        <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                            Firstname
                        </label>
                        <p class="mg-b-0">
                            {{ user.name }}
                        </p>
                    </div>
                    <div class="col-4">
                        <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                            Lastname
                        </label>
                        <p class="mg-b-0">
                            {{ user.last_name }}
                        </p>
                    </div>

                    <div class="col-4">
                        <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                            Email
                        </label>
                        <p class="mg-b-0">
                            {{ user.email }}
                        </p>
                    </div>
                </div>
                <h6 class="mg-b-25 mg-t-25">Account Details</h6>
                <div class="row">
                    <div class="col-4">
                        <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                            Created
                        </label>
                        <p class="mg-b-0">
                            {{ user.created_at }}
                        </p>
                    </div>
                    <div class="col-4">
                        <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                            Last Update
                        </label>
                        <p class="mg-b-0">
                            {{ user.last_update }}
                        </p>
                    </div>

                    <div class="col-4">
                        <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                            Status
                        </label>
                        <p class="mg-b-0 text-uppercase">
                            {{ user.status ? 'Active' : 'De-activated' }}
                        </p>
                    </div>
                </div>
                <h6 class="mg-b-25 mg-t-25">Authority Details</h6>
                <div class="row">
                    <div class="col-6">
                        <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                            Roles
                        </label>
                        <ul class="list-group">
                            <li :key="`role${role.id}`" v-for="role in user.roles" class="list-group-item d-flex align-items-center">
                                <div class="avatar avatar-sm wd-30 rounded-circle mg-r-15">
                                    <span class="avatar-initial rounded-circle">R</span>
                                </div>
                                <div>
                                    <h6 class="tx-13 tx-inverse tx-semibold mg-b-0 text-capitalize">{{ role.name }}</h6>
                                    <span class="d-block tx-11 text-muted">{{ role.created_at }}</span>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="col-6">
                        <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                            Permissions
                        </label>
                        <ul class="list-group">
                            <li :key="`role${permission.id}`" v-for="permission in user.permissions" class="list-group-item d-flex align-items-center">
                                <div class="avatar avatar-sm wd-30 rounded-circle mg-r-15">
                                    <span class="avatar-initial rounded-circle">P</span>
                                </div>
                                <div>
                                    <h6 class="tx-13 tx-inverse tx-semibold mg-b-0 text-capitalize">{{ permission.name }}</h6>
                                    <span class="d-block tx-11 text-muted">{{ permission.created_at }}</span>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>


</template>

<script>
    export default {
        name: "profile",
        mounted :  function(){
          this.init();
        },
        data :  function () {
            return {
                user : {},
                initLoading : true
            }
        },
        methods : {
            init : function () {

                this.initLoading = true;
                // Get Roles and Permissions
                // noinspection JSUnresolvedFunction
                window.axios.get(`${window.location.origin}/profile/view`).then((response) => {
                    this.user = response.data.body.user;
                }).catch((error) => {

                }).finally(() => {
                    this.initLoading = false;
                });

            }
        }
    }
</script>

<style scoped>

</style>
