<template>

    <div class="content">
        <div class="container">
            <div class="media d-block d-lg-flex">
                <div class="media-body">
                    <div class="timeline-group tx-13">
                        <div class="timeline-label py-5"></div>
                        <div :key="item.id" v-for="item in data.content.data" class="timeline-item">
                            <div class="timeline-time">
                                <strong>{{ item.created_at }} <br> {{ item.last_update }}</strong>
                            </div>
                            <div class="timeline-body">
                                <h6 class="mg-b-0">{{ item.event }} : {{ item.user.full_name }} - {{ item.user.email }} - <span class="text-primary">#{{ item.user.id }}</span></h6>
                                <h6 class="mg-b-0"><span class="text-primary">#{{ item.auditable_id }}</span> {{ item.auditable_type }}</h6>
                                <p class="mb-3">
                                    <span class="text-muted">IP : </span> {{ item.ip_address }}<br>
                                    <span class="text-muted">User Agent : </span> {{ item.user_agent }}<br>
                                    <span class="text-muted">Url : </span> <span class="text-primary"> {{ item.url }} </span> <br>
                                </p>
                                <table v-if="Object.entries(item.old_values).length > 0 || Object.entries(item.new_values).length > 0 " class="table border-bottom border-right border-left">
                                    <thead>
                                    <tr>
                                        <th v-if="Object.entries(item.old_values).length > 0" class="w-50">Old</th>
                                        <th v-if="Object.entries(item.new_values).length > 0 " class="w-50">New</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td  v-if="Object.entries(item.old_values).length > 0"  class="">
                                            <div :key="`${i}-${k}-${item.id}-old-values`" v-for="(i , k ) in item.old_values"><span class="text-muted">{{ k.replace('_',' ') }} : </span>{{ i }}</div>
                                        </td>

                                        <td v-if="Object.entries(item.new_values).length > 0 "  class="">
                                            <div :key="`${i}-${k}-${item.id}-new-values`" v-for="(i , k ) in item.new_values"><span class="text-muted">{{ k.replace('_',' ') }} : </span>{{ i }}</div>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="timeline-label pb-4 pt-4">
                            <button @click="data.append()" v-if="data.content.total !== data.content.to && data.content.data.length > 0" :class="['btn btn-white btn-sm' , data.loading ? 'btn-loading' :'']">
                                <arrow-down-icon class="mr-1"/> Load More
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>

<script>
    import { ArrowDownIcon } from 'vue-feather-icons';
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    import DataHandler from "../../core/data/DataHandler";
    export default {
        components : {
            ArrowDownIcon
        },
        name: "profile-activity",
        mounted : function() {
            this.data.fetch();
        },
        methods : {

        },
        data : function () {
            return {
                data : new DataHandler({
                    url : '/profile/activity',
                    prefix : 'audits'
                }),
                // Filter Panel with filter form
                filterPanel : false,
            };
        }
    }
</script>

<style scoped>

</style>
