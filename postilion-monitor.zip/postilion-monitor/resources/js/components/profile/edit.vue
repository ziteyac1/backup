<template>
    <div :class="['dimmer' , initLoading ? 'active' : '']">
        <div class="loader"></div>
        <div class="dimmer-content">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <form @submit.prevent="update">
                            <h6 class="mb-4">PERSONAL DETAILS</h6>
                            <div class="row row-sm mb-4">
                                <div class="col-sm-6">
                                    <label for="name">Name</label>
                                    <input type="text" id="name" name="name" v-model="form.name" :class="[ 'form-control' , form.errors.get('name') ? 'is-invalid' : '' ]" placeholder="">
                                    <div v-text="form.errors.get('name')" class="invalid-feedback"/>
                                </div>
                                <div class="col-sm-6 mg-t-10 mg-sm-t-0">
                                    <label for="last_name">Last Name</label>
                                    <input type="text" id="last_name" name="last_name" v-model="form.last_name" :class="[ 'form-control' , form.errors.get('last_name') ? 'is-invalid' : '' ]" placeholder="">
                                    <div v-text="form.errors.get('last_name')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="text-center mb-5">
                                <button @click="update" :disabled="form.loading" class="btn btn-primary"><edit-icon class="mr-2"/>UPDATE</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import Form from "../../core/forms/form";
    import {EditIcon} from 'vue-feather-icons';

    export default {
        components : {
            EditIcon
        },
        name: "profile",
        mounted :  function(){
             this.init();
        },
        data : function () {
            return {
              initLoading : true,
              form  :  new Form({
                  name : '',
                  last_name : '',
              })
            };
        },
        methods : {
            update :  function () {

                this.initLoading = true;
                this.form.submit(`/profile/edit`).then((response) => {

                }).catch((error) => {

                }).finally(() => {
                    this.initLoading = false;
                });
            },
            init : function () {
                this.initLoading = true;
                // Get Roles and Permissions
                // noinspection JSUnresolvedFunction
                window.axios.get(`${window.location.origin}/profile/view`).then((response) => {
                    this.form.name = response.data.body.user.name;
                    this.form.last_name = response.data.body.user.last_name;
                }).catch((error) => {

                }).finally(() => {
                    this.initLoading = false;
                });
            }
        }
    }
</script>

<style scoped>

</style>
