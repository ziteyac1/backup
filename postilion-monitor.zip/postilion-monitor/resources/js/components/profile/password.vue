<template>
    <div :class="['dimmer' , initLoading ? 'active' : '']">
        <div class="loader"></div>
        <div class="dimmer-content">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <form @submit.prevent="update">
                            <h6 class="mb-4">Password</h6>
                            <div class="row row-sm mb-4">
                                <div class="col-sm-12 mb-4">
                                    <label for="old_password">Old Password</label>
                                    <input type="password" id="old_password" name="old_password" v-model="form.old_password" :class="[ 'form-control' , form.errors.get('old_password') ? 'is-invalid' : '' ]" placeholder="">
                                    <div v-text="form.errors.get('old_password')" class="invalid-feedback"/>
                                </div>
                                <div class="col-sm-6 mg-t-10 mg-sm-t-0">
                                    <label for="password">New Password</label>
                                    <input type="password" id="password" name="password" v-model="form.password" :class="[ 'form-control' , form.errors.get('password') ? 'is-invalid' : '' ]" placeholder="">
                                    <div v-text="form.errors.get('password')" class="invalid-feedback"/>
                                </div>
                                <div class="col-sm-6 mg-t-10 mg-sm-t-0">
                                    <label for="password_confirmation">Confirm Password</label>
                                    <input type="password" id="password_confirmation" name="password_confirmation" v-model="form.password_confirmation" :class="[ 'form-control' , form.errors.get('password_confirmation') ? 'is-invalid' : '' ]" placeholder="">
                                    <div v-text="form.errors.get('password_confirmation')" class="invalid-feedback"/>
                                </div>
                            </div>
                            <div class="text-center mb-5">
                                <button @click="update" :disabled="form.loading" class="btn btn-primary"><edit-icon class="mr-2"/>UPDATE</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import {EditIcon} from "vue-feather-icons";
    import Form from "../../core/forms/form";

    export default {
        name: "profile",
        components : {
            EditIcon
        },
        data : function () {
            return {
                initLoading : false,
                form  :  new Form({
                    old_password : '',
                    password : '',
                    password_confirmation : '',
                })
            };
        },
        methods : {
            update : function () {
                this.initLoading = true;
                this.form.submit(`/profile/password`).then((response) => {

                }).catch((error) => {

                }).finally(() => {
                    this.initLoading = false;
                });
            }
        }
    }
</script>

<style scoped>

</style>
