<template>

    <div class="content">
        <div class="container">
            <div :class="['dimmer' , data.loading ? 'active' : '']">
                <div class="loader"></div>
                <div class="dimmer-content">
                    <ul class="activity tx-13">
                        <li v-for="notification in data.content.data" class="activity-item">
                            <div class="activity-icon bg-primary-light tx-primary">
                                <user-icon/>
                            </div>
                            <div class="activity-body">
                                <p class="mg-b-2">{{ notification.data.message }}</p>
                                <small class="tx-color-03">{{ notification.created_at }}</small>
                            </div>
                        </li>
                        <li class="activity-item">
                            <div class="activity-icon bg-primary-light tx-primary">
                                <info-icon/>
                            </div>
                            <div class="activity-body">
                                <button @click="data.append" v-if="data.content.total !== data.content.to && data.content.data.length > 0" :class="['btn btn-white btn-sm' , data.loading ? 'btn-loading' :'']">
                                    <arrow-down-icon class="mr-1"/> Load More
                                </button>
                                <p class="mt-2" v-else>Start</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

        </div>
    </div>

</template>

<script>
    import { ArrowDownIcon , BellIcon , UserIcon  ,InfoIcon} from 'vue-feather-icons';
    import DataHandler from "../../core/data/DataHandler";
    export default {
        components : {
            ArrowDownIcon , BellIcon  , UserIcon , InfoIcon
        },
        name: "profile-notifications",
        mounted : function() {
            this.data.fetch();
        },

        ///profile/notifications

        data : function () {
            return {
                data :  new DataHandler({
                   url : '/profile/notifications',
                   prefix : 'notifications',
                })
            };
        }
    }
</script>

<style scoped>

</style>
