<template>
    <div>
        <div v-for="notification in notifications" href="" class="dropdown-item">
            <div class="media">
                <div class="activity-icon bg-primary-light tx-primary">
                    <bell-icon/>
                </div>
                <div class="media-body mg-l-15">
                    <p>{{ notification.data.message }}</p>
                    <span>{{ notification.created_at }}</span>
                </div><!-- media-body -->
            </div><!-- media -->
        </div>
    </div>

</template>

<script>
    import { ArrowDownIcon , BellIcon } from 'vue-feather-icons';
    export default {

        components : {
            ArrowDownIcon , BellIcon
        },
        name: "notifications-small",
        mounted : function() {
            this.init();
        },
        methods : {
            init : function () {
                window.axios.get(`${window.location.origin}/profile/notifications-mini`).then((response) => {
                    this.notifications = response.data.body.notification;
                }).catch((error) => {

                }).finally(() => {
                });
            }
        },
        data : function () {
            return {
               notifications : []
            };
        }
    }
</script>

<style scoped>

</style>
