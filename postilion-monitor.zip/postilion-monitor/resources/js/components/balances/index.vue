<template>
    <data-table url="/balances" prefix="balances" order="last_updated_date">
        <template slot="table-header">
            <th/>
            <th>Account ID</th>
            <th>Available</th>
            <th>Ledger</th>
            <th class="">Updated</th>
            <th/>
        </template>
        <!--suppress JSUnusedLocalSymbols -->
        <template slot="table-row" slot-scope="data">
            <td>
                <div class="avatar">
                <span :class="['avatar-initial rounded-circle' , data.row.available_balance < 0 ? 'bg-danger' : 'bg-gray-600']">{{ data.row.account_id.substr( 0 , 2) }}</span></div>
            </td>
            <td class="">{{ data.row.account_id }}</td>
            <td class="">{{ data.row.available_balance }}</td>
            <td class="">{{ data.row.ledger_balance }}</td>
            <td class="">{{ data.row.last_updated_date }}</td>
            <td>
                <router-link :to="`/balances/${data.row.account_id}/view`" class="btn btn-sm pd-x-15 btn-white btn-icon">
                    <eye-icon size="24"/>
                </router-link>
            </td>

        </template>
    </data-table>
</template>

<script>
    import DataTable from "../core/DataTable";
    import {PlusIcon , EyeIcon} from "vue-feather-icons";
    export default {
        name: "roles-index",
        components: {DataTable , PlusIcon , EyeIcon }
    }
</script>

<style scoped>

</style>
