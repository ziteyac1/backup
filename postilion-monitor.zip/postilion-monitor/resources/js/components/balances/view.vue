<template>
    <div class="filemgr-content">
        <div class="filemgr-content-header px-5">
            <div class="d-flex align-items-center">
                <div class="avatar">
                    <span class="avatar-initial rounded-circle bg-gray-600">{{ $route.params.id.substr( 0 , 2) }}</span>
                </div>
                 <span class="ml-4">
                    {{ $route.params.id }}
                </span>
            </div>

            <button @click="init" class="btn btn-white rounded-0 ml-auto btn-sm px-5">Refresh</button>
        </div>
        <div class="filemgr-content-body p-5">
            <div :class="['dimmer' , initLoading ? 'active' : '' ]">
                <div class="loader"></div>
                <div class="dimmer-content">
                    <div class="container">
                        <div class="row">
                                <div class="col-lg-5">
                                    <input type="text" placeholder="Available Balance" :class="[ 'form-control  rounded-0' , form.errors.get('available') ? 'is-invalid' : '' ]" v-model="form.available">
                                    <div v-text="form.errors.get('available')" class="invalid-feedback"/>
                                </div>
                                <div class="col-lg-5">
                                    <input type="text" placeholder="Ledger Balance" :class="[ 'form-control  rounded-0' , form.errors.get('ledger') ? 'is-invalid' : '' ]" v-model="form.ledger">
                                    <div v-text="form.errors.get('ledger')" class="invalid-feedback"/>
                                </div>
                                <div class="col-lg-2">
                                    <button @click="update" class="btn btn-white rounded-0 btn-block">Update</button>
                                </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-lg-4">
                                <div style="height: 95px" class="card card-body text-center ">
                                    <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Actual</h6>
                                    <div class="">
                                        <h2 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">$ {{  actual / 100 }}</h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div style="height: 95px" class="card card-body text-center ">
                                    <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Ledger</h6>
                                    <div class="">
                                        <h2 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">$ {{  account.ledger_balance !== 0 ? account.ledger_balance / 100 : account.ledger_balance }}</h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">

                                <div style="height: 95px" class="card card-body text-center ">
                                    <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Available</h6>
                                    <div class="">
                                        <h2 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">$ {{  account.available_balance !== 0 ? account.available_balance / 100 : account.available_balance }}</h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-4" >
                            <div class="col-lg-12">
                                <div class="card rounded-0">
                                    <div class="card-header border-bottom-0">
                                        <div class="">
                                            <h5 class="mg-b-0">Deltas</h5>
                                        </div>
                                    </div><!-- card-header -->
                                    <div class="table-responsive tx-12">
                                        <table class="table table-dashboard mg-b-0 table-vcenter">
                                            <thead>
                                            <tr>
                                                <th>Extract</th>
                                                <th>Account</th>
                                                <th>Balances</th>
                                                <th>Date</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr v-for="item in deltas">
                                                <td class="">
                                                    Extract : <span class="text-primary">{{ item.extract_nr }}</span><br>
                                                </td>
                                                <td>
                                                    <div>Acc : {{ item.account_id }}</div>
                                                    <div>Type : {{ item.account_type }}</div>
                                                </td>
                                                <td>
                                                    <div>Ledger : $ {{ item.ledger_balance  / 100 }}</div>
                                                    <div>Available : $ {{ item.available_balance  / 100 }}</div>
                                                </td>
                                                <td class="">
                                                    <span class="text-primary">{{ item.last_updated_date }}</span><br>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-4" >
                            <div class="col-lg-12">
                                <div class="card rounded-0">
                                    <div class="card-header border-bottom-0">
                                        <div class="">
                                            <h5 class="mg-b-0">Postilion Transactions</h5>
                                        </div>
                                    </div><!-- card-header -->
                                    <div class="table-responsive tx-12">
                                        <table class="table table-dashboard mg-b-0 table-vcenter">
                                            <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Account</th>
                                                <th>Info</th>
                                                <th>Terminal</th>
                                                <th>Date</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr v-for="item in transactions">
                                                <td class="">
                                                    <span class="text-primary">#{{ item.row_id }}</span><br>
                                                    Extract : <span class="text-primary">{{ item.extract_nr }}</span><br>
                                                </td>
                                                <td>
                                                    <div>Acc : {{ item.account_id }}</div>
                                                    <div>Pan : {{ item.pan }}</div>
                                                </td>
                                                <td>
                                                    <div>Amount : $ {{ item.tran_amount  / 100 }}</div>
                                                    <div>RRN : {{ item.retrieval_ref_nr }}</div>

                                                </td>
                                                <td>
                                                    <div>Loc : {{ item.card_acceptor_name_location }}</div>
                                                    <div>Term : {{ item.card_acceptor_term_id }}</div>
                                                </td>
                                                <td class="">
                                                    <span class="text-primary">{{ item.tran_local_datetime }}</span><br>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-4" >
                            <div class="col-lg-12">
                                <div class="card rounded-0">
                                    <div class="card-header border-bottom-0">
                                        <div class="">
                                            <h5 class="mg-b-0">Logs</h5>
                                        </div>
                                    </div><!-- card-header -->
                                    <div class="table-responsive tx-12">
                                        <table class="table table-dashboard mg-b-0 table-vcenter">
                                            <thead>
                                            <tr>
                                                <th>Account</th>
                                                <th>Balance</th>
                                                <th>Info</th>
                                                <th>Date</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr v-for="item in logs">
                                                <td class="">
                                                    <span class="text-primary">#{{ item.id }}</span><br>
                                                    <span class="text-success">{{ item.account }}</span><br>
                                                </td>
                                                <td>
                                                    <div>Available : {{ item.ledger_balance }}</div>
                                                    <div>Ledger : {{ item.available_balance }}</div>
                                                </td>
                                                <td>
                                                    <div>Name : {{ item.user.full_name }}</div>
                                                    <div>Email : {{ item.user.email }}</div>
                                                </td>
                                                <td class="">
                                                    <span class="text-primary">{{ item.created_at }}</span><br>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</template>

<script>
    import {PlusIcon , EyeIcon , RefreshCwIcon} from "vue-feather-icons";
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    import Form from "../../core/forms/form";
    export default {
        name: "roles-index",
        components: { PlusIcon , EyeIcon , RefreshCwIcon },
        mounted : function () {
            this.init();

        },
        data :  function(){
            return {
                initLoading : true,
                account: {},
                actual: 0,
                deltas: [],
                logs: [],
                transactions: [],
                form : new Form({
                    available : '',
                    ledger : '',
                })
            }
        },
        methods : {
            update : function(){

                this.initLoading = false;
                this.form.submit(`/balances/${this.$route.params.id}/edit`).then((response) => {
                    window.alerts.success(response).then((response) => {
                        this.init();
                    });

                }).catch((error) => {

                }).finally(() => {
                    this.initLoading = false;
                });

            },

            init : function () {
                this.initLoading = true;
                window.axios.get(`${window.location.origin}/balances/${this.$route.params.id}/view`).then((response) => {
                    this.account = response.data.body.account;
                    this.deltas = response.data.body.deltas;
                    this.transactions = response.data.body.transactions;
                    this.logs = response.data.body.logs;
                    this.actual = response.data.body.actual;
                }).finally(() => {
                    this.initLoading = false;
                });
            }
        }
    }
</script>


