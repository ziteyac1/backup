<template>
    <div class="filemgr-content">
        <div class="filemgr-content-with-side">
            <div class="filemgr-content-header align-items-center">
                <users-icon size="26"/>
                    <span class="ml-3 text-primary">
                        <strong class="tx-20">#{{ $route.params.id }}</strong>
                    </span>
                <span class="border-left ml-auto mr-3"/>
            </div>
            <transition name="slide-in-left">
                <router-view/>
            </transition>
        </div>
        <div class="filemgr-content-side">
            <div class="filemgr-sidebar-body">
                <div class="pd-t-20 pd-b-10 pd-x-10">
                    <label class="tx-sans tx-uppercase tx-medium tx-10 tx-spacing-1 tx-color-03 pd-l-10">User</label>
                    <nav class="nav nav-sidebar tx-13">
                        <can permission="view user">
                            <router-link class="nav-link" active-class="active" :to="`/users/${$route.params.id}/view`" exact>
                                <eye-icon/>  View User
                            </router-link>
                        </can>
                        <can permission="edit user">
                            <router-link class="nav-link" active-class="active" :to="`/users/${$route.params.id}/edit`" exact>
                               <edit-icon/> Edit User
                            </router-link>
                        </can>
                    </nav>
                    <can permission="view user">
                        <label class="tx-sans tx-uppercase tx-medium tx-10 tx-spacing-1 tx-color-03 pd-l-10 pd-t-20">Audit</label>
                        <nav class="nav nav-sidebar tx-13">
                            <router-link class="nav-link" active-class="active" :to="`/users/${$route.params.id}/activity`" exact>
                                <activity-icon/> Activity
                            </router-link>
                            <router-link class="nav-link" active-class="active" :to="`/users/${$route.params.id}/timeline`" exact>
                               <clock-icon/> Timeline
                            </router-link>
                        </nav>
                        <label class="tx-sans tx-uppercase tx-medium tx-10 tx-spacing-1 tx-color-03 pd-l-10 pd-t-20">Authority</label>
                        <nav class="nav nav-sidebar tx-13">
                            <router-link class="nav-link" active-class="active" :to="`/users/${$route.params.id}/roles`" exact>
                                <user-plus-icon/> Roles
                            </router-link>
                            <router-link class="nav-link" active-class="active" :to="`/users/${$route.params.id}/permissions`" exact>
                                <user-check-icon/> Permissions
                            </router-link>
                        </nav>
                    </can>

                </div>
            </div>
        </div>
    </div>

</template>

<script>
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    import {
        EyeIcon , EditIcon , ActivityIcon ,
        ClockIcon , UsersIcon , UserPlusIcon , UserCheckIcon
    } from "vue-feather-icons"
    import Can from "../core/can";
    export default {
        components : {
            Can,
            EyeIcon , EditIcon , ActivityIcon  , ClockIcon,
            UsersIcon , UserPlusIcon , UserCheckIcon
        },
        name: "users-open",
        mounted : function() {

        },
    }
</script>

<style scoped>

</style>
