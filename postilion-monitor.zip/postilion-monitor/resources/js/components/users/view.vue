<!--suppress JSUnresolvedVariable -->
<template>
    <div class="filemgr-content-body">
        <div style="min-height:100%" :class="['dimmer' , initLoading ? 'active' : '']">
            <div class="loader"></div>
            <div   class="dimmer-content">
               <div class="container pd-30">
                   <div class="mg-b-25 mg-t-25 d-flex align-items-center">
                       <h6 class="mr-auto mb-0">Personal Details</h6>
                       <button @click="activate" v-if="!user.status" :class="['btn btn-sm pd-x-15 btn-white btn-uppercase mr-3']">
                           <zap-icon class="mr-2"/> Activate
                       </button>
                       <button @click="deActivate" v-if="user.status" :class="['btn btn-sm pd-x-15 btn-white btn-uppercase']">
                           <zap-off-icon class="mr-2"/> De-activate
                       </button>
                   </div>

                   <div class="row">
                       <div class="col-4">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Firstname
                           </label>
                           <p class="mg-b-0">
                               {{ user.name }}
                           </p>
                       </div>
                       <div class="col-4">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Lastname
                           </label>
                           <p class="mg-b-0">
                               {{ user.last_name }}
                           </p>
                       </div>

                       <div class="col-4">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Email
                           </label>
                           <p class="mg-b-0">
                               {{ user.email }}
                           </p>
                       </div>
                   </div>
                   <h6 class="mg-b-25 mg-t-25">Account Details</h6>
                   <div class="row">
                       <div class="col-4">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Created
                           </label>
                           <p class="mg-b-0">
                               {{ user.created_at }}
                           </p>
                       </div>
                       <div class="col-4">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Last Update
                           </label>
                           <p class="mg-b-0">
                               {{ user.last_update }}
                           </p>
                       </div>

                       <div class="col-4">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Status
                           </label>
                           <p class="mg-b-0 text-uppercase">
                               {{ user.status ? 'Active' : 'De-activated' }}
                           </p>
                       </div>
                   </div>
               </div>
            </div>
        </div>
    </div>

</template>

<script>
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    import {
          ZapIcon , ZapOffIcon
    } from "vue-feather-icons"
    export default {
        components : {
            ZapIcon , ZapOffIcon
        },
        name: "users-view",
        mounted : function() {

            this.init();
        },
        data : function () {
            return {
                initLoading : true,
                user : {}
            }
        },
        methods : {
            deActivate : function(){
                this.initLoading = true;
                window.axios.get(`${window.location.origin}/users/${this.$route.params.id}/deactivate`).then((response) => {
                    this.user = response.data.body.user;
                }).catch((error) => {

                }).finally(() => {
                    this.initLoading = false;
                });
            },
            activate : function(){
                this.initLoading = true;
                window.axios.get(`${window.location.origin}/users/${this.$route.params.id}/activate`).then((response) => {
                    this.user = response.data.body.user;
                }).catch((error) => {

                }).finally(() => {
                    this.initLoading = false;
                });
            },
            init : function () {
                this.initLoading = true;
                // Get Roles and Permissions
                // noinspection JSUnresolvedFunction
                window.axios.get(`${window.location.origin}/users/${this.$route.params.id}/view`).then((response) => {
                    this.user = response.data.body.user;
                }).catch((error) => {

                }).finally(() => {
                    this.initLoading = false;
                });
            }
        }
    }
</script>

<style scoped>

</style>
