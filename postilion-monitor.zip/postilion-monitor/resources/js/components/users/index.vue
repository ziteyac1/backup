<template>
    <data-table url="/users" prefix="users">
        <template slot="create-link">
            <can permission="create user">
                <router-link to="/users/create" :class="['btn btn-sm pd-x-15 btn-white btn-uppercase mr-3']">
                    <plus-icon size="24" /> New User
                </router-link>
            </can>
        </template>
        <template slot="table-header">
            <th/>
            <th/>
            <th>Name</th>
            <th>Last Name</th>
            <th class="">Email</th>
            <th class="">Role</th>
            <th class="">Date</th>
            <th class=""/>
        </template>
        <!--suppress JSUnusedLocalSymbols -->
        <template slot="table-row" slot-scope="data">
            <td class="text-primary">#{{ data.row.id }}</td>
            <td>
                <div class="avatar">
                <!--suppress JSUnresolvedVariable -->
                <span class="avatar-initial rounded-circle bg-gray-600">{{ data.row.avatar_name }}</span>
                </div>
            </td>
            <td class="">{{ data.row.name }}</td>
            <td class="">{{ data.row.last_name }}</td>
            <td class="">{{ data.row.email }}</td>
            <td class="">{{ data.row.role }}</td>
            <td class="">
                <!--suppress JSUnresolvedVariable -->
                <div>Created : {{ data.row.created_at }}</div>
                <!--suppress JSUnresolvedVariable -->
                <div>Updated : {{ data.row.last_update }}</div>
            </td>
            <td class="text-center">
                <can permission="view user">
                    <router-link :to="`users/${data.row.id}/view`" class="btn btn-sm pd-x-15 btn-white btn-icon">
                        <eye-icon size="24"/>
                    </router-link>
                </can>

            </td>
        </template>
    </data-table>
</template>

<script>
    import DataTable from "../core/DataTable";
    import {PlusIcon , EyeIcon} from "vue-feather-icons";
    import Can from "../core/can";
    export default {
        name: "users-index",
        components: {Can, DataTable , PlusIcon , EyeIcon }
    }
</script>

<style scoped>

</style>
