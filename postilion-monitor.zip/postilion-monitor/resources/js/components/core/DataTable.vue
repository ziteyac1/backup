<template>
    <div class="filemgr-content">
        <div :class="['filemgr-content-header']">
            <i data-feather="search"/>
            <form @submit.prevent="data.fetch()" class="search-form border-right">
                <!--suppress HtmlFormInputWithoutLabel -->
                <input v-model="data.search" type="search" class="form-control" placeholder="Search...">
            </form><!-- search-form -->
            <div  class="d-flex align-items-center ml-3 tx-12">
                <span class="mr-3"> Showing {{ data.content.data.length }} of {{ data.content.total }} Records </span>
                <span class="border border-secondary py-1 px-2 rounded mr-auto">Sorted By  : <strong> {{ data.sort.field.read }} </strong> , {{ data.sort.value }} </span>
            </div>
            <nav class="nav d-none d-sm-flex mg-l-auto">
                <slot name="create-link"/>
                <button  @click="data.fetch()" :class="['btn btn-sm pd-x-15 btn-white btn-uppercase mr-3',  data.loading ? 'btn-loading' : '']"><refresh-cw-icon class="mr-2"/> Refresh</button>
                <button v-if="filter === undefined" @click="openFilterPanel" :class="['btn btn-sm pd-x-15 btn-white btn-uppercase',  data.loading ? 'btn-loading' : '']"><filter-icon class="mr-2"/> Filter </button>
            </nav>
        </div>
        <div id="filemgr-content-body" :class="['filemgr-content-body' , maximise ? 'filemgr-content-body-maximize' : '']">
            <div v-if="data.filters.length > 0 || data.ranges.length > 0 " class="px-2 py-2 filters-container tx-12">
                    <span class="ml-2" :key="`filters-${index}`" v-for="(item, index) in data.filters" >
                        <span class="border border-secondary py-2 px-2 rounded-left">{{ item.field.read }} : <strong > {{ item.value.read }} </strong></span>
                        <span @click="data.removeFilter(index)" class="border-top border-bottom border-right border-secondary text-muted  py-2 px-2 rounded-right" style="cursor: pointer;"><x-icon size="15"/></span>
                    </span>
                    <span :key="`ranges-${index}`" class="ml-2" v-for="(item, index) in data.ranges">
                        <span class="border border-secondary py-2 px-2 rounded-left"> {{ item.field.read }} : <strong> {{ item.min }} - {{ item.max }} </strong></span>
                        <span @click="data.removeRange(item)" class="border-top border-bottom border-right border-secondary text-muted  py-2 px-2 rounded-right" style="cursor: pointer;"><x-icon size="15"/></span>
                    </span>
            </div>
            <div v-if="data.content.total > 0" class="table-responsive tx-13">
                <table class="table border-bottom table-hover table-vcenter">
                    <thead>
                    <tr class="bg-light">
                        <!--suppress HtmlDeprecatedAttribute -->
                        <th width="10"/>
                            <slot name="table-header"/>
                        <!--suppress HtmlDeprecatedAttribute -->
                        <th width="10"/>
                    </tr>
                    </thead>
                    <tbody>
                    <template v-for="row in data.content.data">
                        <tr :key="row.id">
                            <td/>
                             <slot :row="row" name="table-row"/>
                            <td/>
                        </tr>
                    </template>
                    </tbody>
                </table>
            </div>
            <div v-if="data.content.total !== data.content.to && data.content.data.length > 0" :class="['px-2 py-3 text-center dimmer' , data.loading ? 'active' : '']">
                <div class="loader"></div>
                <div class="dimmer-content">
                    <a @click.prevent="data.append" href="" class="link-03"> Load More <i class="icon ion-md-arrow-down mg-l-5"/></a>
                </div>
            </div>
            <div v-if="data.content.data.length < 1" :class="['px-2 py-5 text-center border-bottom  dimmer' , data.loading ? 'active' : '']">
                <div class="loader"></div>
                <div class="dimmer-content">
                    No records found
                </div>
            </div>
        </div>
        <div :class="['filemgr-content-filters' , filterPanel ? 'filemgr-content-filters-open' : '']">
            <div class="filemgr-content-filters-content">
                <div style="font-size: 18px;height: 55px;padding: 0 20px" class="d-flex justify-content-between align-items-center border-bottom">
                    <span>Filters</span>
                    <x-icon @click="closeFilterPanel"/>
                </div>
                <div class="card-body">
                    <div  class="form-row">
                        <div  class="form-group col-md-8">
                            <label for="order-by-filter-field" class="col-form-label">Order By</label>
                            <select v-model="data.sort.field" id="order-by-filter-field" class="form-control">
                                <option :value="item" :key="`sort-value-key-${item.field}`" v-for="item in data.sortFields">{{ item.read }}</option>
                            </select>
                        </div>
                        <div  class="form-group col-md-4">
                            <label for="order-by-filter-direction" class="col-form-label">Direction</label>
                            <select v-model="data.sort.value" id="order-by-filter-direction" class="form-control">
                                <option  value="Asc">ASC</option>
                                <option  value="Desc">DESC</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group" :key="`key-filter-fields-${item.field}`" v-for="item in data.filterFields">
                        <label for="inputState" class="col-form-label">{{ item.read }}</label>
                        <select v-model="data.filterForm.filters[item.field]" id="inputState" class="form-control">
                            <option :key="`key-filter-fields-value-${i.value}-${item.field}`" :value="i" v-for="i in item.filter">{{ i.read }}</option>
                        </select>
                    </div>
                    <div class="form-group" :key="`key-range-fields-${item.field}`" v-for="item in data.rangeFields">
                        <label>{{ item.read }} </label>
                        <div class="d-flex">
                            <!--suppress HtmlFormInputWithoutLabel -->
                            <input v-model="data.filterForm.ranges.min[item.field]" :type="[item.date ? 'date' : 'text']" placeholder="Min" class="form-control d-inline-block ">
                            <span class="d-inline-block text-center text-muted mx-2"><i class="mdi mdi-window-minimize"/></span>
                            <!--suppress HtmlFormInputWithoutLabel -->
                            <input v-model="data.filterForm.ranges.max[item.field]" :type="[item.date ? 'date' : 'text']" placeholder="Max" class="form-control d-inline-block ">
                        </div>
                    </div>
                </div>
                <div class="border-top text-center card-body">
                    <button @click="runFilters" class="btn btn-sm pd-x-15 btn-white btn-uppercase mr-3"><i class="fa fa-filter wd-10 mg-r-5"/> Filter </button>
                </div>
            </div>

        </div>
    </div>
</template>

<script>
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    import {XIcon , RefreshCwIcon , FilterIcon , MaximizeIcon} from "vue-feather-icons";
    import DataHandler from "../../core/data/DataHandler";
    export default {
        components : {
            XIcon , RefreshCwIcon , FilterIcon , MaximizeIcon
        },
        // Components starts
        mounted : function () {

            this.data.fetch();

            new PerfectScrollbar('.filemgr-content-filters-content', {
                suppressScrollX: true,
            });



        },
        // Config properties
        props: ['url', 'prefix','filter' , 'order'],
        // name of the component
        name: "data-table",
        // Data of the component
        data :  function () {
            return {

                data : new DataHandler({
                    url : this.url,
                    prefix : this.prefix,
                    order : this.order
                }),

                // Filter Panel with filter form
                filterPanel : false,
                maximise : false,

            }
        },
        methods : {
            openFilterPanel : function () {
                this.filterPanel = true
            },
            closeFilterPanel : function () {
                this.filterPanel = false
            },
            runFilters : function (){
                this.data.runFilters();
                this.closeFilterPanel();
            },
        }
    }
</script>

<style scoped>
    .table thead th {
        border-top: none;
    }
    .table th, .table td {
        padding: 8px 15px;
    }
</style>
