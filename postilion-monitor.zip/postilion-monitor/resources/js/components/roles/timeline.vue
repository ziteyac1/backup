<template>
    <timeline name="Timeline" :url="`/roles/${$route.params.id}/timeline`"/>
</template>

<script>
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    import Timeline from "../core/Timeline";
    export default {
        components: {
            Timeline
        },
        name: "roles-timeline",
        mounted : function() {

        }
    }
</script>

<style scoped>

</style>
