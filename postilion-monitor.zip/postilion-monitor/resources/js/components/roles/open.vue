<template>
    <div class="filemgr-content">
        <div class="filemgr-content-with-side">
            <div class="filemgr-content-header align-items-center">
                <user-plus-icon size="26"/>
                    <span class="ml-3 text-primary">
                        <strong class="tx-20">#{{ $route.params.id }}</strong>
                    </span>
                <span class="border-left ml-auto mr-3"/>

            </div>
            <transition name="slide-in-left">
                <router-view/>
            </transition>
        </div>
        <div class="filemgr-content-side">
            <div class="filemgr-sidebar-body">
                <div class="pd-t-20 pd-b-10 pd-x-10">
                    <label class="tx-sans tx-uppercase tx-medium tx-10 tx-spacing-1 tx-color-03 pd-l-10">Role</label>
                    <nav class="nav nav-sidebar tx-13">
                        <router-link class="nav-link" active-class="active" :to="`/roles/${$route.params.id}/view`" exact>
                            <eye-icon/>  View Role
                        </router-link>
                        <router-link class="nav-link" active-class="active" :to="`/roles/${$route.params.id}/edit`" exact>
                           <edit-icon/> Edit Role
                        </router-link>
                    </nav>

                    <label class="tx-sans tx-uppercase tx-medium tx-10 tx-spacing-1 tx-color-03 pd-l-10 pd-t-20">Authority</label>
                    <nav class="nav nav-sidebar tx-13">
                        <router-link class="nav-link" active-class="active" :to="`/roles/${$route.params.id}/permissions`" exact>
                           <user-plus-icon/> Permissions
                        </router-link>
                    </nav>

                    <label class="tx-sans tx-uppercase tx-medium tx-10 tx-spacing-1 tx-color-03 pd-l-10 pd-t-20">Audit</label>
                    <nav class="nav nav-sidebar tx-13">
                        <router-link class="nav-link" active-class="active" :to="`/roles/${$route.params.id}/timeline`" exact>
                           <clock-icon/> Timeline
                        </router-link>
                    </nav>
                </div>
            </div>
        </div>
    </div>

</template>

<script>
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    import {
        EyeIcon , EditIcon , ActivityIcon ,
        ClockIcon , UserPlusIcon
    } from "vue-feather-icons"
    export default {
        components : {
            EyeIcon , EditIcon , ActivityIcon  , ClockIcon,
            UserPlusIcon
        },
        name: "users-open",
        mounted : function() {

        },
    }
</script>

<style scoped>

</style>
