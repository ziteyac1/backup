<template>
    <data-table-min name="Permissions" :url="`/roles/${$route.params.id}/permissions`" prefix="permissions">

        <template slot="table-header">
            <th/>
            <th/>
            <th>Name</th>
            <th>Guard</th>
            <th class="">Created</th>
            <th class="">Updated</th>
        </template>
        <!--suppress JSUnusedLocalSymbols -->
        <template slot="table-row" slot-scope="data">
            <td class="text-primary">#{{ data.row.id }}</td>
            <td>
                <div class="avatar">
                <!--suppress JSUnresolvedVariable -->
                <span class="avatar-initial rounded-circle bg-gray-600">{{ data.row.avatar_name }}</span></div>
            </td>
            <td class="text-capitalize">{{ data.row.name }}</td>
            <td class="">{{ data.row.guard_name }}</td>
            <td class="">{{ data.row.created_at }}</td>
            <td class="">{{ data.row.updated_at }}</td>
        </template>
    </data-table-min>
</template>

<script>
    import DataTable from "../core/DataTable";
    import {PlusIcon , EyeIcon} from "vue-feather-icons";
    import DataTableMin from "../core/DataTableMin";
    export default {
        name: "roles-permissions",
        components: {DataTableMin, DataTable , PlusIcon , EyeIcon }
    }
</script>

<style scoped>

</style>
