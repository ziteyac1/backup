<template>
    <data-table url="/roles" prefix="roles">
        <template slot="create-link">
            <router-link to="/roles/create" :class="['btn btn-sm pd-x-15 btn-white btn-uppercase mr-3']">
                <plus-icon size="24" /> New Role </router-link>
        </template>
        <template slot="table-header">
            <th/>
            <th/>
            <th>Name</th>
            <th class="">Guard</th>
            <th class="">Created</th>
            <th class="">Updated</th>
            <th class=""/>
        </template>
        <!--suppress JSUnusedLocalSymbols -->
        <template slot="table-row" slot-scope="data">
            <td class="text-primary">#{{ data.row.id }}</td>
            <td>
                <div class="avatar">
                <!--suppress JSUnresolvedVariable -->
                <span class="avatar-initial rounded-circle bg-gray-600">{{ data.row.avatar_name }}</span></div></td>
            <td class="">{{ data.row.name }}</td>
            <td class="">{{ data.row.guard_name }}</td>
            <td class="">{{ data.row.created_at }}</td>
            <td class="">{{ data.row.updated_at }}</td>
            <td class="text-center">
                <router-link :to="`roles/${data.row.id}/view`" class="btn btn-sm pd-x-15 btn-white btn-icon">
                   <eye-icon size="24"/>
                </router-link>
            </td>
        </template>
    </data-table>
</template>

<script>
    import DataTable from "../core/DataTable";
    import {PlusIcon , EyeIcon} from "vue-feather-icons";
    export default {
        name: "roles-index",
        components: {DataTable , PlusIcon , EyeIcon }
    }
</script>

<style scoped>

</style>
