<template>
    <div class="filemgr-content-body">
            <div :class="['dimmer' , initLoading ? 'active' : '']">
                <div class="loader"></div>
                <div class="dimmer-content">
                    <div class="container pt-4">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div>
                                    <h6 class="mb-4 mg-t-25">PERSONAL DETAILS</h6>
                                    <div class="row row-sm mb-4">
                                        <div class="col-sm-12">
                                            <label for="name">Name</label>
                                            <input type="text" id="name" name="name" v-model="form.name" :class="[ 'form-control' , form.errors.get('name') ? 'is-invalid' : '' ]" placeholder="">
                                            <div v-text="form.errors.get('name')" class="invalid-feedback"/>
                                        </div>
                                    </div>
                                    <h6 class="mb-4">AUTHORITY</h6>
                                    <div class="row row-sm mb-4">
                                        <div class="col-sm-12 mg-t-10 mg-sm-t-0">
                                            <label >Permissions</label>
                                            <multi-data-select  select="name" :start="form.storage.permissions" url="/permissions" prefix="permissions" v-model="form.permissions" name="Permissions">
                                                <template slot="table-header">
                                                    <th/>
                                                    <th/>
                                                    <th>Name</th>
                                                    <th>Guard</th>
                                                    <th class="">Created</th>
                                                    <th class="">Updated</th>
                                                </template>
                                                <!--suppress JSUnusedLocalSymbols -->
                                                <template slot="table-row" slot-scope="data">
                                                    <td class="text-primary">#{{ data.row.id }}</td>
                                                    <td>
                                                        <div class="avatar">
                                                            <!--suppress JSUnresolvedVariable -->
                                                            <span class="avatar-initial rounded-circle bg-gray-600">{{ data.row.avatar_name }}</span></div>
                                                    </td>
                                                    <td class="text-capitalize">{{ data.row.name }}</td>
                                                    <td class="">{{ data.row.guard_name }}</td>
                                                    <td class="">{{ data.row.created_at }}</td>
                                                    <td class="">{{ data.row.updated_at }}</td>
                                                </template>
                                            </multi-data-select>
                                            <div v-text="form.errors.get('permissions')" class="invalid-feedback"/>
                                        </div>
                                    </div>
                                    <div class="text-center mb-5">
                                        <button @click="create" :disabled="form.loading" class="btn btn-primary"><edit-icon class="mr-2"/>UPDATE</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</template>

<script>
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    import Form from "../../core/forms/form";
    import { EditIcon } from 'vue-feather-icons'
    import MultiDataSelect from "../core/MultiDataSelect";
    export default {
        components: {
            MultiDataSelect,
            EditIcon
        },
        name: "users-edit",
        mounted : function() {

            this.init();
        },
        data : function () {
            return {
                initLoading : true,
                formLoading :  false,
                form : new Form({
                    name : '',
                    permissions : [],
                } , {
                    permissions : []
                }),
                roles : [],
                permissions : [],
                message : {
                    success : true,
                    text : ''
                },
            }
        },
        methods : {
            create :  function () {
                this.initLoading = true;
                this.message.text = "";
                this.form.submit(`/roles/${this.$route.params.id}/edit`).then((response) => {

                }).catch((error) => {

                }).finally(() => {
                    this.initLoading = false;
                });

            },
            init : function () {
                this.initLoading = true;
                // Get Roles and Permissions
                window.axios.get(`${window.location.origin}/roles/${this.$route.params.id}/edit`).then((response) => {
                    this.permissions = response.data.body.all;
                    // Form Fields
                    this.form.name =  response.data.body.role.name;

                    this.form.permissions =  response.data.body.permissions.map((e) => e.id );
                    this.form.storage.permissions =  response.data.body.permissions;

                }).catch((error) => {

                }).finally(() => {
                    this.initLoading = false;
                });
            }
        }
    }
</script>

<style scoped>

</style>
