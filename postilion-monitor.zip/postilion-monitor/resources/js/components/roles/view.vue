<!--suppress JSUnresolvedVariable -->
<template>
    <div class="filemgr-content-body">
        <div style="min-height:100%" :class="['dimmer' , initLoading ? 'active' : '']">
            <div class="loader"></div>
            <div   class="dimmer-content">
               <div class="container pd-30">
                   <div class="mg-b-25 mg-t-25 d-flex align-items-center">
                       <h6 class="mr-auto mb-0">Details</h6>
                   </div>

                   <div class="row">
                       <div class="col-12">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Name
                           </label>
                           <p class="mg-b-0">
                               {{ role.name }}
                           </p>
                       </div>
                   </div>
                   <h6 class="mg-b-25 mg-t-25">Account Details</h6>
                   <div class="row">
                       <div class="col-6">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Created
                           </label>
                           <p class="mg-b-0">
                               {{ role.created_at }}
                           </p>
                       </div>
                       <div class="col-6">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Last Update
                           </label>
                           <p class="mg-b-0">
                               {{ role.updated_at }}
                           </p>
                       </div>
                   </div>
               </div>
            </div>
        </div>
    </div>

</template>

<script>
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    import {
          ZapIcon , ZapOffIcon
    } from "vue-feather-icons"
    export default {
        components : {
            ZapIcon , ZapOffIcon
        },
        name: "roles-view",
        mounted : function() {

            this.init();
        },
        data : function () {
            return {
                initLoading : true,
                role : {},
                permissions : []
            }
        },
        methods : {

            init : function () {
                this.initLoading = true;
                // Get Roles and Permissions
                // noinspection JSUnresolvedFunction
                window.axios.get(`${window.location.origin}/roles/${this.$route.params.id}/view`).then((response) => {
                    this.role = response.data.body.role;
                    this.permissions = response.data.body.permissions;
                }).catch((error) => {

                }).finally(() => {
                    this.initLoading = false;
                });
            }
        }
    }
</script>

<style scoped>

</style>
