<template>
    <div class="filemgr-content">
        <div class="filemgr-content-header px-5">
            <button @click="init" class="btn btn-white rounded-0 ml-auto btn-sm px-5">Refresh</button>
        </div>
        <div class="filemgr-content-body p-5">
            <div :class="['dimmer' , initLoading ? 'active' : '' ]">
                <div class="loader"></div>
                <div class="dimmer-content">
                    <div class="d-flex  mb-5 align-items-center">
                        <h4 class="mr-auto mb-0">SAF Aborting</h4>
                        <div class="border-bottom ml-3 flex-fill"></div>
                    </div>
                    <div class="row mb-5">
                        <div class="col-lg-3">
                            <div style="height: 95px" class="card card-body text-center rounded-0">
                                <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Total Blocked</h6>
                                <div class="">
                                    <h2 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">{{  blocks.total }}</h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div style="height: 95px" class="card card-body text-center rounded-0">
                                <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Last Check</h6>
                                <div class="">
                                    <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">{{ blocks.last_check }}</h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div style="height: 95px" class="card card-body text-center rounded-0">
                                <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Aborted</h6>
                                <div class="">
                                    <h2 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">{{ blocks.aborted }}</h2>
                                </div>
                            </div>
                        </div>
                        <div style="height: 95px" class="col-lg-3">
                            <div class="card card-body text-center rounded-0">
                                <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Pending Posted</h6>
                                <div class="">
                                    <h2 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">{{ blocks.pending_post }}</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-5">
                        <div class="col-lg-12">
                            <div class="mb-4">
                                <div class="row justify-content-end">
                                    <div class="col-lg-4">
                                        <div class="input-group">
                                            <input v-model="tran" type="text" class="form-control rounded-0" placeholder="Tran nr" >
                                            <div class="input-group-append rounded-0">
                                                <button @click="manual" class="btn btn-outline-light rounded-0" type="button" id="button-addon2">Abort</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="blocking" style="height: 400px;;overflow-y: scroll" class="card rounded-0">
                                <div class="card-header border-bottom-0">
                                    <div class="">
                                        <h5 class="mg-b-0">Blocking Transactions</h5>
                                    </div>
                                </div><!-- card-header -->
                                <div class="table-responsive tx-12">
                                    <table class="table table-dashboard mg-b-0 table-vcenter">
                                        <thead>
                                        <tr>
                                            <th>Tran Nr</th>
                                            <th>Nodes</th>
                                            <th>Type</th>
                                            <th>Terminal</th>
                                            <th>Duration</th>
                                            <th></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr v-for="item in blocking">
                                            <td class="">
                                                <span class="text-primary">#{{ item.tran_nr }}</span><br>
                                                <span class="text-muted">{{ item.in_req }}</span>
                                            </td>
                                            <td>
                                                <div>Src : {{ item.source_node }}</div>
                                                <div>Snk : {{ item.sink_node }}</div>
                                            </td>
                                            <td>
                                                <div>Typ : {{ item.tran_type }}</div>
                                                <div>Term : {{ item.card_acceptor_term_id }}</div>
                                            </td>
                                            <td>
                                                <div>Cde : {{ item.rsp_code_req_rsp }}</div>
                                                <div>Ste : {{ item.state }}</div>
                                            </td>
                                            <td class="text-muted">
                                                <span class="text-muted">Monitor</span> :  {{ item.duration }} minutes <br>
                                                <span class="text-muted">Postilion</span>  :  {{ item.postilion_duration }}
                                            </td>
                                            <td class="">
                                                <button @click="abort(item.tran_nr)" class="bt btn btn-white btn-sm">Abort</button>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-5">
                        <div class="col-lg-5">
                            <div id="aborted"  style="height: 400px;;overflow-y: scroll" class="card rounded-0">
                                <div class="card-header border-bottom-0">
                                    <div class="d-flex align-items-center">
                                        <h5 class="mg-b-0 mr-auto">Aborted Transactions</h5>
                                        <button @click="generate" class="btn btn-sm btn-white rounded-0">Generate</button>
                                    </div>
                                </div><!-- card-header -->
                                <div class="table-responsive tx-12">
                                    <table class="table table-dashboard mg-b-0 table-vcenter">
                                        <thead>
                                        <tr>
                                            <th>Tran Nr</th>
                                            <th>Time</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr v-for="item in aborted">
                                            <td class="">
                                                <span class="text-primary">#{{ item.tran_nr }}</span><br>
                                                <div>Type : {{ item.tran_type }} : {{ item.sink_node }} </div>
                                            </td>
                                            <td>
                                                In req : <span class="text-muted">{{ item.in_req }}</span><br>
                                                Aborted : <span class="text-muted">{{ item.created_at }}</span>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div id="reports"  style="height: 400px;overflow-y: scroll" class="card rounded-0">
                                <div class="card-header border-bottom-0">
                                    <div class="">
                                        <h5 class="mg-b-0">Reports</h5>
                                    </div>
                                </div><!-- card-header -->
                                <div class="table-responsive tx-12">
                                    <table class="table table-dashboard mg-b-0 table-vcenter">
                                        <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Date</th>
                                            <th/>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr v-for="item in reports">
                                            <td class="">
                                                <span class="text-primary">#{{ item.id }}</span><br>
                                            </td>
                                            <td class="">
                                                <span class="text-muted">{{ item.created_at }}</span><br>
                                            </td>
                                            <td>
                                                <a target="_blank" :href="`/transactions/${item.id}/download`" class="btn btn-sm btn-white">Download</a>
                                            </td>

                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div  class="col-lg-4">
                            <div id="logs" style="height: 400px;overflow-y: scroll"  class="card rounded-0">
                                <div class="card-header">
                                    <div class="">
                                        <h5 class="mg-b-0">Logs</h5>
                                    </div>
                                </div>
                                <div  class="card-body pd-20">
                                    <ul class="activity tx-13">
                                        <li v-for="item in logs" class="activity-item">
                                            <div class="activity-icon bg-primary-light tx-primary">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-clock"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                                            </div>
                                            <div class="activity-body">
                                                <strong class="mg-b-2">{{ item.log }}</strong><br>
                                                <span class="text-muted">{{ item.created_at }}</span><br>
                                                <small class="tx-color-03">{{ item.last_update }}</small>
                                            </div><!-- activity-body -->
                                        </li><!-- activity-item -->
                                    </ul><!-- activity -->
                                </div><!-- card-body -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</template>

<script>
    import {PlusIcon , EyeIcon , RefreshCwIcon} from "vue-feather-icons";
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    export default {
        name: "roles-index",
        components: { PlusIcon , EyeIcon , RefreshCwIcon },
        mounted : function () {
            this.init();

        },
        data :  function(){
            return {
                blocks : {
                    total : 0,
                    last_check : 0,
                    aborted : 0,
                    pending_post : 0,
                },
                logs  : [],
                blocking  : [],
                aborted : [],
                reports : [],
                initLoading : true,
                tran : '',
            }
        },
        methods : {
            manual : function(){
                this.abort(this.tran);
            },
            generate : function(){
                window.action('generate' , `Report` , `${window.location.origin}/transactions/generate`)
                    .then((res) => {
                        this.init();
                    });
            },
            abort : function(tran){
                window.action('abort' , `Transaction #${tran}` , `${window.location.origin}/transactions/abort/${tran}`)
                .then((res) => {
                    this.init();
                });
            },
            init : function () {
                this.initLoading = true;
                window.axios.get(`${window.location.origin}/transactions/saf`).then((response) => {
                    this.blocks = response.data.body.blocks;
                    this.blocks.total = response.data.body.blocking.length;
                    this.aborted = response.data.body.aborted;
                    this.blocks.aborted = response.data.body.aborted.length;
                    this.blocking = response.data.body.blocking;
                    this.reports = response.data.body.reports;
                    this.logs = response.data.body.logs;

                }).finally(() => {
                    this.initLoading = false;
                });
            }
        }
    }
</script>


