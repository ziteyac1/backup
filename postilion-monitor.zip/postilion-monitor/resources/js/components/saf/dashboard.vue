<template>
    <div class="filemgr-content">
        <div class="filemgr-content-header px-5">
            <button @click="init" class="btn btn-white  ml-auto btn-sm px-5">Refresh</button>
        </div>
        <div class="filemgr-content-body p-5">
            <div :class="['dimmer' , initLoading ? 'active' : '' ]">
                <div class="loader"></div>
                <div class="dimmer-content">
                    <div class="d-flex  mb-5 align-items-center">
                        <h4 class="mr-auto mb-0">Dashboard</h4>
                        <div class="border-bottom ml-3 flex-fill"></div>
                    </div>
                    <div class="row mb-5">
                        <div class="col-lg-3">
                            <div style="height: 95px" class="card card-body text-center ">
                                <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Total SAF</h6>
                                <div class="">
                                    <h2 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">{{  blocks.total }}</h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div style="height: 95px" class="card card-body text-center ">
                                <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Last Check</h6>
                                <div class="">
                                    <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">{{ blocks.posting }}</h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div style="height: 95px" class="card card-body text-center ">
                                <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Aborted Transactions</h6>
                                <div class="">
                                    <h2 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">{{ blocks.aborted }}</h2>
                                </div>
                            </div>
                        </div>
                        <div style="height: 95px" class="col-lg-3">
                            <div class="card card-body text-center ">
                                <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Blocking Transactions</h6>
                                <div class="">
                                    <h2 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">{{ blocks.blocking }}</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex  mb-5 align-items-center">
                        <h4 class="mr-auto mb-0">Summary</h4>
                        <div class="border-bottom ml-3 flex-fill"></div>
                    </div>
                    <div class="row mb-5">
                        <router-link :key="`report-view${item.id}`" :to="`/transactions/reports/${item.report_id}/view`" v-for="item in reports" class="col-lg-3">
                            <div :class="['card card-body mt-2' , item.count > 5000 ? 'bg-danger text-white' : '' ,  item.count < 1 ? 'bg-success text-white' : '']">
                                <h6 :class="['tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8' , item.count > 5000 ? 'text-white' : '',  item.count < 1 ? 'bg-success text-white' : '' ]">{{ item.report.name }}</h6>
                                <div :class="['' , item.count > 5000 ? 'text-white' : '' ,  item.count < 1 ? 'bg-success text-white' : '']">
                                    <h3 :class="['tx-normal mb-0' , item.count > 5000 ? 'text-white' : '',  item.count < 1 ? 'bg-success text-white' : '']">{{ item.count }}</h3>
                                    <p :class="['tx-11 tx-color-03 mg-b-0' , item.count > 5000 ? 'text-white' : '' ,  item.count < 1 ? 'bg-success text-white' : '']">
                                        {{ item.report.description }}
                                    </p>
                                    <p :class="['tx-11 mb-0 mt-1' , item.count > 5000 || item.count < 1 ? 'text-white' : 'text-primary']">{{ item.stamp }}</p>
                                </div>
                            </div>
                        </router-link>
                    </div>
                    <div class="d-flex  mb-5 align-items-center">
                        <h4 class="mr-auto mb-0">Metrics</h4>
                        <div class="border-bottom ml-3 flex-fill"></div>
                    </div>
                    <div class="row mb-5">
                        <div class="col-lg-12">
                            <div class="card ">
                                <div class="card-header py-3">
                                    <div>
                                        <h6 class="mg-b-5 text-center">Store and forward Metrics</h6>
                                    </div>
                                </div><!-- card-header -->
                                <div class="row align-items-center mx-0">
                                    <div class="col-lg-9">
                                        <div style="height: 500px">
                                            <canvas id="chartBar1"/>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 px-0">
                                        <div class="">
                                            <div v-for="(item , i) in side" :class="['p-3 py-5 border-left' , i !== 0 ? 'border-top' : '']">
                                                <h6 class="tx-spacing-1 tx-color-02 tx-semibold mb-2 text-center">{{ item.sink_node }}</h6>
                                                <h2 class="tx-normal tx-rubik mg-b-0 text-center">{{ item.count }}</h2>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row ">
                        <div  class="col-lg-4">
                            <div id="logs" style="height: 400px"  class="card ">
                                <div class="card-header">
                                    <div class="">
                                        <h5 class="mg-b-0">Logs</h5>
                                    </div>
                                </div>
                                <div  class="card-body pd-20">
                                    <ul class="activity tx-13">
                                        <li v-for="item in logs" class="activity-item">
                                            <div class="activity-icon bg-primary-light tx-primary">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-clock"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                                            </div>
                                            <div class="activity-body">
                                                <strong class="mg-b-2">{{ item.log }}</strong><br>
                                                <span class="text-muted">{{ item.created_at }}</span><br>
                                                <small class="tx-color-03">{{ item.last_update }}</small>
                                            </div><!-- activity-body -->
                                        </li><!-- activity-item -->
                                    </ul><!-- activity -->
                                </div><!-- card-body -->
                            </div>
                        </div>
                        <div class="col-lg-8">
                            <div id="blocking" style="height: 400px" class="card ">
                                <div class="card-header border-bottom-0">
                                    <div class="">
                                        <h5 class="mg-b-0">Blocking Transactions</h5>
                                    </div>
                                </div><!-- card-header -->
                                <div class="table-responsive tx-12">
                                    <table class="table table-dashboard mg-b-0 table-vcenter">
                                        <thead>
                                        <tr>
                                            <th>Tran Nr</th>
                                            <th>Nodes</th>
                                            <th>Type</th>
                                            <th>Terminal</th>
                                            <th>Duration</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr v-for="item in blocking">
                                            <td class="">
                                                <span class="text-primary">#{{ item.tran_nr }}</span><br>
                                                <span class="text-muted">{{ item.in_req }}</span>
                                            </td>
                                            <td>
                                                <div>Src : {{ item.source_node }}</div>
                                                <div>Snk : {{ item.sink_node }}</div>
                                            </td>
                                            <td>
                                                <div>Typ : {{ item.tran_type }}</div>
                                                <div>Term : {{ item.card_acceptor_term_id }}</div>
                                            </td>
                                            <td>
                                                <div>Cde : {{ item.rsp_code_req_rsp }}</div>
                                                <div>Ste : {{ item.state }}</div>
                                            </td>
                                            <td class="text-muted">
                                               <span class="text-muted">Monitor</span> :  {{ item.duration }} minutes <br>
                                                <span class="text-muted">Postilion</span>  :  {{ item.postilion_duration }}
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import {PlusIcon , EyeIcon , RefreshCwIcon} from "vue-feather-icons";
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    import Chart  from "chart.js";
    export default {
        name: "roles-index",
        components: { PlusIcon , EyeIcon , RefreshCwIcon },
        mounted : function () {
            this.init();

            new PerfectScrollbar('#blocking', {
                suppressScrollX: true
            });
            new PerfectScrollbar('#logs', {
                suppressScrollX: true
            });

            this.mountChart();
        },
        data :  function(){
            return {
                chart : null,
                blocks : {
                    total : 0,
                    aborted : 0,
                    blocking : 0,
                    posting : 0,
                },
                side : [],
                logs  : [],
                blocking  : [],
                labels : [],
                reports : [],
                datasets : [],
                initLoading : true,
            }
        },
        methods : {
            mountChart : function(){
                this.chart  = new Chart( document.getElementById('chartBar1').getContext('2d'), {
                    type: 'bar',
                    data: {
                        labels: this.labels,
                        datasets: this.datasets,
                    },
                    options: {
                        responsive  : true,
                        animation: {
                            duration: 0
                        },
                        maintainAspectRatio: true,
                        legend: {
                            display: false,
                            labels: {
                                display: false
                            }
                        },
                        scales: {
                            xAxes: [{
                                barPercentage: 1,
                                display: true,
                                gridLines: {
                                    color: '#ebeef3',
                                    display : false
                                },
                                ticks: {
                                    fontColor: '#8392a5',
                                    fontSize: 10,
                                    maxRotation: 45,
                                    minRotation: 45,
                                    display :false
                                }
                            }],
                            yAxes: [{
                                gridLines: {
                                    color: '#ebeef3',
                                    display : true,
                                },
                                ticks: {
                                    fontColor: '#8392a5',
                                    fontSize: 10,
                                    min : 0,
                                }
                            }]
                        }
                    }
                });
                this.chart.update();
            },
            init : function () {
                this.initLoading = true;
                window.axios.get(`${window.location.origin}/transactions/dashboard`).then((response) => {
                    this.blocks = response.data.body.blocks;
                    this.blocks.blocking = response.data.body.blocking.length;
                    this.side = response.data.body.side;
                    this.logs = response.data.body.logs;
                    this.blocking = response.data.body.blocking;
                    this.reports = response.data.body.reports;
                    this.datasets = response.data.body.chart.datasets;
                    this.labels = response.data.body.labels;

                    this.chart.data.labels = [];
                    this.chart.data.datasets = [];

                    response.data.body.chart.labels.forEach((e) => {
                        this.chart.data.labels.push(e);
                    });

                    response.data.body.chart.datasets.forEach((e) => {
                        this.chart.data.datasets.push(e);
                    });

                    this.chart.update();

                    // this.mountChart();

                }).finally(() => {
                    this.initLoading = false;
                });
            }
        }
    }
</script>


