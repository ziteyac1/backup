<template>
    <data-table url="/transactions/reports" filter="false" prefix="reports">
        <template slot="create-link">
            <router-link to="/transactions/reports/create" :class="['btn btn-sm pd-x-15 btn-white btn-uppercase mr-3']">
                <plus-icon size="24" /> New Report </router-link>
        </template>
        <template slot="table-header">
            <th/>
                <th>Name</th>
                <th>Description</th>
                <th>Date</th>
            <th/>
        </template>
        <!--suppress JSUnusedLocalSymbols -->
        <template slot="table-row" slot-scope="data">
            <td class="text-primary">#{{ data.row.id }}</td>
            <td class="">{{ data.row.name }}</td>
            <td class="">{{ data.row.description }}</td>
            <td class="">{{ data.row.created_at }}</td>
            <td class="text-center">
                <router-link :to="`/transactions/reports/${data.row.id}/view`" class="btn btn-sm pd-x-15 btn-white btn-icon">
                   <eye-icon size="24"/>
                </router-link>
            </td>
        </template>
    </data-table>
</template>

<script>
    import DataTable from "../core/DataTable";
    import {PlusIcon , EyeIcon} from "vue-feather-icons";
    export default {
        name: "saf-reports-index",
        components: {DataTable , PlusIcon , EyeIcon }
    }
</script>

<style scoped>

</style>
