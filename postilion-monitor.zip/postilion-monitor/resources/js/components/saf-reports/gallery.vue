<template>
    <gallery name="Gallery" :id="$route.params.id" type="building"/>
</template>

<script>
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    import Timeline from "../core/Timeline";
    import Gallery from "../core/Gallery";
    export default {
        components: {
            Gallery
        },
        name: "users-activity",
        mounted : function() {

        }
    }
</script>

<style scoped>

</style>
