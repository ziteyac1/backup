<template>
    <documents name="Documents" :id="$route.params.id" type="building"/>
</template>

<script>
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    import Documents from "../core/Documents";
    export default {
        components: {
            Documents
        },
        name: "users-activity",
        mounted : function() {

        }
    }
</script>

<style scoped>

</style>
