<!--suppress JSUnresolvedVariable -->
<template>
    <div class="filemgr-content-body">
        <div style="min-height:100%" :class="['dimmer' , initLoading ? 'active' : '']">
            <div class="loader"></div>
            <div   class="dimmer-content">
               <div class="container pd-30">
                   <div class="d-flex  mb-5 align-items-center">
                       <h4 class="mr-auto mb-0">Metrics</h4>
                       <div class="border-bottom ml-3 flex-fill"></div>
                   </div>
                   <div class="row mg-t-25 mb-5">
                       <div class="col-lg-12 mb-4 row">
                           <div v-for="item in top" class="col-lg-3">
                               <div class="card card-body">
                                   <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">{{ item.stamp }}</h6>
                                   <div class="">
                                       <h3 class="tx-normal mb-0">{{ item.count }}</h3>
                                   </div>
                               </div>
                           </div>
                       </div>
                        <div class="col-lg-12">
                            <div style="">
                                <canvas id="chartBar1"/>
                            </div>
                        </div>
                   </div>
                   <div class="d-flex  mb-5 align-items-center">
                       <h4 class="mr-auto mb-0">Details</h4>
                       <div class="border-bottom ml-3 flex-fill"></div>
                   </div>
                   <div class="row">
                       <div class="col-4">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Name
                           </label>
                           <p class="mg-b-0">
                               {{ report.name }}
                           </p>
                       </div>
                       <div class="col-4">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Description
                           </label>
                           <p class="mg-b-0">
                               {{ report.description }}
                           </p>
                       </div>
                       <div class="col-lg-4">
                       </div>
                   </div>
                   <div class="row mg-t-25 mb-5">
                       <div class="col-4">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Order Column
                           </label>
                           <p class="mg-b-0">
                               {{ report.order_column }}
                           </p>
                       </div>
                       <div class="col-4">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Order Direction
                           </label>
                           <p class="mg-b-0">
                               {{ report.order_direction }}
                           </p>
                       </div>
                   </div>
                   <div class="d-flex  mb-5 align-items-center">
                       <h4 class="mr-auto mb-0">Parameters</h4>
                       <div class="border-bottom ml-3 flex-fill"></div>
                   </div>
                   <div class="row mg-t-25">
                       <div class="col-12">
                           <div>
                               <table class="table table-dashboard mg-b-0 table-vcenter">
                                   <thead>
                                   <tr>
                                       <th style="width: 33%">Field</th>
                                       <th style="width: 33%">Sign</th>
                                       <th style="width: 33%">Default Value</th>
                                   </tr>
                                   </thead>
                                   <tbody>
                                   <tr :key="`form-index-${index}`" v-for="(item, index) in report.parameters">
                                       <td>{{ item.field }}</td>
                                       <td>{{ item.sign }}</td>
                                       <td>{{ item.value }}</td>
                                   </tr>
                                   </tbody>
                               </table>
                           </div>
                       </div>
                   </div>

               </div>
            </div>
        </div>
    </div>
</template>

<script>
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    import {
          ZapIcon , ZapOffIcon , EyeIcon
    } from "vue-feather-icons";
    import Chart from "chart.js";
    export default {
        components : {
            ZapIcon , ZapOffIcon , EyeIcon
        },
        name: "users-view",
        mounted : function() {

            this.init();
            this.mountChart();
        },
        data : function () {
            return {
                chart : null,
                datasets : [],
                labels : [],
                top : [],
                initLoading : true,
                report : {
                    parameters : []
                }
            }
        },
        methods : {
            mountChart : function(){
                this.chart  = new Chart( document.getElementById('chartBar1').getContext('2d'), {
                    type: 'bar',
                    data: {
                        labels: this.labels,
                        datasets: this.datasets,
                    },
                    options: {
                        responsive  : true,
                        animation: {
                            duration: 0
                        },
                        maintainAspectRatio: true,
                        legend: {
                            display: false,
                            labels: {
                                display: false
                            }
                        },
                        scales: {
                            xAxes: [{
                                barPercentage: 1,
                                display: true,
                                gridLines: {
                                    color: '#ebeef3',
                                    display : false
                                },
                                ticks: {
                                    fontColor: '#8392a5',
                                    fontSize: 10,
                                    maxRotation: 90,
                                    minRotation: 90,
				    display : false
                                }
                            }],
                            yAxes: [{
                                gridLines: {
                                    color: '#ebeef3',
                                    display : true,
                                },
                                ticks: {
                                    fontColor: '#8392a5',
                                    fontSize: 10,
                                    min : 0,
                                }
                            }]
                        }
                    }
                });
                this.chart.update();
            },
            init : function () {
                this.initLoading = true;
                window.axios.get(`${window.location.origin}/transactions/reports/${this.$route.params.id}/view`).then((response) => {
                    this.report = response.data.body.report;
                    this.top = response.data.body.top;

                    this.datasets = response.data.body.chart.datasets;
                    this.labels = response.data.body.labels;

                    this.chart.data.labels = [];
                    this.chart.data.datasets = [];

                    response.data.body.chart.labels.forEach((e) => {
                        this.chart.data.labels.push(e);
                    });

                    response.data.body.chart.datasets.forEach((e) => {
                        this.chart.data.datasets.push(e);
                    });

                    this.chart.update();

                }).finally(() => {
                    this.initLoading = false;
                });
            },


        }
    }
</script>

<style scoped>
    .table-dashboard tbody tr td {
        padding-bottom: 20px ;
        padding-top: 20px ;
    }
    .table-dashboard thead tr th {
        padding-bottom: 10px ;
        padding-top: 10px ;
    }
</style>
