<!--suppress JSUnresolvedVariable -->
<template>
    <div class="filemgr-content-body">
        <div style="min-height:100%" :class="['dimmer' , initLoading ? 'active' : '']">
            <div class="loader"></div>
            <div   class="dimmer-content">
               <div class="container pd-30">
                   <div class="mg-b-25">
                       <div class="d-flex align-items-center">
                           <h6 class="mr-auto mb-0">Overview</h6>
                       </div>
                       <div class="row mt-4 mb-5">
                           <div style="min-height:102px" class="col-lg-5">
                               <div class="text-center border rounded p-3">
                                   <h6 class="text-muted">Count</h6>
                                   <h2> {{ overview.count }} </h2>
                               </div>
                           </div>

                           <div style="min-height:102px" class="col-lg-7">
                               <div class="text-center border rounded p-3">
                                   <h6 class="text-muted">Sum</h6>
                                   <h2> {{ overview.sum }} </h2>
                               </div>
                           </div>
                       </div>
                   </div>
                   <div class="mg-b-25 d-flex align-items-center">
                       <h6 class="mr-auto mb-0">Date Parameters</h6>
                       <button @click="init" class="btn btn-white mr-2">Refresh</button>
                       <button @click="request" class="btn btn-white">Request Report</button>
                   </div>
                   <div class="row">
                       <div class="col-lg-6">
                           <div class="form-group">
                               <label>Start</label>
                               <input v-model="start" placeholder="2018-02-02 14:00:00.253" type="text" class="form-control">
                           </div>
                       </div>
                       <div class="col-lg-6">
                           <div class="form-group">
                               <label>End</label>
                               <input v-model="end"  placeholder="2018-02-02 14:00:00.253" type="text" class="form-control">
                           </div>
                       </div>
                   </div>

                   <div class="mg-b-25 mg-t-25 d-flex align-items-center">
                       <h6 class="mr-auto mb-0">Other Parameters</h6>
                   </div>
                   <div class="row mg-t-25">
                       <div class="col-12">
                           <div>
                               <table class="table table-dashboard mg-b-0 table-vcenter">
                                   <thead>
                                   <tr>
                                       <th style="width: 33%">Field</th>
                                       <th style="width: 33%">Sign</th>
                                       <th style="width: 33%">Default Value</th>
                                   </tr>
                                   </thead>
                                   <tbody>
                                   <tr :key="`form-index-${index}`" v-for="(item, index) in report.parameters">
                                       <td>{{ item.field }}</td>
                                       <td>{{ item.sign }}</td>
                                       <td>{{ item.value }}</td>
                                   </tr>
                                   </tbody>
                               </table>
                           </div>
                       </div>
                   </div>
               </div>
            </div>
        </div>
    </div>
</template>

<script>
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    import {
          ZapIcon , ZapOffIcon , EyeIcon
    } from "vue-feather-icons";
    export default {
        components : {
            ZapIcon , ZapOffIcon , EyeIcon
        },
        name: "users-view",
        mounted : function() {

            this.init();
        },
        data : function () {
            return {
                start : '',
                end : '',
                initLoading : true,
                report : {
                    parameters : []
                },
                overview : {
                    count : 0,
                    sum : 0,
                }
            }
        },
        methods : {
            init : function () {
                this.initLoading = true;
                window.axios.get(`${window.location.origin}/transactions/reports/${this.$route.params.id}/run?start=${this.start}&end=${this.end}`).then((response) => {
                    this.report = response.data.body.report;
                    this.overview = response.data.body.overview;
                }).finally(() => {
                    this.initLoading = false;
                });
            },
            request : function () {
                this.initLoading = true;
                window.axios.get(`${window.location.origin}/transactions/reports/${this.$route.params.id}/request?start=${this.start}&end=${this.end}`).then((response) => {
                    window.Swal.fire({
                        icon: 'success',
                        title: response.data.message,
                        showConfirmButton: false,
                        padding : '20px',
                        timer: 2000
                    }).then((e) => {
                        this.$router.push('/transactions/requests');
                    }).bind(this);

                }).finally(() => {
                    this.initLoading = false;
                });
            }
        }
    }
</script>

<style scoped>
    .table-dashboard tbody tr td {
        padding-bottom: 20px ;
        padding-top: 20px ;
    }
    .table-dashboard thead tr th {
        padding-bottom: 10px ;
        padding-top: 10px ;
    }
</style>
