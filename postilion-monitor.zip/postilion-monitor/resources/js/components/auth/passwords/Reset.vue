<template>
    <div class="sign-wrapper mg-lg-l-50 mg-xl-l-60 pt-5">
        <form @submit.prevent="reset" class="wd-100p">
            <h3 class="tx-color-01 mg-b-5">Reset Password</h3>
            <div v-if="messagePresent" :class="['tx-12 alert text-center' ,  message.success ? 'alert-success' : 'alert-danger' ]" role="alert">
                {{ message.text }}
            </div>
            <p v-if="!messagePresent" class="tx-color-03 tx-16 mg-b-40">Enter your email address and new password to change password</p>

            <div class="form-group">
                <label for="email">Email address</label>
                <input type="email" id="email" name="email" v-model="form.email" :class="[ 'form-control' , form.errors.get('email') ? 'is-invalid' : '' ]" placeholder="yourname@yourmail.com">
                <div v-text="form.errors.get('email')" class="invalid-feedback"/>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" v-model="form.password" :class="[ 'form-control' , form.errors.get('password') ? 'is-invalid' : '' ]" placeholder="">
                <div v-text="form.errors.get('password')" class="invalid-feedback"/>
            </div>

            <div class="form-group">
                <label for="password_confirmation">Password Confirm</label>
                <input type="password" id="password_confirmation" name="password_confirmation" v-model="form.password_confirmation" :class="[ 'form-control' , form.errors.get('password_confirmation') ? 'is-invalid' : '' ]" placeholder="">
                <div v-text="form.errors.get('password_confirmation')" class="invalid-feedback"/>
            </div>

            <button :class="['btn btn-brand-02 btn-block' , form.loading ? 'btn-loading' : '' ]">Send Password Reset Link</button>
        </form>
    </div>
</template>

<script>
    import Form from "../../../core/forms/form";

    export default {
        props : ['token','email'],
        name: "reset",
        data : function(){
            return {
                form :  new Form({
                    email : this.email,
                    token : this.token,
                    password : "",
                    password_confirmation : ""
                }),
                message : {
                    success : true,
                    text : ''
                }
            }
        },
        methods : {
          reset : function () {

              this.message.text = "";
              this.form.submit('/password/reset').then((e) => {

                  console.log(e);
                  this.message.success = true;
                  this.message.text = `${e.data.message}`;

                  // Redirect to home

                  setTimeout(function () {
                      window.location = `${window.location.origin}/home`;
                  } , 1000 );


              }).catch((e) => {

                  console.log(e.response.data);
                  if(!e.response.data.errors) {
                      this.message.success = false;
                      this.message.text = e.response.data.message;
                  }

              });

          }
        },
        computed : {
            messagePresent : function () {
                return (this.message.text !== '');
            }
        }

    }
</script>

<style scoped>

</style>
