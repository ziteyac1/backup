<template>
    <div class="sign-wrapper mg-lg-l-50 mg-xl-l-60 pt-5">
        <form @submit.prevent="login" class="wd-100p">
            <h3 class="tx-color-01 mg-b-5">Sign In</h3>

            <div v-if="messagePresent" :class="['tx-12 alert text-center' ,  message.success ? 'alert-success' : 'alert-danger' ]" role="alert">
                {{ message.text }}
            </div>
            <p v-if="!messagePresent" class="tx-color-03 tx-16 mg-b-40">Welcome back! Please signin to continue.</p>
            <div class="form-group">
                <label for="email">Email address</label>
                <input type="email" id="email" name="email" v-model="form.email" :class="[ 'form-control' , form.errors.get('email') ? 'is-invalid' : '' ]" placeholder="yourname@yourmail.com">
                <div v-text="form.errors.get('email')" class="invalid-feedback"/>
            </div>
            <div class="form-group">
                <div class="d-flex justify-content-between mg-b-5">
                    <label for="password" class="mg-b-0-f">Password</label>
                </div>
                <input id="password" name="password" v-model="form.password" type="password" class="form-control" placeholder="Enter your password">
                <div v-text="form.errors.get('password')" class="invalid-feedback"/>
            </div>
            <button :class="['btn btn-brand-02 btn-block' , loading ? 'btn-loading' : '' ]">Sign In</button>

        </form>
    </div>
</template>

<script>
    import Form from "../../core/forms/form";
    export default {
        name: "login",
        data : function () {
            return {
                loading : false,
                message : {
                    success : true,
                    text : ''
                },
                form : new Form({
                    email : "",
                    password : ""
                })
            }
        },
        methods : {
            login : function () {
                this.message.text = "";
                this.loading = true;
                this.form.submit('/login').then((e) => {

                    console.log(e);
                    this.message.success = true;

                    // Redirecting

                    this.message.text = `${e.data.message}`;
                    setTimeout(function () {
                        window.location = `${window.location.origin}/home`;
                    } , 1000 );

                }).catch((e) => {

                    this.loading = false;
                    console.log(e.response.data);
                    if(!e.response.data.errors){
                        this.message.success = false;
                        this.message.text = e.response.data.message;
                    }

                });
            }
        },
        computed : {
            messagePresent : function () {
                return (this.message.text !== '');
            }
        }
    }
</script>

<style scoped>

</style>
