<!--suppress JSUnresolvedVariable -->
<template>
    <div class="filemgr-content-body">
        <div style="min-height:100%" :class="['dimmer' , initLoading ? 'active' : '']">
            <div class="loader"></div>
            <div   class="dimmer-content">
               <div class="container pd-30">
                   <div class="mg-b-25 mg-t-25 d-flex align-items-center">
                       <h6 class="mr-auto mb-0">Details</h6>
                       <button @click="init" class="btn btn-white btn-sm btn-uppercase mr-3">
                           Refresh
                       </button>
                       <button v-if="!request.aborted_at" @click="abort" class="btn btn-white btn-sm btn-uppercase mr-3">
                           Abort
                       </button>
                       <a target="_blank" class="btn btn-white btn-sm btn-uppercase" :href="`/transactions/requests/${request.id}/download`">
                           Download
                       </a>
                   </div>
                   <div class="row mb-4">
                       <div class="col-4">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Start
                           </label>
                           <p class="mg-b-0">
                               {{ request.start }}
                           </p>
                       </div>
                       <div class="col-4">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               End
                           </label>
                           <p class="mg-b-0">
                               {{ request.end }}
                           </p>
                       </div>
                       <div class="col-4">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               State
                           </label>
                           <p class="mg-b-0">
                               {{ request.state }}
                           </p>
                       </div>
                   </div>
                   <div class="row mt-4 mb-5">
                       <div style="min-height:102px" class="col-lg-5">
                           <div class="text-center border rounded p-3">
                               <h6 class="text-muted">Count</h6>
                               <h2> {{ request.count }} </h2>
                           </div>
                       </div>
                       <div style="min-height:102px" class="col-lg-7">
                           <div class="text-center border rounded p-3">
                               <h6 class="text-muted">Sum</h6>
                               <h2> {{ request.sum }} </h2>
                           </div>
                       </div>
                   </div>
                   <div class="row mt-4 mb-5">
                       <div style="min-height:102px" class="col-lg-5">
                           <div class="text-center border rounded p-3">
                               <h6 class="text-muted">Aborted</h6>
                               <h2> {{ request.aborted }} </h2>
                           </div>
                       </div>
                       <div style="min-height:102px" class="col-lg-7">
                           <div class="text-center border rounded p-3">
                               <h6 class="text-muted">Date</h6>
                               <h2> {{ request.aborted_at }} </h2>
                           </div>
                       </div>
                   </div>
                   <div class="row">
                       <div class="col-lg-7">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               SQL
                           </label>
                           <p style="white-space: pre-wrap;" class="bg-light p-2 mg-b-0 rounded text-center" v-if="request.sql">
                               <strong>{{ request.sql.trim() }}</strong>
                           </p>
                       </div>
                       <div class="col-lg-5">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Bindings
                           </label>
                           <p class="mg-b-0">
                                <strong style="display: block" v-for="(i , index) in request.bindings" class="mr-3"> {{ index }} - {{ i }}</strong>
                           </p>
                       </div>
                   </div>
                   <div class="row mt-5">
                       <div class="col-12">
                           <div>
                               <table class="table table-dashboard table-bordered mg-b-0 table-vcenter">
                                   <thead>
                                   <tr>
                                       <th style="width: 33%">Field</th>
                                       <th style="width: 33%">Sign</th>
                                       <th style="width: 33%">Default Value</th>
                                   </tr>
                                   </thead>
                                   <tbody>
                                   <tr :key="`form-index-${index}`" v-for="(item, index) in request.params">
                                       <td>{{ item.field }}</td>
                                       <td>{{ item.sign }}</td>
                                       <td>{{ item.value }}</td>
                                   </tr>
                                   </tbody>
                               </table>
                           </div>
                       </div>
                   </div>
                   <div class="mg-b-25 mg-t-25 d-flex align-items-center">
                       <h6 class="mr-auto mb-0">User</h6>
                   </div>
                   <div class="row">
                       <div class="col-4">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Name
                           </label>
                           <p class="mg-b-0">
                               {{ request.user.full_name }}
                           </p>
                       </div>
                       <div class="col-4">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Email
                           </label>
                           <p class="mg-b-0">
                               {{ request.user.email }}
                           </p>
                       </div>
                       <div class="col-lg-4">
                       </div>
                   </div>
                   <div class="mg-b-25 mg-t-25 d-flex align-items-center">
                       <h6 class="mr-auto mb-0">Report</h6>
                   </div>
                   <div class="row">
                       <div class="col-4">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Name
                           </label>
                           <p class="mg-b-0">
                               {{ request.report.name }}
                           </p>
                       </div>
                       <div class="col-4">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Description
                           </label>
                           <p class="mg-b-0">
                               {{ request.report.description }}
                           </p>
                       </div>
                       <div class="col-lg-4">
                       </div>
                   </div>
                   <div class="row mg-t-25">
                       <div class="col-4">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Order Column
                           </label>
                           <p class="mg-b-0">
                               {{ request.report.order_column }}
                           </p>
                       </div>
                       <div class="col-4">
                           <label class="tx-10 tx-medium tx-spacing-1 tx-color-03 tx-uppercase tx-sans mg-b-10">
                               Order Direction
                           </label>
                           <p class="mg-b-0">
                               {{ request.report.order_direction }}
                           </p>
                       </div>
                   </div>
                   <div class="mg-b-25 mg-t-25 d-flex align-items-center">
                       <h6 class="mr-auto mb-0">Parameters</h6>
                   </div>
                   <div class="row mg-t-25">
                       <div class="col-12">
                           <div>
                               <table class="table table-dashboard table-bordered mg-b-0 table-vcenter">
                                   <thead>
                                   <tr>
                                       <th style="width: 33%">Field</th>
                                       <th style="width: 33%">Sign</th>
                                       <th style="width: 33%">Default Value</th>
                                   </tr>
                                   </thead>
                                   <tbody>
                                   <tr :key="`form-index-${index}`" v-for="(item, index) in request.report.parameters">
                                       <td>{{ item.field }}</td>
                                       <td>{{ item.sign }}</td>
                                       <td>{{ item.value }}</td>
                                   </tr>
                                   </tbody>
                               </table>
                           </div>
                       </div>
                   </div>

               </div>
            </div>
        </div>
    </div>
</template>

<script>
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    import {
          ZapIcon , ZapOffIcon , EyeIcon
    } from "vue-feather-icons";
    export default {
        components : {
            ZapIcon , ZapOffIcon , EyeIcon
        },
        name: "users-view",
        mounted : function() {

            this.init();
        },
        data : function () {
            return {
                initLoading : true,
                request : {
                    user : {},
                    report : {}
                }
            }
        },
        methods : {
            init : function () {
                this.initLoading = true;
                window.axios.get(`${window.location.origin}/transactions/requests/${this.$route.params.id}/view`).then((response) => {
                    this.request = response.data.body.request;
                }).finally(() => {
                    this.initLoading = false;
                });
            },
            abort : function () {
                this.initLoading = true;
                window.axios.get(`${window.location.origin}/transactions/requests/${this.$route.params.id}/abort`).then((response) => {
                    this.request = response.data.body.request;
                    window.alerts.success(response);
                }).finally(() => {
                    this.initLoading = false;
                });
            },


        }
    }
</script>

<style scoped>
    .table-dashboard tbody tr td {
        padding-bottom: 20px ;
        padding-top: 20px ;
    }
    .table-dashboard thead tr th {
        padding-bottom: 10px ;
        padding-top: 10px ;
    }
</style>
