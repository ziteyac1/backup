<template>
    <data-table url="/transactions/requests" filter="false" prefix="requests">
        <template slot="table-header">
            <th/>
                <th>Report</th>
                <th>Info</th>
                <th>Info</th>
                <th>Date</th>
                <th class="text-center"></th>
            <th/>
        </template>
        <!--suppress JSUnusedLocalSymbols -->
        <template slot="table-row" slot-scope="data">
            <td class="text-primary">#{{ data.row.id }}</td>
            <td class="">
                <div> User : {{ data.row.user.full_name }} </div>
                <div> Name : {{ data.row.report.name }} </div>
                <div> Description : {{ data.row.report.description | string_limit(20) }} </div>
            </td>

            <td class="">
                <div> State : {{ data.row.state }} </div>
                <div> Start : {{ data.row.start }} </div>
                <div> End : {{ data.row.end }} </div>
            </td>
            <td class="">
                <div> Count : {{ data.row.count }} </div>
                <div> Sum : {{ data.row.sum }} </div>
            </td>
            <td class="">{{ data.row.created_at }}</td>
            <td class="">
                <a target="_blank" class="btn btn-white btn-sm btn-uppercase" :href="`/transactions/requests/${data.row.id}/download`">
                    Download
                </a>
            </td>
            <td class="text-center">
                <router-link :to="`/transactions/requests/${data.row.id}/view`" class="btn btn-sm pd-x-15 btn-white btn-icon">
                   <eye-icon size="24"/>
                </router-link>
            </td>
        </template>
    </data-table>
</template>

<script>
    import DataTable from "../core/DataTable";
    import {PlusIcon , EyeIcon} from "vue-feather-icons";
    export default {
        name: "saf-requests-index",
        components: {DataTable , PlusIcon , EyeIcon }
    }
</script>

<style scoped>

</style>
