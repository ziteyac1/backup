<template>
    <div class="filemgr-content">
         <div class="filemgr-content-header justify-content-center">
             <strong class="">Create Report</strong>
         </div>
        <div class="filemgr-content-body">
            <div :class="['dimmer' , initLoading ? 'active' : '']">
                <div class="loader"></div>
                <div class="dimmer-content">
                    <div class="container pt-4">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div>
                                    <h6 class="mb-4">DETAILS</h6>
                                    <div class="row row-sm mb-4">
                                        <div class="col-sm-6">
                                            <label for="name">Name</label>
                                            <input type="text" id="name" name="name" v-model="form.name" :class="[ 'form-control' , form.errors.get('name') ? 'is-invalid' : '' ]" placeholder="">
                                            <div v-text="form.errors.get('name')" class="invalid-feedback"/>
                                        </div>
                                        <div class="col-sm-6 mg-t-10 mg-sm-t-0">
                                            <label for="description">Description</label>
                                            <input type="text" id="description" name="description" v-model="form.description" :class="[ 'form-control' , form.errors.get('description') ? 'is-invalid' : '' ]" placeholder="">
                                            <div v-text="form.errors.get('description')" class="invalid-feedback"/>
                                        </div>

                                    </div>
                                    <h6 class="mb-4">Sorting</h6>
                                    <div class="row row-sm mb-4">
                                        <div class="col-sm-6">
                                            <label for="order_column">Column</label>
                                            <input type="text" id="order_column" name="order_column" v-model="form.order_column" :class="[ 'form-control' , form.errors.get('order_column') ? 'is-invalid' : '' ]" placeholder="">
                                            <div v-text="form.errors.get('order_column')" class="invalid-feedback"/>
                                        </div>
                                        <div class="col-sm-6 mg-t-10 mg-sm-t-0">
                                            <label for="order_direction">Direction</label>
                                            <input type="text" id="order_direction" name="order_direction" v-model="form.order_direction" :class="[ 'form-control' , form.errors.get('order_direction') ? 'is-invalid' : '' ]" placeholder="">
                                            <div v-text="form.errors.get('order_direction')" class="invalid-feedback"/>
                                        </div>
                                    </div>

                                    <h6 class="mb-4 mt-4">Parameters</h6>
                                    <div>
                                        <table class="table table-dashboard mg-b-0 table-vcenter">
                                            <thead>
                                                <tr>
                                                    <th style="width: 30%">Field</th>
                                                    <th style="width: 30%">Sign</th>
                                                    <th style="width: 30%">Default Value</th>
                                                    <th style="width: 10%">
                                                        <button @click="createRow" class="btn btn-icon btn-white btn-sm">
                                                            <plus-circle-icon size="24"/>
                                                        </button>
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr :key="`form-index-${index}`" v-for="(item, index) in form.parameters">
                                                    <td>
                                                        <input type="text"  v-model="form.parameters[index]['field']" :class="[ 'form-control']" placeholder=""/>
                                                    </td>
                                                    <td>
                                                        <input type="text"  v-model="form.parameters[index]['sign']" :class="[ 'form-control']" placeholder=""/>
                                                    </td>
                                                    <td>
                                                        <input type="text"  v-model="form.parameters[index]['value']" :class="[ 'form-control']" placeholder=""/>
                                                    </td>
                                                    <td>
                                                        <button @click="removeRow(index)" class="btn btn-icon btn-danger btn-sm">
                                                            <x-icon size="24"/>
                                                        </button>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <div class="text-center mb-5 border-top mt-1 pt-4">
                                        <button @click="create" :disabled="form.loading" class="btn btn-primary"><plus-circle-icon class="mr-2"/>CREATE</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    import Form from "../../core/forms/form";
    import { PlusCircleIcon } from 'vue-feather-icons';
    import { XIcon } from 'vue-feather-icons';
    export default {
        components: {
            PlusCircleIcon ,
            XIcon
        },
        name: "reports-create",
        mounted : function() {

            this.init();
        },
        data : function () {
            return {
                initLoading : false,
                form : new Form({
                    name : '',
                    description : '',
                    order_column : '',
                    order_direction : '',
                    parameters : []
                }),
            }
        },
        methods : {
            removeRow : function(index){
                this.form.parameters.splice(index, 1);
            },
            createRow : function(){
                this.form.parameters.push({
                    field : '',
                    sign : '',
                    value : '',
                });
            },

            create :  function () {
                this.initLoading = true;
                this.form.submit('/transactions/reports/create').then((response) => {
                    window.Swal.fire({
                        icon: 'success',
                        title: response.data.message,
                        showConfirmButton: false,
                        padding : '20px',
                        timer: 2000
                    });
                }).finally(() => {
                    this.initLoading = false;
                });

            },
            init : function () {

            }
        }
    }
</script>

<style scoped>
 .table-dashboard tbody tr td {
     padding-bottom: 20px ;
     padding-top: 20px ;
 }
 .table-dashboard thead tr th {
     padding-bottom: 10px ;
     padding-top: 10px ;
 }
</style>
