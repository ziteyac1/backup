<template>
    <div class="filemgr-content">
        <div class="filemgr-content-with-side">
            <div class="filemgr-content-header align-items-center">
                <users-icon size="26"/>
                    <span class="ml-3 text-primary">
                        <strong class="tx-20">#{{ $route.params.id }}</strong>
                    </span>
                <span class="border-left ml-auto mr-3"/>
            </div>
            <transition name="slide-in-left">
                <router-view/>
            </transition>
        </div>
        <div class="filemgr-content-side">
            <div class="filemgr-sidebar-body">
                <div class="pd-t-20 pd-b-10 pd-x-10">
                    <label class="tx-sans tx-uppercase tx-medium tx-10 tx-spacing-1 tx-color-03 pd-l-10 pd-t-20">Report</label>
                    <nav class="nav nav-sidebar tx-13">
                        <router-link class="nav-link" active-class="active" :to="`/transactions/requests/${$route.params.id}/view`" exact>
                            <eye-icon/>  View Request
                        </router-link>
                    </nav>
                </div>
            </div>
        </div>
    </div>

</template>

<script>
    import PerfectScrollbar from "../../core/perfect-scrollbar.esm";
    import {
        EyeIcon , EditIcon , ActivityIcon , ImageIcon ,
        ClockIcon , UsersIcon , UserPlusIcon , UserCheckIcon ,
        FolderIcon , AlignJustifyIcon , ColumnsIcon , CommandIcon ,
        TagIcon , PlusCircleIcon , ZapIcon
    } from "vue-feather-icons"
    export default {
        components : {
            EyeIcon , EditIcon , ActivityIcon  , ClockIcon,
            UsersIcon , UserPlusIcon , UserCheckIcon , ImageIcon ,
            FolderIcon ,AlignJustifyIcon ,  ColumnsIcon , CommandIcon ,
            TagIcon , PlusCircleIcon  , ZapIcon
        },
        name: "users-open",
        mounted : function() {


            new PerfectScrollbar('.filemgr-content-side', {
                suppressScrollX: true
            });
        },
    }
</script>

<style scoped>

</style>
