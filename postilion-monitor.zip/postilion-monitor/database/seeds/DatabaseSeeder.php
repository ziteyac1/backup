<?php

use App\Building;
use App\Owner;
use App\Room;
use App\RoomTypes;
use App\SAFReport;
use App\Tenant;
use App\Unit;
use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
         // Create Base User
        // Remove Guards

        echo "Starting Database Seeding".PHP_EOL;

        Model::unguard();

        // Users

        // Remove cache of permissions
        /** @var PermissionRegistrar $permissionRegistrar
         * @noinspection VirtualTypeCheckInspection
         */

        $permissionRegistrar = app()[PermissionRegistrar::class];
        $permissionRegistrar->forgetCachedPermissions();

        echo "Creating Users".PHP_EOL;

        /** @var User $user
         * @noinspection VirtualTypeCheckInspection
         */
        $user = User::query()->create([
            'email' => 'root@system',
            'password' => Hash::make('password'),
            'name' => 'System',
            'last_name' => 'Root',
        ]);

        $default = Role::query()->create([
            'name' => 'default'
        ]);


        /** @var Role $admin
         * @noinspection VirtualTypeCheckInspection
         */

        $admin = \App\Entities\core\Role::query()->create([
            'name' => 'admin',
        ]);

        collect([
            'list user',
            'create user',
            'edit user',
            'view user',
            'manage roles',
            'monitor system',
        ])->each(function ($permission) use ($admin){
            $admin->givePermissionTo(\App\Entities\core\Permission::query()->create([
                'name' => $permission
            ]));
        });

        $user->assignRole($admin);

        // Reports

        /** @var SAFReport $reports */
        $reports = SAFReport::query()->create([
           'name' => 'SAF Transactions',
            'description' => 'All transactions in the store and forward queue',
            'order_column' => 'tran_nr',
            'order_direction' => 'desc',
            'chart' => false,
        ]);

        $reports->parameters()->create([
           'field' => 'state',
           'sign' => '<',
           'value' => '99',
        ]);

        $reports->parameters()->create([
           'field' => 'msg_type',
           'sign' => '<>',
           'value' => '800',
        ]);
    }

    // Sink Nodes
    //$sinkNodes = [
    //[ 'Agri24Host' , true ],
    //[ 'Agri24NotSnk' , true ],
    //[ 'Agri24SchSnk' , true ],
    //[ 'AgriBankHost' , true ],
    //[ 'AgriNoftHost' , true ],
    //[ 'AgriSchmSnk' , true ],
    //[ 'AGRIT24HOST' , true ],
    //[ 'AgriZssSnk' , false ],
    //[ 'EcoCashSnk' , false ],
    //[ 'EcoMerchSnk' , false ],
    //[ 'PostIntSnk' , false ],
    //[ 'TransferSnk' , false ],
    //[ 'ZimSwitchSnk' , false ],
    //];
    //
    //    // Source nodes
    //$sourceNodes = [
    //'TransferSrc',
    //'AgriPstInSrc',
    //'AgriMerchSrc',
    //'AgriTellSrc',
    //'AgriZssSrc',
    //'AgriMobileSr',
    //'ATMApp',
    //'AgriPosSrc',
    //'AgriZswSrc',
    //'AgriAgencySr',
    //'ECOCASHSrc',
    //'AgriMPOSSrc',
    //'AgriZssSnk',
    //];
    //    // tran types
    //$tranTypes = [
    //'01',
    //'50',
    //'27',
    //'00',
    //'42',
    //'09',
    //'31',
    //'40',
    //'39',
    //'93',
    //'92',
    //'91',
    //'22',
    //'37',
    //'21',
    //'38',
    //];

}
