<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSAFRequestsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('s_a_f_requests', function (Blueprint $table) {
            $table->bigIncrements('id');

            $table->bigInteger('report_id');
            $table->bigInteger('user_id');

            $table->string('tnx_full_path')->nullable();
            $table->string('tnx_id_path')->nullable();
            $table->string('state')->nullable();

            $table->string('count')->nullable();
            $table->string('sum')->nullable();

            $table->string('start')->nullable();
            $table->string('end')->nullable();
            $table->string('aborted_at')->nullable();
            $table->string('aborted')->nullable();

            $table->string('progress')->nullable();
            $table->text('sql')->nullable();
            $table->text('bindings')->nullable();
            $table->text('params')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('s_a_f_requests');
    }
}
