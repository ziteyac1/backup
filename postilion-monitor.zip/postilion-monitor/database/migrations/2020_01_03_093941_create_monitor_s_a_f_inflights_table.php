<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMonitorSAFInflightsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('monitor_s_a_f_inflights', function (Blueprint $table) {
            $table->bigIncrements('id')->nullable();
            $table->string('pan')->nullable();
            $table->string('card_acceptor_term_id')->nullable();
            $table->string('rsp_code_req_rsp')->nullable();
            $table->string('in_req')->nullable();
            $table->string('tran_nr')->nullable();
            $table->string('sink_node')->nullable();
            $table->string('source_node')->nullable();
            $table->string('tran_type')->nullable();
            $table->string('srcnode_amount_final')->nullable();
            $table->string('state')->nullable();
            $table->string('duration')->nullable();
            $table->string('postilion_duration')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('monitor_s_a_f_inflights');
    }
}
