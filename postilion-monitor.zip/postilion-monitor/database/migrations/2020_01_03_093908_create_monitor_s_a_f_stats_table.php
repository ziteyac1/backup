<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMonitorSAFStatsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('monitor_s_a_f_stats', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('tran_type')->nullable();
            $table->string('source_node')->nullable();
            $table->string('sink_node')->nullable();
            $table->string('count')->nullable();
            $table->string('stamp')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('monitor_s_a_f_stats');
    }
}
