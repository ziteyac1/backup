<?php

namespace App\Jobs;

use App\core\model\DBHelper;
use App\SAFRequest;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class AbortTransactions implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels , DBHelper;

    private  $request;
    /**
     * Create a new job instance.
     *
     * @param SAFRequest $request
     */
    public function __construct(SAFRequest $request)
    {
        $this->request = $request;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $request = $this->request;

        $request->update([
            'state' => 'started collecting transaction ids'
        ]);

        $request->update([
           'aborted' => 0
        ]);

        // Get Ids into Array

        $ids = [];

        $file = fopen($request->tnx_id_path,"r");

        while(! feof($file))
        {
            $string =  fgets($file);
            $ids[] = trim($string);
        }

        fclose($file);

        $request->update([
            'state' => 'started aborting transaction ids'
        ]);

        $chunks = collect($ids)->chunk(100);

        foreach ($chunks as $chunk){

            // update tnxs

            $builder = $this->getTable('tm_trans')
                ->whereIn('tran_nr' , $chunk);

//            $builder->update([
//                'state' => '100'
//            ]);

            $request->update([
                'aborted' => (int)$request->aborted + (int)count($chunk)
            ]);

        }

        $request->update([
            'state' => 'request completed',
            'aborted' => (int)$request->aborted - 1
        ]);

    }
}
