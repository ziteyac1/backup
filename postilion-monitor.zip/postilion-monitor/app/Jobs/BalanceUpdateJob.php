<?php

namespace App\Jobs;

use App\core\model\DBHelper;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;

class BalanceUpdateJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels, DBHelper;

    public $request;
    private $account_number;
    private $available_balance;
    private $ledger_balance;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($account_number, $available_balance, $ledger_balance)
    {
        $this->account_number = $account_number;
        $this->available_balance = $available_balance;
        $this->ledger_balance = $ledger_balance;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $account_number = $this->account_number;
        $available_balance = $this->available_balance;
        $ledger_balance = $this->ledger_balance;
        $total = 0;

        DB::transaction(function () use ($account_number , &$total){

            $saf_curr_query = DB::connection('sqlsrv_live')
                ->table('tm_trans_current')
                ->lock('WITH(NOLOCK)')
                ->where('state' , '>' , 2 )
                ->where('state' , '<' , 99 )
                ->where('msg_type','!=','0800')
                ->where('sink_node','=','Agri24Host')
                ->where('in_req','!=',null)
                ->orderBy('in_req','asc')
                ->first('in_req');

            if ($saf_curr_query) {
                $saf = $saf_curr_query->in_req;
            } else {
                $saf = now();
            }

            $saf_transactionsNegative = DB::connection('sqlsrv_live')
                ->table('tm_trans_current')
                ->lock('WITH(NOLOCK)')
                ->where('account_id_1','=',$account_number)
                ->where('in_req','>=',$saf)
                ->where('state','>','2')
                ->where('state','<','99')
                ->where('msg_type','!=','0800')
                ->where('sink_node','=','Agri24Host')
                ->orderBy('in_req','asc')
                ->sum('snknode_amount_final');

            $saf_transactionsPositive = DB::connection('sqlsrv_live')
                ->table('tm_trans_current')
                ->lock('WITH(NOLOCK)')
                ->where('account_id_2','=',$account_number)
                ->where('in_req','>=',$saf)
                ->where('state','>','2')
                ->where('state','<','99')
                ->where('msg_type','!=','0800')
                ->where('sink_node','=','Agri24Host')
                ->orderBy('in_req','asc')
                ->sum('snknode_amount_final');

            $total = $saf_transactionsPositive - $saf_transactionsNegative;

        } ,  5);

        DB::transaction(function () use ($total , $available_balance , $ledger_balance , $account_number)
        {
            DB::connection('sqlsrv_live_postcard')->table('pc_account_balance_deltas')
                ->where('account_id','=',$account_number)->update([
                    'ledger_balance'=> $total,
                    'available_balance'=> $total
                ]);

            $number = DB::connection('sqlsrv_live_postcard')->table('pc_account_balance_deltas')
                ->lock('WITH(NOLOCK)')
                ->where('account_id','=',$account_number)
                ->first('extract_nr');

            if ($number)
            {
                $extract_nr = $number->extract_nr;

                DB::connection('sqlsrv_live_postcard')->table('pc_account_balance_deltas')
                    ->where('account_id','=',$account_number)
                    ->where('extract_nr','>',$extract_nr)
                    ->delete();
            }

            DB::connection('sqlsrv_live_postcard')
                ->table('pc_account_balances_1_A')
                ->where('account_id','=',$account_number)
                ->update([
                    'ledger_balance'=>$ledger_balance,
                    'available_balance'=>$available_balance,
                    'last_updated_date'=> now()
                ]);

        } , 5 );

    }

    public function tags()
    {
        return ['balance'];
    }

}
