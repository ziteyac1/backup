<?php

namespace App\Jobs;

use App\core\model\DBHelper;
use App\SAFRequest;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use SebastianBergmann\CodeCoverage\Report\PHP;

class ExtractTransactions implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels , DBHelper;

    public $request;

    /**
     * Create a new job instance.
     *
     * @param SAFRequest $request
     */
    public function __construct(SAFRequest $request)
    {
        $this->request = $request;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        // Extract Records to file
        /** @var SAFRequest $request */
        $request = $this->request;
        $request->update([
           'state' => 'starting collecting transactions',
        ]);
        $report = $request->report;

        $min =  storage_path('app/public/reports/'.Str::random(90).'.txt' );
        $full = storage_path('app/public/reports/'.Str::random(90).'.txt' );
        $count = 0;
        $request->update([
           'tnx_id_path' => $min ,
           'tnx_full_path' => $full,
        ]);

        $min = fopen($min,"w+");
        $full = fopen($full,"w+");

        $builder = $this->getTable('tm_trans')->lock('WITH(NOLOCK)')
            ->select([
                'tran_nr',
                'state',
                'source_node',
                'sink_node',
                'srcnode_amount_final',
                'pan',
                'expiry_date',
                'ret_ref_no',
                'card_acceptor_term_id',
                'card_acceptor_name_loc',
                'account_id_1',
                'account_id_2',
                'in_req',
                'tran_type',
                'rsp_code_req_rsp',
            ])->whereBetween('in_req' , [
                $request->start , $request->end
            ])->orderBy($report->order_column , $report->order_direction);

        $overview = $this->getTable('tm_trans')->whereBetween('in_req' , [
            $request->start , $request->end
        ]);

        $parameters = $report->parameters()->get();
        foreach ($parameters  as $parameter)
        {
            $builder = $builder->where($parameter->field , $parameter->sign , $parameter->value );
            $overview = $overview->where($parameter->field , $parameter->sign , $parameter->value );
        }

        $overview =  $overview->first(
            [
                DB::raw('COUNT(snknode_amount_final) as count') ,
                DB::raw('SUM(snknode_amount_final) / 100 as sum')
            ]
        );

        $request->update([
           'count' => $overview->count,
           'sum' => $overview->sum,
           'sql' => trim($builder->toSql()),
           'bindings' => $builder->getBindings(),
           'params' => $parameters->toArray()
        ]);

        $builder->chunk(1000 , function ($items) use ($full , $min , $count){

            foreach ($items as $item)
            {
                $count++;
                $output = "{$item->tran_nr},{$item->state},{$item->source_node},{$item->sink_node},{$item->srcnode_amount_final},{$item->pan},{$item->expiry_date},{$item->ret_ref_no},{$item->card_acceptor_term_id},{$item->card_acceptor_name_loc},{$item->account_id_1},{$item->account_id_2},{$item->in_req},{$item->tran_type},{$item->rsp_code_req_rsp}".PHP_EOL;
                fwrite( $full , $output );
                fwrite( $min ,$item->tran_nr.PHP_EOL );
            }

        });

        fclose($min);
        fclose($full);

        $request->update([
            'state' => 'finished collecting transactions'
        ]);
    }

    public function tags()
    {
        return ['extracts'];
    }

}
