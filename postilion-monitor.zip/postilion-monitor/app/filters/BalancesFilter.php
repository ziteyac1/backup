<?php
/** @noinspection MethodShouldBeFinalInspection */
/** @noinspection MissingParameterTypeDeclarationInspection */
namespace App\filters;


use App\Entities\core\Role;
use App\filters\core\ModelFilter;
use App\User;

class BalancesFilter extends ModelFilter
{
    protected  $filters = [
        'search'
    ];
    protected  $equal = [
        'roles.id'
    ];
    protected  $dates = [];
    protected  $range = [];
    protected  $sort = [
        'id',
        'created_at'
    ];

    protected $morphs = [];

    protected $search = [
        'account_id'
    ];

    public $documentation = [];

}
