<?php
/** @noinspection MethodShouldBeFinalInspection */
/** @noinspection MissingParameterTypeDeclarationInspection */
namespace App\filters;


use App\filters\core\ModelFilter;

class UserFilter extends ModelFilter
{
    protected  $filters = [
        'search'
    ];
    protected  $equal = [
        'id'
    ];
    protected  $dates = [];
    protected  $range = [];
    protected  $sort = [
        'id',
        'created_at'
    ];

    protected $search = [
      'name',
      'email',
      'status',
    ];

    public $documentation = [
        [
            "field"  => "id",
            "read"  => "ID",
            "range"  => true,
            "date"  => false,
            "filter" => [
                [
                    "read" => 'First ID',
                    "value" => 1
                ],
                [
                    "read" => 'Last ID',
                    "value" => 2
                ]
            ],
            "sort" => true,
        ],
        [
            "field"  => "status",
            "read"  => "Status",
            "range"  => false,
            "date"  => false,
            "filter" => [
                [
                    "read" => 'Building Open',
                    "value" => 'open'
                ],
                [
                    "read" => 'Building Closed',
                    "value" => 'closed'
                ]
            ],
            "sort" => true,
        ],
        [
            "field"  => "created_at",
            "read"  => "Date Created",
            "range"  => true,
            "filter" => [],
            "sort" => true,
            "date"  => true,
        ]
    ];

}
