<?php
/** @noinspection MethodShouldBeFinalInspection */
/** @noinspection MissingParameterTypeDeclarationInspection */
namespace App\filters;


use App\filters\core\ModelFilter;

class SAFRequestFilter extends ModelFilter
{
    protected  $filters = [
        'search'
    ];
    protected  $equal = [];
    protected  $dates = [];
    protected  $range = [];
    protected  $sort = [
        'id',
        'created_at'
    ];

    protected $search = [
      'name',
    ];

    public $documentation = [
    ];

}
