<?php

namespace App\Console\Commands;

use App\core\model\DBHelper;
use App\MonitorLog;
use App\MonitorSAFInflight;
use App\MonitorSAFStats;
use App\ReportStats;
use App\SAFReport;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class SAFReportSnapshot extends Command
{
    use DBHelper;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'monitor:reports';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Monitor Report SAF levels';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }



    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $stamp = now()->format('Y-m-d H:i:s');
        foreach (SAFReport::query()->get() as $report ){

            $this->log("Running stats for report #{$report->id} : {$report->name}" , 'query' , $stamp);
            $overview = $this->getTable('tm_trans')->lock('WITH(NOLOCK)');
            $parameters = $report->parameters()->get();
            foreach ($parameters  as $parameter)
            {
                $overview = $overview->where($parameter->field , $parameter->sign , $parameter->value );
            }

            $overview =  $overview->first(
                [
                    DB::raw('COUNT(*) as count')
                ]
            );

            ReportStats::query()->create([
                'report_id' => $report->id,
                'stamp' => $stamp,
                'count' => $overview->count
            ]);
        }
    }


}
