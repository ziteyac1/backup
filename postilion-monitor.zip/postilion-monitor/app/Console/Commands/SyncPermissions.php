<?php

namespace App\Console\Commands;

use App\sso\models\Permission;
use App\sso\services\PermissionService;
use Illuminate\Console\Command;
use Spatie\Permission\PermissionRegistrar;

class SyncPermissions extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */

    protected $signature = 'sso:sync-permissions';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sync Permissions with Single Sign On Server';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->info('Sync Permissions Started');
        (new PermissionService())->sync();
        $this->info('Sync Permissions Completed');
    }
}
