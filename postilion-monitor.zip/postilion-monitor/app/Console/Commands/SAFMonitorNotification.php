<?php

namespace App\Console\Commands;

use App\core\model\DBHelper;
use App\MonitorNotification;
use App\User;
use GuzzleHttp\Client;
use Illuminate\Console\Command;

class SAFMonitorNotification extends Command
{
    use DBHelper;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'monitor:limit';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Monitors SAF Limits';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $stamp = now()->format('Y-m-d H:i:s');
        $this->log('Checking Saf levels' , 'check',$stamp);

        $number = $this->getTable('tm_trans')->lock('WITH(NOLOCK)')
                ->where('state' , '<', '99')
                ->where('msg_type' , '<>', '800')
                ->where('sink_node' , '=' , 'Agri24Host')
            ->count();

        $this->log("SAF level is : {$number}" , 'check',$stamp);

        if ($number > 5000)
        {
            foreach (MonitorNotification::query()->get() as $notification)
            {
                $message = "Dear Admin  , the SAF ( Store and forward ) level is {$number}  as at  {$stamp}";
                $client = new Client();
                $res = $client->request('GET' , "https://secure.zss.co.zw/vportal/cnm/vsms/plain?user=Agribank012&password=agri13&sender=Agribank&SMSText={$message}&GSM={$notification->phone}");
            }

        }

        $this->log('Completed checking Saf levels' , 'check',$stamp);

    }
}
