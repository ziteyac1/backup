<?php

namespace App\Console\Commands;

use App\core\model\DBHelper;
use App\MonitorLog;
use App\MonitorSAFInflight;
use App\MonitorSAFStats;
use App\ReportStats;
use App\SAFReport;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class SAFMonitorSnapshot extends Command
{
    use DBHelper;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'monitor:saf';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Monitor SAF levels';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }



    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        $sinkNodes = $this->sink;

        $stamp = now()->format('Y-m-d H:i:s');
        $this->log('Monitoring SAF snapshot started' , 'start' , $stamp);
        $this->log('Collecting statistics form Postilion' , 'query' , $stamp);

        $extracts = $this->getTable('tm_trans')->lock('WITH(NOLOCK)')
            ->where('state' , '<', '99')
            ->where('state' , '>', '2')
            ->where('msg_type' , '<>', '800')
            ->whereIn('sink_node' , $sinkNodes)
            ->groupBy(['sink_node'])
            ->get([
                'sink_node',
                DB::raw('count(*) as count') ,
            ]);


        $this->log('Collected statistics form Postilion' , 'query' , $stamp);
        $this->log('Aggregating statistics for transactions' , 'start' , $stamp);

        // Get values

        foreach ($sinkNodes as $node){

            $extract = $extracts->firstWhere('sink_node' , $node);

            if ($extract){
                MonitorSAFStats::query()->create([
                    'sink_node' => $extract->sink_node,
                    'count' => $extract->count,
                    'stamp' => $stamp
                ]);
            } else {
                MonitorSAFStats::query()->create([
                    'sink_node' => $node,
                    'count' => 0,
                    'stamp' => $stamp
                ]);
            }
        }

        $this->log('Completed' , 'start' , $stamp);

    }


}
