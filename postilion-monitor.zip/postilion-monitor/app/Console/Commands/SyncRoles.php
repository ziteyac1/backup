<?php

namespace App\Console\Commands;

use App\sso\models\Permission;
use App\sso\models\Role;
use App\sso\services\RoleService;
use Illuminate\Console\Command;
use Spatie\Permission\PermissionRegistrar;

class SyncRoles extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'sso:sync-roles';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sync Roles with Single Sign On Server';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->info('Sync Roles Started');
        (new RoleService())->sync();
        $this->info('Sync Roles Completed');
    }
}
