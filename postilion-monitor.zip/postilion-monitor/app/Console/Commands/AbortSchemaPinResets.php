<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class AbortSchemaPinResets extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'transactions:abort-scheme';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**W
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $result = DB::connection('sqlsrv_live')->update("update realtime.dbo.tm_trans set state = '100' where sink_node = 'AgriSchmSnk'and snknode_amount_final/100 = 0 and tran_type = '00'and file_update_name = 'CARD_MANAGEMENT' and state < '99'");
    }
}
