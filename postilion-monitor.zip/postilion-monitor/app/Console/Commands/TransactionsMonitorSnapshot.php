<?php

namespace App\Console\Commands;

use App\core\model\DBHelper;
use App\MonitorLog;
use App\MonitorSAFInflight;
use App\MonitorSAFStats;
use Illuminate\Console\Command;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class TransactionsMonitorSnapshot extends Command
{
    use DBHelper;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'monitor:transactions';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Monitor Blocking transactions from the queue';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $sinkNodes = $this->sink;
        $stamp = now()->format('Y-m-d H:i:s');

        // Get values

        foreach ($sinkNodes as $node){

            $this->log('Collecting inflight for node '.$node , 'query' , $stamp);

            $tns = $this->getTable('tm_trans')
                    ->where('state' , '<', '99')
                    ->where('state' , '>', '2')
                    ->where('msg_type' , '<>', '800')
                    ->where('sink_node' , '=' , $node)
                    ->orderBy('tran_nr' , 'asc')
                    ->limit(5)
                ->get(['pan', 'card_acceptor_term_id' ,'rsp_code_req_rsp', 'in_req','tran_nr' , 'sink_node' , 'source_node' , 'tran_type' , 'srcnode_amount_final' , 'state']);

            foreach ($tns as $transaction)
            {
                /** @var MonitorSAFInflight $transaction */
                $transaction = MonitorSAFInflight::query()->firstOrCreate([
                    'tran_nr' =>  $transaction->tran_nr,
                ] , [
                    'postilion_duration' => $transaction->in_req ? Carbon::createFromFormat('Y-m-d H:i:s.u' , $transaction->in_req )->diffForHumans() : '',
                    'pan' =>  $transaction->pan,
                    'card_acceptor_term_id' =>  $transaction->card_acceptor_term_id,
                    'rsp_code_req_rsp' =>  $transaction->rsp_code_req_rsp,
                    'in_req' =>  $transaction->in_req,
                    'tran_nr' =>  $transaction->tran_nr,
                    'sink_node' =>  $transaction->sink_node,
                    'source_node' =>  $transaction->source_node,
                    'tran_type' =>  $transaction->tran_type,
                    'srcnode_amount_final' =>  $transaction->srcnode_amount_final / 100,
                    'state' =>  $transaction->state,
                ]);

                $transaction->update([
                    'postilion_duration' => $transaction->in_req  ? Carbon::createFromFormat('Y-m-d H:i:s.u' , $transaction->in_req )->diffForHumans() : '',
                    'duration' => $transaction->created_at->diffInMinutes(now()),
                    'pan' =>  $transaction->pan,
                    'card_acceptor_term_id' =>  $transaction->card_acceptor_term_id,
                    'rsp_code_req_rsp' =>  $transaction->rsp_code_req_rsp ,
                    'in_req' =>  $transaction->in_req,
                    'tran_nr' =>  $transaction->tran_nr,
                    'sink_node' =>  $transaction->sink_node,
                    'source_node' =>  $transaction->source_node,
                    'tran_type' =>  $transaction->tran_type,
                    'srcnode_amount_final' =>  $transaction->srcnode_amount_final / 100,
                    'state' =>  $transaction->state,
                ]);

            }

            $this->log('Collected inflight for node '.$node , 'query' , $stamp);
        }

        // Clear blocking transactions

        $this->log('Clearing inflights' , 'query' , $stamp);

        // TODO : Check Aborted check
        MonitorSAFInflight::query()->where(function (Builder $builder){
            $builder->orWhere('duration' , '=' , '0');
            $builder->orWhere('state' , '>=' , '99');
        })->where('updated_at' , '<' , now()->subMinutes(20) )->delete();

        MonitorSAFInflight::query()
            ->where('updated_at' , '<' , now()->subMinutes(40) )->delete();

        // Update Stats

        $this->log('Cleared inflights' , 'query' , $stamp);

    }

    /**
     * @param $log
     * @param $type
     * @param $stamp
     */
    public function log( string $log , string $type , string  $stamp) : void {

        $item =  MonitorLog::query()->create([
            'log' => $log,
            'type' => $type,
            'stamp' => $stamp,
        ]);

        echo  "[ {$item->created_at} ] {$item->log}".PHP_EOL;
    }
}
