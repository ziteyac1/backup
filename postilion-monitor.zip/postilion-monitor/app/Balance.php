<?php

namespace App;

use App\filters\core\HasModelFilter;
use Illuminate\Database\Eloquent\Model;

/**
 * @property mixed account_id
 */
class Balance extends Model
{
    use HasModelFilter;
    public $incrementing = false;
    protected $keyType = 'string';
    public $timestamps = false;
    protected $connection = 'sqlsrv_live_postcard';
    protected $table = 'pc_account_balances_1_A';
    protected $primaryKey  = 'account_id';
}
