<?php

namespace App;

use App\filters\core\HasModelFilter;
use Illuminate\Database\Eloquent\Model;

class Deltas extends Model
{
    use HasModelFilter;
    public $incrementing = false;
    protected $keyType = 'string';
    public $timestamps = false;
    protected $connection = 'sqlsrv_live_postcard';
    protected $table = 'pc_account_balance_deltas';
    protected $primaryKey  = 'account_id';
}
