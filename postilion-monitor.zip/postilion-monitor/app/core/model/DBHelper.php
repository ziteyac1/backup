<?php


namespace App\core\model;


use App\MonitorLog;
use Illuminate\Support\Facades\DB;

trait DBHelper
{
    public $sink =  [
        'Agri24Host',
        'EcoMerchSnk',
        'ZimSwitchSnk',
        'AgriSchmSnk',
    ];

    /**
     * @param $log
     * @param $type
     * @param $stamp
     */
    public function log( string $log , string $type , string  $stamp) : void {

        $item =  MonitorLog::query()->create([
            'log' => $log,
            'type' => $type,
            'stamp' => $stamp,
        ]);

        echo  "[ {$item->created_at} ] {$item->log}".PHP_EOL;
    }

    public function getTable($name): \Illuminate\Database\Query\Builder
    {
        return DB::connection('sqlsrv_live')->table($name);
    }
}
