<?php


namespace App\core\model;

use Carbon\Carbon;

/**
 * Trait ModelAttributeCommons
 * @package App\core\model
 * @property Carbon $updated_at
 */
trait ModelAttributeCommons
{
    /**
     * @return string
     */
    public function getLastUpdateAttribute() : string
    {
        return $this->updated_at->diffForHumans();
    }
}
