<?php /** @noinspection ClassNameCollisionInspection */


namespace App\Entities\core;


use App\Building;
use App\filters\core\HasModelFilter;
use App\Owner;
use App\Room;
use App\Tenant;
use App\Unit;
use App\User;

/**
 * @property mixed user_id
 */
class Audit extends \OwenIt\Auditing\Models\Audit
{
     use HasModelFilter;

     protected $appends = [
         'last_update'
     ];

     public function getAuditableTypeAttribute($value){

         $config = [
           User::class => 'User',
           Role::class => 'Role',
         ];

         return $config[$value];

     }

    public function getEventAttribute($value){

       return strtoupper($value);

    }

    /**
     * @return string
     */
    public function getLastUpdateAttribute() : string
    {
        return $this->created_at->diffForHumans();
    }
}
