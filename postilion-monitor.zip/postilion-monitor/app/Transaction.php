<?php

namespace App;

use App\filters\core\HasModelFilter;
use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    use HasModelFilter;
    public $incrementing = false;
    protected $keyType = 'string';
    public $timestamps = false;
    protected $connection = 'sqlsrv_live_postcard';
    protected $table = 'pc_statement_deltas';
    protected $primaryKey  = 'row_id';
}
