<?php

namespace App;

use App\core\model\ModelAttributeCommons;
use App\filters\core\HasModelFilter;
use Illuminate\Database\Eloquent\Model;

/**
 * @property mixed start
 * @property mixed end
 * @property SAFReport report
 * @property mixed tnx_full_path
 * @property mixed tnx_id_path
 * @property mixed aborted
 */
class SAFRequest extends Model implements \OwenIt\Auditing\Contracts\Auditable
{
    use \OwenIt\Auditing\Auditable;
    protected $casts = [
        'bindings' => 'array',
        'params' => 'array',
    ];

    use HasModelFilter , ModelAttributeCommons;
    protected $guarded = [];

    public function parameters()
    {
        return $this->hasMany(SAFRequestParameters::class , 'request_id' , 'id');
    }

    public function report(){
        return $this->hasOne(SAFReport::class , 'id' , 'report_id');
    }

    public function user(){
        return $this->hasOne(User::class , 'id' , 'user_id');
    }
}
