<?php

namespace App\Http\Controllers;

use App\Entities\core\Permission;
use App\filters\PermissionFilter;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PermissionController extends Controller
{
    /**
     * @param PermissionFilter $filter
     * @return JsonResponse
     */
    public function index(PermissionFilter $filter){

        $permissions = Permission::filter($filter , [

        ])->paginate(\request('size') ?? 30 );

        return api()
            ->data('permissions' , $permissions)
            ->data('filters' , $filter->documentation)
           ->build();

    }
}
