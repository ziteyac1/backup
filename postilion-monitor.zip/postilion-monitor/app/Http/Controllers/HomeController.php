<?php

namespace App\Http\Controllers;

use Illuminate\Contracts\View\Factory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Redirector;
use Illuminate\View\View;

class HomeController extends Controller
{
    /**
     * @return RedirectResponse|Redirector
     */
    public function landing()  : RedirectResponse
    {
        return redirect('/login');
    }

    /**
     * @return Factory|View
     */
    public function home() : RedirectResponse
    {
        return redirect('/apps/postilion');
    }
}
