<?php

namespace App\Http\Controllers;

use App\Balance;
use App\BalanceUpdatesLog;
use App\Jobs\BalanceUpdateJob;
use App\PartialLoadLogs;

class PartialRefreshController extends Controller
{
    public function edit(Balance $account, $ledgerBalance, $availableBalance){


        // log

        BalanceUpdatesLog::query()->create([
            'user_id' => 1,
            'account' =>  $account->account_id,
            'ledger_balance' =>  $ledgerBalance,
            'available_balance' =>  $availableBalance,
        ]);

        // Call JOB

        $this->dispatch(new BalanceUpdateJob($account->account_id ,$availableBalance, $ledgerBalance));

        return api()
            ->message('Account Update Queued , please refresh in a moment')
            ->build();

    }

    public function sendTCPRequest() {
        $output = "Balances Refresh request sent.";
        $ftpServer = "127.0.0.1";
        $ftpServerPort = 13000;
        try {
            $fp = fsockopen($ftpServer, $ftpServerPort, $errno, $errstr, 30);
            if (!$fp) {
                $output = "An error occured.";
            } else {
                fwrite($fp, "Request");
                /*
                while (!feof($fp)) {
                    echo fgets($fp, 128);
                }
                */
                fclose($fp);
            }
        } catch(\Exception $e) {
            $output = $e->getMessage();
        }
        catch (\Throwable $e) {
            $output = $e->getMessage();
        }
        //dd("Got here");
        return api()
            ->message($output)
            ->build();
    }

    public function partialRefreshLogs($message, $type) {

        PartialLoadLogs::query()->create([
            'type' => $type,
            'message' =>  $message,
        ]);

        return api()
            ->data('message' , "done")
            ->build();

    }

    public function view(Balance $account){

        $top  = PartialLoadLogs::query()
            ->limit(1)
            ->orderBy('id' , 'desc')->get();

        $logs  = PartialLoadLogs::query()
            ->limit(10)
            ->orderBy('id' , 'desc')->get();

        return api()
            ->data('logs' , $logs)
            ->data('typ_type' , $top)
            ->build();

    }

}
