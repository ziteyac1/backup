<?php

namespace App\Http\Controllers;

use App\core\model\DBHelper;
use App\GeneratedReport;
use App\MonitorLog;
use App\MonitorSAFBlocked;
use App\MonitorSAFInflight;
use App\MonitorSAFStats;
use App\ReportStats;
use App\SAFReport;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use function count;

class SAFController extends Controller
{
    use DBHelper;

    /**
     * @return mixed
     * @throws Exception
     */
    public function getRandomColor()
    {
        $string = '#AA5959,#AC5A61,#AD5C69,#AC5E71,#AB6179,#A96582,#A56889,#A16D91,#9B7198,#95769E,#8D7BA3,#857FA8,#7B84AC,#7289AE,#678DB0,#5D91B0,#5295AF,#4899AE,#3F9DAB,#38A0A7,#33A3A2,#32A69D,#35A996,#3CAB8F,#44AD88,#4EAF81,#59B079,#65B171,#70B26A,#7CB363,#88B35C,#95B356,#A1B251,#ADB24D,#B9B14B,#C6AF4A,#D2AD4A,#DDAB4D,#E9A951,#F3A757';
        $colors =  explode(',', $string);
        return $colors[random_int(0, count($colors) - 1)];
    }

    /**
     * @return JsonResponse
     * @throws Exception
     */
    public function index(){

        $blocks = [
            'total' => 0 ,
            'aborted' => 0 ,
            'blocking' => 0 ,
            'posting' => 0 ,
        ];

        $side = MonitorSAFStats::query()->limit(count($this->sink))->orderBy('stamp' , 'desc')->get();

        // blocks
        $d = MonitorSAFStats::query()->groupBy(['stamp'])->limit(2)->orderBy('stamp' , 'desc')->first([
            'stamp',
            DB::raw('sum(count) as sum')
        ]);
        // Total SAF
        $blocks['total'] = $d ? $d->sum : 0;
        $blocks['posting'] = $d ? Carbon::createFromFormat('Y-m-d H:i:s' , $d->stamp )->diffForHumans() : 0;

        // Aborted
        $blocks['aborted']  = MonitorSAFBlocked::query()->where('cleared' , '=' , false)->count();


        $labels = [];
        $datasets = [];
        $number  = 150;
        $data =  MonitorSAFStats::query()
                     ->limit($number)->where('sink_node' , '=' , 'Agri24Host')
                        ->orderBy('stamp' ,'desc')
                    ->get();

        $flow = $data->groupBy('stamp')->reverse()->toArray();
        foreach ($flow as $key => $item )
        {
            $labels[] = $key . " - " .  Carbon::createFromFormat('Y-m-d H:i:s' , $key)->diffForHumans();
//            $labels[] =  $key;
            $total  = 0;
            foreach ($item as $value)
            {
                $total += $value['count'];
                $datasets[$value['sink_node']]['data'][] = (int)$value['count'];
                if((int)$value['count'] <= 1000 ){
                    $datasets[$value['sink_node']]['backgroundColor'][] = '#58D68D ';
                } else if ((int)$value['count'] > 1000 && (int)$value['count'] < 6000){
                    $datasets[$value['sink_node']]['backgroundColor'][] = '#5499C7 ';
                } else {
                    $datasets[$value['sink_node']]['backgroundColor'][] = '#E74C3C';
                }
            }
        }

        $chart =  [ 'datasets' =>  collect($datasets)->values()  , 'labels' => $labels ];

        $stats = ReportStats::query()->limit(
            SAFReport::query()->count()
        )->with('report')->orderByDesc('id')->get();

        return api()
                ->data('chart' , $chart)
                ->data('reports' ,$stats )
                ->data('side' , $side)
                ->data('blocks' , $blocks)
                ->data('logs' ,  MonitorLog::query()->limit(20)->latest('id')->get())
                ->data('blocking' ,  MonitorSAFInflight::query()->where('duration', '>' , '0')->orderBy('duration' , 'desc')->get())
            ->build();

    }

    public function saf()
    {

        $blocks = [
            'total' => 0 ,
            'last_check' => 'null' ,
            'aborted' => MonitorSAFBlocked::query()->where('cleared' , '=' , false)->count() ,
            'pending_post' => MonitorSAFBlocked::query()->where('cleared' , '=' , false)->count() ,
        ];

        $last = MonitorSAFInflight::query()->orderByDesc('id')->first();

        if ($last)
        {
            $blocks['last_check'] = $last->updated_at->diffForHumans();
        }

        return api()
                ->data('logs' ,  MonitorLog::query()->limit(50)->latest('id')->get())
                ->data('blocks' , $blocks)
                ->data('reports' , GeneratedReport::query()->latest()->limit(20)->get())
                ->data('aborted' , MonitorSAFBlocked::query()->latest()->limit(20)->get())
                ->data('blocking' , MonitorSAFInflight::query()->where('duration', '>' , '0')->orderBy('duration' , 'desc')->get())
            ->build();
    }

    public function abort($tran){

        // get tran from postilion

        try {

            $transaction = $this->getTable('tm_trans')
                ->where('state' , '<' , '99')
                ->where('tran_nr' , '=' , $tran)
                ->first();

            if ($transaction)
            {

                MonitorSAFBlocked::query()->create([
                    'cleared' => false ,
                    'pan' =>  $transaction->pan,
                    'card_acceptor_term_id' =>  $transaction->card_acceptor_term_id,
                    'rsp_code_req_rsp' =>  $transaction->rsp_code_req_rsp ,
                    'in_req' =>  $transaction->in_req,
                    'tran_nr' =>  $transaction->tran_nr,
                    'sink_node' =>  $transaction->sink_node,
                    'source_node' =>  $transaction->source_node,
                    'tran_type' =>  $transaction->tran_type,
                    'srcnode_amount_final' =>  $transaction->srcnode_amount_final / 100,
                    'state' =>  $transaction->state,
                ]);

                MonitorSAFInflight::query()->where('tran_nr' ,'=', $tran)->delete();

//            $this->getTable('tm_trans')
//                ->where('tran_nr' , '=' , $tran)
//                ->update([
//                    'state' => 100
//                ]);

                return api()
                    ->message('Tran #' . $tran . ' was successfully aborted')
                    ->build();
            }

            throw  new Exception();

        } catch (Exception $exception){
            return api()
                ->message('Tran #' . $tran . ' not found')
                ->build();
        }

    }

    public function generate(){

        $transactions = MonitorSAFBlocked::query()->where('cleared' , '=' , false)->get();

        if ( $transactions->count() > 0 ){

            $full = storage_path('app/public/reports/'.Str::random(90).'.txt' );

            $gen = GeneratedReport::query()->create([
                'path' => $full
            ]);

            $full = fopen($full,"w+");

            foreach ($transactions as $transaction)
            {
                $output = "{$transaction->tran_nr},{$transaction->tran_nr},";
                $output .= "{$transaction->tran_nr},{$transaction->pan},";
                $output .= "{$transaction->tran_nr},{$transaction->card_acceptor_term_id},";
                $output .= "{$transaction->tran_nr},{$transaction->rsp_code_req_rsp},";
                $output .= "{$transaction->tran_nr},{$transaction->in_req},";
                $output .= "{$transaction->tran_nr},{$transaction->sink_node},";
                $output .= "{$transaction->tran_nr},{$transaction->source_node},";
                $output .= "{$transaction->tran_nr},{$transaction->tran_type},";
                $output .= "{$transaction->tran_nr},{$transaction->srcnode_amount_final},";
                $output .= "{$transaction->tran_nr},{$transaction->state},";
                $output .= PHP_EOL;

                fwrite( $full , $output );

                $transaction->update([
                    'cleared' => true,
                ]);

            }

            fclose($full);

            return api()
                     ->message('Report Created')
                 ->build();
        }

        return api()
                ->message('No transactions found')
            ->build();


    }

    public function download(GeneratedReport $report)
    {
        if (file_exists($report->path))
        {
            $name =  strtolower(str_slug(GeneratedReport::class))
                . '-' . $report->id
                . '-' . now()->format('Y-m-d|H:i:s')
                . ".txt";
            return response()->download($report->path , $name);
        }
        return api()->message('File not found')->build();
    }

}
