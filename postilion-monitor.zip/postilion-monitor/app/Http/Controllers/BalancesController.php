<?php

namespace App\Http\Controllers;

use App\Balance;
use App\BalanceUpdatesLog;
use App\Deltas;
use App\filters\BalancesFilter;
use App\Jobs\BalanceUpdateJob;
use App\Transaction;
use Illuminate\Http\Request;

class BalancesController extends Controller
{
    public function index(BalancesFilter $filter){

        $balances = Balance::filter($filter , [

        ])->paginate(\request('size') ?? 30 );

        return api()
                ->data('balances' , $balances)
                ->data("filters", $filter->documentation)
            ->build();


    }

    public function view(Balance $account){

        $deltas = Deltas::query()->where('account_id' , $account->account_id)->get();
        $transactions = Transaction::query()->where('account_id' , $account->account_id)->limit(20)->orderBy('row_id' , 'desc')->get();
        $logs  = BalanceUpdatesLog::query()->with('user')
            ->where('account' , $account->account_id)->limit(10)
            ->orderBy('id' , 'desc')->get();

        $actual = $account->available_balance + $deltas->sum('available_balance');

        return api()
                ->data('account' , $account)
                ->data('actual' , $actual)
                ->data('deltas' , $deltas)
                ->data('transactions' , $transactions)
                ->data('logs' , $logs)
            ->build();

    }


    public function edit(Request $request , Balance $account){


        $request->validate([
            'available' =>  ['required' , 'integer'],
            'ledger' =>  ['required' , 'integer'],
        ]);

        // log

        BalanceUpdatesLog::query()->create([
           'user_id' => auth()->id(),
           'account' =>  $account->account_id,
           'ledger_balance' =>  $request->get('ledger'),
           'available_balance' =>  $request->get('available'),
        ]);

        // Call JOB

        $this->dispatch(new BalanceUpdateJob($account->account_id ,$request->get('available' ),$request->get('ledger')));

        return api()
                ->message('Account Update Queued , please refresh in a moment')
            ->build();

    }
}
