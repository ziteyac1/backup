<?php

namespace App\Http\Controllers;

use App\Entities\core\Audit;
use App\Entities\core\Role;
use App\filters\AuditFilter;
use App\filters\PermissionFilter;
use App\filters\RoleFilter;
use App\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Permission;

class RoleController extends Controller
{
    /**
     * @param RoleFilter $filter
     * @return JsonResponse
     */
    public function index(RoleFilter $filter) : JsonResponse
    {
        $roles  = Role::filter($filter , [

        ])->paginate(\request('size') ?? 30);
        return api()
            ->data('roles' , $roles)
            ->data('filters' , $filter->documentation)
            ->build();

    }

    /**
     * @return JsonResponse
     */
    public function create() : JsonResponse
    {
        return api()
            ->data('permissions' , Permission::all())
            ->build();
    }

    public function store(Request $request) : RedirectResponse
    {
        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'permissions' => ['required'],
        ]);

        /**
         * @var Role $role
         * @noinspection VirtualTypeCheckInspection
         */

        $role = Role::query()->create([
            'name' => $request->get('name')
        ]);

        $permissions = Permission::query()->whereIn('id' , $request->get('permissions'))->get();
        $role->givePermissionTo($permissions);

        return back()->with('message' , 'Role was created successfully');
    }

    /**
     * @param Role $role
     * @return JsonResponse
     */
    public function view(Role $role) : JsonResponse
    {
        return api()
            ->data('role' , $role)
            ->data('permissions' , $role->permissions()->get())
            ->build();
    }

    /**
     * @param Role $role
     * @return JsonResponse
     */
    public function edit(Role $role) : JsonResponse
    {
        return api()
            ->data('role' , $role)
            ->data('permissions' , $role->permissions()->get())
            ->data('all' , Permission::all())
            ->build();
    }


    /**
     * @param Request $request
     * @param Role $role
     * @return RedirectResponse
     */
    public function update(Request $request , Role $role) : RedirectResponse
    {

        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'permissions' => ['required'],
        ]);


        $role->update([
            'name' => $request->get('name'),
        ]);

        $permissions = Permission::query()->whereIn('id' , $request->get('permissions'))->get();
        $role->syncPermissions($permissions);

        return back()->with('message' , 'Role was updated successfully');
    }


    /**
     * @param Role $role
     * @param AuditFilter $filter
     * @return JsonResponse
     */
    public function timeline(Role $role  , AuditFilter $filter) : JsonResponse
    {
        $audits = Audit::filter($filter , [
            'auditable_type' => Role::class,
            'auditable_id' => $role->id,
        ])->with('user')->paginate(\request('size') ?? 30 );

        return api()
            ->data('audits',$audits)
            ->data('filters' , $filter->documentation)
            ->build();
    }

    /**
     * @param Role $role
     * @param PermissionFilter $filter
     * @return JsonResponse
     */
    public function permissions(Role $role , PermissionFilter $filter) : JsonResponse
    {

        $permissions = \App\Entities\core\Permission::filter($filter , [
            'roles.id' => $role->id,
        ])->paginate(\request('size') ?? 30 );

        return api()
            ->data('permissions',$permissions)
            ->data('filters' , $filter->documentation)
            ->build();
    }

}
