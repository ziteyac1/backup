<?php

namespace App\Http\Controllers;

use App\filters\SAFRequestFilter;
use App\Jobs\AbortTransactions;
use App\SAFReport;
use App\SAFRequest;
use Illuminate\Http\Request;

class SAFRequestController extends Controller
{
    public function index(SAFRequestFilter $filter ){

        $overrides = [];
        $requests =  SAFRequest::filter($filter , $overrides)->with(['report' ,'user'])->paginate(\request('size') ?? 30 );
        return api()
            ->data('requests' , $requests)
            ->data('filters' , $filter->documentation)
            ->build();

    }

    public function view(SAFRequest $request){

        $request->load(['report.parameters' ,'user']);

        return api()
            ->data('request' , $request)
            ->build();
    }

    public function abort(SAFRequest $request){

        $request->update([
            'aborted_at' => now()
        ]);

        $this->dispatch(new AbortTransactions($request));

        $request->load(['report.parameters' ,'user']);

        return api()
                ->data('request' , $request)
            ->build();
    }

    public function download(SAFRequest $request){

        if (file_exists($request->tnx_full_path))
        {
            $report  = $request->report;
            $name =  strtolower(str_slug($report->name)) . '-' . now()->format('Y-m-d|H:i:s') . ".txt";
            return response()->download($request->tnx_full_path , $name);
        }

        return api()->message('File not found')->build();
    }


}
