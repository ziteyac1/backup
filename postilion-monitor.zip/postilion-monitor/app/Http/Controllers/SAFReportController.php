<?php

namespace App\Http\Controllers;

use App\core\model\DBHelper;
use App\filters\SAFReportFilter;
use App\filters\UserFilter;
use App\Jobs\ExtractTransactions;
use App\ReportStats;
use App\SAFReport;
use App\SAFRequest;
use App\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class SAFReportController extends Controller
{
    use DBHelper;
    /**
     * @param SAFReportFilter $filter
     * @return JsonResponse
     */
    public function index(SAFReportFilter $filter) : JsonResponse
    {
        $overrides = [];
        $users =  SAFReport::filter($filter , $overrides)->paginate(\request('size') ?? 30 );
        return api()
            ->data('reports' , $users)
            ->data('filters' , $filter->documentation)
            ->build();
    }

    public function store(Request $request){

        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['required', 'string', 'max:255'],
            'order_column' => ['required', 'string', 'max:255'],
            'order_direction' => ['required', 'string', 'max:255'],
        ]);

        /** @var SAFReport $report */
        $report = SAFReport::query()->create([
            'name' => $request->get('name'),
            'description' => $request->get('description'),
            'order_column' => $request->get('order_column'),
            'order_direction' => $request->get('order_direction'),
        ]);

        foreach ($request->get('parameters') as $parameter ){
            $report->parameters()->create([
               'field' => $parameter['field'],
               'sign' => $parameter['sign'],
               'value' => $parameter['value'],
            ]);
        }

        return api()->message('Report was created successfully')->build();

    }

    public function update(Request $request  , SAFReport $report){

        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['required', 'string', 'max:255'],
            'order_column' => ['required', 'string', 'max:255'],
            'order_direction' => ['required', 'string', 'max:255'],
        ]);

        /** @var SAFReport $report */
        $report->update([
            'name' => $request->get('name'),
            'description' => $request->get('description'),
            'order_column' => $request->get('order_column'),
            'order_direction' => $request->get('order_direction'),
        ]);

        $report->parameters()->delete();

        foreach ($request->get('parameters') as $parameter ){
            $report->parameters()->create([
               'field' => $parameter['field'],
               'sign' => $parameter['sign'],
               'value' => $parameter['value'],
            ]);
        }

        return api()->message('Report was updated successfully')->build();

    }

    public function view(SAFReport $report)
    {

        $labels = [];
        $datasets = [];

        foreach ( ReportStats::query()
                     ->where('report_id' , '=' ,$report->id)
                     ->limit(150)->orderBy('id' , 'desc')
                     ->get()->reverse() as $stat ){
            $labels[] = $stat->stamp;
            $datasets['count']['data'][] = (int)$stat->count;

            if((int)$stat->count <= 2000 ){
                $datasets['count']['backgroundColor'][] = '#58D68D ';
            } else if ((int)$stat->count > 2000 && (int)$stat->count < 4000 ){
                $datasets['count']['backgroundColor'][] = '#5499C7 ';
            } else {
                $datasets['count']['backgroundColor'][] = '#E74C3C';
            }

        }

        $chart =  [ 'datasets' =>  collect($datasets)->values()  , 'labels' => $labels ];

        $report->load('parameters');
        return api()
                ->data('report' , $report)
                ->data('top' , ReportStats::query()
                    ->where('report_id' , '=' ,$report->id)
                    ->limit(4)->orderBy('id' , 'desc')->with('report')
                    ->get()->reverse()->values()
                )
                ->data('chart' , $chart)
            ->build();
    }

    public function request(SAFReport $report){

        // Create Request

        $start = \request()->get('start') ?? now()->subDay();
        $end = \request()->get('end') ?? now();

        /** @var SAFRequest $request */
        $request = SAFRequest::query()->create([
           'user_id' => auth()->id(),
           'report_id' => $report->id,
           'state' => 'Sent to queue',
           'start' => $start,
           'end' => $end,
        ]);

        $this->dispatch(new ExtractTransactions($request));

        return api()->message('Request was created successfully please check queue')->build();

    }

    public function run(SAFReport $report)
    {

        // Get Transactions Summary

        $start = \request()->get('start') ?? now()->subDay();
        $end = \request()->get('end') ?? now();

        $builder = $this->getTable('tm_trans')
            ->whereBetween('in_req' , [
                $start , $end
            ]);

        foreach ($report->parameters()->get() as $parameter)
        {
            $builder = $builder->where($parameter->field , $parameter->sign , $parameter->value );
        }

        $overview =  $builder->first(
            [
                DB::raw('COUNT(snknode_amount_final) as count') ,
                DB::raw('SUM(snknode_amount_final) / 100 as sum')
            ]
        );

        $report->load('parameters');

        return api()
                ->data('report' , $report)
                ->data('overview' , $overview)
            ->build();
    }
}
