<?php

namespace App\Http\Controllers;

use App\Entities\core\Audit;
use App\filters\AuditFilter;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class ProfileController extends Controller
{
    /**
     * @return JsonResponse
     */
    public function view() : JsonResponse
    {
        $user = auth()->user();
        $user->load('roles' , 'permissions');
        return api()
                ->data('user',$user)
            ->build();
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function edit(Request $request) : JsonResponse
    {

        $request->validate([
           'name' => ['required'],
           'last_name' => ['required'],
        ]);

        $user = auth()->user();

        $user->update([
            'name' => $request->get('name'),
            'last_name' => $request->get('last_name'),
        ]);

        return api()
                ->data('user',$user)
            ->build();
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function password(Request $request) : JsonResponse
    {

        $request->validate([
            'old_password' => ['required','current_password'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ],[
            'old_password.current_password' => 'Your old password is wrong'
        ]);

        $user = auth()->user();

        $user->update([
            'password' => Hash::make($request->get('password'))
        ]);

        return api()->message('Password Updated')->build();

    }

    /**
     * @param AuditFilter $filter
     * @return JsonResponse
     */
    public function activity(AuditFilter $filter) : JsonResponse
    {

        $user = auth()->user();

        $audits = Audit::filter($filter , [
            'user_id' => $user->id,
        ])->with('user')->paginate(\request('size') ?? 30 );
        return api()
                ->data('audits',$audits)
                ->data('filters' , $filter->documentation)
            ->build();
    }

    /**
     * @return JsonResponse
     */
    public function notificationsMini() : JsonResponse
    {
        $user = auth()->user();
        $notification = $user->notifications()->latest()->limit(8)->get();
        return api()
                ->data('notification',$notification)
            ->build();
    }

    /**
     * @return JsonResponse
     */
    public function notifications() : JsonResponse
    {
        $user = auth()->user();
        $notification = $user->notifications()->paginate(\request('size') ??  30);
        return api()
                ->data('notifications',$notification)
                ->data('filters',[])
            ->build();
    }
}
