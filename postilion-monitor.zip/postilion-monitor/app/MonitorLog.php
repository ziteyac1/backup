<?php

namespace App;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;

/**
 * @property Carbon created_at
 */
class MonitorLog extends Model implements Auditable
{
    use \OwenIt\Auditing\Auditable;
    protected $guarded = [];

    protected $appends = ['last_update'];

    public function getLastUpdateAttribute(){
        return $this->created_at->diffForHumans();
    }
}
