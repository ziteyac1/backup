<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SAFReportParameters extends Model implements \OwenIt\Auditing\Contracts\Auditable
{
    use \OwenIt\Auditing\Auditable;
    protected $guarded = [];
}
