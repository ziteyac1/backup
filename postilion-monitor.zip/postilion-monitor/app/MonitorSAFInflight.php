<?php

namespace App;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;

/**
 * @property Carbon created_at
 */
class MonitorSAFInflight extends Model implements Auditable
{
    use \OwenIt\Auditing\Auditable;
    protected $guarded = [];
}
