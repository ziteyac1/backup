<?php

namespace App;

use App\filters\core\HasModelFilter;
use Illuminate\Database\Eloquent\Model;

/**
 * @property mixed id
 * @property mixed order_column
 * @property mixed order_direction
 * @property mixed name
 */
class SAFReport extends Model implements \OwenIt\Auditing\Contracts\Auditable
{
    use HasModelFilter, \OwenIt\Auditing\Auditable;
    protected $guarded = [];

    public function parameters()
    {
        return $this->hasMany(SAFReportParameters::class , 'report_id' , 'id');
    }

}
