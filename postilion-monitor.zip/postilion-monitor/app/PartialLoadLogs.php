<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PartialLoadLogs extends Model
{
    protected $guarded = [];
}
