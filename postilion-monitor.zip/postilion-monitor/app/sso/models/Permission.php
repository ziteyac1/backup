<?php


namespace App\sso\models;


class Permission extends  \App\Entities\core\Permission
{
    protected $connection = 'sso';
}
