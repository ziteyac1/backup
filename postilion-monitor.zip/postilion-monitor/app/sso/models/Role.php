<?php


namespace App\sso\models;


use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Role extends \App\Entities\core\Role
{
    protected $connection = 'sso';

    /**
     * A model may have multiple direct permissions.
     */

    /**
     * A role may be given various permissions.
     */
    public function permissions(): BelongsToMany
    {
        return $this->belongsToMany(
            Permission::class,
            config('permission.table_names.role_has_permissions'),
            'role_id',
            'permission_id'
        );
    }
}
