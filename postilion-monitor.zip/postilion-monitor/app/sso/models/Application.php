<?php

namespace App\sso\models;

use App\core\model\ModelAttributeCommons;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use OwenIt\Auditing\Auditable;

/**
 * @property mixed id
 * @property mixed link
 * @property mixed name
 */
class Application extends Model implements \OwenIt\Auditing\Contracts\Auditable
{
    use Auditable , ModelAttributeCommons;
    protected $appends = ['last_update' , 'select_name'];
    protected $guarded = [];
    protected $connection = 'sso';

    /**
     * @return BelongsToMany
     */
    public function users() : BelongsToMany {

        return $this->belongsToMany(User::class ,
            'user_applications' ,
            'application_id',
            'user_id'
        )->using(UserApplication::class)->withPivot([
            'created_at',
            'updated_at',
        ])->withTimestamps();

    }

    public function getSelectNameAttribute() : string {
        return $this->name . " - " .$this->link;
    }
}
