<?php

namespace App\sso\models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\Pivot;
use OwenIt\Auditing\Contracts\Auditable;

class UserApplication extends Pivot
{
    protected $connection = 'sso';
}
