<?php


namespace App\sso\services;


use App\sso\models\Role;
use Spatie\Permission\PermissionRegistrar;

class RoleService
{
        public function sync(){

            // Remove cached of permissions

            /** @var PermissionRegistrar $permissionRegistrar
             * @noinspection VirtualTypeCheckInspection
             */

            $permissionRegistrar = app()[PermissionRegistrar::class];
            $permissionRegistrar->forgetCachedPermissions();

            $ssoRoles = Role::query()
                ->where('application_id' , '=' , env('APP_ID'))
                ->get();

            $names = [];
            /** @var Role $role */
            foreach ($ssoRoles as $role)
            {
                $names[] = $role->name;
                $this->syncRole($role);
            }

            \App\Entities\core\Role::query()->whereNotIn('name' , $names)->delete();

        }

        public function syncRole($role)
        {
            /** @var \App\Entities\core\Role $moduleRole */
            $moduleRole = \App\Entities\core\Role::query()->updateOrCreate([
                'name' => $role->name
            ],[
                'name' => $role->name
            ]);

            $permissions = $role->permissions()->get();

            $moduleRolePermissions  = \App\Entities\core\Permission::query()
                ->whereIn('name' , $permissions->map(function ($d){
                    return $d->name;
                })->values()->toArray())->get();

            $moduleRole->syncPermissions( $moduleRolePermissions->map(function ($d){
                return $d->id;
            })->values()->toArray());
        }
}
