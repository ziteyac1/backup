<?php


namespace App\sso\services;


use App\sso\models\Permission;
use Spatie\Permission\PermissionRegistrar;

class PermissionService
{
    public function sync(){

        // Remove cached of permissions

        /** @var PermissionRegistrar $permissionRegistrar
         * @noinspection VirtualTypeCheckInspection
         */

        $permissionRegistrar = app()[PermissionRegistrar::class];
        $permissionRegistrar->forgetCachedPermissions();

        // Get Permissions from Single Sign on

        $ssoPermissions = Permission::query()
            ->where('application_id' , '=' , env('APP_ID'))
            ->get();

        $names = [];

        foreach ($ssoPermissions as $permission)
        {
            $names[] = $permission->name;
            $this->syncPermission($permission);
        }

        // Clear Permissions Not Found at SSO Server

        \App\Entities\core\Permission::query()->whereNotIn('name' , $names)->delete();

    }

    /**
     * @param $permission
     */

    public function syncPermission($permission) : void {
        \App\Entities\core\Permission::query()->updateOrCreate([
            'name' => $permission->name
        ],[
            'name' => $permission->name
        ]);
    }
}
