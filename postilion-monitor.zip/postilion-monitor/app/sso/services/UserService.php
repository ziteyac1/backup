<?php


namespace App\sso\services;


use App\Entities\core\Permission;
use App\sso\models\Application;
use App\sso\models\Role;
use App\sso\models\User;
use Spatie\Permission\PermissionRegistrar;

class UserService
{
    public function sync(){

        /** @var PermissionRegistrar $permissionRegistrar
         * @noinspection VirtualTypeCheckInspection
         */

        $permissionRegistrar = app()[PermissionRegistrar::class];
        $permissionRegistrar->forgetCachedPermissions();

        /** @var Application $application */
        $application  = Application::query()->find(env('APP_ID'));

        if ($application)
        {
            $emails = [];
            /** @var User $user */
            foreach ($application->users()->get() as $user )
            {
                $emails[] = $user->email;
                $this->syncUser($user);
            }
        }
    }

    public function syncUser($user){

        $userSSOArray = $user->toArray();
        $a = explode("," , env('APP_SSO_USER_INFO'));
        $b = [];
        $c = [
            'email' => $userSSOArray['email']
        ];

        foreach ($a as $item)
        {
            $b[$item] = $userSSOArray[$item];
        }

        /** @var \App\User $moduleUser */
        $moduleUser = \App\User::query()->updateOrCreate( $c , $b );
        $roles = $user->roles()->where('application_id' , '=' , env('APP_ID'))->get();

        $moduleUserRoles = \App\Entities\core\Role::query()
            ->whereIn('name' , $roles->map(function ($value){
                return $value->name;
            })->values()->toArray())->get();

        $moduleUser->syncRoles($moduleUserRoles->map(function ($value){
            return $value->id;
        })->values()->toArray());

        $permissions = $user->permissions()->where('application_id' , '=' , env('APP_ID'))->get();

        $moduleUserPermissions = Permission::query()
            ->whereIn('name' , $permissions->map(function ($value){
                return $value->name;
            })->values()->toArray())->get();

        $moduleUser->syncPermissions($moduleUserPermissions->map(function ($value){
            return $value->id;
        })->values()->toArray());

    }

}
