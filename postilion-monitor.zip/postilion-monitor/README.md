To install

run composer install and npm install and @php -r "file_exists('.env') || copy('.env.example', '.env');" and @php artisan key:generate --ansi

