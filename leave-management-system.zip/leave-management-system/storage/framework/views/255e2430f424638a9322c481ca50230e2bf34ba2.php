<div class="col-lg order-lg-first">
    <ul class="nav nav-tabs border-0 flex-column flex-lg-row">
        <li class="nav-item">
            <a href="/home" class="nav-link"><i class="fe fe-home"></i> Home</a>
        </li>

        <li class="nav-item dropdown">
            <a href="javascript:void(0)" class="nav-link" data-toggle="dropdown"><i class="fe fe-calendar"></i>Requests</a>
            <div class="dropdown-menu dropdown-menu-arrow">
                <a href="/requests" class="dropdown-item dropdown">My Requests</a>
                <?php if(auth()->check() && auth()->user()->hasRole('human resources')): ?>
                    <a href="/requests/all" class="dropdown-item dropdown">All Requests</a>
                <?php endif; ?>
            </div>
        </li>
        <?php if(auth()->check() && auth()->user()->hasRole('human resources')): ?>
        <li class="nav-item">
            <a href="/users" class="nav-link"><i class="fe fe-users"></i> Users</a>
        </li>
        <?php endif; ?>
        <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
            <li class="nav-item">
                <a href="/horizon" class="nav-link"><i class="fe fe-server"></i> Monitor </a>
            </li>
        <?php endif; ?>

        <li class="nav-item dropdown">
            <a href="javascript:void(0)" class="nav-link" data-toggle="dropdown"><i class="fa fa-book"></i>Reports</a>
            <div class="dropdown-menu dropdown-menu-arrow">
                <a href="/reports/individual" class="dropdown-item">My Report</a>
                <a href="/reports/departmental" class="dropdown-item">Departmental</a>
                <?php if(auth()->check() && auth()->user()->hasRole('human resources')): ?>
                    <a href="/reports/organisational" class="dropdown-item">Organisational</a>
                <?php endif; ?>
        </div>
        </li>
        <li class="nav-item">
            <a href="/manual" class="nav-link"><i class="fa fa-book"></i> User Manual</a>
        </li>
    </ul>
</div>
<?php /**PATH C:\Users\cziteya\PhpstormProjects\leave-management-system\resources\views/includes/nav.blade.php ENDPATH**/ ?>