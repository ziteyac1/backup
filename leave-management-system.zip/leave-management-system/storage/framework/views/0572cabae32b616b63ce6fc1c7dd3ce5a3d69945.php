<?php $__env->startSection('title', __('Server Error')); ?>
<?php $__env->startSection('code', '500'); ?>
<?php $__env->startSection('message', __('Server Error')); ?>

<?php $__env->startSection('image'); ?>
<img src="images/errors/500.svg" alt="">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors::illustrated-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zuvarashe\PhpstormProjects\leave-management-system\resources\views/errors/500.blade.php ENDPATH**/ ?>