<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-3">
            <div class="card card-profile">
                <div class="card-header" style="background-image: url('<?php echo e(asset('images/pic2.jpeg')); ?>');"></div>
                <div class="card-body text-center">
                    <img class="card-profile-img" style="height: 100px;width: 100px" src="<?php echo e(asset('images/avatar.png')); ?>">
                    <h3 class="mb-3"><?php echo e($user->name); ?> <?php echo e($user->last_name); ?></h3>
                    <small class="text-muted d-block mt-1"><?php echo e($user->job_title); ?></small>
                </div>
            </div>

        </div>
        <div class="col-lg-9">
            <form class="card"  method="post">
                <?php if(session()->has('message')): ?>
                    <div class="card-alert alert alert-success text-center">
                       <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <h3 class="card-title">Edit Profile</h3>
                    <div class="row">
                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label for="emp_num" class="form-label">Employee Number</label>
                                <input type="text" name="emp_num" id="emp_num" class="form-control <?php echo e($errors->has('emp_num') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('emp_num',$user->emp_num)); ?>">
                                <?php $__errorArgs = ['emp_num'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     <div class="invalid-feedback" role="alert"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label for="job_title" class="form-label">Job Title</label>
                                <input type="text" name="job_title" id="emp_num" class="form-control <?php echo e($errors->has('job_title') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('job_title',$user->job_title)); ?>">
                                <?php $__errorArgs = ['job_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     <div class="invalid-feedback" role="alert"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12">
                            <div class="form-group">
                                <label for="address" class="form-label">Address</label>
                                <input type="text" name="address" id="address" class="form-control <?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('address',$user->address)); ?>">
                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     <div class="invalid-feedback" role="alert"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label for="address" class="form-label">Gender</label>
                                <select id="address" class="custom-select <?php echo e($errors->has('gender') ? ' is-invalid' : ''); ?>" name="gender">
                                    <option value="">Choose Gender</option>
                                    <option value="male" <?php echo e(old('gender',$user->gender) == 'male' ? 'selected':''); ?>>Male</option>
                                    <option value="female" <?php echo e(old('gender',$user->gender) =='female' ? 'selected':''); ?>>Female</option>
                                </select>
                                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback" role="alert"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label for="mobile_number" class="form-label">Mobile Number</label>
                                <input type="text" name="mobile_number" id="address" class="form-control <?php echo e($errors->has('mobile_number') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('mobile_number',$user->mobile_number)); ?>">
                                <?php $__errorArgs = ['mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback" role="alert"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label for="office_number" class="form-label">Office Number</label>
                                <input type="text" name="office_number" id="office_number" class="form-control <?php echo e($errors->has('office_number') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('office_number',$user->office_number)); ?>">
                                <?php $__errorArgs = ['office_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback" role="alert"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label for="location" class="form-label">Location</label>
                                <select class="custom-select <?php echo e($errors->has('location') ? ' is-invalid' : ''); ?>" name="location">
                                    <option value="">Choose Location</option>
                                    <?php $__currentLoopData = \App\Location::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($location->id); ?>" <?php echo e(old( 'location' , $user->location_id ) == $location->id ? 'selected':''); ?>><?php echo e($location->location_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback" role="alert"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label for="supervisor_email" class="form-label">Supervisor Email</label>
                                <input type="text" name="supervisor_email" id="supervisor_email" class="form-control <?php echo e($errors->has('supervisor_email') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('supervisor_email',$user->supervisor_email)); ?>">
                                <?php $__errorArgs = ['supervisor_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback" role="alert"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label for="authorisations_to_hr" class="form-label">No of Authorisations</label>
                                <input type="text" name="authorisations_to_hr" id="authorisations_to_hr" class="form-control <?php echo e($errors->has('authorisations_to_hr') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('authorisations_to_hr',$user->auth_to_hr)); ?>">
                                <?php $__errorArgs = ['auth_to_hr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback" role="alert"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>



                    </div>
                </div>
                <div class="card-footer text-right">
                    <button type="submit" class="btn btn-outline-success">Update Profile</button>
                </div>
            </form>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main',['title'=>'','active'=>''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cziteya\PhpstormProjects\leave-management-system\resources\views/leave/profile.blade.php ENDPATH**/ ?>