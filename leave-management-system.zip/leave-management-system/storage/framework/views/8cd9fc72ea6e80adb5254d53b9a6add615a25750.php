<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success rounded-0 text-center">
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>
        </div>
        <div class="col-lg-12">
            <div class="card">
                <div class="table-responsive">
                    <table class="table table-hover table-outline table-vcenter -nowrap card-table">
                        <thead>
                        <tr>
                            <th class="">ID</th>
                            <th class="">Dates</th>
                            <th class="">Other Details</th>
                            <th class="">Requester</th>
                            <th class="">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-primary">#<?php echo e($leave->id); ?></td>
                                <td>
                                    <div>Start : <?php echo e($leave->start_date->format('Y-m-d')); ?></div>
                                    <div>End : <?php echo e($leave->end_date->format('Y-m-d')); ?></div>
                                    <div>Days : <?php echo e($leave->days); ?></div>
                                </td>
                                <td>
                                    <div>Type : <?php echo e($leave->type->name); ?></div>
                                    <?php if($leave->completed == false): ?>
                                        <div>Status : <span class="tag tag-yellow"><?php echo e($leave->status); ?></span></div>
                                    <?php endif; ?>
                                    <?php if($leave->status == 'Authorized'): ?>
                                        <div>Status : <span class="tag tag-green"><?php echo e($leave->status); ?></span></div>
                                    <?php endif; ?>
                                    <?php if($leave->status == 'Rejected'): ?>
                                        <div>Status : <span class="tag tag-red"><?php echo e($leave->status); ?></span></div>
                                    <?php endif; ?>
                                    <?php if($leave->document_name): ?>
                                        <div><a target="_blank" href="/leaves/<?php echo e($leave->id); ?>/download">Document : <?php echo e($leave->document_name); ?></a></div>
                                    <?php endif; ?>
                                    <?php if($leave->leave_notes): ?>
                                        <div><span>Notes: <?php echo e(\Illuminate\Support\Str::limit($leave->leave_notes , 20 , '...' )); ?></span></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div>Name : <?php echo e($leave->user->full_name); ?></div>
                                    <div>Email : <?php echo e($leave->user->email); ?></div>
                                </td>
                                <td class="text">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view' , $leave)): ?>
                                        <div><a href="/leaves/<?php echo e($leave->id); ?>/view">View</a></div>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('authorize' , $leave)): ?>
                                        <div><a href="/leaves/<?php echo e($leave->id); ?>/authorize">Authorize</a></div>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reject' , $leave)): ?>
                                        <?php if(!$leave->completed): ?>
                                        <div><a href="" data-toggle="modal" data-target="#myModal" >Reject</a></div>
                                        <div id="myModal" class="modal fade" role="dialog">
                                                <div class="modal-dialog">
                                                    <form action="/leaves/<?php echo e($leave->id); ?>/reject" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <!-- Modal content-->
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <button type="button" class="close bg-red" data-dismiss="modal">&times;</button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="row">
                                                                    <div class="col-lg-12">
                                                                        <label for="">Leave Notes (Optional)</label>
                                                                        <input type="text" name="leave_notes" id="leave_notes" class="form-control">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button class="btn btn-outline-danger" type="submit"> Reject</button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <div class="mt-3 d-flex justify-content-center align-items-center">
                        <?php echo e($leaves->render()); ?>

                    </div>

                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main',['title'=>'','active'=>''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cziteya\PhpstormProjects\leave-management-system\resources\views/leave/list.blade.php ENDPATH**/ ?>