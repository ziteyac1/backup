<div class="header py-4">
    <div class="container">
        <div class="d-flex">
            <a class="header-brand" href="/home">
                <h4><img src="<?php echo e(asset('images/logo.png')); ?>" class="header-brand-img" alt="tabler logo">Agri-Leave</h4>
            </a>
            <div class="d-flex order-lg-2 ml-auto">

                
                <div class="dropdown">
                    <a href="#" class="nav-link pr-0 leading-none" data-toggle="dropdown">
                        <span class="avatar" style="background-image: url('<?php echo e(asset('images/logo.png')); ?>')"></span>

                        <span class="ml-2 d-none d-lg-block">
                      <span class="text-default"><?php echo e(auth()->user()->full_name); ?></span>
                      <small class="text-muted d-block mt-1"><?php echo e(auth()->user()->job_title); ?></small>
                    </span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                        <a class="dropdown-item" href="/profile">
                            <i class="dropdown-icon fe fe-user"></i> Profile
                        </a>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            <i class="dropdown-icon fe fe-log-out"></i> Sign out
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </div>
            </div>
            <a href="#" class="header-toggler d-lg-none ml-3 ml-lg-0" data-toggle="collapse" data-target="#headerMenuCollapse">
                <span class="header-toggler-icon"></span>
            </a>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\cziteya\PhpstormProjects\leave-management-system\resources\views/includes/header.blade.php ENDPATH**/ ?>