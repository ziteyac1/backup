@extends('layouts.main',['title'=>'','active'=>''])

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-4 text-center">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        User Balances
                    </h3>
                </div>
                <div class="card-body">
                    <table class="table card-table">
                        <thead>
                        <tr>
                            <th>Leave Name</th>
                            <th>Balance</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($balances as $balance)
                            <tr>
                                <td>{{ $balance->type->name }}</td>
                                <td class="text"><span class="text-muted">{{ $balance->balance }}</span></td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-4 text-center">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Edit User Information</h3>
                </div>

                <div class="">
                    @if(session()->has('message'))
                        <div class="alert alert-success rounded-0 text-center">
                            {{ session()->get('message') }}
                        </div>
                    @endif
                </div>

                <div class="card-body">
                    <form action="/users/{{$user->id}}/view" method="post">
                        @csrf
                        <div class="form-label">Leave Balances</div>
                        <div class="form-group">
                                @foreach($types as $type)
                                    <div class="form-group">
                                        <label for="{{ str_slug(strtolower($type->name)) }}">{{ $type->name }}</label>
                                        <input type="text" class="form-control" id="{{ str_slug(strtolower($type->name)) }}" name="{{ str_slug(strtolower($type->name)) }}"
                                               value="{{ old( str_slug(strtolower($type->name)), isset($values[str_slug(strtolower($type->name))]) ? $values[str_slug(strtolower($type->name))] : '0' ) }}"></td>
                                        @error( str_slug(strtolower($type->name)))
                                        <span class="text-danger" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>
                                @endforeach
                            <div class="card-footer text-right">
                                <button type="submit" class="btn btn-primary btn-block">Update</button>
                            </div>
                        </div>
                    </form>

                </div>

            </div>
        </div>
    </div>

@endsection

