@extends('layouts.main',['title'=>'','active'=>''])

@section('content')
    <div class="row">
        <div class="col-lg-12">
            @if(session()->has('message'))
                <div class="alert alert-success rounded-0 text-center">
                    {{ session()->get('message') }}
                </div>
            @endif
        </div>
        <div class="col-lg-12">
            <div class="card">
                <div class="table-responsive">
                    <table class="table table-hover table-outline table-vcenter -nowrap card-table">
                        <thead>
                        <tr>
                            <th class="">ID</th>
                            <th class="">Dates</th>
                            <th class="">Other Details</th>
                            <th class="">Requester</th>
                            <th class="">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($leaves as $leave)
                            <tr>
                                <td class="text-primary">#{{ $leave->id }}</td>
                                <td>
                                    <div>Start : {{ $leave->start_date->format('Y-m-d') }}</div>
                                    <div>End : {{ $leave->end_date->format('Y-m-d') }}</div>
                                    <div>Days : {{ $leave->days}}</div>
                                </td>
                                <td>
                                    <div>Type : {{ $leave->type->name }}</div>
                                    @if($leave->completed == false)
                                        <div>Status : <span class="tag tag-yellow">{{ $leave->status }}</span></div>
                                    @endif
                                    @if($leave->status == 'Authorized')
                                        <div>Status : <span class="tag tag-green">{{ $leave->status }}</span></div>
                                    @endif
                                    @if($leave->status == 'Rejected')
                                        <div>Status : <span class="tag tag-red">{{ $leave->status }}</span></div>
                                    @endif
                                    @if($leave->document_name)
                                        <div><a target="_blank" href="/leaves/{{ $leave->id }}/download">Document : {{ $leave->document_name }}</a></div>
                                    @endif
                                    @if($leave->leave_notes)
                                        <div><span>Reasons For Rejection : {{\Illuminate\Support\Str::limit($leave->leave_notes , 20 , '...' ) }}</span></div>
                                    @endif
                                </td>
                                <td>
                                    <div>Name : {{ $leave->user->full_name }}</div>
                                    <div>Email : {{ $leave->user->email }}</div>
                                </td>
                                <td class="text">
                                    @can('view' , $leave)
                                        <div><a href="/leaves/{{ $leave->id }}/view">View</a></div>
                                    @endcan

                                    @can('authorize' , $leave)
                                        <div><a href="/leaves/{{ $leave->id }}/authorize">Authorize</a></div>
                                    @endcan
                                    @can('reject' , $leave)
                                        <div><a href="" data-toggle="modal" data-target="#myModal" >Reject</a></div>
                                        <div id="myModal" class="modal fade" role="dialog">
                                            <div class="modal-dialog">
                                                    <form action="/leaves/{{ $leave->id }}/reject" method="POST">
                                                        @csrf
                                                        <!-- Modal content-->
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <button type="button" class="close bg-red" data-dismiss="modal">&times;</button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="row">
                                                                    <div class="col-lg-12">
                                                                        <label for="">Leave Notes (Optional)</label>
                                                                        <input type="text" name="leave_notes" id="leave_notes" class="form-control">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button class="btn btn-outline-danger" type="submit"> Reject</button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                        </div>
                                    @endcan
                                    {{--@can('close' , $leave)
                                        <div><a href="/leaves/{{ $leave->id }}/close">Delete</a></div>
                                    @endcan--}}
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>

                    <div class="mt-3 d-flex justify-content-center align-items-center">
                        {{ $leaves->render() }}
                    </div>

                </div>
            </div>
        </div>
    </div>


@endsection
