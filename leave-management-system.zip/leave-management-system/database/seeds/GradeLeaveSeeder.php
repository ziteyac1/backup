<?php

use App\EmployeeGrade;
use App\GradeLeaveType;
use App\LeaveType;
use Illuminate\Database\Seeder;

class GradeLeaveSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $grades = EmployeeGrade::all();
        $leave_types = LeaveType::all();


        foreach ($grades as $grade)
        {
            if ($grade->compassionate_leave == false){
                $leave_types = LeaveType::query()->where('all_grades','=',true)->get();
            }

            if ($grade->compassionate_leave == true){
                $leave_types = LeaveType::all();
            }
            foreach ($leave_types as $leave_type){

                GradeLeaveType::query()->create([
                    'grade_name' => $grade->name,
                    'leave_type_id' => $leave_type->id
                ]);
            }

        }
    }
}
