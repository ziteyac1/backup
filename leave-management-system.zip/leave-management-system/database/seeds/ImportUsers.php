<?php

use App\LeaveBalance;
use App\LeaveType;
use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class ImportUsers extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        $users = file('data/import.csv');

        $grades_array = ['A3','B2','B3','B4','B5'];

        $leave_types = LeaveType::query()->where('all_grades','=',true)->where('main','=',false)->get();

        foreach ($users as $user){

            echo 'Importing '. $user;

            $data = explode(',' , $user);

            $email = strtolower(substr(trim($data[3]) , 0 , 1 )) . strtolower(trim($data[2])) . '@agribank.co.zw';

            if (!User::query()->where('email' , '=' , $email)->exists())
            {
                $user = User::query()->create([
                    'password' => Hash::make('password'),
                    'emp_num' => trim($data[1]),
                    'emp_grade'=>trim($data[0]),
                    'name' => ucwords(strtolower(trim($data[3]))),
                    'last_name' => ucwords(strtolower(trim($data[2]))),
                    'email' => $email,
                    'job_title' => ucwords(strtolower(trim($data[4]))),
                    'auth_to_hr' => 2,
                    'profile_completed' => false,
                ]);

                $type  = LeaveType::query()->where('main' , '=',true)->first();

                LeaveBalance::query()->create([
                    'user_id' => $user->id,
                    'type_id' => $type->id,
                    'balance' => (float)trim($data[7]),
                    'available_balance' => (float)trim($data[7]),
                    'visibility' => true
                ]);
                if (!in_array($user->emp_grade,$grades_array))
                {
                    LeaveBalance::query()->create([
                        'user_id' => $user->id,
                        'type_id' => 4,
                        'balance' => 6,
                        'available_balance' => 6,
                        'visibility' => true
                    ]);
                }
                foreach ($leave_types as $leave_type)
                {
                    LeaveBalance::query()->create([
                        'user_id' => $user->id,
                        'type_id' => $leave_type->id,
                        'available_balance' => $leave_type->max,
                        'balance' => $leave_type->max
                    ]);
                }
            }
        }

    }
}
