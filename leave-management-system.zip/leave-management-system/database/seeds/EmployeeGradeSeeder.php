<?php

use App\EmployeeGrade;
use App\Location;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Seeder;

class EmployeeGradeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $values = [
            [
                'name' => 'A3',
                'compassionate_leave' => false
            ],
            [
                'name' => 'B2',
                'compassionate_leave' => false
            ],
            [
                'name' => 'B3',
                'compassionate_leave' => false
            ],
            [
                'name' => 'B4',
                'compassionate_leave' => false
            ],
            [
                'name' => 'B5',
                'compassionate_leave' => false
            ],
            [
                'name' => 'C1',
                'compassionate_leave' => true
            ],
            [
                'name' => 'C2',
                'compassionate_leave' => true
            ],
            [
                'name' => 'C3',
                'compassionate_leave' => true
            ],
            [
                'name' => 'C4',
                'compassionate_leave' => true
            ],
            [
                'name' => 'C5',
                'compassionate_leave' => true
            ],
            [
                'name' => 'CW',
                'compassionate_leave' => true
            ],
            [
                'name' => 'D2',
                'compassionate_leave' => true
            ],
            [
                'name' => 'D3',
                'compassionate_leave' => true
            ],
            [
                'name' => 'D4',
                'compassionate_leave' => true
            ],
            [
                'name' => 'D5',
                'compassionate_leave' => true
            ]
        ];
        Model::unguard();

        foreach($values as $value)
        {
            EmployeeGrade::query()->create([
                'name' => $value['name'],
                'compassionate_leave' => $value['compassionate_leave'],
            ]);
        }
    }
}
