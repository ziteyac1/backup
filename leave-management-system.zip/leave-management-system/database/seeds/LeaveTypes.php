<?php

use App\LeaveType;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class LeaveTypes extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $values = [
            [
                'name'=>'Vacation Or Annual Leave',
                'max'=> 90,
                'document' => false,
                'male' => true,
                'female' => true,
                'main' => true,
                'deduct' => true,
                'all_grades' => true,
                'deduct_main' => true,
            ],
            [
                'name'=>'Cash In Lieu Leave',
                'max'=> 0,
                'document' => false,
                'male' => true,
                'female' => true,
                'main' => false,
                'deduct' => true,
                'all_grades' => true,
                'deduct_main' => true,
            ],
            [
                'name'=>'Un-Paid Leave',
                'max'=> 0,
                'document' => false,
                'male' => true,
                'female' => true,
                'main' => false,
                'deduct' => false,
                'all_grades' => true,
                'deduct_main' => false,
            ],
            [
                'name'=>'Occasional',
                'max'=> 6,
                'document' => false,
                'male' => true,
                'female' => true,
                'main' => false,
                'deduct' => true,
                'all_grades' => false,
                'deduct_main' => false,
            ],
            [
                'name'=>'Sick Leave',
                'max'=> 180,
                'document' => true,
                'male' => true,
                'female' => true,
                'main' => false,
                'deduct' => true,
                'all_grades' => true,
                'deduct_main' => false,
            ],
            [
                'name'=>'Maternity Leave',
                'max'=> 98,
                'document' => false,
                'male' => false,
                'female' => true,
                'main' => false,
                'deduct' => true,
                'all_grades' => true,
                'deduct_main' => false,
            ],
            [
                'name'=>'Study Leave',
                'max'=> 0,
                'document' => true,
                'male' => true,
                'female' => true,
                'main' => false,
                'deduct' => false,
                'all_grades' => true,
                'deduct_main' => false,
            ],
            [
                'name'=>'Special or Compassionate Leave',
                'max'=> 12,
                'document' => false,
                'male' => true,
                'female' => true,
                'main' => false,
                'deduct' => true,
                'all_grades' => true,
                'deduct_main' => false,
            ],

        ];

        Model::unguard();

        foreach($values as $value)
        {
            LeaveType::query()->create([
                'name' => ucwords($value['name']),
                'max' => $value['max'],
                'document' => $value['document'],
                'deduct_main' => $value['deduct_main'],
                'deduct' => $value['deduct'],
                'main' => $value['main'],
                'female' => $value['female'],
                'all_grades' => $value['all_grades'],
                'male' => $value['male'],
            ]);
        }

    }
}
