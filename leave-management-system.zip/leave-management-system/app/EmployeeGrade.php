<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeGrade extends Model
{
    protected $guarded = [];

}
