<?php

namespace App\Policies;

use App\Leave;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class LeavePolicy
{
    use HandlesAuthorization;

    public function view(User $user, Leave $leave)
    {

        if ($user->hasRole('human resources'))
        {
            return true;
        }

        return $user->id == $leave->user_id
            || $leave->supervisor_email === $user->email
            || $leave->timeline->contains('email' , '=' , $user->email);
    }

    public function authorize(User $user, Leave $leave)
    {
        return strtolower($leave->supervisor_email) == strtolower($user->email)
            && $user->id != $leave->user_id
            && !$leave->completed;
    }
    public function reject(User $user, Leave $leave)
    {
        return strtolower($leave->supervisor_email) == strtolower($user->email)
            && $user->id != $leave->user_id
            && !$leave->completed;
    }

    public function close(User $user, Leave $leave)
    {
        return !$leave->completed &&  ( $user->id == $leave->user_id);
    }

}


