<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

/**
 * @property mixed document
 * @property mixed id
 * @property mixed name
 */
class LeaveType extends Model
{
    protected $guarded = [];

    public function leave(){
        return $this->belongsTo(Leave::class,'leave_type_id','id');
    }
    public function users(){
        return $this->belongsToMany(User::class);
    }
    public function leave_types() : BelongsToMany {

        return $this->belongsToMany(GradeLeaveType::class ,
            'grade_leave_types' ,
            'grade_name' ,
            'leave_type_id',
            'id',
            'emp_grade'
        );
    }


}
