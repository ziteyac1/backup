<?php

namespace App\Http\Controllers;


use App\Leave;
use App\LeaveBalance;
use App\LeaveTimeline;
use App\LeaveType;
use App\Notifications\DefaultNotification;
use App\User;
use Illuminate\Contracts\View\Factory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\View\View;
use function auth;
use Carbon\Carbon;
use Illuminate\Http\Request;


class LeaveController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Factory|View
     */

    public function create()
    {
        $leave_types = LeaveType::all();
        $user = auth()->user();

        return view('leave.apply', [
            'user' => $user,
            'leave_types' => $leave_types,
        ]);
    }

    public function view(Leave $leave)
    {
        return view('leave.view', compact('leave'));
    }

    public function requests()
    {
        $leaves = Leave::query()
            ->where(function (Builder $builder) {
                $builder->orWhere('user_id', '=', auth()->user()->id);
                $builder->orWhere('supervisor_email', '=', auth()->user()->email);
                $builder->orWhereHas('timeline', function (Builder $b) {
                    $b->where('email', auth()->user()->email);
                });
            })
            ->latest()->paginate(20);

        return view('leave.list', compact('leaves'));

    }

    public function all()
    {

        $leaves = Leave::query()->latest()
            ->paginate(20);

        return view('leave.list', compact('leaves'));
    }


    public function store(Request $request)
    {
        /** @var User $user */
        $user = auth()->user();

        // check pending requests

        $this->validate($request, [
            'leave_type' => 'required|exists:leave_types,id',
            'start_date' => 'required',
            'end_date' => 'required|after_or_equal:start_date'
        ]);


        /** @var LeaveType $leave_type */
        $leave_type = LeaveType::query()->find($request->get('leave_type'));


        $days = $this->carbon($request->get('start_date'))->diffInDays($this->carbon($request->get('end_date'))) + 1;

        /** @var LeaveType $leave_type */
        $main = LeaveType::query()->where('main' , '=' , true)->first();


        if ($leave_type->deduct)
        {
            $balance = LeaveBalance::query()->where('user_id', '=', $user->id)
                ->where('type_id', $leave_type->id)->first();

            if ($leave_type->deduct_main)
            {

             $balance = LeaveBalance::query()->where('user_id', '=', $user->id)
                    ->where('type_id', $main->id)->first();
            }

            if ($days > $balance->available_balance) {
                return back()->with('message', 'You do not have enough Days, Cannot apply');
            }
        }

        $path = null;
        $name = null;

        if ($leave_type->document) {
            $this->validate($request, [
                'document_name' => 'required',
            ]);
            $name = $request->file('document_name')->getClientOriginalName();
            $path = $request->file('document_name')->store('documents');

        }

        $auth = $this->getUserByEmail(auth()->user()->supervisor_email);

        $leave = Leave::query()->create([
            'user_id' => $user->id,
            'supervisor_email' => $user->supervisor_email,
            'type_id' => $request->get('leave_type'),
            'start_date' => $this->carbon($request->get('start_date')),
            'end_date' => $this->carbon($request->get('end_date')),
            'document_path' => $path,
            'document_name' => $name,
            'status' => 'Pending Authorisation',
            'completed' => false
        ]);


        if ($leave_type->deduct)
        {

            LeaveBalance::query()
                ->where('user_id','=',$user->id)
                ->where('type_id','=',$leave->type_id)
                ->update([
                    'available_balance' => $balance->available_balance - $days
                ]);

            if ($leave_type->deduct_main)
            {
                LeaveBalance::query()
                    ->where('user_id','=',$user->id)
                    ->where(function (Builder $builder) use ($main , $leave) {
                        $builder->orWhere('type_id','=',$main->id);
                        $builder->orWhere('type_id','=',$leave->type_id);
                    })->update([
                        'available_balance' => $balance->available_balance - $days
                    ]);
            }
        }


        $message = 'Applied for leave';

        $this->create_timeline($leave,$message);

        /** @var User $user */
        $user = $this->getUserByEmail($user->supervisor_email);
        $user->notify(new DefaultNotification("Leave application with id #{$leave->id} was created, Kindly action"));

        return back()->with('message', 'Record added, Leave Application awaits authorisation by '. $user->full_name);

    }

    public function carbon($date)
    {
        if ($date === '' || empty($date)) {
            return null;
        }
        $date = explode("-", $date);
        return count($date) === 3 ? Carbon::createMidnightDate($date[0], $date[1], $date[2]) : now();

    }


    public function download(Leave $leave)
    {
        return response()->download((storage_path('/app/' . $leave->document_path)), $leave->document_name);
    }


    public function close(Leave $leave)
    {
        $leave_type = $leave->type;


        $actual_days = $leave->days;

        if ($leave_type->deduct)
        {
            $balance = LeaveBalance::query()->where('user_id', '=', $leave->user_id)
                ->where('type_id', $leave->type_id)->first();

            if ($leave_type->deduct_main)
            {
                /** @var LeaveType $leave_type */
                $main = LeaveType::query()->where('main' , '=' , true)->first();

                $balance = LeaveBalance::query()
                    ->where('user_id', '=', $leave->user->id)
                    ->where('type_id', $main->id)->first();
            }

            if ($balance) {
                $balance->update([
                    'available_balance' => $balance->available_balance + $actual_days
                ]);
            }
        }

        $leave->delete();

        return back()->with('message', 'Application was successfully Deleted');

    }
    public function reject(Leave $leave,Request $request)
    {

        $message = 'Rejected rejected leave application';

        $this->create_timeline($leave,$message);

        /*Leave::query()->where('id','=',$leave->id)->update([
            'completed' => true,
            'status' => 'Rejected',
            'leave_notes' => $request->leave_notes,
        ]);*/

        $leave->update([
            'completed' => true,
            'status' => 'Rejected',
            'leave_notes' => $request->leave_notes,
        ]);
        $leave_type = $leave->type;


        $actual_days = $leave->days;

        if ($leave_type->deduct)
        {
            $balance = LeaveBalance::query()->where('user_id', '=', $leave->user_id)
                ->where('type_id', $leave->type_id)->first();

            if ($leave_type->deduct_main)
            {
                /** @var LeaveType $leave_type */
                $main = LeaveType::query()->where('main' , '=' , true)->first();

                $balance = LeaveBalance::query()
                    ->where('user_id', '=', $leave->user->id)
                    ->where('type_id', $main->id)->first();
            }

            if ($balance) {

                $balance->update([
                    'available_balance' => $balance->available_balance + $actual_days
                ]);
            }
        }

        $closer = $this->getUserByEmail($leave->supervisor_email);

        $user = $this->getUserByEmail($leave->user->email);
        $user->notify(new DefaultNotification("Your leave application with id  #{$leave->id} , has been rejected by {$closer->full_name}"));

        return back()->with('message', 'Application Rejected');

    }

    public function authoriz(Leave $leave)
    {

        $auth = $this->getUserByEmail(auth()->user()->email);

        $leave->update([
            'auth_to_hr' => $leave->auth_to_hr + 1
        ]);


        if ($leave->auth_to_hr >= $leave->user->auth_to_hr) {

            $leave_type = $leave->type;

            if ($leave_type->deduct)
            {
                $balance = LeaveBalance::query()->where('user_id', '=', $leave->user_id)
                    ->where('type_id', $leave->type_id)->first();

                if ($leave_type->deduct_main)
                {
                    /** @var LeaveType $leave_type */
                    $main = LeaveType::query()->where('main' , '=' , true)->first();

                    $balance = LeaveBalance::query()
                        ->where('user_id', '=', $leave->user->id)
                        ->where('type_id', $main->id)->first();
                }

                $actual_days = $leave->days;

                if ($balance) {
                    $balance->update([
                        'balance' => $balance->balance - $actual_days
                    ]);
                }
            }

            $message = 'Authorized By ' . $auth->full_name;

            $this->create_timeline($leave,$message);

            /** @var User $user */
            $user = $this->getUserByEmail($leave->user->email);
            $user->notify(new DefaultNotification("Your leave application with id  #{$leave->id} , is now Authorised and completed"));

            $leave->update([
                'status' => 'Authorized',
                'completed' => true,
            ]);

            return back()->with('message', 'Application was successfully Authorized');

        }

        $nxt = $this->getUserByEmail(auth()->user()->supervisor_email);

        $leave->update([
            'supervisor_email' => $nxt->email
        ]);

        $message = 'Approved By ' . $auth->full_name. ' waiting for further approval from '.$nxt->full_name;

        $this->create_timeline($leave,$message);

        $user = $leave->user;
        $user->notify(new DefaultNotification("Your leave application with id  #{$leave->id} was Authorised by {$auth->full_name}, now awaits authorisation from {$nxt->full_name}"));

        $user = $this->getUserByEmail($leave->supervisor_email);
        $user->notify(new DefaultNotification("Leave application with id #{$leave->id} was authorized by {$auth->full_name} it now waits for further approval, Kindly action"));

        return back()->with('message', 'Application was successfully Authorized');

    }

    public function create_timeline($leave,$message){
        return LeaveTimeline::query()->create([
            'email' => auth()->user()->email,
            'leave_id' => $leave->id,
            'event' => $message,
        ]);
    }

    public function getUserByEmail($email)
    {
        return User::query()->where('email', $email)->first();
    }

}
