<?php

namespace App\Http\Controllers;

use App\LeaveBalance;
use Illuminate\Database\Eloquent\Builder;
use function alert;
use App\Department;
use App\Events\UserCreated;
use App\Leave;
use App\LeaveType;
use App\Location;
use App\User;
use function auth;
use Carbon\Carbon;
use function dd;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;
use function view;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $colums = [
            'emp_num',
            'name',
            'last_name',
            'job_title',
            'address',
            'gender',
            'mobile_number',
            'office_number',
            'supervisor_email',
        ];

        $users = User::query();

        if ($request->get('search')){
            $users = $users->where(function (Builder $builder) use ($colums , $request){
                foreach ($colums as $colum)
                {
                    $builder->orWhere($colum , 'like' , "%{$request->get('search')}%");
                }
            });
        }

        $users = $users->paginate(20);

        return view('leave.users.index',compact(['users']));
    }

    public function view(User $user)
    {
        $balances = LeaveBalance::query()->where('user_id' , '=' , $user->id)->with('type')->get();
        $types = LeaveType::query()->where($user->gender == 'male' ? 'male' : 'female' , '=' , true)->where('main' , '=' , true)->get();

        $values = [];
        foreach ($balances as $balance ){
            $values[str_slug(strtolower($balance->type->name))] = $balance->balance;
        }

        return view('leave.users.edit' ,[
            'user' => $user,
            'balances' => $balances,
            'types' => $types,
            'values' => $values
        ]);

    }


    public function update(Request $request , User $user)
    {

        $required = [];
        $types = LeaveType::query()->where($user->gender == 'male' ? 'male' : 'female' , '=' , true)->where('main' , '=' , true)->get();

        foreach ($types as $type)
        {
            $required[str_slug(strtolower($type->name))] = [ 'numeric','min:0' ,'max:'.$type->max];
        }

        $request->validate($required);

        foreach ($types as $type)
        {
            LeaveBalance::query()->updateOrCreate([
                'user_id' => $user->id,
                'type_id' => $type->id,
            ],[
                'balance' => $request->get(str_slug(strtolower($type->name))),
                'available_balance' => $request->get(str_slug(strtolower($type->name)))
            ]);
        }

        return back()->with('message' , 'User was updated successfully');
    }

    public function profile(Request $request)
    {
        $this->validate($request,[
            'emp_num'=> ['required' , 'numeric'],
            'job_title'=> ['required'],
            'address'=> ['required'],
            'gender'=> ['required'],
            'mobile_number'=> ['required'],
            'office_number'=> ['required'],
            'supervisor_email'=> ['required' ,'exists:users,email'],
            'location'=> ['required'],
            'authorisations_to_hr'=> ['required','min:1'],
        ]);

        /** @var User $user */
        $user = auth()->user();

        $user->update([
            'emp_num' => $request->get('emp_num'),
            'job_title' => $request->get('job_title'),
            'address' => $request->get('address'),
            'gender' => $request->get('gender'),
            'mobile_number' => $request->get('mobile_number'),
            'office_number' => $request->get('office_number'),
            'supervisor_email' => $request->get('supervisor_email'),
            'location_id' => $request->get('location'),
            'profile_completed' => true,
            'auth_to_hr' => $request->get('authorisations_to_hr')
        ]);


        return back()->with('message' , 'Your Profile was updated successfully');
    }


}
