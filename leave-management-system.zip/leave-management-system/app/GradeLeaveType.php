<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GradeLeaveType extends Model
{
    protected $guarded = [];

    public function type(){
        return $this->hasOne(LeaveType::class, 'id','leave_type_id');
    }
}
