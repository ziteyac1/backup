<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LeaveTimeline extends Model
{
    protected $guarded = [];
}
