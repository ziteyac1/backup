$(function () {
    $('#datetimepicker1').datetimepicker({
        format: 'H:i:s'
    });
});
