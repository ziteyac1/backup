package com.company;

import com.sun.deploy.net.HttpRequest;
import com.sun.deploy.net.HttpResponse;
import com.sun.xml.internal.messaging.saaj.packaging.mime.MessagingException;
import sun.net.www.http.HttpClient;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.file.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {

    private static final String logFilename = "SuccessLog " + getDate();
    private static final String errorlog = "ErrorLog " + getDate();
    public static void main(String[] args) throws IOException, MessagingException {
        readDirectory();
    }
    public static void readDirectory() throws IOException, MessagingException {
        System.out.println("Reading from folder");
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();

        File file;
        file = new File("D:\\MESSAGES\\");
        File[] files = file.listFiles();

        assert files != null;
        System.out.println("Reading from folder: "+file.getPath());
        for (File f : files) {
            System.out.println(f.getName());
            BufferedReader bufferedReader = new BufferedReader(new FileReader(f.getAbsoluteFile()));

            String contents = bufferedReader.readLine();


            String[] entries = contents.split("/");
            try
            {

                String phone = entries[0];



                String message = "Valued Client, " + entries[2] + " of " + entries[10] + " " + entries[3] + " " + entries[6] + " has been processed on your account " + entries[5] + " . Available Balance is " + entries[9] + " " + entries[10] + ". For queries call 242772103";
                String my_email_message = "Valued Client, \n" + entries[2] + " of " + entries[10] + " " + entries[3] + " " + entries[6] + " has been processed on your account " + entries[5] + ". \nAvailable Balance is " + entries[9] + " " + entries[10] + ". \nFor queries call 242772103";


                String curr_url = "https://secure.zss.co.zw/vportal/cnm/vsms/plain?user=Agribank012&password=agri13&sender=Agribank&SMSText=" + message + "&GSM=" + entries[0];
                //backup URL for Afrosoft string postURL2 = "http://193.105.74.59/api/sendsms/plain?user=Agribank012&password=agri13&sender=Agribank&SMSText=" + message + "{}&GSM=" + entries[0] ;

                String sms_url = curr_url.replaceAll(" ","%20");

                URL url = new URL(sms_url);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("GET");
                con.setRequestProperty("User-Agent","Mozilla/5.0");



                System.out.println(message);

                appendlogFile("Payment with details :" + message + " : has been processed : response code" + con.getResponseCode() + " " + entries[0] + " " + f.getName()+"\n");


            }
            catch (Exception e)
            {
                System.out.println("Got an error : " + e);
                appendErrorlogFile("Got an error : " + e+"\n");

            }
            bufferedReader.close();
            Files.delete(Paths.get(f.getAbsolutePath()));
        }
    }


    private static void appendlogFile(String log){
        try {
            File myObj = new File("D:\\SMS\\logs\\" + logFilename + ".txt");
            if (myObj.exists()) {
                BufferedWriter out = new BufferedWriter(
                        new FileWriter(myObj, true));
                out.write(log);
                out.close();
            }
            else {
                if (myObj.createNewFile())
                {
                    BufferedWriter out = new BufferedWriter(
                            new FileWriter(myObj, true));
                    out.write(log);
                    out.close();
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
    private static void appendErrorlogFile(String log){
        try {
            File myObj = new File("D:\\SMS\\logs\\" + errorlog + ".txt");
            if (myObj.exists()) {
                BufferedWriter out = new BufferedWriter(
                        new FileWriter(myObj, true));
                out.write(log);
                out.close();
            }
            else {
                if (myObj.createNewFile())
                {
                    BufferedWriter out = new BufferedWriter(
                            new FileWriter(myObj, true));
                    out.write(log);
                    out.close();
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }


    public static String getDate()
    {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();

        return dateFormat.format(date);
    }
}
