<?php


namespace App\Core;


use App\Transaction;
use App\Transactions\Core\TransactionContract;
use Illuminate\Contracts\Container\BindingResolutionException;
use Ramsey\Uuid\Uuid;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

trait HasTransactionServiceFunctions
{

    /**
     * @param $transaction
     * @return TransactionContract
     * @throws BindingResolutionException
     */
    public function instantiateService($transaction)
    {
        return app()->make(config('system.services')[$transaction->transaction_type]);
    }

    /**
     * @param Transaction $transaction
     * @return string[]
     */
    public function generateTransactionQr(Transaction $transaction): array
    {
        $code = Uuid::uuid1() . '-' . Uuid::uuid4() . '-' . $transaction->id;
        $path = '/storage/transactions/' . $transaction->id . '-' . Uuid::uuid1() . '.png';
        $full = public_path($path);

        /** @noinspection PhpUndefinedMethodInspection */
        QrCode::format('png')
            ->size(800)
            ->generate( config('system.url').'/transaction/verify?code=' . $code , $full);
        return array($code, $path);
    }
}
