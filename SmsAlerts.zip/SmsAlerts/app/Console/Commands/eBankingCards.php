<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class eBankingCards extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cards:create';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $cards = file('data/50,000 card files for 31.07.2020 - correct - eBanking Format.txt');

        $chunk = array_chunk($cards,1000);

        foreach ($chunk as $data) {

            $num = array_keys($chunk,$data);

            $file_num = $num[0] + 1;

            $output = fopen("out/cards/cards - ".$file_num.".txt" , "w+");

            foreach ($data as $item)
            {
                $temp = $item;

                $line = explode(",", $item);

                $exp = " 12/25 ";

                $pan = chunk_split($line[0],4," ");

                $new_pan = substr_replace($pan,"",-1);

                $last = substr_replace($line[1],"20",-2)."?";
                ////{$new_pan}|{$exp}|;{$last}
                fwrite($output,"{$new_pan}|{$exp}|;{$last}".PHP_EOL);

            }

            fclose($output);
        }
    }
}
