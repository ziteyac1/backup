<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class doc_compare extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'docs:compare';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {


        $master = file('upload_files/ACCTS.csv');

        $masterData = [];

        foreach ($master as $line){

            $line = explode("," , $line);

            $masterData[$line[10]] = [
                1 => $line[0],
                2 => $line[1],
                3 => $line[5],
                4 => $line[7],
            ];
        }


        $sub = file('upload_files/Boka_accounts.csv');

        $output = fopen("output_accounts.csv" , "w+");

        foreach ($sub as $line){

            $temp = $line;
            $line = explode("," , $line);

            if (isset($masterData[$line[4]]))
            {
                fwrite($output , "{$masterData[$line[4]][1]},{$masterData[$line[4]][2]},{$masterData[$line[4]][3]},{$masterData[$line[4]][4]},".$temp.PHP_EOL);
            }

        }

        fclose($output);
    }
}
