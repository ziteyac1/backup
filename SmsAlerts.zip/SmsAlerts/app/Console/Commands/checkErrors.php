<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class checkErrors extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'check:error';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $file = file('out/');
        $output = fopen("out/","w+");
        fwrite($output,"CustomerID,Name,Cell Number,Response".PHP_EOL);
        foreach ($file as $key => $item) {
            $data = explode(',', trim($item));
            $word = "Error";
            $mystring = $data[3];

            if(strpos($mystring, $word) !== false){
                fwrite($output,"{$data[0]},{$data[1]},{$data[2]},{$data[3]}".PHP_EOL);
            }
        }
        fclose($output);
    }
}
