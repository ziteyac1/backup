<?php

namespace App\Console\Commands;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use Illuminate\Console\Command;
use League\CommonMark\Util\Xml;
use SimpleXMLElement;

class sendAlert extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'alert:sms';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */

    public function handle()
    {
        $file = file('data/');

        $state[1] = "Message Sent";
        $state[2] = "Failed";
        $state[-4] = "";

        $output = fopen("out/","w+");
        fwrite($output,"CustomerID,Name,Cell Number,Response".PHP_EOL);
        foreach ($file as $key => $item)
        {
            $data = explode(',' , trim($item));

            try {

                echo  "[". count($file) ." - " .  $key . "]"  .$item;
                $new_line =  "[". count($file) ." - " .  $key . "]"  .$item;
                $message = "Dear {$data[2]},your ZWL account {$data[1]} under COTTCO has been successfully opened. For queries call 08677202202";
                $link = "https://secure.zss.co.zw/vportal/cnm/vsms/plain?user=Agribank012&password=agri13&sender=Agribank&SMSText={$message}&GSM={$data[3]}";
                //$link = "http://193.105.74.59/api/sendsms/plain?user=Agribank012&password=agri13&sender=Agribank&SMSText={$message}&GSM={$data[3]}";
                $client = new Client();
                $result  = $client->request('GET', $link);

                echo $result->getBody().PHP_EOL;

                $xml = new SimpleXMLElement($result->getBody());
                $word = "Error";
                $mystring = $xml->result;

                if(strpos($mystring, $word) !== false){
                    fwrite($output,"{$data[0]},{$data[1]},{$data[2]},{$xml->result}".PHP_EOL);
                }
                //fwrite($output,"{$data[0]},{$data[2]},{$data[3]},{$xml->result}".PHP_EOL);

            } catch (\Exception $exception) {
                echo $exception->getMessage().PHP_EOL;
            } catch (GuzzleException $e) {

            }
        }
        fclose($output);
    }
}
