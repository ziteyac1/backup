<?php

namespace App\Http\Controllers;

use App\SmsAlert;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use Illuminate\Http\Request;
use SimpleXMLElement;
use Symfony\Component\VarDumper\Dumper\DataDumperInterface;

class ActivityController extends Controller
{
    public function sendSmsIndex()
    {
        return view();
    }
    public function smsFileValidation(Request $request)
    {
        $request->validate([
            'file' => 'required',
        ]);

        $contents = file($request->file);

        $response = '';

        $output = fopen(public_path('/storage/output/'.$request->file('file')->getClientOriginalName()) , 'w+');

        foreach ($contents as $key => $item)
        {
            $data = explode(',' , trim($item));

            if(substr( $data[3], 0, 3 ) === "263" && strlen($data[3]) === 12)
            {
                $message = "Dear {$data[2]},your ZWL account {$data[1]} under COTTCO has been successfully opened. For queries call 08677202202";
                $link = "https://secure.zss.co.zw/vportal/cnm/vsms/plain?user=Agribank012&password=agri13&sender=Agribank&SMSText={$message}&GSM={$data[3]}";

                SmsAlert::query()->create([
                    'customer_id'=>$data[0],
                    'account_id'=>$data[1],
                    'customer_name'=>$data[2],
                    'phone_number'=>$data[3],
                    'file_name'=>$request->file('file')->getClientOriginalName(),
                    'link'=>$link,
                ]);

                $response = 'Phone Number Okay';

            }
            else
            {
                $response = 'Error with Phone Number Message Won\'t be sent';
            }


            fwrite($output,"{$data[0]},{$data[1]},{$data[2]},{$data[3]},{$response}".PHP_EOL);


        }

        fclose($output);

        $contents = file(public_path('/storage/output/'.$request->file('file')->getClientOriginalName()));

        return api()->data('contents', $contents)->build();
    }

    public function sendSMS($contents,$request)
    {
        try {
            $output = fopen(public_path('/storage/output/'.$request->file('file')->getClientOriginalName()) , 'w+');
            fwrite($output,"CustomerID,Name,Cell Number,Response".PHP_EOL);
            foreach ($contents as $key => $item) {

                $data = explode(',' , trim($item));

                $message = "Dear {$data[2]},your ZWL account {$data[1]} under COTTCO has been successfully opened. For queries call 08677202202";
                $link = "https://secure.zss.co.zw/vportal/cnm/vsms/plain?user=Agribank012&password=agri13&sender=Agribank&SMSText={$message}&GSM={$data[3]}";
                //$link = "http://193.105.74.59/api/sendsms/plain?user=Agribank012&password=agri13&sender=Agribank&SMSText={$message}&GSM={$data[3]}";
                $client = new Client();
                $result = $client->request('GET', $link);

                $xml = new SimpleXMLElement($result->getBody());

                fwrite($output,"{$data[0]},{$data[2]},{$data[3]},{$xml->result}".PHP_EOL);
            }

            fclose($output);
        } catch (\Exception $exception) {
            echo $exception->getMessage().PHP_EOL;
        } catch (GuzzleException $e) {

        }


    }
    public function cardProductionIndex()
    {
        return view();
    }
}
