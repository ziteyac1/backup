<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Agribank POS Reports Portal </title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="shortcut icon" href="images/logo_YDo_icon.ico">
    <link href="/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="/assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <link href="/assets/css/app.css" rel="stylesheet" type="text/css" />
    <link href="/css/app.css" rel="stylesheet" type="text/css" />
</head>
<body data-leftbar-theme="light">
<div id="app" class="wrapper">
    <div class="left-side-menu">
        <div class="h-100"  data-simplebar>
            <router-link to="/" class="logo text-center">
                <span class="logo-lg">
                    <img src="/assets/images/logo.jpeg" alt="" height="43" id="side-main-logo">
                </span>
            </router-link>
            <ul class="metismenu side-nav">
                <li class="side-nav-title side-nav-item">Navigation</li>
                <li class="side-nav-item">
                    <router-link to="/" class="side-nav-link">
                        <i class="uil-home-alt"></i>
                        <span> Dashboard </span>
                    </router-link>
                </li>
                <li class="side-nav-title side-nav-item">Activities</li>
                <li class="side-nav-item">
                    <router-link to="/sendsms/alerts" class="side-nav-link">
                        <i class="uil-comment-alt-message"></i>
                        <span> Send SMS Alerts </span>
                    </router-link>
                </li>
                <li class="side-nav-item">
                    <router-link to="/agency/cardfiles" class="side-nav-link">
                        <i class="uil-card-atm"></i>
                        <span> Card Production </span>
                    </router-link>
                </li>
                <li class="side-nav-item">
                    <router-link to="/batch/comparisons" class="side-nav-link">
                        <i class="uil-file-info-alt"></i>
                        <span> File Comparisons </span>
                    </router-link>
                </li>
            </ul>
        </div>
    </div>
    <div class="content-page">
        <div class="content">
            <div class="container-fluid">
                <keep-alive>
                    <transition name="slide-in-left">
                        <router-view></router-view>
                    </transition>
                </keep-alive>
            </div>
        </div>
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6">
                        @ <?php echo e(now()->format('Y')); ?> Humble Projects Sales Administration
                    </div>
                </div>
            </div>
        </footer>
    </div>
</div>
<script src="/assets/js/vendor.min.js"></script>
<script src="/assets/js/app.min.js"></script>
<script src="/js/app.js"></script>
</body>

<?php /**PATH C:\Users\zuvarashe\PhpstormProjects\SmsAlerts\resources\views/welcome.blade.php ENDPATH**/ ?>