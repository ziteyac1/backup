<template>

    <div class="dimmer active">
        <div class="loader"></div>
        <div class="dimmer-content">
            <div style="min-height: 60vh;" class="row pt-4">
                <div class="col-lg-12">
                </div>
            </div>
        </div>
    </div>

</template>

<script>
    export default {
        name: "loading"
    }
</script>

<style scoped>

</style>
