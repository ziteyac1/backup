<template>
    <div class="py-3">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-3">
                                <span>
                                    Select File For Upload
                                </span>
                            </div>
                            <div class="col-5">
                                <input type="file" id="file" @change="fileChange" ref="file" :class="[ 'form-control-file border p-1 rounded mw-400' , form.errors.get('file') ? 'is-invalid' : '' ]">
                                <div v-text="form.errors.get('file')" class="invalid-feedback"/>
                            </div>
                            <div class="col-2">
                                <button type="submit" @click.prevent="submit" :class="['btn btn-primary' , form.loading ? 'btn-loading' : '']">
                                    <i class="mdi mdi-lightbulb-outline mr-1"></i> Validate
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header text-center">
                        <h6>Original File Data</h6>
                    </div>
                    <div class="card-body" style="max-height: 750px;overflow-y: scroll">
                       <pre id="output"></pre>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header text-center">
                        <h6> Validated Output </h6>
                    </div>
                    <div class="card-body" style="max-height: 750px;overflow-y: scroll">
                       <!--<pre id="voutput"></pre>-->
                        <p>Results</p>
                        <br />
                        <div id="results" style="border:1px solid #000; padding:10px; width:300px; height:250px; overflow:auto; background:#eee;"></div>
                        <br />

                        <progress id='progressor' value="0" max='100' style=""></progress>
                        <span id="percentage" style="text-align:right; display:block; margin-top:5px;">0</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import Form from "../../core/forms/form";
    let fr = new FileReader();
    export default {
        data()
        {
            return {
                loading : true,
                form : new Form({
                    file : '',
                })
            }
        },
        methods : {
            init()
            {
                document.getElementById('file').addEventListener('change', function() {

                    fr.onload=function(){
                        document.getElementById('output').textContent = fr.result.toString();
                    }
                    fr.readAsText(this.files[0]);
                })
            },
            fileChange : function ()
            {
                this.form.file = this.$refs.file.files[0];
            },
            submit(){
                this.form.upload('/smsalerts/validate').then((response) => {
                    if (response.data.success === true){
                        window.alerts.success(response).then((response) => {
                            document.getElementById('voutput').textContent = response.data.body.contents;
                        });
                    } else {
                        window.alerts.error(response).then((response) => {
                            document.getElementById('voutput').textContent = response.data.body.contents;
                        });
                    }
                }).catch((error) => {
                });
            },
            startTask() {
                let es = new EventSource('/smsalerts/validate');

                //a message is received
                es.addEventListener('message', function(e) {
                    let result = JSON.parse( e.data );

                    addLog(result.message);

                    if(e.lastEventId === 'CLOSE') {
                        addLog('Received CLOSE closing');
                        es.close();
                        let pBar = document.getElementById('progressor');
                        pBar.value = pBar.max; //max out the progress bar
                    }
                    else {
                        let pBar = document.getElementById('progressor');
                        pBar.value = result.progress;
                        let perc = document.getElementById('percentage');
                        perc.innerHTML   = result.progress  + "%";
                        perc.style.width = (Math.floor(pBar.clientWidth * (result.progress/100)) + 15) + 'px';
                    }
                });

                es.addEventListener('error', function(e) {
                    addLog('Error occurred');
                    es.close();
                });
            }
        },
        mounted() {
            this.init();
        }
    }
</script>
<style scoped>

</style>
