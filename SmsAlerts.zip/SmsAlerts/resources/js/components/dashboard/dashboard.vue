<template>
    <div class="py-3">
        <div class="row">
            <div class="col-lg-12">
                <div class="row mb-5">
                    <div class="text-center col-12">
                        <span style="font-size: 50px">QUICK WIN ACTIVITIES</span>
                    </div>
                </div>
                <div class="row mt-5">
                    <div class="col-4">
                    <router-link to="/sendsms/alerts" class="side-nav-link">
                            <div style="min-height: 135px" class="card cta-box bg-primary text-white">
                                <div class="card-body">
                                    <div class="media align-items-center">
                                        <div class="media-body">
                                            <h3 class="m-0 font-weight-normal cta-box-title">SMS Quick Alerts</h3>
                                        </div>
                                        <img class="ml-3" src="/assets/images/email-campaign.svg" width="120" alt="Generic placeholder image">
                                    </div>
                                </div>
                            </div>
                    </router-link>
                    </div>
                    <div class="col-4">
                    <router-link to="/agency/cardfiles" class="side-nav-link">
                            <div style="min-height: 135px" class="card cta-box bg-primary text-white">
                                <div class="card-body">
                                    <div class="media align-items-center">
                                        <div class="media-body">
                                            <h3 class="m-0 font-weight-normal cta-box-title">Agency Banking Card Production</h3>
                                        </div>
                                        <img class="ml-3" src="/assets/images/email-campaign.svg" width="120" alt="Generic placeholder image">
                                    </div>
                                </div>
                            </div>
                    </router-link>
                    </div>
                    <div class="col-4">
                    <router-link to="/batch/comparisons" class="side-nav-link">
                            <div style="min-height: 135px" class="card cta-box bg-primary text-white">
                                <div class="card-body">
                                    <div class="media align-items-center">
                                        <div class="media-body">
                                            <h3 class="m-0 font-weight-normal cta-box-title">File Comparisons</h3>
                                        </div>
                                        <img class="ml-3" src="/assets/images/email-campaign.svg" width="120" alt="Generic placeholder image">
                                    </div>
                                </div>
                            </div>
                    </router-link>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {

    }
</script>

<style scoped>

</style>
