import Vue from "vue";
import router from "./routes/core/engine";
import { Plugin } from 'vue-fragment';
Vue.use(Plugin);

require('./boot/axios');
require('./boot/alerts');
require('./boot/filters');
require('./boot/helpers');

window.Vue = new Vue({
    router : router,
    el: '#app',
    methods : {
        logout : function (){
            document.getElementById('logout-form').submit();
        }
    }
});
