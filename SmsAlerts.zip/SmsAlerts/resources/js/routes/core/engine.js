import VueRouter from "vue-router";
import Vue from "vue";

Vue.use(VueRouter);

let routes = [];


import dash from "../dash";
routes = routes.concat(dash);

const router = new VueRouter({
    routes :  routes
});

router.beforeEach((to, from, next) => {
    window.scrollTo( 0 , 0 );
    next();
});

export default router;
