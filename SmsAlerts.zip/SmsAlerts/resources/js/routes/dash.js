import loading from "../components/async/loading";
import error from "../components/async/error";

const Index = () => ({
    component : import(/* webpackChunkName : "dash" */ "../components/dashboard/dashboard"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});
const SMSIndex = () => ({
    component : import(/* webpackChunkName : "dash" */ "../components/smsalerts/index"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});
const CardsIndex = () => ({
    component : import(/* webpackChunkName : "dash" */ "../components/cards/index"),
    loading : loading,
    error : error,
    delay : 1,
    timeout : 9999999
});

const routes = [
    {
        path : '/',
        component : Index
    },
    {
        path : '/sendsms/alerts',
        component : SMSIndex
    },
    {
        path : '/agency/cardfiles',
        component : CardsIndex
    },
];
export default routes;
