<template>
    <div class="container-fluid">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. A
        ab, culpa cumque deserunt dolor doloribus eius in ipsum magni
        nemo odio quam qui similique sit vel. Iusto, repudiandae, sit. Deserunt.
    </div>
</template>

<script>
    export default {
        name: "MainView"
    }
</script>

<style scoped>

</style>
