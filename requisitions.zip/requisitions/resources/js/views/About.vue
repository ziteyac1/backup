<template>
    <p>About Us</p>
</template>

<script>

    export default {
        name : 'About'
    }
</script>
