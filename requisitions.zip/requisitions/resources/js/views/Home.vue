<template>
    <div>
        Home View
    </div>

</template>
<script>

    export default {
        name : 'Home'
    }
</script>
