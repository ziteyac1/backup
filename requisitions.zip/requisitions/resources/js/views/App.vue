<template>
    <div>

    </div>
</template>
<script>
    import MainView from "./MainView";
    export default {
        components: {MainView}
    }
</script>
