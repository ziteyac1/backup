@extends('home')

@section('styling')



    @endsection

@section('content')
    <hr>
<button class="btn btn-primary">Crate Assets Personell Account</button>


@endsection

@section('scripts')

    @endsection
