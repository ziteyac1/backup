
#Todo
##Tabbed interface on manage <br>
* Pending
* Collection
* Collected
* Not Available
* Declined

##Tabbed interface Home
* Pending
* Collection
* Collected
* Declined

##Tabbed interface Supervisor
* Pending
* Approved
* Declined

##Search For all the above
* i.e > 10 searches

##Collection App
* Generate QR codes on the website
* Display Codes
* Scan code & record in collected

##Make it realtime
* i.e Auto refresh

##User Roles
* Only assets personell...

##Logs
* Approved, declined, collected, not available actions

##Notifications for users
* Approved by supervisor
* Declined
* Ready for collection
* Not Available

#
#
#Todo
* QR Code use ID
* QR Code Verification
#
#Todo
* Notifications
* UI
* Search
* Logs
* Notifications
