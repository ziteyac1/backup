#Option 1
##Assets section.
###Assets Personell create an account inside the procurement system
Once you have an account, you can see the assets management menu.
#
#Option 2
Location?  No.

